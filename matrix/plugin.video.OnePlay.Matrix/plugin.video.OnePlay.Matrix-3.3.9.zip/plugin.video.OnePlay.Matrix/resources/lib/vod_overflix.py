# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Resolver VOD isolado para a origem Overflix.

A origem não usa manifest.json/Stremio. O fluxo é:
  busca do título -> item exato -> playerData -> host suportado -> URL de mídia.

Contratos conservadores:
* filme: título + ano quando o ano está disponível;
* série: título + temporada/episódio;
* hosts intermediários aceitos: Dood, Streamtape e Mixdrop;
* áudio dublado tem preferência sobre legendado, como na origem;
* somente uma URL final é publicada por consulta para limitar latência;
* orçamento total curto por resolução; sem retry automático em cascata;
* falha/cooldown nunca afeta os demais providers do ONEPLAY;
* reprodução, relay, Range, legendas e Stop continuam no pipeline homologado.
"""

import html
import random
import re
import string
import time
import unicodedata
try:
    from html.parser import HTMLParser
except ImportError:  # pragma: no cover
    from HTMLParser import HTMLParser
try:
    from urllib.parse import urljoin, urlparse
except ImportError:  # pragma: no cover
    from urlparse import urljoin, urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None


SITE_URL = 'https://www.overflixtv.surf'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/126.0.0.0 Safari/537.36'
)
BASE_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept': 'application/json, text/plain, */*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
}
SEARCH_SCORE_MIN = 60.0
MOVIE_BUDGET_SECONDS = 7.0
SERIES_BUDGET_SECONDS = 8.5
CONNECT_TIMEOUT = 1.8
READ_TIMEOUT = 3.6
NETWORK_COOLDOWN_SECONDS = 30
SERVER_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60

_PRIORITY = ('dood', 'streamtape', 'mixdrop')
_DOOD_HINTS = (
    'dood', 'ds2play', 'ds2video', 'vidply', 'all3do', 'do7go', 'doodcdn',
    'doply', 'vide0', 'vvide0', 'd-s.io', 'dsvplay', 'myvidplay', 'playmogo',
)
_STREAMTAPE_HINTS = (
    'streamtape', 'strtape', 'strcloud', 'strtpe', 'scloud', 'stape',
    'shavetape', 'adblocktape', 'antiadtape', 'tapeblocker', 'streamnoads',
    'tapeadvertisement', 'tapeadsenjoyer', 'watchadsontape', 'tpead', 'advertape',
)
_MIXDROP_HINTS = ('mixdrop', 'mixdrp', 'mxdrop', 'm1xdrop', 'miixdrop')


def _safe_text(value):
    try:
        return str(value or '').strip()
    except Exception:
        return ''


def _plain_title(value):
    text = _safe_text(value)
    text = re.sub(r'\s*[\[(]\d{4}[\])]\s*$', '', text)
    text = unicodedata.normalize('NFKD', text)
    text = ''.join(ch for ch in text if not unicodedata.combining(ch))
    text = text.lower().replace(':', ' ')
    text = re.sub(r'[^a-z0-9]+', ' ', text)
    return re.sub(r'\s+', ' ', text).strip()


def _similarity(left, right):
    # Implementação local simples para não adicionar dependências ao addon.
    import difflib
    return difflib.SequenceMatcher(None, _plain_title(left), _plain_title(right)).ratio() * 100.0


def _four_digit_year(value):
    match = re.search(r'(?<!\d)(19\d{2}|20\d{2}|21\d{2})(?!\d)', _safe_text(value))
    return match.group(1) if match else ''


class _SearchHTMLParser(HTMLParser):
    def __init__(self, site_url, expected_type=''):
        HTMLParser.__init__(self)
        self.site_url = site_url
        self.expected_type = expected_type if expected_type in ('movie', 'series') else ''
        self.results = []
        self.current = None
        self.capture = ''

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs or ())
        if tag.lower() == 'a':
            href = _safe_text(attrs.get('href'))
            if re.search(r'(?:/(?:filmes|series)/online/|/assistir-).+-\d+/?(?:[?#].*)?$', href, re.I):
                low_href = href.lower()
                if '/filmes/' in low_href:
                    kind = 'movie'
                elif '/series/' in low_href:
                    kind = 'series'
                else:
                    kind = self.expected_type
                video_match = re.search(r'-(\d+)/?(?:[?#].*)?$', href)
                self.current = {
                    'url': urljoin(self.site_url + '/', html.unescape(href)),
                    'title': '', 'year': '', 'type': kind,
                    'video_id': video_match.group(1) if video_match else '',
                    'all_text': [],
                }
        if self.current is not None and tag.lower() in ('h3', 'p'):
            self.capture = tag.lower()

    def handle_endtag(self, tag):
        tag = tag.lower()
        if tag in ('h3', 'p'):
            self.capture = ''
        if tag == 'a' and self.current is not None:
            self.current['title'] = re.sub(r'\s+', ' ', self.current['title']).strip()
            self.current['year'] = _four_digit_year(self.current['year'])
            self.current['all_text'] = re.sub(r'\s+', ' ', ' '.join(self.current['all_text'])).strip()
            if self.current['url'] and self.current['title']:
                self.results.append(self.current)
            self.current = None
            self.capture = ''

    def handle_data(self, data):
        if self.current is None:
            return
        text = re.sub(r'\s+', ' ', _safe_text(data))
        if not text:
            return
        self.current['all_text'].append(text)
        if self.capture == 'h3':
            self.current['title'] += (' ' if self.current['title'] else '') + text
        elif self.capture == 'p':
            self.current['year'] += (' ' if self.current['year'] else '') + text


class _VideoIdParser(HTMLParser):
    def __init__(self):
        HTMLParser.__init__(self)
        self.video_id = ''

    def handle_starttag(self, tag, attrs):
        if self.video_id or tag.lower() != 'div':
            return
        attrs = dict(attrs or ())
        if _safe_text(attrs.get('id')).lower() == 'view':
            value = _safe_text(attrs.get('data-video-id'))
            if value.isdigit():
                self.video_id = value


class OverflixProvider(object):
    def __init__(self, requests_module=None, cache_api=None, logger=None, clock=None,
                 monotonic=None, site_url=SITE_URL):
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.monotonic = monotonic or time.monotonic
        self.site_url = _safe_text(site_url).rstrip('/') or SITE_URL
        self.health_namespace = 'vod_overflix_provider_health_v1'
        self.session = None
        if self.requests is not None:
            try:
                self.session = self.requests.Session()
                self.session.headers.update(BASE_HEADERS)
                self.session.headers['Referer'] = self.site_url + '/'
            except Exception:
                self.session = None

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(self.health_namespace, 'cooldown')
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return _safe_text(value.get('reason')) or 'cooldown'
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                self.health_namespace, 'cooldown',
                {'reason': _safe_text(reason) or 'provider-indisponivel'},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    def _request_timeout(self, deadline):
        remaining = float(deadline - self.monotonic())
        if remaining <= 0.20:
            raise TimeoutError('budget-esgotado')
        connect = min(CONNECT_TIMEOUT, max(0.20, remaining))
        read = min(READ_TIMEOUT, max(0.20, remaining))
        return (connect, read)

    def _get(self, url, deadline, headers=None, allow_redirects=True, stream=False):
        if self.session is None:
            raise RuntimeError('cliente-http-indisponivel')
        merged = dict(BASE_HEADERS)
        if headers:
            merged.update(headers)
        response = self.session.get(
            url, headers=merged, timeout=self._request_timeout(deadline),
            allow_redirects=allow_redirects, stream=stream
        )
        status = int(getattr(response, 'status_code', 0) or 0)
        if status == 429:
            self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
        elif status >= 500 or status <= 0:
            self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
        return response

    def _update_site_url(self, response):
        try:
            parsed = urlparse(_safe_text(getattr(response, 'url', '')))
            if parsed.scheme in ('http', 'https') and parsed.netloc:
                self.site_url = '{}://{}'.format(parsed.scheme, parsed.netloc).rstrip('/')
                if self.session is not None:
                    self.session.headers['Referer'] = self.site_url + '/'
        except Exception:
            pass

    def _follow_json_redirect(self, response, deadline):
        try:
            data = response.json()
        except Exception:
            return response
        if not isinstance(data, dict) or not data.get('redirect'):
            return response
        redirect_url = urljoin(self.site_url + '/', _safe_text(data.get('redirect')))
        try:
            response.close()
        except Exception:
            pass
        return self._get(
            redirect_url, deadline,
            headers={'Referer': self.site_url + '/', 'X-Requested-With': 'XMLHttpRequest'}
        )

    def _search(self, title, media_type, year, deadline):
        content_type = 'filmes' if media_type == 'movie' else 'series'
        for requested_type in (content_type, 'todos'):
            params = {
                'app': 'videobox', 'module': 'video', 'controller': 'index',
                'do': 'buscarContent', 'q': title, 'type': requested_type,
                'genre': '', 'year': year if media_type == 'movie' else '', 'page': 1,
            }
            # urlencode local sem manter uma dependência adicional no objeto.
            try:
                from urllib.parse import urlencode
            except ImportError:  # pragma: no cover
                from urllib import urlencode
            url = '{}/index.php?{}'.format(self.site_url, urlencode(params))
            response = self._get(
                url, deadline,
                headers={
                    'Referer': self.site_url + '/',
                    'X-Requested-With': 'XMLHttpRequest',
                    'Accept': 'application/json, text/plain, */*',
                }
            )
            try:
                if int(getattr(response, 'status_code', 0) or 0) != 200:
                    continue
                response = self._follow_json_redirect(response, deadline)
                if int(getattr(response, 'status_code', 0) or 0) != 200:
                    continue
                self._update_site_url(response)
                payload = response.json()
                html_content = payload.get('html', '') if isinstance(payload, dict) else ''
                if not html_content:
                    continue
                parser = _SearchHTMLParser(self.site_url, expected_type=media_type)
                parser.feed(html_content)
                expected = [r for r in parser.results if r.get('type') == media_type]
                if expected:
                    return expected
            finally:
                try:
                    response.close()
                except Exception:
                    pass
        return []

    def _best_match(self, results, title, media_type, year):
        wanted_year = _four_digit_year(year)
        best = None
        best_score = 0.0
        for result in results:
            if result.get('type') != media_type:
                continue
            found_year = _four_digit_year(result.get('year')) or _four_digit_year(result.get('all_text'))
            if media_type == 'movie' and wanted_year and found_year and wanted_year != found_year:
                continue
            score = _similarity(title, result.get('title'))
            # Ano ausente no resultado não bloqueia; ano conflitante bloqueia acima.
            if score >= SEARCH_SCORE_MIN and score > best_score:
                best_score = score
                best = result
        return best, best_score

    def _video_id_from_page(self, url, deadline):
        response = self._get(url, deadline, headers={'Referer': self.site_url + '/'})
        try:
            if int(getattr(response, 'status_code', 0) or 0) != 200:
                return ''
            parser = _VideoIdParser()
            parser.feed(_safe_text(response.text))
            return parser.video_id
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _episode_video_id(self, series_url, season, episode, deadline):
        response = self._get(series_url, deadline, headers={'Referer': self.site_url + '/'})
        try:
            if int(getattr(response, 'status_code', 0) or 0) != 200:
                return ''
            source = _safe_text(response.text)
            pattern = re.compile(
                r'''href=["']([^"']*{}x{}[^"']*-\d+/?)["']'''.format(
                    int(season), int(episode)
                ), re.I
            )
            match = pattern.search(source)
            if not match:
                return ''
            episode_url = urljoin(self.site_url + '/', html.unescape(match.group(1)))
        finally:
            try:
                response.close()
            except Exception:
                pass
        return self._video_id_from_page(episode_url, deadline)

    def _player_data(self, video_id, deadline):
        url = (
            '{}/index.php?app=videobox&module=video&controller=view&do=playerData&id={}'
            .format(self.site_url, video_id)
        )
        response = self._get(
            url, deadline,
            headers={'Referer': self.site_url + '/', 'X-Requested-With': 'XMLHttpRequest'}
        )
        try:
            if int(getattr(response, 'status_code', 0) or 0) != 200:
                return {}
            response = self._follow_json_redirect(response, deadline)
            if int(getattr(response, 'status_code', 0) or 0) != 200:
                return {}
            payload = response.json()
            return payload if isinstance(payload, dict) else {}
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _play_urls(self, player_data):
        players = player_data.get('players') if isinstance(player_data, dict) else None
        players_map = {}
        if isinstance(players, list):
            for item in players:
                if not isinstance(item, dict):
                    continue
                label = _safe_text(item.get('label')).lower()
                url = _safe_text(item.get('url'))
                if label and url:
                    players_map[label] = url
        rows = []
        for field, audio in (('servers_dub', 'dub'), ('servers_leg', 'leg')):
            raw = html.unescape(_safe_text(player_data.get(field))) if isinstance(player_data, dict) else ''
            for pair in raw.split('&'):
                if '=' not in pair:
                    continue
                server, media_id = pair.split('=', 1)
                server = _safe_text(server).lower()
                media_id = _safe_text(media_id)
                base_url = players_map.get(server)
                if not base_url or not media_id:
                    continue
                source_url = base_url.rstrip('/') + '/' + media_id
                rows.append({'url': source_url, 'audio': audio, 'server': server})
        return sorted(rows, key=lambda item: (
            0 if item.get('audio') == 'dub' else 1,
            self._server_priority(item.get('url')),
        ))

    @staticmethod
    def _server_priority(url):
        host = (urlparse(_safe_text(url)).netloc or '').lower()
        for index, key in enumerate(_PRIORITY):
            if key in host:
                return index
        return 99

    @staticmethod
    def _host_kind(url):
        host = (urlparse(_safe_text(url)).netloc or '').lower()
        if any(hint in host for hint in _DOOD_HINTS):
            return 'dood'
        if any(hint in host for hint in _STREAMTAPE_HINTS):
            return 'streamtape'
        if any(hint in host for hint in _MIXDROP_HINTS):
            return 'mixdrop'
        return ''

    @staticmethod
    def _infer_media_kind(url):
        probe = _safe_text(url).lower().split('?', 1)[0]
        if '.m3u8' in probe:
            return 'hls'
        if '.mpd' in probe:
            return 'dash'
        if any(probe.endswith(ext) or ext + '/' in probe for ext in (
            '.mp4', '.mkv', '.webm', '.avi', '.mov', '.m4v', '.ts'
        )):
            return 'progressive'
        return 'unknown'

    @staticmethod
    def _rand_ua():
        # Variação pequena, sem depender de estado global externo.
        return random.choice((
            USER_AGENT,
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:128.0) Gecko/20100101 Firefox/128.0',
            'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/126.0.0.0 Mobile Safari/537.36',
        ))

    def _resolve_dood(self, url, deadline):
        clean_url = _safe_text(url).split('?', 1)[0]
        parsed = urlparse(clean_url)
        host = parsed.netloc.replace('www.', '')
        media_id = parsed.path.rstrip('/').split('/')[-1]
        if not host or not media_id:
            return None
        web_url = 'https://{}/d/{}'.format(host, media_id)
        headers = {'User-Agent': self._rand_ua(), 'Referer': 'https://{}/'.format(host)}
        response = self._get(web_url, deadline, headers=headers)
        try:
            if getattr(response, 'url', ''):
                redirected = urlparse(response.url)
                if redirected.netloc:
                    host = redirected.netloc.replace('www.', '')
                    web_url = 'https://{}/d/{}'.format(host, media_id)
            page = _safe_text(response.text)
        finally:
            try:
                response.close()
            except Exception:
                pass
        iframe = re.search(r'<iframe\s+[^>]*src=["\']([^"\']+)', page, re.I)
        next_url = ''
        if iframe:
            next_url = urljoin(web_url, html.unescape(iframe.group(1)))
        else:
            next_url = web_url.replace('/d/', '/e/')
        response = self._get(next_url, deadline, headers={'User-Agent': headers['User-Agent'], 'Referer': web_url})
        try:
            page = _safe_text(response.text)
        finally:
            try:
                response.close()
            except Exception:
                pass
        match = re.search(
            r'''dsplayer\.hotkeys[^']+'([^']+).+?function\s*makePlay.+?return[^?]+([^"']+)''',
            page, re.I | re.S
        )
        if not match:
            return None
        pass_url = urljoin('https://{}/'.format(host), match.group(1))
        token = match.group(2)
        response = self._get(pass_url, deadline, headers={'User-Agent': headers['User-Agent'], 'Referer': web_url})
        try:
            payload = _safe_text(response.text)
        finally:
            try:
                response.close()
            except Exception:
                pass
        if not payload:
            return None
        if 'cloudflarestorage.' in payload:
            direct = payload
        else:
            alphabet = string.ascii_letters + string.digits
            direct = payload + ''.join(random.choice(alphabet) for _ in range(10)) + token + str(int(time.time() * 1000))
        if urlparse(direct).scheme not in ('http', 'https'):
            return None
        return direct, {'User-Agent': headers['User-Agent'], 'Referer': web_url}

    def _resolve_streamtape(self, url, deadline):
        embed_url = _safe_text(url).replace('/v/', '/e/')
        parsed = urlparse(embed_url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            return None
        referer = '{}://{}/'.format(parsed.scheme, parsed.netloc)
        headers = {'User-Agent': self._rand_ua(), 'Referer': referer}
        response = self._get(embed_url, deadline, headers=headers)
        try:
            data = _safe_text(response.text)
        finally:
            try:
                response.close()
            except Exception:
                pass
        src = re.findall(r'''ById\(['"].+?=\s*(["']//[^;<]+)''', data, re.I)
        candidate = ''
        if src:
            pieces = src[-1].replace("'", '"').split('+')
            built = ''
            for part in pieces:
                literal = re.findall(r'"([^"]*)', part)
                if not literal:
                    continue
                value = literal[0]
                offset = sum(int(x) for x in re.findall(r'substring\((\d+)', part))
                built += value[offset:]
            candidate = built + '&stream=1'
        else:
            part1 = re.findall(r'<div.+?style=["\']display:none;?["\']>(.*?)&token=.+?</div>', data, re.I | re.S)
            part2 = re.findall(r"&token=(.*?)'", data, re.I)
            if part1 and part2:
                first = part1[0].replace(' ', '')
                token = part2[-1]
                if 'streamtape' in first:
                    candidate = 'https://streamtape' + first.split('streamtape', 1)[1] + '&token=' + token + '&stream=1'
                elif 'get_video' in first:
                    before, after = first.split('get_video', 1)
                    candidate = 'https://' + before.replace('/', '') + '/get_video' + after + '&token=' + token + '&stream=1'
        if candidate.startswith('//'):
            candidate = 'https:' + candidate
        if urlparse(candidate).scheme not in ('http', 'https'):
            return None
        headers['Referer'] = embed_url
        return candidate, headers

    @staticmethod
    def _unbase(value, base):
        alphabet = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
        if base <= 36:
            return int(value, base)
        result = 0
        for char in value:
            result = result * base + alphabet.index(char)
        return result

    @classmethod
    def _unpack_packer(cls, source):
        # Decoder mínimo para o padrão Dean Edwards usado pelo Mixdrop.
        match = re.search(
            r'''\}\(['"](.*)['"],\s*(\d+),\s*(\d+),\s*['"](.*)['"]\.split\(['"]\|['"]\)''',
            source, re.S
        )
        if not match:
            return source
        payload, radix, count, symtab = match.groups()
        try:
            radix = int(radix)
            count = int(count)
            words = symtab.split('|')
            if count > len(words):
                return source
        except Exception:
            return source
        def replace_token(token_match):
            token = token_match.group(0)
            try:
                index = cls._unbase(token, radix)
                if 0 <= index < len(words) and words[index]:
                    return words[index]
            except Exception:
                pass
            return token
        try:
            return re.sub(r'\b[0-9A-Za-z]+\b', replace_token, payload.replace('\\\'', "'").replace('\\\\', '\\'))
        except Exception:
            return source

    def _resolve_mixdrop(self, url, deadline):
        embed_url = _safe_text(url).replace('.club', '.co')
        parsed = urlparse(embed_url)
        if parsed.scheme not in ('http', 'https') or not parsed.netloc:
            return None
        referer = '{}://{}/'.format(parsed.scheme, parsed.netloc)
        headers = {'Origin': referer.rstrip('/'), 'Referer': referer, 'User-Agent': self._rand_ua()}
        response = self._get(embed_url, deadline, headers=headers)
        try:
            page = _safe_text(response.text)
        finally:
            try:
                response.close()
            except Exception:
                pass
        redirect = re.search(r'''location\s*=\s*["']([^'"]+)''', page, re.I)
        if redirect:
            embed_url = urljoin(embed_url, redirect.group(1))
            response = self._get(embed_url, deadline, headers=headers)
            try:
                page = _safe_text(response.text)
            finally:
                try:
                    response.close()
                except Exception:
                    pass
        if '(p,a,c,k,e,d)' in page:
            page = self._unpack_packer(page)
        match = re.search(r'(?:vsr|wurl|surl)[^=]*=\s*["\']([^"\']+)', page, re.I)
        if not match:
            return None
        direct = html.unescape(match.group(1))
        if direct.startswith('//'):
            direct = 'https:' + direct
        if urlparse(direct).scheme not in ('http', 'https'):
            return None
        headers.pop('Origin', None)
        headers['Referer'] = embed_url
        return direct, headers

    def _resolve_host(self, item, deadline):
        source_url = _safe_text(item.get('url'))
        kind = self._host_kind(source_url)
        if kind == 'dood':
            resolved = self._resolve_dood(source_url, deadline)
        elif kind == 'streamtape':
            resolved = self._resolve_streamtape(source_url, deadline)
        elif kind == 'mixdrop':
            resolved = self._resolve_mixdrop(source_url, deadline)
        else:
            return None
        if not resolved:
            return None
        direct, headers = resolved
        return {
            'url': direct,
            'headers': headers,
            'server': kind,
            'audio': item.get('audio') or '',
            'kind': self._infer_media_kind(direct),
        }

    def resolve(self, media_type, title, year='', season=None, episode=None):
        media_type = _safe_text(media_type).lower()
        title = _safe_text(title)
        if media_type not in ('movie', 'series') or not title:
            return {'streams': [], 'reason': 'tipo/título inválido', 'audit': ['entrada-invalida']}
        if media_type == 'series':
            try:
                season = int(season)
                episode = int(episode)
                if season < 0 or episode < 1:
                    raise ValueError()
            except Exception:
                return {'streams': [], 'reason': 'episódio inválido', 'audit': ['episodio-invalido']}
        if self.session is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}
        cooldown = self._cooldown_state()
        if cooldown:
            self._log('Overflix em cooldown temporário: {}.'.format(cooldown), 1)
            return {'streams': [], 'reason': 'Overflix temporariamente em cooldown', 'audit': ['cooldown']}

        budget = SERIES_BUDGET_SECONDS if media_type == 'series' else MOVIE_BUDGET_SECONDS
        deadline = self.monotonic() + budget
        audit = []
        try:
            results = self._search(title, media_type, _four_digit_year(year), deadline)
            if not results:
                return {'streams': [], 'reason': 'Overflix sem resultado para o título', 'audit': ['sem-resultado']}
            match, score = self._best_match(results, title, media_type, year)
            if not match:
                return {'streams': [], 'reason': 'Overflix sem correspondência segura', 'audit': ['sem-match-seguro']}
            audit.append('match={:.0f}'.format(score))
            video_id = _safe_text(match.get('video_id'))
            if media_type == 'series':
                video_id = self._episode_video_id(match.get('url'), season, episode, deadline)
            elif not video_id:
                video_id = self._video_id_from_page(match.get('url'), deadline)
            if not video_id:
                return {'streams': [], 'reason': 'Overflix sem ID reproduzível', 'audit': audit + ['sem-video-id']}
            player_data = self._player_data(video_id, deadline)
            play_urls = self._play_urls(player_data)
            if not play_urls:
                return {'streams': [], 'reason': 'Overflix sem servidor compatível', 'audit': audit + ['sem-servidor']}
            supported = [item for item in play_urls if self._server_priority(item.get('url')) < 99]
            if not supported:
                return {'streams': [], 'reason': 'Overflix sem host suportado', 'audit': audit + ['host-nao-suportado']}
            for item in supported:
                if self.monotonic() >= deadline:
                    break
                try:
                    resolved = self._resolve_host(item, deadline)
                except Exception as exc:
                    audit.append('{}={}'.format(item.get('server') or 'host', exc.__class__.__name__))
                    continue
                if not resolved:
                    audit.append('{}=sem-url'.format(item.get('server') or 'host'))
                    continue
                audio_label = 'Dublado' if resolved['audio'] == 'dub' else 'Legendado'
                server_label = {'dood': 'Dood', 'streamtape': 'Streamtape', 'mixdrop': 'Mixdrop'}.get(
                    resolved['server'], 'Host'
                )
                stream = {
                    'name': '{} • {}'.format(audio_label, server_label),
                    'title': '{} • {}'.format(audio_label, server_label),
                    'description': '{} • {}'.format(audio_label, server_label),
                    'url': resolved['url'],
                    '__vod_kind': resolved['kind'],
                    '__vod_source_family': 'Overflix',
                    '__vod_source_host': (urlparse(resolved['url']).hostname or '').lower(),
                    '__vod_playable': True,
                    '__vod_caution': resolved['kind'] == 'unknown',
                    '__vod_caution_reasons': ('link-opaco',) if resolved['kind'] == 'unknown' else (),
                    '__vod_raw_title': '{} • {}'.format(audio_label, server_label),
                    '__vod_raw_name': 'Overflix',
                    '__vod_target_type': 'url',
                    '__vod_target_value': resolved['url'],
                    '__request_rank': 60,
                    '__request_label': 'overflix-title',
                    '__vod_provider_id': video_id,
                    '__vod_provider_id_kind': 'overflix-video-id',
                    '__vod_provider': 'Overflix',
                    '__vod_request_headers': resolved['headers'],
                }
                audit.append('host={}'.format(resolved['server']))
                self._log('Overflix resolveu {} por título: 1 fonte ({}; {}%).'.format(
                    media_type, server_label, int(round(score))), 1)
                return {'streams': [stream], 'reason': '', 'audit': audit}
            return {'streams': [], 'reason': 'Overflix sem URL direta resolvida', 'audit': audit + ['sem-url-direta']}
        except TimeoutError:
            self._remember_cooldown('budget-timeout', NETWORK_COOLDOWN_SECONDS)
            self._log('Overflix indisponível nesta consulta: orçamento de tempo esgotado.', 1)
            return {'streams': [], 'reason': 'Overflix excedeu o tempo desta consulta', 'audit': audit + ['budget-timeout']}
        except Exception as exc:
            self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('Overflix indisponível nesta consulta: {}.'.format(exc.__class__.__name__), 1)
            return {
                'streams': [], 'reason': 'Overflix indisponível nesta consulta',
                'audit': audit + ['erro:{}'.format(exc.__class__.__name__)]
            }


_DEFAULT_PROVIDER = None


def _kodi_logger(message, level=1):
    try:
        from resources.lib.common import log, log_debug
        log('[VOD Overflix] {}'.format(message), level=level)
        log_debug(message, component='Overflix')
    except Exception:
        pass


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        _DEFAULT_PROVIDER = OverflixProvider(logger=_kodi_logger)
    return _DEFAULT_PROVIDER
