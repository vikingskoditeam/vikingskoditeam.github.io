# diagnostics.py
# -*- coding: utf-8 -*-
"""Diagnóstico leve do ambiente Android/Kodi.

Este módulo não participa do catálogo, resolução MediaFire, download ou limpeza.
Ele apenas coleta informações do ambiente para suporte/perícia quando solicitado.
"""

import platform as py_platform
import sys

import xbmc
import xbmcaddon


ADDON_ID = 'script.oneplayapk.downloader'


def _addon():
    return xbmcaddon.Addon(id=ADDON_ID)


def _text(string_id, fallback):
    try:
        value = _addon().getLocalizedString(int(string_id))
        return value or fallback
    except Exception:
        return fallback


def is_debug_enabled():
    try:
        return _addon().getSetting('enable_debug').lower() == 'true'
    except Exception:
        return False


def collect_device_info():
    """Retorna somente informações de diagnóstico; não altera configuração."""
    architecture = (py_platform.machine() or '').strip() or 'unknown'
    android_version = (xbmc.getInfoLabel('System.OSVersionInfo') or '').strip() or 'unknown'
    kodi_version = (xbmc.getInfoLabel('System.BuildVersion') or '').strip() or 'unknown'
    addon_version = (_addon().getAddonInfo('version') or '').strip() or 'unknown'
    python_version = sys.version.split()[0] if sys.version else 'unknown'

    return {
        'android': android_version,
        'architecture': architecture,
        'kodi': kodi_version,
        'addon': addon_version,
        'python': python_version,
    }


def format_device_info():
    data = collect_device_info()
    return (
        '[B]%s:[/B] %s\n'
        '[B]%s:[/B] %s\n'
        '[B]%s:[/B] %s\n'
        '[B]%s:[/B] %s\n'
        '[B]%s:[/B] %s'
        % (
            _text(30016, 'Android'), data['android'],
            _text(30017, 'Arquitetura'), data['architecture'],
            _text(30018, 'Kodi'), data['kodi'],
            _text(30019, 'Add-on'), data['addon'],
            _text(30020, 'Python'), data['python'],
        )
    )


def debug_log(message):
    if not is_debug_enabled():
        return
    try:
        xbmc.log('[ONEPLAY APK Downloader][DEBUG] %s' % message, xbmc.LOGINFO)
    except Exception:
        pass


def log_device_info_if_debug():
    if not is_debug_enabled():
        return
    data = collect_device_info()
    xbmc.log(
        '[ONEPLAY APK Downloader][DEBUG] Android=%s | arch=%s | Kodi=%s | addon=%s | Python=%s'
        % (
            data['android'],
            data['architecture'],
            data['kodi'],
            data['addon'],
            data['python'],
        ),
        xbmc.LOGINFO,
    )
