# -*- coding: utf-8 -*-
import hashlib
import json
import os
import time
from datetime import datetime, timedelta
from urllib.parse import urlparse
from urllib.request import Request
import xbmc
import xbmcaddon
import xbmcvfs
from .proxy import cloudflare_urlopen
from .source_contract import api_headers
from .storage import write_json_atomic

ADDON=xbmcaddon.Addon()
PROFILE=xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EVENTS_URLS=(
    'https://embedtv.lat/api/events',
    'https://embedtv.lat/api/jogos',
)
# Compatibilidade com testes/código que referenciem o nome antigo.
EVENTS_URL=EVENTS_URLS[0]
EVENTS_MAX_BYTES=4*1024*1024
_MEMO_DEADLINE = 0.0
_MEMO_ONLINE = False
CACHE_TTL=90
EVENT_PRESTART_SECONDS=20*60
EVENT_POSTEND_GRACE_SECONDS=20*60
EVENT_NO_END_MAX_SECONDS=6*60*60
_EVENTS_MEMO=None


def _log(msg, warning=False):
    xbmc.log('[ONEPLAY LIVE] EVENTOS %s' % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _cache_path(): return os.path.join(PROFILE,'events_api.cache')


def _rows(obj):
    if isinstance(obj,list): return obj
    if isinstance(obj,dict):
        for key in ('events','eventos','data','items','results'):
            value=obj.get(key)
            if isinstance(value,list): return value
        flat=[]
        for value in obj.values():
            if isinstance(value,list): flat.extend(value)
        if flat: return flat
    return []


def _valid_payload(obj):
    # An error object or scalar must not overwrite the last useful schedule.
    if isinstance(obj, list):
        rows = obj
    elif isinstance(obj, dict):
        keys = ('events', 'eventos', 'data', 'items', 'results')
        present = [key for key in keys if key in obj]
        if present:
            rows = obj[present[0]]
            if not isinstance(rows, list):
                return False
        else:
            groups = [value for value in obj.values() if isinstance(value, list)]
            if not groups:
                return False
            rows = [row for group in groups for row in group]
    else:
        return False
    return all(isinstance(row, dict) for row in rows)


def _read_cache(fresh_only=False):
    path=_cache_path()
    try:
        if fresh_only and time.time()-os.path.getmtime(path)>CACHE_TTL: return None
        with open(path,'rb') as fh: raw=fh.read(EVENTS_MAX_BYTES+1)
        if len(raw)>EVENTS_MAX_BYTES: return None
        obj=json.loads(raw.decode('utf-8'))
        return obj if _valid_payload(obj) else None
    except Exception: return None


def _write_cache(obj):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_cache_path(), obj, EVENTS_MAX_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _fetch():
    """Consolida feeds conhecidos sem aceitar vazio/legado cedo demais.

    O site já expôs a programação esportiva em mais de uma rota. Os feeds são
    lidos de forma independente e suas linhas são deduplicadas antes da janela
    temporal. Assim um endpoint vazio ou com grade antiga não esconde eventos
    atuais presentes no alternativo.
    """
    merged=[]
    seen=set()
    valid_feed=False
    errors=[]
    for url in EVENTS_URLS:
        endpoint=urlparse(url).path or url
        try:
            req=Request(url,headers=api_headers(),method='GET')
            with cloudflare_urlopen(req,timeout=7) as response:
                raw=response.read(EVENTS_MAX_BYTES+1)
            if len(raw)>EVENTS_MAX_BYTES:
                raise ValueError('payload excedeu limite')
            obj=json.loads(raw.decode('utf-8'))
            if not _valid_payload(obj):
                raise ValueError('schema de eventos inválido')
            valid_feed=True
            rows=_rows(obj)
            _log('feed=%s eventos=%d' % (endpoint,len(rows)))
            for row in rows:
                if not isinstance(row,dict):
                    continue
                try:
                    sig=json.dumps(row,sort_keys=True,ensure_ascii=False,separators=(',',':'))
                except Exception:
                    sig=repr(row)
                key=hashlib.sha1(sig.encode('utf-8','ignore')).hexdigest()
                if key in seen:
                    continue
                seen.add(key); merged.append(row)
        except Exception as exc:
            errors.append('%s:%s' % (endpoint,exc.__class__.__name__))
            _log('feed=%s indisponível: %s' % (endpoint,exc.__class__.__name__),True)
    if valid_feed:
        _log('feeds consolidados eventos=%d' % len(merged))
        return merged
    raise IOError('feeds de eventos indisponíveis (%s)' % ','.join(errors))


def _payload(allow_network=True):
    global _EVENTS_MEMO, _MEMO_DEADLINE, _MEMO_ONLINE
    online = bool(allow_network)
    now = time.monotonic()
    if _EVENTS_MEMO is not None and now < _MEMO_DEADLINE and (not online or _MEMO_ONLINE):
        return _EVENTS_MEMO
    _MEMO_DEADLINE = now + CACHE_TTL
    _MEMO_ONLINE = online
    fresh=_read_cache(True)
    if fresh is not None: _EVENTS_MEMO=fresh; return fresh
    if allow_network:
        try:
            live=_fetch(); _write_cache(live); _EVENTS_MEMO=live
            _log('atualizado eventos=%d'%len(_rows(live)))
            return live
        except Exception as exc: _log('API indisponível; usando cache se houver: %s'%exc,True)
    stale=_read_cache(False); _EVENTS_MEMO=stale if stale is not None else []
    return _EVENTS_MEMO


def _epoch(value):
    if value is None or value=='': return None
    if isinstance(value,(int,float)):
        v=float(value); v=v/1000.0 if v>10**12 else v
        return v if v>0 else None
    text=str(value).strip()
    if not text: return None
    try:
        num=float(text); num=num/1000.0 if num>10**12 else num
        if num>10**9: return num
    except Exception: pass
    try:
        if text.endswith('Z'): text=text[:-1]+'+00:00'
        dt=datetime.fromisoformat(text)
        return time.mktime(dt.timetuple()) if dt.tzinfo is None else dt.timestamp()
    except Exception: return None



def event_display_text(value, multiline=False, _depth=0):
    """Converte metadados editoriais em texto, nunca em repr de estruturas."""
    if _depth > 5 or value is None or isinstance(value, bool):
        return ''
    if isinstance(value, dict):
        for key in ('name', 'title', 'label', 'shortName', 'displayName',
                    'text', 'value', 'event', 'competition', 'league', 'tournament'):
            if key in value:
                result = event_display_text(value[key], multiline, _depth + 1)
                if result:
                    return result
        return ''
    if isinstance(value, (list, tuple)):
        parts = []
        for entry in value[:16]:
            text = event_display_text(entry, multiline, _depth + 1)
            if text and text not in parts:
                parts.append(text)
        return ', '.join(parts)
    if not isinstance(value, (str, int, float)):
        return ''
    text = str(value)
    if not text or text.startswith(('http://', 'https://', '//')):
        return ''
    # Mantém as quebras de linha do plot, mas remove controles indevidos.
    text = ''.join(c for c in text if c == '\n' or (ord(c) >= 32 and ord(c) != 127))
    if multiline:
        return '\n'.join(' '.join(line.split()) for line in text.splitlines()).strip()[:8192]
    return ' '.join(text.split()).strip()[:2048]


def _name(obj):
    return event_display_text(obj)


def _first_text(*values):
    for value in values:
        text = _name(value)
        if text:
            return text
    return ''


def event_art_url(value, _depth=0):
    """Extrai somente uma URI de imagem válida dos formatos conhecidos da API."""
    if _depth > 5 or value is None:
        return ''
    if isinstance(value, dict):
        for key in ('image', 'logo', 'icon', 'thumbnail', 'thumb', 'poster',
                    'image_url', 'imageUrl', 'url', 'src'):
            if key in value:
                result = event_art_url(value[key], _depth + 1)
                if result:
                    return result
        return ''
    if isinstance(value, (list, tuple)):
        for entry in value[:16]:
            result = event_art_url(entry, _depth + 1)
            if result:
                return result
        return ''
    if not isinstance(value, str):
        return ''
    url = value.strip()
    try:
        parsed = urlparse(url)
        if parsed.scheme in ('http', 'https') and parsed.netloc:
            return url[:4096]
        if parsed.scheme in ('special', 'resource') and parsed.path:
            return url[:4096]
    except Exception:
        pass
    return ''


def _image(obj):
    return event_art_url(obj)


def _channel_from_url(value):
    try:
        if isinstance(value,dict): value=value.get('url') or value.get('src') or value.get('player') or value.get('channel_id') or value.get('id') or ''
        text=str(value or '').strip()
        if not text: return ''
        if '://' not in text and '/' not in text: return text
        p=urlparse(text); seg=(p.path or '').rstrip('/').split('/')[-1].strip()
        if seg.endswith('.html'): seg=seg[:-5]
        return seg
    except Exception: return ''


def _collect_players(raw,data):
    vals=[]
    for key in ('players','streams','urls','player','channels','canais'):
        value=raw.get(key)
        if value is None: value=data.get(key)
        if value is None: continue
        if isinstance(value,(str,int,float,dict)): value=[value]
        if isinstance(value,list): vals.extend(value)
    direct=raw.get('channel_id') or raw.get('channelId') or data.get('channel_id') or data.get('channelId')
    if direct: vals.insert(0,direct)
    ids=[]
    for value in vals:
        cid=_channel_from_url(value)
        if cid and cid not in ids: ids.append(cid)
    return ids


def _normalize_event(raw):
    if not isinstance(raw,dict): return None
    data=raw.get('data') if isinstance(raw.get('data'),dict) else {}
    timer=data.get('timer') if isinstance(data.get('timer'),dict) else {}
    teams=data.get('teams') if isinstance(data.get('teams'),dict) else (raw.get('teams') if isinstance(raw.get('teams'),dict) else {})
    home=teams.get('home') if isinstance(teams.get('home'),dict) else {}
    away=teams.get('away') if isinstance(teams.get('away'),dict) else {}
    home_name=_name(home); away_name=_name(away)
    raw_title=_first_text(raw.get('title'), raw.get('name'), raw.get('event'),
                          data.get('title'), data.get('name'))
    # A API/site modela evento esportivo por participantes. Priorize o confronto para não
    # repetir competição/nome genérico como título de todos os itens.
    title=('%s x %s'%(home_name,away_name)) if home_name and away_name else raw_title
    if not title: title=(home_name or away_name)
    if not title: return None
    league=_first_text(raw.get('league'), raw.get('competition'),
                       data.get('league'), data.get('competition'))
    # Preserva título bruto quando ele trouxer informação extra não duplicada.
    subtitle=raw_title if raw_title and raw_title.lower()!=title.lower() and raw_title.lower()!=league.lower() else ''
    home_image=_image(home); away_image=_image(away)
    image=(event_art_url(raw.get('image')) or event_art_url(raw.get('thumbnail'))
           or event_art_url(raw.get('logo')) or home_image or away_image
           or event_art_url(raw.get('league')) or event_art_url(raw.get('competition'))
           or event_art_url(data.get('league')) or event_art_url(data.get('competition')))
    start=_epoch(raw.get('start') or raw.get('start_date') or raw.get('start_time') or raw.get('timestamp') or timer.get('start'))
    end=_epoch(raw.get('end') or raw.get('end_date') or raw.get('end_time') or timer.get('end'))
    channel_ids=_collect_players(raw,data)
    sig='|'.join([title,league,str(int(start or 0)),','.join(channel_ids)])
    key=hashlib.sha1(sig.encode('utf-8','ignore')).hexdigest()[:16]
    return {'event_key':key,'title':title,'subtitle':subtitle,'league':league,'image':image,
            'home_image':home_image,'away_image':away_image,'start_ts':start,'end_ts':end,
            'home':home_name,'away':away_name,'channel_ids':channel_ids}


def _when_label(ts,now=None):
    if not ts: return ''
    now=float(time.time() if now is None else now); d=datetime.fromtimestamp(ts); n=datetime.fromtimestamp(now)
    return d.strftime('%H:%M') if d.date()==n.date() else d.strftime('%d/%m %H:%M')


def _day_key(ts,now=None):
    if not ts: return 'sem_horario'
    now=float(time.time() if now is None else now); d=datetime.fromtimestamp(ts).date(); n=datetime.fromtimestamp(now).date()
    diff=(d-n).days
    if diff==0: return 'hoje'
    if diff==1: return 'amanha'
    return d.isoformat()


def _day_label(key):
    if key=='hoje': return 'Hoje'
    if key=='amanha': return 'Amanhã'
    if key=='sem_horario': return 'Sem horário definido'
    try:
        d=datetime.strptime(key,'%Y-%m-%d'); return d.strftime('%d/%m/%Y')
    except Exception: return key


class EventsGuide:
    def __init__(self,allow_network=True):
        obj=_payload(bool(allow_network)); self._events=[]
        raw_rows=_rows(obj)
        for raw in raw_rows:
            event=_normalize_event(raw)
            if event: self._events.append(event)
        self._events.sort(key=lambda x:(x.get('start_ts') is None,x.get('start_ts') or 0,x.get('league',''),x.get('title','')))
        _log('normalização raw=%d válidos=%d' % (len(raw_rows),len(self._events)))

    def events(self,known_channels=None,now_ts=None):
        now=float(time.time() if now_ts is None else now_ts); known=known_channels or {}; out=[]
        for event in self._events:
            start=event.get('start_ts'); end=event.get('end_ts')
            # Grade temporal: evento sem horário não é exibido. Um evento futuro só entra
            # 20 minutos antes do início. Depois do horário, usa o fim da API com pequena
            # tolerância para acréscimos; sem fim confiável, aplica teto de segurança de 6 h.
            if not start: continue
            if start > now + EVENT_PRESTART_SECONDS: continue
            valid_end=end if end and end>start else None
            if valid_end:
                if now > valid_end + EVENT_POSTEND_GRACE_SECONDS: continue
            elif now > start + EVENT_NO_END_MAX_SECONDS:
                continue
            item=dict(event); matches=[]
            for cid in event.get('channel_ids') or []:
                if cid in known and cid not in matches: matches.append(cid)
            item['matched_channels']=matches
            if start<=now and (not valid_end or now<=valid_end+EVENT_POSTEND_GRACE_SECONDS): status='AO VIVO'
            else: status=_when_label(start,now)
            item['status']=status; item['day_key']=_day_key(start,now); item['day_label']=_day_label(item['day_key'])
            lines=[]
            if item.get('status'): lines.append(item['status'])
            if item.get('league'): lines.append(item['league'])
            if item.get('subtitle'): lines.append(item['subtitle'])
            matches=item.get('matched_channels') or []
            if matches:
                names=[_first_text((known.get(cid) or {}).get('name'), cid) for cid in matches]
                lines.append(('Transmissão: ' if len(names)==1 else 'Transmissões: ')+', '.join(names))
            else: lines.append('Fonte de canal ainda não associada no catálogo atual.')
            item['plot']='\n'.join(lines); out.append(item)
        _log('janela temporal elegíveis=%d total_normalizados=%d antecedência=%dmin' % (
            len(out),len(self._events),int(EVENT_PRESTART_SECONDS/60)))
        return out

    def days(self,known_channels=None,now_ts=None):
        groups=[]; seen={}
        for item in self.events(known_channels,now_ts):
            key=item.get('day_key') or 'sem_horario'
            if key not in seen:
                seen[key]={'key':key,'label':item.get('day_label') or key,'count':0,'live':0}; groups.append(seen[key])
            seen[key]['count']+=1
            if item.get('status')=='AO VIVO': seen[key]['live']+=1
        return groups

    def events_for_day(self,day_key,known_channels=None,now_ts=None):
        return [x for x in self.events(known_channels,now_ts) if (x.get('day_key') or 'sem_horario')==day_key]

    def event_by_key(self,event_key,known_channels=None,now_ts=None):
        for item in self.events(known_channels,now_ts):
            if item.get('event_key')==event_key: return item
        return None
