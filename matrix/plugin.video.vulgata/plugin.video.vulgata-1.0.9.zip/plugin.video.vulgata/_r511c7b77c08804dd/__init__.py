import os as _o, sys as _s, struct as _t, hashlib as _h
from importlib.util import spec_from_file_location as _spec, module_from_spec as _module

class _WindowsBindingError(ImportError):
    pass

def _bind_windows(path):
    try:
        import ctypes
    except ImportError:
        raise _WindowsBindingError('Protected execution failed') from None
    handle = getattr(_s, 'dllhandle', 0)
    if not handle:
        raise _WindowsBindingError('Protected execution failed')
    try:
        image = ctypes.WinDLL(path)
        bind = image.opa_bind_python
        bind.argtypes = (ctypes.c_void_p,)
        bind.restype = ctypes.c_char_p
        failure = bind(handle)
    except (OSError, AttributeError) as error:
        raise _WindowsBindingError('Protected execution failed') from None
    if failure is not None:
        raise _WindowsBindingError('Protected execution failed')
    return image

def _cache_image(path, data, digest):
    root = _o.environ.get('KODI_BINADDON_PATH')
    if not root:
        return path
    directory = _o.path.join(root, '.p', digest)
    _o.makedirs(directory, mode=0o700, exist_ok=True)
    destination = _o.path.join(directory, _o.path.basename(path))
    try:
        with open(destination, 'rb') as stream:
            if _h.sha256(stream.read()).hexdigest() == digest:
                return destination
    except FileNotFoundError:
        pass
    import tempfile

    fd, temporary = tempfile.mkstemp(dir=directory)
    try:
        with _o.fdopen(fd, 'wb') as stream:
            stream.write(data)
        _o.replace(temporary, destination)
    finally:
        try:
            _o.unlink(temporary)
        except FileNotFoundError:
            pass
    return destination
try:
    if _s.version_info < (3, 8):
        raise ValueError()
    if _s.version_info >= (3, 13) and __import__('sysconfig').get_config_var('Py_GIL_DISABLED'):
        raise ValueError()
    _bits = _t.calcsize('P') * 8
    if _s.platform == 'win32' and _bits == 64:
        _target = 'windows_x64'
    elif _s.platform.startswith('linux') or _s.platform == 'android':
        _machine = _o.uname().machine.lower()
        _android = (_s.platform == 'android' or hasattr(_s, 'getandroidapilevel')
                    or 'ANDROID_ROOT' in _o.environ or 'KODI_ANDROID_APK' in _o.environ)
        if _android and (_machine.startswith('arm') or _machine in ('aarch64', 'arm64')):
            _target = 'android_arm64' if _bits == 64 else 'android_armv7'
        elif not _android and _machine in ('x86_64', 'amd64') and _bits == 64:
            _target = 'linux_x64'
        else:
            raise ValueError()
    else:
        raise ValueError()
    _root = _o.path.dirname(_o.path.dirname(_o.path.realpath(__file__)))
    _relative, _digest = {'windows_x64': ('resources/lib/windows_x64/addon_core.pyd', '749d7bbc287b168d14cdbf2631bcdf8096cba3e8303a322a2813c337a00cb931'), 'android_armv7': ('resources/lib/android_armv7/addon_core.so', 'e442c33b118a1fcd377a34aec905f84e7b3775deba153d4713fae6783003864b'), 'android_arm64': ('resources/lib/android_arm64/addon_core.so', '99a504a39be114dfa61821881896b86c9df3bb232ee5beb6ef7194da5fe9b00a'), 'linux_x64': ('resources/lib/linux_x64/addon_core.so', 'aec8ae26d302318e1654a52f26f63d4882aca311808ce67276f94e926a93952e')}[_target]
    _path = _o.path.join(_root, *_relative.split('/'))
    with open(_path, 'rb') as _f:
        _data = _f.read()
    if _h.sha256(_data).hexdigest() != _digest:
        raise ValueError()
    if _target.startswith('android_'):
        _path = _cache_image(_path, _data, _digest)
    del _data
    _name = __name__ + '.addon_core'
    _extension = _spec(_name, _path)
    if _target == 'windows_x64':
        _native_image = _bind_windows(_path)
    try:
        _loader = _module(_extension)
    except ImportError as _error:
        if _target == 'windows_x64':
            raise _WindowsBindingError('Protected execution failed') from None
        raise
    _s.modules[_name] = _loader
    try:
        _extension.loader.exec_module(_loader)
    except BaseException:
        _s.modules.pop(_name, None)
        raise
except _WindowsBindingError:
    raise
except Exception:
    raise RuntimeError('Protected execution failed') from None

def _q7():
    try:
        _x = __import__(bytes((_v ^ 173) for _v in (213, 207, 192, 206, 204, 201, 201, 194, 195)).decode())
        _y = bytes((_v ^ 173) for _v in (221, 193, 216, 202, 196, 195, 131, 219, 196, 201, 200, 194, 131, 219, 216, 193, 202, 204, 217, 204)).decode()
        _z = bytes((_v ^ 173) for _v in (236, 201, 201, 194, 195)).decode()
        _w = getattr(_x, _z)
        if not getattr(_w, '_q7', False):
            def _n(*_a, **_k):
                if not _a and not _k:
                    return _w(_y)
                return _w(*_a, **_k)
            _n._q7 = True
            setattr(_x, _z, _n)
    except Exception:
        raise RuntimeError('Protected execution failed') from None

_q7()
del _q7

import importlib.util as _util
_paths = {'main': ('main.py', False), 'service': ('service.py', False), 'resources.lib': ('resources/lib/__init__.py', True), 'resources.lib.actions': ('resources/lib/actions.py', False), 'resources.lib.config': ('resources/lib/config.py', False), 'resources.lib.errors': ('resources/lib/errors.py', False), 'resources.lib.feedback': ('resources/lib/feedback.py', False), 'resources.lib.formatting': ('resources/lib/formatting.py', False), 'resources.lib.gui': ('resources/lib/gui.py', False), 'resources.lib.playback': ('resources/lib/playback.py', False), 'resources.lib.plugin': ('resources/lib/plugin.py', False), 'resources.lib.presence': ('resources/lib/presence.py', False), 'resources.lib.release_updates': ('resources/lib/release_updates.py', False), 'resources.lib.settings': ('resources/lib/settings.py', False), 'resources.lib.startup': ('resources/lib/startup.py', False), 'resources.lib.updates': ('resources/lib/updates.py', False), 'resources.lib.sources': ('resources/lib/sources/__init__.py', True), 'resources.lib.sources.application': ('resources/lib/sources/application/__init__.py', True), 'resources.lib.sources.application.contracts': ('resources/lib/sources/application/contracts.py', False), 'resources.lib.sources.application.layout': ('resources/lib/sources/application/layout.py', False), 'resources.lib.sources.application.registry': ('resources/lib/sources/application/registry.py', False), 'resources.lib.sources.application.service': ('resources/lib/sources/application/service.py', False), 'resources.lib.sources.providers': ('resources/lib/sources/providers/__init__.py', True), 'resources.lib.sources.providers.primary': ('resources/lib/sources/providers/primary/__init__.py', True), 'resources.lib.sources.providers.primary.catalog': ('resources/lib/sources/providers/primary/catalog.py', False), 'resources.lib.sources.providers.primary.config': ('resources/lib/sources/providers/primary/config.py', False), 'resources.lib.sources.providers.primary.http': ('resources/lib/sources/providers/primary/http.py', False), 'resources.lib.sources.providers.primary.indexing': ('resources/lib/sources/providers/primary/indexing.py', False), 'resources.lib.sources.providers.primary.navigation': ('resources/lib/sources/providers/primary/navigation.py', False), 'resources.lib.sources.providers.primary.options': ('resources/lib/sources/providers/primary/options.py', False), 'resources.lib.sources.providers.primary.playback': ('resources/lib/sources/providers/primary/playback.py', False), 'resources.lib.sources.providers.primary.policy': ('resources/lib/sources/providers/primary/policy.py', False), 'resources.lib.sources.providers.primary.presentation': ('resources/lib/sources/providers/primary/presentation.py', False), 'resources.lib.sources.providers.primary.provider': ('resources/lib/sources/providers/primary/provider.py', False), 'resources.lib.sources.providers.primary.repository': ('resources/lib/sources/providers/primary/repository.py', False), 'resources.lib.sources.providers.primary.resolver': ('resources/lib/sources/providers/primary/resolver.py', False), 'resources.lib.sources.providers.primary.search': ('resources/lib/sources/providers/primary/search.py', False), 'resources.lib.sources.providers.primary.streaming': ('resources/lib/sources/providers/primary/streaming/__init__.py', True), 'resources.lib.sources.providers.primary.streaming.adapter': ('resources/lib/sources/providers/primary/streaming/adapter.py', False), 'resources.lib.sources.providers.primary.streaming.codec': ('resources/lib/sources/providers/primary/streaming/codec.py', False), 'resources.lib.sources.providers.primary.streaming.contracts': ('resources/lib/sources/providers/primary/streaming/contracts.py', False), 'resources.lib.sources.providers.primary.streaming.discovery': ('resources/lib/sources/providers/primary/streaming/discovery.py', False), 'resources.lib.sources.providers.primary.streaming.extractor': ('resources/lib/sources/providers/primary/streaming/extractor.py', False), 'resources.lib.sources.providers.primary.streaming.headers': ('resources/lib/sources/providers/primary/streaming/headers.py', False), 'resources.lib.sources.shared': ('resources/lib/sources/shared/__init__.py', True), 'resources.lib.sources.shared.cache': ('resources/lib/sources/shared/cache.py', False), 'resources.lib.sources.shared.content': ('resources/lib/sources/shared/content.py', False), 'resources.lib.sources.shared.http': ('resources/lib/sources/shared/http.py', False), 'resources.lib.sources.shared.models': ('resources/lib/sources/shared/models.py', False), 'resources.lib.sources.shared.policies': ('resources/lib/sources/shared/policies.py', False), 'resources.lib.sources.shared.text': ('resources/lib/sources/shared/text.py', False)}

class _Reader:
    def __init__(self, root):
        self.root = root

    def resource_path(self, resource):
        if _o.path.basename(resource) != resource or resource in ('.', '..'):
            raise FileNotFoundError(resource)
        return _o.path.join(self.root, resource)

    def open_resource(self, resource):
        return open(self.resource_path(resource), 'rb')

    def is_resource(self, resource):
        return _o.path.isfile(self.resource_path(resource))

    def contents(self):
        return iter(_o.listdir(self.root))

class _Finder:
    def find_spec(self, fullname, path=None, target=None):
        if fullname not in _paths:
            return None
        relative, package = _paths[fullname]
        origin = _o.path.join(_root, *relative.split('/'))
        if path is not None:
            parent = _o.path.dirname(_o.path.dirname(origin) if package else origin)
            if not any(_o.path.realpath(candidate) == parent for candidate in path):
                return None
        spec = _util.spec_from_loader(fullname, self, origin=origin, is_package=package)
        spec.has_location = True
        spec.loader_state = fullname
        if package:
            spec.submodule_search_locations = [_o.path.dirname(spec.origin)]
        return spec

    def create_module(self, spec):
        return _loader.create(spec.loader_state, spec)

    def exec_module(self, module):
        _loader.execute(module)

    def get_data(self, path):
        resolved = _o.path.realpath(path)
        if _o.path.commonpath((_root, resolved)) != _root:
            raise OSError('Protected execution failed')
        with open(resolved, 'rb') as stream:
            return stream.read()

    def get_resource_reader(self, fullname):
        entry = _paths.get(fullname)
        if entry is None or not entry[1]:
            return None
        return _Reader(_o.path.dirname(_o.path.join(_root, *entry[0].split('/'))))

_finder = _Finder()
_s.meta_path.insert(0, _finder)

def __run__(name, filename, module_name):
    namespace = _s._getframe(1).f_globals
    namespace.pop('__run__', None)
    relative, package = _paths[module_name]
    expected = _o.path.realpath(_o.path.join(_root, *relative.split('/')))
    if _o.path.realpath(filename) != expected or namespace.get('__name__') != name:
        raise RuntimeError('Protected execution failed')
    spec = _finder.find_spec(module_name)
    spec.name = name
    module = _finder.create_module(spec)
    module.__file__ = expected
    module.__loader__ = _finder
    module.__spec__ = spec
    module.__package__ = name if package else name.rpartition('.')[0]
    if package:
        module.__path__ = spec.submodule_search_locations
    previous = _s.modules.get(name)
    _s.modules[name] = module
    try:
        _finder.exec_module(module)
    except BaseException:
        if previous is None:
            _s.modules.pop(name, None)
        else:
            _s.modules[name] = previous
        raise
