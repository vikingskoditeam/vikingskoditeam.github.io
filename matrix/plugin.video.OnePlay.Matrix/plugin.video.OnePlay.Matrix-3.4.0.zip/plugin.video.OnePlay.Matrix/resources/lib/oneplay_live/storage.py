# -*- coding: utf-8 -*-
"""Bounded JSON cache writes shared by the Live modules."""
import json
import os
import tempfile


def write_json_atomic(path, value, max_bytes):
    raw = json.dumps(value, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    if len(raw) > max_bytes:
        raise ValueError('cache payload exceeds limit')
    fd, temporary = tempfile.mkstemp(prefix=os.path.basename(path) + '.', suffix='.tmp',
                                     dir=os.path.dirname(path))
    try:
        with os.fdopen(fd, 'wb') as handle:
            fd = None
            handle.write(raw)
        os.replace(temporary, path)
    finally:
        if fd is not None:
            os.close(fd)
        try:
            os.remove(temporary)
        except FileNotFoundError:
            pass
