# -*- coding: utf-8 -*-
import base64
import json
import os
import time
import zlib
from urllib.request import Request
import xbmc
import xbmcaddon
import xbmcvfs
from .proxy import cloudflare_urlopen
from .source_contract import api_headers
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
DATA = os.path.join(ROOT, 'resources', 'oneplay_live', 'data')
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
API_URL = 'https://embedtv.lat/api/channels'
API_MAX_BYTES = 2 * 1024 * 1024
_MEMO_DEADLINE = 0.0
_MEMO_ONLINE = False
CACHE_TTL = 5 * 60
_KEY = b'OPC9-data-4fA7!'
_BUNDLE_CACHE = None
_API_MEMO = None

_PRETTY = {1:'Esportes', 2:'Infantil', 3:'Documentários', 4:'Filmes e Séries', 5:'Notícias', 6:'TV Aberta', 7:'Variedades', 9:'Portugal'}
_DESCS = {
    'TV Aberta':'Emissoras abertas e afiliadas regionais com programação geral, jornalismo, entretenimento e eventos.',
    'Notícias':'Canais dedicados a notícias, informação, entrevistas e cobertura dos principais acontecimentos.',
    'Esportes':'Transmissões e programação esportiva, incluindo futebol, lutas, notícias e eventos ao vivo.',
    'Filmes e Séries':'Canais voltados a filmes, séries, dramaturgia e entretenimento ficcional.',
    'Infantil':'Programação infantil e familiar, com desenhos, animações e conteúdos para o público jovem.',
    'Documentários':'Documentários, história, ciência, natureza, viagens e conteúdos de conhecimento.',
    'Variedades':'Entretenimento, música, gastronomia, casa, estilo de vida e programação de variedades.',
    'Portugal':'Canais portugueses do catálogo, com foco principal em esportes e programação produzida em Portugal.',
    'Adulto':'Conteúdo adulto destinado exclusivamente a maiores de 18 anos.',
    '24 Horas':'Canais temáticos com programação contínua dedicada a uma série, desenho ou franquia específica.',
}
_CATEGORY_ORDER = ['TV Aberta','Notícias','Esportes','Filmes e Séries','Infantil','24 Horas','Documentários','Variedades','Portugal','Adulto']


# Classificação editorial exclusiva, mas presença de canais é soberania da API.
# Se /api/channels adicionar/remover um ID, o add-on acompanha automaticamente.
# Cada canal aparece em UMA única categoria principal; IDs novos usam a primeira
# categoria válida devolvida pela API, sem duplicação.
_NAME_OVERRIDES = {'ae':'A&E', 'warnerchannel':'Warner Channel'}

_PRIMARY_OVERRIDES = {
    'ae':'Variedades',
    'aparecida':'TV Aberta',
    'cancaonova':'TV Aberta',
    'discoveryhh':'Variedades',
    'gnt':'Variedades',
    'globonovelas':'Filmes e Séries',
    'hgtv':'Variedades',
    'mtv':'Variedades',
    'multishow':'Variedades',
    'off':'Esportes',
    'redevida':'TV Aberta',
    'sbtrj':'TV Aberta',
    'sbtsp':'TV Aberta',
    'tlc':'Variedades',
    'tvpaieterno':'TV Aberta',
}



def _log(msg, warning=False):
    xbmc.log('[ONEPLAY LIVE] API %s' % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _xor(raw, key):
    return bytes((b ^ key[i % len(key)]) for i, b in enumerate(raw))


def _bundle():
    global _BUNDLE_CACHE
    if _BUNDLE_CACHE is not None:
        return _BUNDLE_CACHE
    path = os.path.join(DATA, 'catalog.dat')
    try:
        with xbmcvfs.File(path, 'r') as fh:
            encoded = fh.read()
        if isinstance(encoded, str): encoded = encoded.encode('ascii')
        raw = zlib.decompress(_xor(base64.b85decode(encoded), _KEY))
        obj = json.loads(raw.decode('utf-8'))
        _BUNDLE_CACHE = obj if isinstance(obj, dict) else {}
    except Exception as exc:
        _log('falha carregando snapshot protegido: %s' % exc, True)
        _BUNDLE_CACHE = {}
    return _BUNDLE_CACHE


def _cache_path():
    return os.path.join(PROFILE, 'channels_api.cache')


def _valid_payload(obj):
    if not isinstance(obj, dict): return False
    categories=obj.get('categories'); channels=obj.get('channels')
    if not isinstance(categories,list) or not isinstance(channels,list): return False
    if len(channels) < 20 or len(channels) > 2000: return False
    ids=[]
    for ch in channels:
        if not isinstance(ch,dict): return False
        cid=str(ch.get('id') or '').strip()
        url=str(ch.get('url') or '').strip()
        if not cid or not url.startswith(('http://','https://')): return False
        ids.append(cid)
    return len(ids)==len(set(ids))


def _read_cache(fresh_only=False):
    path=_cache_path()
    try:
        if fresh_only and time.time()-os.path.getmtime(path) > CACHE_TTL: return None
        with open(path,'rb') as fh: data=fh.read(API_MAX_BYTES+1)
        if len(data)>API_MAX_BYTES: return None
        obj=json.loads(data.decode('utf-8'))
        return obj if _valid_payload(obj) else None
    except Exception:
        return None


def _write_cache(obj):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_cache_path(), obj, API_MAX_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _fetch_api():
    req=Request(API_URL,headers=api_headers(),method='GET')
    with cloudflare_urlopen(req,timeout=8) as response:
        data=response.read(API_MAX_BYTES+1)
        if len(data)>API_MAX_BYTES: raise ValueError('payload excedeu limite')
        obj=json.loads(data.decode('utf-8'))
        if not _valid_payload(obj): raise ValueError('schema/IDs/URLs inválidos')
        return obj


def _api_payload():
    global _API_MEMO, _MEMO_DEADLINE, _MEMO_ONLINE
    online = True
    now = time.monotonic()
    if _API_MEMO is not None and now < _MEMO_DEADLINE and (not online or _MEMO_ONLINE):
        return _API_MEMO
    _MEMO_DEADLINE = now + CACHE_TTL
    _MEMO_ONLINE = online
    fresh=_read_cache(True)
    if fresh is not None:
        _API_MEMO=fresh; return fresh
    try:
        live=_fetch_api(); _write_cache(live); _API_MEMO=live
        _log('catálogo atualizado canais=%d' % len(live.get('channels',[])))
        return live
    except Exception as exc:
        _log('API indisponível; usando contingência: %s' % exc, True)
    stale=_read_cache(False)
    if stale is not None:
        _API_MEMO=stale; return stale
    snap=_bundle().get('api_snapshot.json',{})
    if _valid_payload(snap):
        _API_MEMO=snap; return snap
    _API_MEMO={}; return _API_MEMO


def _normalize(payload):
    cmap={}
    for item in payload.get('categories',[]) if isinstance(payload,dict) else []:
        try: cid=int(item.get('id'))
        except Exception: continue
        if cid==0: continue
        name=_PRETTY.get(cid,str(item.get('name') or '').strip())
        if name: cmap[cid]=name
    channels=[]
    fallback_by_id={str(x.get('id')):x for x in _bundle().get('channels.json',[]) if isinstance(x,dict)}
    for raw in payload.get('channels',[]) if isinstance(payload,dict) else []:
        if not isinstance(raw,dict): continue
        cid=str(raw.get('id') or '').strip()
        if not cid: continue
        cats=[]
        for value in raw.get('categories') or []:
            try: name=cmap.get(int(value))
            except Exception: name=None
            if name and name not in cats: cats.append(name)
        # Categoria única e determinística. Portugal/24h/Adulto são famílias
        # exclusivas; IDs atuais com classificação ampla/incorreta recebem
        # correção explícita; demais IDs usam somente a primeira categoria API.
        if cid.startswith('24h_'):
            primary='24 Horas'
        elif cid.startswith('pt_'):
            primary='Portugal'
        elif cid in ('playboy','sexyhot'):
            primary='Adulto'
        elif cid in _PRIMARY_OVERRIDES:
            primary=_PRIMARY_OVERRIDES[cid]
        else:
            primary=cats[0] if cats else 'Outros'
        cats=[primary]
        # As descrições editoriais antigas dos canais foram removidas.
        # A interface passa a preencher o painel informativo exclusivamente
        # com EPG dinâmico de /api/epg_all.
        desc=''
        channels.append({
            'id':cid,
            'name':_NAME_OVERRIDES.get(cid, str(raw.get('name') or cid).strip()),
            'categories':cats,
            'category':cats[0] if cats else 'Outros',
            'description':desc,
            'image':str(raw.get('image') or '').strip(),
            'preview':str(raw.get('preview') or '').strip(),
            'api_url':str(raw.get('url') or '').strip(),
            'source_page':str(raw.get('url') or '').strip(),
            'stream_url':'',
            'headers':{},
        })
    return channels


class Catalog:
    def __init__(self):
        self._channels=_normalize(_api_payload())
        if not self._channels:
            # Contingência somente de catálogo/metadados. Mesmo que um bundle
            # antigo contenha stream_url(s), nunca os devolvemos ao player.
            rows=[]
            for raw in _bundle().get('channels.json',[]):
                if not isinstance(raw,dict): continue
                item=dict(raw)
                item['stream_url']=''
                item.pop('stream_urls',None)
                item['description']=''
                cid=str(item.get('id') or '').strip()
                if not cid:
                    continue
                item['name']=_NAME_OVERRIDES.get(cid, str(item.get('name') or cid).strip())
                existing=[str(x) for x in (item.get('categories') or []) if str(x)]
                if cid.startswith('24h_'):
                    primary='24 Horas'
                elif cid.startswith('pt_'):
                    primary='Portugal'
                elif cid in ('playboy','sexyhot'):
                    primary='Adulto'
                elif cid in _PRIMARY_OVERRIDES:
                    primary=_PRIMARY_OVERRIDES[cid]
                else:
                    primary=existing[0] if existing else str(item.get('category') or 'Outros')
                item['categories']=[primary]
                item['category']=primary
                api_url=str(item.get('api_url') or '').strip()
                item['source_page']=api_url
                item['headers']={}
                rows.append(item)
            self._channels=rows

    def channels(self):
        return list(self._channels)

    def categories(self):
        present=set()
        for c in self._channels:
            for name in c.get('categories') or [c.get('category','Outros')]:
                if name: present.add(name)
        ordered=[x for x in _CATEGORY_ORDER if x in present]
        return ordered+sorted(present-set(ordered))

    def category_description(self, category):
        return _DESCS.get(category,'')

    def by_category(self, category):
        return [c for c in self._channels if category in (c.get('categories') or [c.get('category')])]

    def get(self, channel_id):
        for c in self._channels:
            if c.get('id')==channel_id: return c
        return None

    def refresh_get(self, channel_id):
        """Força uma leitura live da API após falha de startup.

        Só retorna uma nova entrada do mesmo ID. Em erro, não inventa URL e não
        usa contrato legado; o chamador mantém a contingência já carregada.
        """
        global _API_MEMO
        try:
            live=_fetch_api()
            _write_cache(live)
            _API_MEMO=live
            _log('catálogo forçado atualizado canais=%d' % len(live.get('channels',[])))
            for item in _normalize(live):
                if item.get('id')==channel_id:
                    return item
        except Exception as exc:
            _log('refresh live falhou id=%s: %s' % (channel_id,exc), True)
        return None
