# cleanup.py
# -*- coding: utf-8 -*-
"""Controle seguro da limpeza automática dos APKs baixados pelo add-on.

Contrato:
- registra SOMENTE APKs concluídos pelo ONEPLAY APK DOWNLOADER;
- cada registro guarda a identidade da sessão do Kodi em que foi baixado;
- o serviço só remove registros pertencentes a sessões ANTERIORES;
- reiniciar/recarregar o serviço no mesmo Kodi nunca apaga APK da sessão atual;
- remove apenas arquivos na pasta Android Download cujo nome e tamanho ainda
  correspondam ao artefato registrado.
"""

import json
import os

import xbmc
import xbmcvfs

ADDON_ID = 'script.oneplayapk.downloader'
DOWNLOAD_DIR = '/storage/emulated/0/Download'
PROFILE_DIR = xbmcvfs.translatePath('special://profile/addon_data/%s/' % ADDON_ID)
STATE_FILE = os.path.join(PROFILE_DIR, 'cleanup_state.json')


def _log(message, level=None):
    try:
        xbmc.log(
            '[ONEPLAY APK Downloader][CLEANUP] %s' % message,
            level if level is not None else xbmc.LOGINFO,
        )
    except Exception:
        pass


def current_kodi_session_id():
    """Identidade estável no mesmo processo Kodi e diferente após reinício.

    Em Android/Linux, combina PID com o starttime de /proc/self/stat. O
    starttime evita falso positivo até no caso raro de o sistema reutilizar um
    mesmo PID em outra execução do Kodi. Se /proc não estiver disponível,
    usa o PID como fallback.
    """
    pid = os.getpid()
    try:
        with open('/proc/self/stat', 'r', encoding='ascii') as handle:
            raw = handle.read().strip()
        tail = raw[raw.rfind(')') + 2:].split()
        starttime = tail[19]  # campo 22; tail começa no campo 3
        return '%s:%s' % (pid, starttime)
    except Exception:
        return str(pid)


def _empty_state():
    return {'pending': []}


def _ensure_profile_dir():
    try:
        if not xbmcvfs.exists(PROFILE_DIR):
            xbmcvfs.mkdirs(PROFILE_DIR)
    except Exception:
        try:
            os.makedirs(PROFILE_DIR, exist_ok=True)
        except Exception:
            pass


def _load_state():
    try:
        if not os.path.isfile(STATE_FILE):
            return _empty_state()
        with open(STATE_FILE, 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        if not isinstance(data, dict):
            return _empty_state()
        pending = data.get('pending')
        if not isinstance(pending, list):
            pending = []
        return {'pending': pending}
    except Exception as exc:
        _log('Estado inválido; reiniciando controle: %s' % exc, xbmc.LOGWARNING)
        return _empty_state()


def _save_state(state):
    _ensure_profile_dir()
    temp_file = STATE_FILE + '.tmp'
    payload = {'pending': state.get('pending', [])}
    with open(temp_file, 'w', encoding='utf-8') as handle:
        json.dump(payload, handle, ensure_ascii=False, sort_keys=True, indent=2)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except Exception:
            pass
    os.replace(temp_file, STATE_FILE)


def _safe_filename(filename):
    if not isinstance(filename, str):
        return None
    filename = filename.strip()
    if not filename or filename in ('.', '..'):
        return None
    if filename != os.path.basename(filename):
        return None
    if '/' in filename or '\\' in filename:
        return None
    if not filename.lower().endswith('.apk'):
        return None
    return filename


def _managed_path(filename):
    filename = _safe_filename(filename)
    if not filename:
        return None
    return os.path.join(DOWNLOAD_DIR, filename)


def register_download(path):
    """Agenda um APK concluído para limpeza em uma sessão futura do Kodi."""
    try:
        normalized_dir = os.path.normpath(os.path.dirname(path))
        if normalized_dir != os.path.normpath(DOWNLOAD_DIR):
            _log('Registro recusado fora da pasta gerenciada: %s' % path, xbmc.LOGWARNING)
            return False

        filename = _safe_filename(os.path.basename(path))
        if not filename or not os.path.isfile(path):
            return False

        stat = os.stat(path)
        record = {
            'filename': filename,
            'size': int(stat.st_size),
            'session_id': current_kodi_session_id(),
        }

        state = _load_state()
        pending = []
        for item in state.get('pending', []):
            if not isinstance(item, dict) or item.get('filename') == filename:
                continue
            pending.append(item)
        pending.append(record)
        state['pending'] = pending
        _save_state(state)
        _log(
            'APK agendado para próxima sessão: %s (%d bytes, sessão=%s)'
            % (filename, stat.st_size, record['session_id'])
        )
        return True
    except Exception as exc:
        _log('Falha ao registrar APK para limpeza: %s' % exc, xbmc.LOGWARNING)
        return False


def cleanup_previous_sessions(current_session_id=None):
    """Remove somente APKs registrados por sessões anteriores do Kodi."""
    current_session_id = str(current_session_id or current_kodi_session_id())
    state = _load_state()
    stats = {
        'deleted': 0,
        'missing': 0,
        'preserved': 0,
        'failed': 0,
        'current_session': 0,
    }
    pending = []

    for record in state.get('pending', []):
        if not isinstance(record, dict):
            continue

        record_session = record.get('session_id')
        # Registros da sessão atual ficam intactos, mesmo que o serviço seja
        # iniciado/reiniciado depois do download.
        if record_session and str(record_session) == current_session_id:
            stats['current_session'] += 1
            pending.append(record)
            continue

        filename = _safe_filename(record.get('filename'))
        expected_size = record.get('size')
        path = _managed_path(filename) if filename else None
        if not path:
            stats['preserved'] += 1
            continue

        if not os.path.isfile(path):
            stats['missing'] += 1
            continue

        try:
            current_size = int(os.path.getsize(path))
        except Exception:
            current_size = None

        # Se o arquivo com mesmo nome mudou, deixa de ser considerado o mesmo
        # artefato que o add-on baixou e é preservado por segurança.
        if expected_size is not None and current_size != int(expected_size):
            stats['preserved'] += 1
            _log('Arquivo preservado porque mudou desde o download: %s' % filename, xbmc.LOGWARNING)
            continue

        try:
            os.remove(path)
            stats['deleted'] += 1
            _log('APK removido na inicialização do Kodi: %s' % filename)
        except Exception as exc:
            stats['failed'] += 1
            pending.append(record)
            _log('Falha ao remover %s; ficará pendente: %s' % (filename, exc), xbmc.LOGWARNING)

    state['pending'] = pending
    try:
        _save_state(state)
    except Exception as exc:
        _log('Falha ao atualizar estado após limpeza: %s' % exc, xbmc.LOGWARNING)

    _log(
        'Resumo: removidos=%d ausentes=%d preservados=%d falhas=%d sessão_atual=%d'
        % (
            stats['deleted'],
            stats['missing'],
            stats['preserved'],
            stats['failed'],
            stats['current_session'],
        )
    )
    return stats
