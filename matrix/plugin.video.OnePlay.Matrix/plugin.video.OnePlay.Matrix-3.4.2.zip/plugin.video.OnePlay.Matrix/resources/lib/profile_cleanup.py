# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Migração local e conservadora de resíduos pertencentes ao OnePlay Matrix.

Não cria configuração nova, não faz rede e não altera preferências atuais.
Executa antes de xbmcaddon.Addon() ler o perfil, remove duas chaves legadas,
temporários QR antigos e limita quarentenas de bancos comprovadamente corruptos.
"""

import os
import re
import time

try:
    from kodi_six import xbmcvfs
except ImportError:
    import xbmcvfs

_ADDON_ID = 'plugin.video.OnePlay.Matrix'
_QR_TEMP_PREFIX = 'oneplay_qrcode_'
_QR_TEMP_MAX_AGE_SECONDS = 24 * 3600
_CORRUPT_DATABASE_NAMES = ('oneplay_navigation_data.sqlite', 'm3u_navigation.sqlite')
_CORRUPT_GENERATIONS_TO_KEEP = 2


def _retired_ids():
    # Construção por partes evita manter os identificadores aposentados como
    # literais no pacote final; eles existem apenas em memória durante a migração.
    prefix = 'online' + '_' + 'counter' + '_'
    return (prefix + 'enabled', prefix + 'endpoint')


def _translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return path


def _atomic_write(path, data):
    tmp = path + '.oneplay-clean.tmp'
    try:
        with open(tmp, 'wb') as handle:
            handle.write(data)
            try:
                handle.flush()
                os.fsync(handle.fileno())
            except Exception:
                pass
        os.replace(tmp, path)
        return True
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass
        return False


def _clean_profile_settings():
    path = _translate('special://profile/addon_data/{}/settings.xml'.format(_ADDON_ID))
    if not path or not os.path.isfile(path):
        return False
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
    except Exception:
        return False
    if not raw:
        return False

    try:
        text = raw.decode('utf-8-sig')
    except Exception:
        try:
            text = raw.decode('utf-8')
        except Exception:
            return False

    original = text
    for setting_id in _retired_ids():
        escaped = re.escape(setting_id)
        # Kodi 19-21 costuma persistir como <setting id="...">valor</setting>,
        # mas a forma autocontida também é aceita defensivamente.
        pattern = (
            r'(?ms)^[ \t]*<setting\b(?=[^>]*\bid=["\']' + escaped +
            r'["\'])[^>]*(?:/>|>.*?</setting>)[ \t]*\r?\n?'
        )
        text = re.sub(pattern, '', text)

    if text == original:
        return False
    return _atomic_write(path, text.encode('utf-8'))


def _clean_python_cache():
    """Apaga apenas bytecode antigo que ainda contenha identificadores aposentados."""
    root = _translate('special://home/addons/{}/'.format(_ADDON_ID))
    if not root or not os.path.isdir(root):
        return False
    markers = [setting_id.encode('ascii') for setting_id in _retired_ids()]
    changed = False
    for current, _dirs, files in os.walk(root):
        for filename in files:
            if not filename.lower().endswith(('.pyc', '.pyo')):
                continue
            target = os.path.join(current, filename)
            try:
                with open(target, 'rb') as handle:
                    raw = handle.read()
                if not any(marker in raw for marker in markers):
                    continue
                os.remove(target)
                changed = True
            except Exception:
                pass
    return changed


def _clean_stale_qr_temps(now=None):
    """Remove somente PNGs temporários antigos criados pelo próprio diálogo QR."""
    root = _translate('special://profile/addon_data/{}/'.format(_ADDON_ID))
    if not root or not os.path.isdir(root):
        return False
    try:
        now = float(time.time() if now is None else now)
    except Exception:
        now = time.time()
    try:
        filenames = os.listdir(root)
    except Exception:
        return False
    changed = False
    for filename in filenames:
        if not (filename.startswith(_QR_TEMP_PREFIX) and filename.endswith('.png')):
            continue
        target = os.path.join(root, filename)
        try:
            if not os.path.isfile(target):
                continue
            if now - os.path.getmtime(target) < _QR_TEMP_MAX_AGE_SECONDS:
                continue
            os.remove(target)
            changed = True
        except Exception:
            pass
    return changed


def _quarantine_generation(filename, database_name):
    prefix = database_name + '.corrupt.'
    if not filename.startswith(prefix):
        return ''
    match = re.match(r'^(\d+\.\d+)(?:-(?:wal|shm|journal))?$', filename[len(prefix):])
    return match.group(1) if match else ''


def _clean_old_database_quarantines():
    """Mantém as duas quarentenas mais novas de cada banco e seus sidecars."""
    root = _translate('special://profile/addon_data/{}/navigation_cache'.format(_ADDON_ID))
    if not root or not os.path.isdir(root):
        return False
    try:
        filenames = os.listdir(root)
    except Exception:
        return False
    changed = False
    for database_name in _CORRUPT_DATABASE_NAMES:
        generations = {}
        for filename in filenames:
            generation = _quarantine_generation(filename, database_name)
            if generation:
                generations.setdefault(generation, []).append(filename)
        ordered = sorted(
            generations,
            key=lambda value: tuple(int(part) for part in value.split('.', 1)),
            reverse=True,
        )
        for generation in ordered[_CORRUPT_GENERATIONS_TO_KEEP:]:
            for filename in generations.get(generation, ()):
                target = os.path.join(root, filename)
                try:
                    if os.path.isfile(target):
                        os.remove(target)
                        changed = True
                except Exception:
                    pass
    return changed


def cleanup_retired_runtime_residue(clean_bytecode=False):
    """Limpa resíduos aposentados sem afetar configurações ou dados funcionais."""
    changed = False
    try:
        changed = _clean_profile_settings() or changed
    except Exception:
        pass
    try:
        changed = _clean_stale_qr_temps() or changed
    except Exception:
        pass
    try:
        changed = _clean_old_database_quarantines() or changed
    except Exception:
        pass
    if clean_bytecode:
        try:
            changed = _clean_python_cache() or changed
        except Exception:
            pass
    return changed
