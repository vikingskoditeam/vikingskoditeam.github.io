# -*- coding: utf-8 -*-
import sys
import os
import time
import json
import html
import calendar
import urllib.parse
import xml.etree.ElementTree as ET
import ntpath
from urllib.request import build_opener, install_opener, urlretrieve
import re
from datetime import datetime
import base64
import hashlib
import unicodedata
import traceback
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import requests

# =========================
# Configurações do Addon
# =========================
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_HANDLE = int(sys.argv[1])

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36'
HEADERS = {'User-Agent': USER_AGENT}

HOME = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
addonIcon = xbmcvfs.translatePath(os.path.join(HOME, 'icon.png'))
addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.jpg'))
if not xbmcvfs.exists(addonFanart):
    addonFanart = xbmcvfs.translatePath(os.path.join(HOME, 'fanart.png'))
from resources.lib.server_config import (
    DNS_LIST_B64,
    b64_decode as external_b64_decode,
    get_base_url as external_get_base_url,
    get_current_server_choice as external_get_current_server_choice,
    get_server_labels as external_get_server_labels,
    get_server_name as external_get_server_name,
    get_server_summary as external_get_server_summary,
    set_server_choice as external_set_server_choice,
)
from resources.lib import live_proxy as live_proxy_helper
QR_IMAGE_PATH = xbmcvfs.translatePath(os.path.join(HOME, 'resources', 'media', 'qr_whatsapp_paulo.png'))
SUPPORT_WHATSAPP = '(31) 99594-9574'
SUPPORT_CONTACT_LABEL = 'Suporte / WhatsApp'
APK_DOWNLOAD_FOLDER_ANDROID = '/storage/emulated/0/Download'
APK_ENTRIES_B64 = [('OnePlay Alpha - PRINCIPAL', 'aHR0cHM6Ly9vbmVwbGF5aGQuY29tL2Rvd25sb2FkL09uZVBsYXlBbHBoYS5hcGs='),]

USERNAME = ''
PASSWORD = ''
ENABLE_EPG = 'false'
ENABLE_GLOBAL_SEARCH = 'true'
ENABLE_FAVORITES = 'false'
ENABLE_ADULT = 'false'
ADULT_PIN = ''
DEFAULT_ADULT_PIN = '0000'
ADULT_SESSION_PROPERTY = f'{ADDON_ID}.adult_unlocked'
MENU_SETTINGS_DIRTY_PROPERTY = f'{ADDON_ID}.menu_settings_dirty'
SILENT_ACTION_MODES = {'download_apk', 'install_help'}

def set_menu_settings_dirty(value=True):
    try:
        win = xbmcgui.Window(10000)
        if value:
            win.setProperty(MENU_SETTINGS_DIRTY_PROPERTY, 'true')
        else:
            win.clearProperty(MENU_SETTINGS_DIRTY_PROPERTY)
    except Exception:
        pass

def is_menu_settings_dirty():
    try:
        return xbmcgui.Window(10000).getProperty(MENU_SETTINGS_DIRTY_PROPERTY) == 'true'
    except Exception:
        return False

def consume_menu_settings_dirty():
    dirty = is_menu_settings_dirty()
    if dirty:
        set_menu_settings_dirty(False)
    return dirty

def refresh_runtime_settings():
    global USERNAME, PASSWORD, ENABLE_EPG, ENABLE_GLOBAL_SEARCH, ENABLE_FAVORITES, ENABLE_ADULT, ADULT_PIN
    try:
        USERNAME = (ADDON.getSetting('username') or '').strip()
        PASSWORD = (ADDON.getSetting('password') or '').strip()
        ENABLE_EPG = (ADDON.getSetting('enable_epg') or 'false').lower()
        ENABLE_GLOBAL_SEARCH = (ADDON.getSetting('enable_global_search') or 'true').lower()
        ENABLE_FAVORITES = (ADDON.getSetting('enable_favorites') or 'false').lower()
        ENABLE_ADULT = (ADDON.getSetting('enable_adult') or 'false').lower()
        ADULT_PIN = get_adult_pin_value()
        if ENABLE_ADULT != 'true':
            try:
                xbmcgui.Window(10000).clearProperty(ADULT_SESSION_PROPERTY)
            except Exception:
                pass
    except Exception as e:
        log(f"Falha ao reler configurações: {e}", xbmc.LOGERROR)
        USERNAME = ''
        PASSWORD = ''
        ENABLE_EPG = 'false'
        ENABLE_GLOBAL_SEARCH = 'true'
        ENABLE_FAVORITES = 'false'
        ENABLE_ADULT = 'false'
        ADULT_PIN = DEFAULT_ADULT_PIN

def has_addon(addon_id):
    try:
        return xbmc.getCondVisibility(f'System.HasAddon({addon_id})')
    except Exception:
        return False

def strip_kodi_url_headers(url):
    try:
        return (url or '').split('|', 1)[0]
    except Exception:
        return url or ''

def ensure_play_url_headers(url, stream_kind=''):
    try:
        play = url or ''
        kind = str(stream_kind or '').lower()
        if kind == 'live' and is_live_proxy_enabled():
            return strip_kodi_url_headers(play)
        if play and 'User-Agent=' not in play:
            return play + '|User-Agent=' + USER_AGENT
        return play
    except Exception:
        return url or ''


def apply_video_info(list_item, info):
    info = info or {}
    try:
        tag = list_item.getVideoInfoTag()
    except Exception:
        tag = None
    try:
        title = info.get('title')
        if tag and title:
            try:
                tag.setTitle(str(title))
            except Exception:
                pass
        plot = info.get('plot')
        if tag and plot:
            try:
                tag.setPlot(str(plot))
            except Exception:
                pass
        mediatype = info.get('mediatype')
        if tag and mediatype:
            try:
                tag.setMediaType(str(mediatype))
            except Exception:
                pass
        if tag and (title or plot or mediatype):
            return
    except Exception:
        pass
    try:
        list_item.setInfo('video', info)
    except Exception:
        pass

def detect_stream_manifest_type(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if '.m3u8' in clean_url or 'output=m3u8' in clean_url or 'type=m3u8' in clean_url:
        return 'hls'
    if '.mpd' in clean_url:
        return 'mpd'
    return ''

def detect_stream_extension(url):
    clean_url = strip_kodi_url_headers(url).lower()
    if not clean_url:
        return ''
    base = clean_url.split('?', 1)[0].split('#', 1)[0]
    _, ext = os.path.splitext(base)
    return ext.lstrip('.')

def detect_stream_mime_type(url, stream_kind=''):
    manifest_type = detect_stream_manifest_type(url)
    if manifest_type == 'hls':
        return 'application/vnd.apple.mpegurl'
    if manifest_type == 'mpd':
        return 'application/dash+xml'

    ext = detect_stream_extension(url)
    if ext == 'ts':
        return 'video/mp2t'
    if ext == 'mp4':
        return 'video/mp4'
    if ext == 'mkv':
        return 'video/x-matroska'
    if ext == 'avi':
        return 'video/x-msvideo'
    if ext == 'mov':
        return 'video/quicktime'
    if ext == 'wmv':
        return 'video/x-ms-wmv'
    if ext == 'flv':
        return 'video/x-flv'
    if ext == 'webm':
        return 'video/webm'
    if ext == 'm4v':
        return 'video/x-m4v'
    if ext in ('mpg', 'mpeg'):
        return 'video/mpeg'

    if stream_kind == 'live':
        return 'video/mp2t'
    return ''

def configure_live_stream_listitem(li, url):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, 'live')

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Melhor caminho para live quando disponível: ffmpegdirect.
    # Se não existir, o Kodi cai no player nativo com mime correto.
    try:
        if has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream live: {e}", xbmc.LOGDEBUG)

def configure_vod_stream_listitem(li, url, stream_kind='vod'):
    manifest_type = detect_stream_manifest_type(url)
    mime_type = detect_stream_mime_type(url, stream_kind)
    ext = detect_stream_extension(url)

    try:
        li.setContentLookup(False)
    except Exception:
        pass

    if mime_type:
        try:
            li.setMimeType(mime_type)
        except Exception:
            pass

    # Arquivos diretos (mp4/mkv/avi...) ficam no player nativo.
    # HLS/DASH/TS ganham inputstream quando disponível.
    try:
        if (manifest_type or ext == 'ts') and has_addon('inputstream.ffmpegdirect'):
            li.setProperty('inputstream', 'inputstream.ffmpegdirect')
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'false')
            if manifest_type:
                li.setProperty('inputstream.ffmpegdirect.manifest_type', manifest_type)
    except Exception as e:
        log(f"Falha ao configurar inputstream VOD: {e}", xbmc.LOGDEBUG)

def b64_decode(text):
    return external_b64_decode(text, log_fn=lambda message: log(message, xbmc.LOGERROR))

def get_base_url():
    return external_get_base_url(ADDON, dns_list=DNS_LIST_B64, log_fn=lambda message: log(message, xbmc.LOGERROR))

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
MENU_TOGGLE_DEFAULTS_MARKER = os.path.join(PROFILE_DIR, '.menu_toggle_defaults_v016_all_off_applied')
LEGACY_EPG_XML_PATH = os.path.join(PROFILE_DIR, 'epg.xml')
LEGACY_EPG_META_PATH = os.path.join(PROFILE_DIR, 'epg_meta.json')
EPG_TTL = 24 * 3600

_EPG_PARSED = None
_EPG_PARSED_SCOPE = None

DESC_TTL = 7 * 24 * 3600
LEGACY_VOD_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'vod_desc_cache.json')
LEGACY_SERIES_DESC_CACHE_PATH = os.path.join(PROFILE_DIR, 'series_desc_cache.json')
LEGACY_SEARCH_STATE_PATH = os.path.join(PROFILE_DIR, 'search_state.json')
LEGACY_FAVORITES_PATH = os.path.join(PROFILE_DIR, 'favorites.json')
LEGACY_RESUME_POINTS_PATH = os.path.join(PROFILE_DIR, 'resume_points.json')
SCOPED_STORAGE_ROOT = os.path.join(PROFILE_DIR, 'profiles')
VALIDATED_SCOPE_STATE_PATH = os.path.join(PROFILE_DIR, '.validated_scope_state.json')
VOD_DESC_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.vod_desc_scoped_migrated')
SERIES_DESC_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.series_desc_scoped_migrated')
SEARCH_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.search_scoped_migrated')
FAVORITES_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.favorites_scoped_migrated')
RESUME_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.resume_scoped_migrated')
EPG_XML_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.epg_xml_scoped_migrated')
EPG_META_MIGRATION_MARKER = os.path.join(PROFILE_DIR, '.epg_meta_scoped_migrated')
MAX_RESUME_POINTS = 300
ADULT_PIN_FILE = os.path.join(PROFILE_DIR, 'adult_pin.txt')

def ensure_default_menu_toggle_state():
    try:
        if xbmcvfs.exists(MENU_TOGGLE_DEFAULTS_MARKER) or os.path.exists(MENU_TOGGLE_DEFAULTS_MARKER):
            return
    except Exception:
        pass

    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
    except Exception:
        try:
            if not xbmcvfs.exists(PROFILE_DIR):
                xbmcvfs.mkdirs(PROFILE_DIR)
        except Exception:
            pass

    try:
        ADDON.setSetting('enable_global_search', 'false')
        ADDON.setSetting('enable_favorites', 'false')
        ADDON.setSetting('enable_vod_resume', 'false')
        with open(MENU_TOGGLE_DEFAULTS_MARKER, 'w', encoding='utf-8') as fh:
            fh.write(str(int(time.time())))
    except Exception as e:
        try:
            log(f'Falha ao aplicar defaults dos ajustes do menu: {e}', xbmc.LOGDEBUG)
        except Exception:
            pass
ADULT_MARKERS = ('18+', '+18', '18 +', '+ 18', 'xxx', 'porn', 'porno', 'sex', 'adulttime', 'adulto', 'onlyfans', 'only fans', 'privacy', 'novinha', 'novinho', 'interracialsexx', 'mypervyfamily', 'brazzersexxtra', 'blacked raw', 'brad montana', 'mia khalifa', 'brasileirinhas')

def sanitize_adult_pin(value):
    value = ''.join(ch for ch in (value or '') if ch.isdigit())
    return value if len(value) == 4 else ''

def read_adult_pin_file():
    try:
        if not os.path.exists(ADULT_PIN_FILE):
            return ''
        with open(ADULT_PIN_FILE, 'r', encoding='utf-8') as fh:
            return sanitize_adult_pin(fh.read().strip())
    except Exception:
        return ''

def write_adult_pin_file(pin):
    pin = sanitize_adult_pin(pin)
    if not pin:
        return False
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
    except Exception:
        try:
            if not xbmcvfs.exists(PROFILE_DIR):
                xbmcvfs.mkdirs(PROFILE_DIR)
        except Exception:
            pass
    try:
        with open(ADULT_PIN_FILE, 'w', encoding='utf-8') as fh:
            fh.write(pin)
        return True
    except Exception:
        return False

def save_adult_pin(pin):
    pin = sanitize_adult_pin(pin)
    if not pin:
        return False
    saved = False
    try:
        ADDON.setSetting('adult_pin', pin)
        saved = True
    except Exception:
        pass
    if write_adult_pin_file(pin):
        saved = True
    return saved

def get_adult_pin_value():
    pin_from_file = read_adult_pin_file()
    pin_from_setting = sanitize_adult_pin(ADDON.getSetting('adult_pin') or '')
    current = pin_from_file or pin_from_setting or DEFAULT_ADULT_PIN

    if pin_from_file:
        if pin_from_setting != pin_from_file:
            try:
                ADDON.setSetting('adult_pin', pin_from_file)
            except Exception:
                pass
    elif pin_from_setting:
        write_adult_pin_file(pin_from_setting)
    else:
        save_adult_pin(current)

    return current
_TAG_RE = re.compile(r'<[^>]+>')

# =========================
# Utilitários
# =========================
def clear_desc_caches():
    try:
        vod_path = vod_desc_cache_storage_path()
        series_path = series_desc_cache_storage_path()
        if os.path.exists(vod_path):
            os.remove(vod_path)
        if os.path.exists(series_path):
            os.remove(series_path)
        log('Caches de sinopses do servidor atual limpos com sucesso.')
        return True
    except Exception as e:
        log(f"Falha ao limpar cache de sinopse: {e}", xbmc.LOGERROR)
        return False

def clear_search_cache():
    try:
        search_path = search_state_storage_path()
        if os.path.exists(search_path):
            os.remove(search_path)
        log('Estado de busca limpo com sucesso.')
        return True
    except Exception as exc:
        log(f'Falha ao limpar estado de busca: {exc}', xbmc.LOGERROR)
        return False

def clear_favorites_cache():
    try:
        favorites_path = favorites_storage_path()
        if os.path.exists(favorites_path):
            os.remove(favorites_path)
        log('Favoritos do servidor atual limpos com sucesso.')
        return True
    except Exception as exc:
        log(f'Falha ao limpar favoritos: {exc}', xbmc.LOGERROR)
        return False

def clear_resume_cache():
    try:
        resume_path = resume_points_storage_path()
        if os.path.exists(resume_path):
            os.remove(resume_path)
        log('Continue assistindo do servidor atual limpo com sucesso.')
        return True
    except Exception as exc:
        log(f'Falha ao limpar resume: {exc}', xbmc.LOGERROR)
        return False

def clear_epg_cache():
    global _EPG_PARSED, _EPG_PARSED_SCOPE
    try:
        xml_path = epg_xml_storage_path()
        meta_path = epg_meta_storage_path()
        if os.path.exists(xml_path):
            os.remove(xml_path)
        if os.path.exists(meta_path):
            os.remove(meta_path)
        _EPG_PARSED = None
        _EPG_PARSED_SCOPE = None
        log('EPG do servidor atual limpo com sucesso.')
        return True
    except Exception as exc:
        log(f'Falha ao limpar EPG: {exc}', xbmc.LOGERROR)
        return False

def clear_all_current_server_state():
    results = [
        clear_desc_caches(),
        clear_search_cache(),
        clear_resume_cache(),
        clear_epg_cache(),
        clear_favorites_cache(),
    ]
    return all(results)

def open_cleanup_dialog():
    options = [
        'Limpar cache de sinopses',
        'Limpar busca',
        'Limpar EPG',
        'Limpar Continue Assistindo',
        'Limpar Favoritos',
        'Limpar tudo do servidor atual',
    ]
    selected = xbmcgui.Dialog().select('Limpeza', options)
    if selected < 0:
        return False

    if selected == 0:
        ok = clear_desc_caches()
        if ok:
            notify('Cache de sinopses limpo.', heading='Limpeza', iconimage='INFO')
        else:
            show_dialog('Limpeza', 'Não foi possível limpar o cache de sinopses.')
        return ok

    if selected == 1:
        ok = clear_search_cache()
        if ok:
            notify('Busca limpa.', heading='Limpeza', iconimage='INFO')
        else:
            show_dialog('Limpeza', 'Não foi possível limpar a busca.')
        return ok

    if selected == 2:
        ok = clear_epg_cache()
        if ok:
            notify('EPG limpo.', heading='Limpeza', iconimage='INFO')
        else:
            show_dialog('Limpeza', 'Não foi possível limpar o EPG.')
        return ok

    if selected == 3:
        ok = clear_resume_cache()
        if ok:
            notify('Continue Assistindo limpo.', heading='Limpeza', iconimage='INFO')
        else:
            show_dialog('Limpeza', 'Não foi possível limpar o Continue Assistindo.')
        return ok

    if selected == 4:
        if not xbmcgui.Dialog().yesno('Limpeza', 'Deseja limpar os Favoritos do servidor atual?'):
            return False
        ok = clear_favorites_cache()
        if ok:
            notify('Favoritos limpos.', heading='Limpeza', iconimage='INFO')
        else:
            show_dialog('Limpeza', 'Não foi possível limpar os Favoritos.')
        return ok

    if not xbmcgui.Dialog().yesno('Limpeza', 'Deseja limpar tudo do servidor atual agora?'):
        return False
    ok = clear_all_current_server_state()
    if ok:
        notify('Limpeza do servidor atual concluída.', heading='Limpeza', iconimage='INFO')
    else:
        show_dialog('Limpeza', 'A limpeza foi parcial ou não pôde ser concluída.')
    return ok

def show_expire_popup(days_left, exp_date=None):
    if is_silent_action_mode():
        return

    if days_left is None:
        return

    try:
        warn_days = int(ADDON.getSetting('expire_warning_days')) + 1
    except Exception:
        warn_days = 3

    dialog = xbmcgui.Dialog()

    def center_text(text):
        # Adiciona linhas no topo e no final para simular centralização
        return "\n\n\n" + text + "\n\n\n"

    if days_left < 0:
        # Conta vencida
        message = center_text(
            "[COLOR red][B]SUA CONTA ESTÁ VENCIDA[/B][/COLOR]\n"
            "[COLOR white][B]Renove agora para continuar usando o serviço.[/B][/COLOR]"
        )
        dialog.ok("[COLOR white][B]CONTA VENCIDA[/B][/COLOR]", message)
        return

    if days_left <= warn_days:
        # Aviso de vencimento
        due_line = f"[COLOR white]Sua conta vence em: [B][COLOR yellow]{days_left} dia(s)[/COLOR][/B][/COLOR]"
        try:
            if days_left == 0 and exp_date:
                due_line = (
                    f"[COLOR white]Sua conta vence [B][COLOR yellow]hoje às {time.strftime('%H:%M', time.localtime(int(exp_date)))}[/COLOR][/B][/COLOR]"
                )
        except Exception:
            pass
        message = center_text(
            due_line + "\n"
            "[COLOR white]Evite bloqueio renovando com antecedência.[/COLOR]"
        )
        dialog.ok("[COLOR white][B]AVISO DE VENCIMENTO[/B][/COLOR]", message)

def color(text, color_name):
    return f"[COLOR {color_name}]{text}[/COLOR]"

def format_date(text):
    return color(text, 'lightblue')

def get_status_color(status):
    status = (status or '').lower()
    if status in ['active', 'ativo']:
        return 'lime'
    if status in ['expired', 'expirado', 'disabled']:
        return 'red'
    return 'orange'

def log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f"[{ADDON_ID}] {msg}", level)

refresh_runtime_settings()
ensure_default_menu_toggle_state()
refresh_runtime_settings()

def is_silent_action_mode():
    try:
        return mode in SILENT_ACTION_MODES
    except Exception:
        return False

def should_suppress_account_dialog(title=''):
    if not is_silent_action_mode():
        return False
    normalized = (title or '').strip().lower()
    blocked_titles = {
        'configuração necessária',
        'erro de acesso',
        'acesso bloqueado',
        'conta vencida',
        'erro de comunicação',
        'erro de conexão'
    }
    return normalized in blocked_titles

def settle_after_settings_action(delay_ms=350):
    if is_silent_action_mode():
        try:
            xbmc.sleep(int(delay_ms))
        except Exception:
            pass

def show_dialog(title, message):
    if should_suppress_account_dialog(title):
        log(f"Diálogo suprimido no modo {mode}: {title} - {message}", xbmc.LOGDEBUG)
        return False
    return xbmcgui.Dialog().ok(title, message)

def prompt_text_input(title, default='', hidden=False):
    try:
        keyboard = xbmc.Keyboard(default or '', title, bool(hidden))
        keyboard.doModal()
        if not keyboard.isConfirmed():
            return None
        return (keyboard.getText() or '').strip()
    except Exception as exc:
        log(f'Falha ao abrir teclado para {title}: {exc}', xbmc.LOGERROR)
        return None

def get_platform_name():
    try:
        if xbmc.getCondVisibility('system.platform.android'):
            return 'android'
        if xbmc.getCondVisibility('system.platform.windows'):
            return 'windows'
        if xbmc.getCondVisibility('system.platform.osx'):
            return 'osx'
        if xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
            return 'ios'
        if xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
            return 'linux'
    except Exception:
        pass
    return 'unknown'

def decode_b64_url(data):
    try:
        missing_padding = len(data or '') % 4
        if missing_padding:
            data += '=' * (4 - missing_padding)
        return base64.b64decode((data or '').encode('utf-8')).decode('utf-8')
    except Exception as e:
        log(f'Falha ao decodificar URL de APK: {e}', xbmc.LOGERROR)
        return ''

def get_apk_entries():
    items = []
    for name, b64_url in APK_ENTRIES_B64:
        url = decode_b64_url(b64_url)
        if url:
            items.append((name, url))
    return items

def notify(message, heading=None, iconimage=None, time_ms=3500, sound=False):
    heading = heading or ADDON.getAddonInfo('name')
    if iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    elif iconimage is None:
        iconimage = addonIcon
    xbmcgui.Dialog().notification(heading, message, iconimage, time_ms, sound=sound)

def normalize_bool(value):
    return str(value or '').strip().lower() in ('1', 'true', 'yes', 'on')

def is_global_search_enabled():
    return str(ENABLE_GLOBAL_SEARCH or '').strip().lower() == 'true'

def is_favorites_enabled():
    return str(ENABLE_FAVORITES or '').strip().lower() == 'true'

def is_menu_toggle_enabled(setting_id):
    try:
        return normalize_bool(ADDON.getSetting(setting_id))
    except Exception:
        return False

def set_menu_toggle(setting_id, enabled):
    try:
        ADDON.setSetting(setting_id, 'true' if normalize_bool(enabled) else 'false')
        refresh_runtime_settings()
        return True
    except Exception as exc:
        log(f'Falha ao salvar toggle {setting_id}: {exc}', xbmc.LOGERROR)
        return False

def colored_toggle_status(enabled):
    return '[COLOR lime]Ligado[/COLOR]' if normalize_bool(enabled) else '[COLOR red]Desligado[/COLOR]'

def render_account_connection_menu():
    build_menu(build_account_connection_items())
    return True

def render_root_menu():
    build_root_menu()
    return True

def refresh_container():
    try:
        xbmc.executebuiltin('Container.Refresh')
    except Exception:
        pass

def end_directory(cache_to_disc=True):
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=cache_to_disc)
    except TypeError:
        end_directory(cache_to_disc=True)

def show_install_apk_help(download_path=''):
    settle_after_settings_action(250)
    filename = ntpath.basename(download_path) if download_path else 'OnePlayAlpha.apk'
    lines = [
        '1. Feche o Kodi.',
        '2. Abra o gerenciador de arquivos do Android.',
        f'3. Vá até a pasta: [COLOR lime]Download / {filename}[/COLOR].',
        '4. Se o Android bloquear, libere [COLOR yellow]Instalar apps desconhecidos[/COLOR].',
        '5. Faça a instalação e abra o aplicativo.'
    ]
    xbmcgui.Dialog().ok('Como instalar o APK', '\n'.join(lines))

def select_apk_url():
    items = get_apk_entries()
    if not items:
        show_dialog('Download de APK', 'Nenhum APK disponível no momento.')
        return ''

    if len(items) == 1:
        return items[0][1]

    names = [name for name, _url in items]
    urls = [_url for _name, _url in items]
    selected = xbmcgui.Dialog().select('Selecione o APK para baixar', names)
    if selected < 0:
        return ''
    return urls[selected]

def download_progress_hook(numblocks, blocksize, filesize, dp):
    try:
        downloaded = numblocks * blocksize
        percent = int(min((downloaded * 100) / filesize, 100)) if filesize > 0 else 0
        elapsed = max(time.time() - download_progress_hook.start_time, 0.001)
        speed_kbps = (downloaded / elapsed) / 1024.0
        eta_seconds = ((filesize - downloaded) / (downloaded / elapsed)) if filesize > 0 and downloaded > 0 else 0
        downloaded_mb = float(downloaded) / (1024 * 1024)
        total_mb = float(filesize) / (1024 * 1024) if filesize > 0 else 0
        mins, secs = divmod(max(int(eta_seconds), 0), 60)
        message = (
            f'{downloaded_mb:.2f} MB de {total_mb:.2f} MB\n'
            f'[COLOR yellow]Velocidade:[/COLOR] {speed_kbps:.02f} KB/s  '
            f'[COLOR yellow]Tempo restante:[/COLOR] {mins:02d}:{secs:02d}'
        )
        dp.update(percent, message)
    except Exception:
        try:
            dp.update(0, 'Baixando arquivo...')
        except Exception:
            pass

    if dp.iscanceled():
        dp.close()
        raise Exception('Download cancelado pelo usuário.')

def perform_apk_download(url, destination_path):
    filename = ntpath.basename(url.split('?', 1)[0]) or 'OnePlayAlpha.apk'
    dp = xbmcgui.DialogProgress()
    dp.create(f'Baixando {filename}...', 'Por favor, aguarde...')
    try:
        opener = build_opener()
        opener.addheaders = [('User-Agent', USER_AGENT)]
        install_opener(opener)
        download_progress_hook.start_time = time.time()
        urlretrieve(url, destination_path, lambda nb, bs, fs: download_progress_hook(nb, bs, fs, dp))
        dp.update(100, 'Finalizando download...')
        return True
    except Exception as e:
        try:
            if xbmcvfs.exists(destination_path):
                xbmcvfs.delete(destination_path)
        except Exception:
            pass
        log(f'Falha no download do APK: {e}', xbmc.LOGERROR)
        notify('Erro ao baixar o APK', iconimage='ERROR')
        return False
    finally:
        try:
            dp.close()
        except Exception:
            pass

def handle_apk_download():
    settle_after_settings_action(400)

    if get_platform_name() != 'android':
        show_dialog('Download de APK', 'Esse recurso foi feito para Android.\nAbra este addon em um dispositivo android TV para baixar o APK direto.\n\n[B]Att: Paulo_OnePlay[/B]')
        return

    url = select_apk_url()
    if not url:
        return

    filename = ntpath.basename(url.split('?', 1)[0]) or 'OnePlayAlpha.apk'
    if not xbmcvfs.exists(APK_DOWNLOAD_FOLDER_ANDROID):
        xbmcvfs.mkdirs(APK_DOWNLOAD_FOLDER_ANDROID)

    destination_path = os.path.join(APK_DOWNLOAD_FOLDER_ANDROID, filename)

    try:
        if xbmcvfs.exists(destination_path):
            xbmcvfs.delete(destination_path)
    except Exception:
        pass

    if perform_apk_download(url, destination_path):
        try:
            xbmc.sleep(250)
        except Exception:
            pass

        xbmcgui.Dialog().ok(
            'Download concluído',
            '[COLOR yellow]APK baixado com sucesso.[/COLOR]\n'
            f'Arquivo salvo em:\n[COLOR lime]{destination_path}[/COLOR]\n\n'
            '[COLOR white]Toque em OK para ver as instruções de instalação.[/COLOR]'
        )

        try:
            xbmc.sleep(300)
        except Exception:
            pass
        show_install_apk_help(destination_path)

class QRCodeDialog(xbmcgui.WindowXMLDialog):
    CONTROL_IMAGE = 1001
    CONTROL_OK = 1002
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def __init__(self, *args, **kwargs):
        self.image_path = kwargs.pop('image_path', '')
        super().__init__(*args, **kwargs)

    def onInit(self):
        try:
            image_control = self.getControl(self.CONTROL_IMAGE)
            try:
                image_control.setImage(self.image_path, useCache=False)
            except TypeError:
                image_control.setImage(self.image_path)
        except Exception as e:
            log(f"Falha ao carregar imagem do QR no diálogo: {e}", xbmc.LOGERROR)

        try:
            self.setFocusId(self.CONTROL_OK)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == self.CONTROL_OK:
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = int(action)

        if action_id in (self.ACTION_PREVIOUS_MENU, self.ACTION_NAV_BACK, self.ACTION_BACKSPACE):
            self.close()
        else:
            super().onAction(action)

def show_qr_code():
    message = (
        "[B]Escaneie o QR Code para falar com o suporte[/B]\n\n"
        "[COLOR white]Se o QR não abrir, use o WhatsApp:[/COLOR]\n"
        f"[COLOR gold]{SUPPORT_WHATSAPP}[/COLOR]"
    )

    if xbmcvfs.exists(QR_IMAGE_PATH):
        try:
            dialog = QRCodeDialog('QRCodeDialog.xml', ADDON.getAddonInfo('path'), 'Default', '1080i', image_path=QR_IMAGE_PATH)
            dialog.doModal()
            del dialog
            return
        except Exception as e:
            log(f"Falha ao abrir QR Code em janela customizada: {e}", xbmc.LOGERROR)

    xbmcgui.Dialog().ok("QR Code", message)

def is_adult_name(text):
    lowered = (text or '').strip().lower()
    return bool(lowered and any(marker in lowered for marker in ADULT_MARKERS))

def is_adult_enabled():
    return ENABLE_ADULT.lower() == 'true'

def clear_adult_session():
    try:
        xbmcgui.Window(10000).clearProperty(ADULT_SESSION_PROPERTY)
    except Exception:
        pass

def prompt_current_adult_pin(title='Conteúdo Adulto'):
    expected = get_adult_pin_value()
    entered = xbmcgui.Dialog().input(title, type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if entered is None:
        return False
    return sanitize_adult_pin(entered) == expected

def ensure_adult_access(label='Conteúdo Adulto'):
    if not is_adult_enabled():
        show_dialog('Conteúdo Adulto', 'O conteúdo adulto está desativado nas configurações do addon.')
        return False
    if prompt_current_adult_pin(f'PIN Adulto - {label}'):
        return True
    show_dialog('Conteúdo Adulto', 'PIN inválido.')
    return False

def build_url(**kwargs):
    return sys.argv[0] + '?' + urllib.parse.urlencode(kwargs)

def ensure_profile_dir():
    try:
        os.makedirs(PROFILE_DIR, exist_ok=True)
    except Exception:
        try:
            if not xbmcvfs.exists(PROFILE_DIR):
                xbmcvfs.mkdirs(PROFILE_DIR)
        except Exception:
            pass

def ensure_parent_dir(path):
    try:
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
    except Exception:
        try:
            parent = os.path.dirname(path)
            if parent and not xbmcvfs.exists(parent):
                xbmcvfs.mkdirs(parent)
        except Exception:
            pass

def storage_identity_from_values(base_url='', username=''):
    base_url = (base_url or '').strip().rstrip('/').lower()
    username = (username or '').strip().lower()
    return f'{base_url}|{username}' if (base_url or username) else 'default'

def scope_name_from_identity(identity, base_url='', username=''):
    identity = (identity or '').strip() or 'default'
    if identity == 'default':
        return 'default'
    if not (base_url or username):
        try:
            base_url, username = identity.split('|', 1)
        except Exception:
            base_url, username = '', ''
    try:
        parsed = urllib.parse.urlparse((base_url or '').strip())
        host = parsed.netloc or parsed.path or 'server'
    except Exception:
        host = (base_url or '').strip() or 'server'
    safe_host = re.sub(r'[^A-Za-z0-9._-]+', '_', (host or 'server')).strip('._-') or 'server'
    safe_user = re.sub(r'[^A-Za-z0-9._-]+', '_', (username or 'user')).strip('._-') or 'user'
    digest = hashlib.sha1(identity.encode('utf-8')).hexdigest()[:10]
    return f'{safe_host}__{safe_user}__{digest}'

def remember_validated_scope_state(base_url='', username=''):
    try:
        identity = storage_identity_from_values(base_url, username)
        if identity == 'default':
            return False
        payload = {
            'identity': identity,
            'scope_name': scope_name_from_identity(identity, base_url, username),
            'updated_at': int(time.time())
        }
        ensure_profile_dir()
        with open(VALIDATED_SCOPE_STATE_PATH, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        log(f'Falha ao salvar estado do escopo validado: {exc}', xbmc.LOGDEBUG)
        return False

def server_slot_scope_name(server_idx=None):
    try:
        idx = get_current_server_choice() if server_idx is None else int(server_idx)
    except Exception:
        idx = 0
    if idx < 0:
        idx = 0
    return f'server_{idx + 1}'

def current_server_scope_identity():
    return server_slot_scope_name()

def server_slot_storage_path(filename, server_idx=None):
    return os.path.join(PROFILE_DIR, 'server_slot_storage', server_slot_scope_name(server_idx), filename)

def scoped_storage_path_from_values(filename, base_url='', username=''):
    identity = storage_identity_from_values(base_url, username)
    if identity == 'default':
        return ''
    scope_name = scope_name_from_identity(identity, base_url, username)
    return os.path.join(SCOPED_STORAGE_ROOT, scope_name, filename)

def maybe_migrate_server_slot_json(filename, legacy_path, default_payload, server_idx=None, base_url=None, username=None, log_label='dados'):
    target_path = server_slot_storage_path(filename, server_idx)
    try:
        ensure_profile_dir()
        ensure_parent_dir(target_path)
        if xbmcvfs.exists(target_path):
            return target_path

        base_url = (get_base_url() if base_url is None else base_url) or ''
        username = (USERNAME if username is None else username) or ''

        candidate_paths = []
        current_scoped_path = scoped_storage_path_from_values(filename, base_url, username)
        if current_scoped_path and current_scoped_path != target_path and xbmcvfs.exists(current_scoped_path):
            candidate_paths.append(current_scoped_path)
        if legacy_path and xbmcvfs.exists(legacy_path) and legacy_path not in candidate_paths:
            candidate_paths.append(legacy_path)

        for source_path in candidate_paths:
            data = load_json_file(source_path, default_payload)
            if data is None:
                continue
            if save_json_file(target_path, data):
                log(f'{log_label} migrados para escopo por servidor: {target_path}')
                return target_path
    except Exception as exc:
        log(f'Falha ao migrar {log_label} por servidor: {exc}', xbmc.LOGDEBUG)
    return target_path

def maybe_migrate_server_slot_file(filename, legacy_path, server_idx=None, base_url=None, username=None, log_label='arquivo'):
    target_path = server_slot_storage_path(filename, server_idx)
    try:
        ensure_profile_dir()
        ensure_parent_dir(target_path)
        if xbmcvfs.exists(target_path):
            return target_path

        base_url = (get_base_url() if base_url is None else base_url) or ''
        username = (USERNAME if username is None else username) or ''

        candidate_paths = []
        current_scoped_path = scoped_storage_path_from_values(filename, base_url, username)
        if current_scoped_path and current_scoped_path != target_path and xbmcvfs.exists(current_scoped_path):
            candidate_paths.append(current_scoped_path)
        if legacy_path and xbmcvfs.exists(legacy_path) and legacy_path not in candidate_paths:
            candidate_paths.append(legacy_path)

        for source_path in candidate_paths:
            try:
                if xbmcvfs.copy(source_path, target_path):
                    log(f'{log_label} migrado para escopo por servidor: {target_path}')
                    return target_path
            except Exception:
                continue
    except Exception as exc:
        log(f'Falha ao migrar {log_label} por servidor: {exc}', xbmc.LOGDEBUG)
    return target_path

def preserve_current_server_slot_state():
    try:
        current_idx = get_current_server_choice()
        current_base_url = get_base_url()
        current_username = USERNAME
        maybe_migrate_server_slot_json('favorites.json', LEGACY_FAVORITES_PATH, {'items': []}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Favoritos')
        maybe_migrate_server_slot_json('resume_points.json', LEGACY_RESUME_POINTS_PATH, {}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Resume')
        maybe_migrate_server_slot_json('vod_desc_cache.json', LEGACY_VOD_DESC_CACHE_PATH, {}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Cache VOD')
        maybe_migrate_server_slot_json('series_desc_cache.json', LEGACY_SERIES_DESC_CACHE_PATH, {}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Cache séries')
        maybe_migrate_server_slot_json('search_state.json', LEGACY_SEARCH_STATE_PATH, {}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Estado de busca')
        maybe_migrate_server_slot_json('epg_meta.json', LEGACY_EPG_META_PATH, {}, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='Meta EPG')
        maybe_migrate_server_slot_file('epg.xml', LEGACY_EPG_XML_PATH, server_idx=current_idx, base_url=current_base_url, username=current_username, log_label='EPG XML')
    except Exception as exc:
        log(f'Falha ao preservar estado do servidor atual: {exc}', xbmc.LOGDEBUG)

def preserve_current_server_favorites():
    preserve_current_server_slot_state()

def favorites_storage_path():
    return maybe_migrate_server_slot_json('favorites.json', LEGACY_FAVORITES_PATH, {'items': []}, log_label='Favoritos')

def resume_points_storage_path():
    return maybe_migrate_server_slot_json('resume_points.json', LEGACY_RESUME_POINTS_PATH, {}, log_label='Resume')

def vod_desc_cache_storage_path():
    return maybe_migrate_server_slot_json('vod_desc_cache.json', LEGACY_VOD_DESC_CACHE_PATH, {}, log_label='Cache VOD')

def series_desc_cache_storage_path():
    return maybe_migrate_server_slot_json('series_desc_cache.json', LEGACY_SERIES_DESC_CACHE_PATH, {}, log_label='Cache séries')

def search_state_storage_path():
    return maybe_migrate_server_slot_json('search_state.json', LEGACY_SEARCH_STATE_PATH, {}, log_label='Estado de busca')

def epg_xml_storage_path():
    return maybe_migrate_server_slot_file('epg.xml', LEGACY_EPG_XML_PATH, log_label='EPG XML')

def epg_meta_storage_path():
    return maybe_migrate_server_slot_json('epg_meta.json', LEGACY_EPG_META_PATH, {}, log_label='Meta EPG')

def load_json_file(path, default=None):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        if not xbmcvfs.exists(path):
            return default
        with open(path, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except Exception as exc:
        log(f'Falha ao ler JSON {path}: {exc}', xbmc.LOGDEBUG)
        return default

def save_json_file(path, data):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        with open(path, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        return True
    except Exception as exc:
        log(f'Falha ao salvar JSON {path}: {exc}', xbmc.LOGDEBUG)
        return False

def normalize_sort_text(text):
    try:
        text = str(text or '').strip().lower()
        text = unicodedata.normalize('NFKD', text)
        return ''.join(ch for ch in text if not unicodedata.combining(ch))
    except Exception:
        return str(text or '').strip().lower()

def favorite_prefix(kind):
    kind = (kind or '').strip().lower()
    if kind == 'live':
        return 'Canal:'
    if kind == 'vod':
        return 'Filme:'
    if kind == 'series':
        return 'Séries:'
    return ''

def favorite_base_title(kind, title):
    title = (title or 'Favorito').strip() or 'Favorito'
    known_prefixes = ['Canal:', 'Filme:', 'Série:', 'Séries:']
    for pref in known_prefixes:
        if title.startswith(pref):
            stripped = title[len(pref):].strip()
            if stripped:
                title = stripped
            break
    return title

def favorite_display_title(kind, title):
    title = favorite_base_title(kind, title)
    prefix = favorite_prefix(kind)
    return f'{prefix} {title}'.strip() if prefix else title

def is_vod_resume_enabled():
    try:
        return (ADDON.getSetting('enable_vod_resume') or 'false').lower() == 'true'
    except Exception:
        return False

def load_resume_points():
    data = load_json_file(resume_points_storage_path(), {})
    return data if isinstance(data, dict) else {}

def trim_resume_points(data):
    if not isinstance(data, dict):
        return {}
    if len(data) <= MAX_RESUME_POINTS:
        return data
    def _resume_sort_key(item):
        entry = item[1] if isinstance(item[1], dict) else {}
        try:
            updated_at = int(entry.get('updated_at') or 0)
        except Exception:
            updated_at = 0
        return updated_at
    trimmed = sorted(data.items(), key=_resume_sort_key, reverse=True)[:MAX_RESUME_POINTS]
    return {key: value for key, value in trimmed}

def save_resume_points(data):
    save_json_file(resume_points_storage_path(), trim_resume_points(data or {}))

def make_resume_key(stream_kind='', vod_id='', stream_id='', url=''):
    stream_kind = (stream_kind or '').strip().lower()
    vod_id = str(vod_id or '').strip()
    stream_id = str(stream_id or '').strip()
    clean_url = strip_kodi_url_headers(url).strip()
    if stream_kind == 'vod' and vod_id:
        return f'vod:{vod_id}'
    if stream_kind == 'episode':
        if stream_id:
            return f'episode:{stream_id}'
        if clean_url:
            return f'episode_url:{clean_url}'
    return ''

def get_resume_point(resume_key):
    if not resume_key:
        return None
    data = load_resume_points()
    entry = data.get(resume_key)
    return entry if isinstance(entry, dict) else None

def sanitize_resume_meta(meta):
    meta = meta if isinstance(meta, dict) else {}
    out = {}
    for key in ('url', 'icon', 'fanart', 'plot', 'normalplayer', 'stream_kind', 'container_extension', 'vod_id', 'series_id', 'stream_id', 'is_adult'):
        if key in meta and meta.get(key) not in (None, ''):
            out[key] = meta.get(key)
    if 'url' in out:
        out['url'] = str(out.get('url') or '').strip()
    if 'stream_kind' in out:
        out['stream_kind'] = str(out.get('stream_kind') or '').strip().lower()
    if 'normalplayer' in out:
        out['normalplayer'] = str(out.get('normalplayer') or 'false').lower()
    if 'is_adult' in out:
        out['is_adult'] = normalize_bool(out.get('is_adult', False))
    return out

def set_resume_point(resume_key, title, position, total, meta=None):
    if not resume_key:
        return
    try:
        position = float(position or 0)
        total = float(total or 0)
    except Exception:
        return
    if position <= 0 or total <= 0:
        return
    data = load_resume_points()
    existing = data.get(resume_key) if isinstance(data.get(resume_key), dict) else {}
    payload = dict(existing)
    payload.update({
        'title': title or existing.get('title', ''),
        'position': position,
        'total': total,
        'updated_at': int(time.time())
    })
    clean_meta = sanitize_resume_meta(meta)
    if clean_meta:
        payload.update(clean_meta)
    data[resume_key] = payload
    save_resume_points(data)

def resume_entry_is_active(entry):
    if not isinstance(entry, dict):
        return False
    try:
        position = float(entry.get('position') or 0)
        total = float(entry.get('total') or 0)
    except Exception:
        return False
    if position < 30:
        return False
    if total > 0 and position >= max(total - 120, total * 0.95):
        return False
    return True

def continue_resume_prefix(stream_kind):
    return 'Filme: ' if str(stream_kind or '').strip().lower() == 'vod' else 'Série: '

def list_continue_watching_items():
    data = load_resume_points()
    items = []
    legacy_count = 0
    for resume_key, entry in data.items():
        if not resume_entry_is_active(entry):
            continue
        stream_kind = str(entry.get('stream_kind') or '').strip().lower()
        if stream_kind not in ('vod', 'episode'):
            legacy_count += 1
            continue
        play_url = str(entry.get('url') or '').strip()
        if not play_url:
            legacy_count += 1
            continue
        title = str(entry.get('title') or 'Sem título').strip() or 'Sem título'
        title = favorite_base_title('series' if stream_kind == 'episode' else stream_kind, title)
        try:
            updated_at = int(entry.get('updated_at') or 0)
        except Exception:
            updated_at = 0
        try:
            position = float(entry.get('position') or 0)
            total = float(entry.get('total') or 0)
        except Exception:
            position = 0.0
            total = 0.0
        plot = str(entry.get('plot') or '').strip()
        progress_text = f'Continuar em: {format_resume_time(position)}'
        if total > 0:
            progress_text += f' de {format_resume_time(total)}'
        plot = f'{progress_text}\n\n{plot}' if plot else progress_text
        items.append({
            'resume_key': str(resume_key or ''),
            'title': continue_resume_prefix(stream_kind) + title,
            'play_title': title,
            'url': play_url,
            'icon': str(entry.get('icon') or addonIcon),
            'fanart': str(entry.get('fanart') or addonFanart),
            'plot': plot,
            'normalplayer': str(entry.get('normalplayer') or 'false').lower(),
            'stream_kind': stream_kind,
            'container_extension': str(entry.get('container_extension') or ''),
            'vod_id': str(entry.get('vod_id') or ''),
            'series_id': str(entry.get('series_id') or ''),
            'stream_id': str(entry.get('stream_id') or ''),
            'is_adult': normalize_bool(entry.get('is_adult', False)),
            'updated_at': updated_at,
            'position': position,
            'total': total
        })
    items.sort(key=lambda it: int(it.get('updated_at') or 0), reverse=True)
    return items, legacy_count
def return_to_enter_menu_with_message(title, message=''):
    if message:
        show_dialog(title, message)
    try:
        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
    except Exception as e:
        log(f"Falha ao retornar ao menu Enter com replace: {e}", xbmc.LOGERROR)
        build_menu(get_enter_menu_items())
    raise SystemExit

def build_continue_watching_menu():
    items, legacy_count = list_continue_watching_items()
    if not items:
        return_to_enter_menu_with_message('Continue Assistindo', 'Nenhum conteúdo em resume no momento.')
        return
    for item in items:
        label = item.get('title', '')
        play_title = item.get('play_title', label)
        li = xbmcgui.ListItem(label=label)
        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': label}
        plot = item.get('plot', '') or ''
        if plot:
            info['plot'] = plot
        if item.get('stream_kind') == 'vod':
            info['mediatype'] = 'movie'
        elif item.get('stream_kind') == 'episode':
            info['mediatype'] = 'episode'
        apply_video_info(li, info)
        li.setProperty('IsPlayable', 'true')
        cm = []
        resume_key = item.get('resume_key', '')
        if resume_key:
            cm_url = build_url(mode='clear_resume_entry', resume_key=resume_key)
            cm.append(('Remover de Continue Assistindo', f'RunPlugin({cm_url})'))
        if cm:
            li.addContextMenuItems(cm, replaceItems=False)
        play = ensure_play_url_headers(item.get('url', ''), item.get('stream_kind', ''))
        params = {
            'mode': 'play',
            'url': play,
            'title': play_title,
            'icon': icon,
            'fanart': fanart,
            'normalplayer': str(item.get('normalplayer', 'false')).lower(),
            'stream_kind': item.get('stream_kind', ''),
            'container_extension': item.get('container_extension', ''),
            'stream_id': str(item.get('stream_id', '') or ''),
            'is_adult': str(normalize_bool(item.get('is_adult', False))).lower(),
            'resume_key': resume_key
        }
        if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
            params['play_nonce'] = str(int(time.time() * 1000))
        if item.get('vod_id'):
            params['vod_id'] = str(item.get('vod_id'))
        if item.get('series_id'):
            params['series_id'] = str(item.get('series_id'))
        url = build_url(**params)
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
    end_directory(cache_to_disc=True)

def clear_resume_point(resume_key):
    if not resume_key:
        return
    data = load_resume_points()
    if resume_key in data:
        del data[resume_key]
        save_resume_points(data)

def format_resume_time(seconds):
    try:
        seconds = int(float(seconds or 0))
    except Exception:
        seconds = 0
    if seconds <= 0:
        return '00:00'
    h = seconds // 3600
    m = (seconds % 3600) // 60
    s = seconds % 60
    if h > 0:
        return f'{h:02d}:{m:02d}:{s:02d}'
    return f'{m:02d}:{s:02d}'

def prompt_resume_position(title, resume_entry, resume_key=''):
    if not isinstance(resume_entry, dict):
        return 0.0
    try:
        position = float(resume_entry.get('position') or 0)
        total = float(resume_entry.get('total') or 0)
    except Exception:
        return 0.0
    if position < 30:
        return 0.0
    if total > 0 and position >= max(total - 120, total * 0.95):
        return 0.0
    message = f'Deseja continuar de onde parou?\n\nParado em: {format_resume_time(position)}'
    if total > 0:
        message += f' de {format_resume_time(total)}'
    try:
        yes = xbmcgui.Dialog().yesno(title or 'Continuar assistindo', message, yeslabel='Continuar', nolabel='Do início')
    except Exception:
        yes = False
    if yes:
        return position
    clear_resume_point(resume_key)
    return 0.0

def monitor_and_persist_resume(player, resume_key, title='', meta=None):
    if not resume_key:
        return
    monitor = xbmc.Monitor()
    started = False
    last_pos = 0.0
    last_total = 0.0
    startup_deadline = time.time() + 20.0
    while not monitor.abortRequested() and time.time() < startup_deadline:
        try:
            if player.isPlayingVideo() or player.isPlaying():
                started = True
                break
        except Exception:
            pass
        if monitor.waitForAbort(0.25):
            return
    if not started:
        return
    while not monitor.abortRequested():
        try:
            if not (player.isPlayingVideo() or player.isPlaying()):
                break
            pos = float(player.getTime() or 0)
            total = float(player.getTotalTime() or 0)
            if pos > 0:
                last_pos = pos
            if total > 0:
                last_total = total
        except Exception:
            pass
        if monitor.waitForAbort(1.0):
            return
    if last_total > 0 and last_pos >= max(last_total - 120, last_total * 0.95):
        clear_resume_point(resume_key)
        return
    if last_pos >= 30 and (last_total <= 0 or last_pos < max(last_total - 30, last_total * 0.99)):
        set_resume_point(resume_key, title, last_pos, last_total, meta=meta)

def apply_resume_seek(player, resume_seconds):
    try:
        resume_seconds = float(resume_seconds or 0)
    except Exception:
        resume_seconds = 0.0
    if resume_seconds <= 0:
        return
    monitor = xbmc.Monitor()
    deadline = time.time() + 20.0
    while not monitor.abortRequested() and time.time() < deadline:
        try:
            if player.isPlayingVideo() or player.isPlaying():
                player.seekTime(resume_seconds)
                return
        except Exception:
            pass
        if monitor.waitForAbort(0.25):
            return

def favorites_load():
    data = load_json_file(favorites_storage_path(), {'items': []})
    if not isinstance(data, dict):
        data = {'items': []}
    items = data.get('items')
    data['items'] = items if isinstance(items, list) else []
    return data

def favorites_save(data):
    payload = {'items': []}
    if isinstance(data, dict):
        items = data.get('items')
        if isinstance(items, list):
            payload['items'] = items
    return save_json_file(favorites_storage_path(), payload)

def favorite_key(kind, item_id):
    kind = (kind or '').strip().lower()
    item_id = str(item_id or '').strip()
    if not kind or not item_id:
        return ''
    return f'{kind}:{item_id}'

def favorites_key_set():
    return {str(item.get('key', '')) for item in favorites_load().get('items', []) if str(item.get('key', '')).strip()}

def infer_favorite_kind(item):
    kind = (item.get('favorite_kind') or '').strip().lower()
    if kind in ('live', 'vod', 'series'):
        return kind
    if item.get('series_id'):
        return 'series'
    if item.get('stream_kind') == 'live':
        return 'live'
    if item.get('stream_kind') == 'vod' or item.get('vod_id') or item.get('stream_id'):
        return 'vod'
    return ''

def favorite_entry_from_item(item):
    kind = infer_favorite_kind(item)
    title = favorite_base_title(kind, html.unescape(item.get('favorite_title') or item.get('title') or '').strip())
    icon = item.get('icon', '') or ''
    fanart = item.get('fanart', addonFanart) or addonFanart
    plot = item.get('plot', '') or ''
    category_id = str(item.get('category_id', '') or '').strip()
    is_adult = normalize_bool(item.get('is_adult', False))

    if kind == 'live':
        stream_id = str(item.get('stream_id', '') or '').strip()
        if not stream_id:
            return None
        return {'key': favorite_key('live', stream_id), 'kind': 'live', 'title': title, 'stream_id': stream_id, 'epg_channel_id': str(item.get('epg_channel_id', '') or '').strip(), 'container_extension': 'm3u8', 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    if kind == 'vod':
        vod_id = str(item.get('vod_id') or item.get('stream_id') or '').strip()
        if not vod_id:
            return None
        ext = (item.get('container_extension') or 'mp4').lower()
        stream_type = (item.get('stream_type') or 'movie').strip() or 'movie'
        return {'key': favorite_key('vod', vod_id), 'kind': 'vod', 'title': title, 'vod_id': vod_id, 'stream_type': stream_type, 'container_extension': ext, 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    if kind == 'series':
        series_id = str(item.get('series_id', '') or '').strip()
        if not series_id:
            return None
        return {'key': favorite_key('series', series_id), 'kind': 'series', 'title': title, 'series_id': series_id, 'icon': icon, 'fanart': fanart, 'plot': plot, 'category_id': category_id, 'is_adult': is_adult, 'added_at': time.time()}

    return None

def favorite_entry_from_params(params):
    item = {'favorite_kind': params.get('fav_kind', ''), 'title': params.get('title', ''), 'favorite_title': params.get('favorite_title', ''), 'icon': params.get('icon', ''), 'fanart': params.get('fanart', addonFanart), 'plot': params.get('plot', ''), 'category_id': params.get('category_id', ''), 'is_adult': params.get('is_adult', 'false'), 'stream_id': params.get('stream_id', ''), 'vod_id': params.get('vod_id', ''), 'series_id': params.get('series_id', ''), 'container_extension': params.get('container_extension', ''), 'stream_type': params.get('stream_type', ''), 'stream_kind': params.get('stream_kind', ''), 'epg_channel_id': params.get('epg_channel_id', '')}
    return favorite_entry_from_item(item)

def add_favorite(entry):
    if not isinstance(entry, dict) or not entry.get('key'):
        return False
    data = favorites_load()
    items = [it for it in data.get('items', []) if str(it.get('key', '')) != entry['key']]
    items.insert(0, entry)
    data['items'] = items
    return favorites_save(data)

def remove_favorite(favorite_key_value):
    favorite_key_value = str(favorite_key_value or '').strip()
    if not favorite_key_value:
        return False
    data = favorites_load()
    items = data.get('items', [])
    new_items = [it for it in items if str(it.get('key', '')) != favorite_key_value]
    if len(new_items) == len(items):
        return False
    data['items'] = new_items
    return favorites_save(data)

def favorite_to_menu_item(fav):
    kind = (fav.get('kind') or '').strip().lower()
    title = fav.get('title', 'Favorito') or 'Favorito'
    icon = fav.get('icon', '') or addonIcon
    fanart = fav.get('fanart', addonFanart) or addonFanart
    plot = fav.get('plot', '') or ''
    category_id = str(fav.get('category_id', '') or '').strip()
    is_adult = normalize_bool(fav.get('is_adult', False))
    base_url = get_base_url().rstrip('/')

    if kind == 'live':
        stream_id = str(fav.get('stream_id', '') or '').strip()
        if not stream_id or not base_url or not USERNAME or not PASSWORD:
            return None
        return {'title': title, 'url': f'{base_url}/live/{USERNAME}/{PASSWORD}/{stream_id}.m3u8', 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'video', 'normalplayer': 'false', 'stream_kind': 'live', 'stream_id': stream_id, 'epg_channel_id': str(fav.get('epg_channel_id', '') or '').strip(), 'container_extension': 'm3u8', 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'live', 'favorite_key': fav.get('key', '')}

    if kind == 'vod':
        vod_id = str(fav.get('vod_id', '') or '').strip()
        stream_type = (fav.get('stream_type') or 'movie').strip() or 'movie'
        ext = (fav.get('container_extension') or 'mp4').lower()
        if not vod_id or not base_url or not USERNAME or not PASSWORD:
            return None
        return {'title': title, 'url': f'{base_url}/{stream_type}/{USERNAME}/{PASSWORD}/{vod_id}.{ext}', 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'movie', 'normalplayer': 'false', 'stream_kind': 'vod', 'stream_id': vod_id, 'vod_id': vod_id, 'container_extension': ext, 'stream_type': stream_type, 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'vod', 'favorite_key': fav.get('key', '')}

    if kind == 'series':
        series_id = str(fav.get('series_id', '') or '').strip()
        if not series_id:
            return None
        return {'title': title, 'mode': 'seasons', 'params': f"series_id={series_id}&category_id={urllib.parse.quote(category_id, safe='')}&is_adult={'true' if is_adult else 'false'}", 'icon': icon, 'fanart': fanart, 'plot': plot, 'media_type': 'tvshow', 'series_id': series_id, 'category_id': category_id, 'is_adult': is_adult, 'favorite_kind': 'series', 'favorite_key': fav.get('key', '')}

    return None

def list_favorites_items():
    items = []
    for fav in favorites_load().get('items', []):
        item = favorite_to_menu_item(fav)
        if not item:
            continue
        if item.get('is_adult') and not is_adult_enabled():
            continue
        item['display_title'] = favorite_display_title(item.get('favorite_kind') or infer_favorite_kind(item), item.get('title', 'Favorito'))
        items.append(item)
    items.sort(key=lambda it: normalize_sort_text(it.get('display_title') or it.get('title') or ''))
    return items

def build_favorites_menu():
    items = list_favorites_items()
    if not items:
        return_to_enter_menu_with_message('Favoritos', 'Nenhum favorito salvo no momento.')
        return

    favorite_keys = favorites_key_set() if is_favorites_enabled() else set()
    for item in items:
        label = item.get('display_title') or item.get('title', '')
        play_title = item.get('title', label)
        li = xbmcgui.ListItem(label=label)
        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        plot = item.get('plot', '') or ''
        info = {'title': label}
        if plot:
            info['plot'] = plot
        apply_video_info(li, info)
        favorite_key_value = item.get('favorite_key', '')
        cm = []
        if favorite_key_value and favorite_key_value in favorite_keys:
            cm_url = build_url(mode='remove_favorite', favorite_key=favorite_key_value, from_favorites='true')
            cm.append(('Remover dos Favoritos do Addon', f'RunPlugin({cm_url})'))
        if cm:
            li.addContextMenuItems(cm, replaceItems=False)

        if item.get('url'):
            play = ensure_play_url_headers(item['url'], item.get('stream_kind', ''))
            params = {'mode': 'play', 'url': play, 'title': play_title, 'icon': icon, 'fanart': fanart, 'normalplayer': str(item.get('normalplayer', 'false')).lower(), 'stream_kind': item.get('stream_kind', ''), 'container_extension': item.get('container_extension', ''), 'category_id': str(item.get('category_id', '') or ''), 'stream_id': str(item.get('stream_id', '') or ''), 'epg_channel_id': str(item.get('epg_channel_id', '') or ''), 'is_adult': str(normalize_bool(item.get('is_adult', False))).lower()}
            if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
                params['play_nonce'] = str(int(time.time() * 1000))
            if item.get('vod_id'):
                params['vod_id'] = str(item.get('vod_id'))
            if item.get('series_id'):
                params['series_id'] = str(item.get('series_id'))
            url = build_url(**params)
            li.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': item.get('mode', 'seasons')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, True)
    end_directory(cache_to_disc=True)

def load_search_state():
    try:
        ensure_profile_dir()
        search_path = search_state_storage_path()
        if not xbmcvfs.exists(search_path):
            return {}
        with open(search_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            return data if isinstance(data, dict) else {}
    except Exception as e:
        log(f"Falha ao ler estado da pesquisa: {e}", xbmc.LOGDEBUG)
        return {}

def save_search_state(data):
    try:
        ensure_profile_dir()
        search_path = search_state_storage_path()
        ensure_parent_dir(search_path)
        with open(search_path, 'w', encoding='utf-8') as f:
            json.dump(data or {}, f)
    except Exception as e:
        log(f"Falha ao salvar estado da pesquisa: {e}", xbmc.LOGDEBUG)

def remember_search(scope, query, results=None):
    state = load_search_state()
    state['last_scope'] = (scope or 'all').strip()
    state['last_query'] = (query or '').strip()
    if results is not None:
        state['last_results'] = results if isinstance(results, list) else []
    save_search_state(state)

def mark_resume_search(scope, query):
    state = load_search_state()
    state['resume_once'] = True
    state['last_scope'] = (scope or state.get('last_scope') or 'all').strip()
    state['last_query'] = (query or state.get('last_query') or '').strip()
    save_search_state(state)

def pop_resume_search():
    state = load_search_state()
    query = (state.get('last_query') or '').strip()
    scope = (state.get('last_scope') or 'all').strip()
    if state.get('resume_once') and query:
        state['resume_once'] = False
        save_search_state(state)
        cached_results = state.get('last_results')
        if isinstance(cached_results, list):
            return {'scope': scope, 'query': query, 'results': cached_results}
        return {'scope': scope, 'query': query}
    return None

def has_valid_credentials():
    return bool(USERNAME and PASSWORD and get_base_url())
def prompt_server_selection(title='Selecionar servidor'):
    current_idx = get_current_server_choice()
    labels = []
    for idx, label in enumerate(get_server_labels()):
        if idx == current_idx:
            labels.append(f'[COLOR lime]{label}[/COLOR]')
        else:
            labels.append(label)
    return xbmcgui.Dialog().select(title, labels)

def apply_login_settings(username, password, server_choice=None):
    try:
        preserve_current_server_favorites()
        ADDON.setSetting('username', (username or '').strip())
        ADDON.setSetting('password', (password or '').strip())
        if server_choice is not None:
            ADDON.setSetting('server_choice', str(int(server_choice)))
        refresh_runtime_settings()
        return True
    except Exception as exc:
        log(f'Falha ao salvar login: {exc}', xbmc.LOGERROR)
        return False

def clear_login_settings(keep_server=True):
    try:
        preserve_current_server_favorites()
        saved_server = get_current_server_choice()
        ADDON.setSetting('username', '')
        ADDON.setSetting('password', '')
        if keep_server:
            ADDON.setSetting('server_choice', str(saved_server))
        refresh_runtime_settings()
        return True
    except Exception as exc:
        log(f'Falha ao limpar login: {exc}', xbmc.LOGERROR)
        return False

def probe_player_api(endpoint='', base_url=None, username=None, password=None):
    base_url = (base_url if base_url is not None else get_base_url()) or ''
    username = (username if username is not None else USERNAME) or ''
    password = (password if password is not None else PASSWORD) or ''
    base_url = base_url.strip()
    username = username.strip()
    password = password.strip()

    if not all([base_url, username, password]):
        return None, 'missing_config', 'Configure usuário, senha e servidor para continuar.'

    query = urllib.parse.urlencode({'username': username, 'password': password})
    url = f"{base_url.rstrip('/')}/player_api.php?{query}"
    if endpoint:
        url += f"&{endpoint}"

    try:
        r = safe_requests_get(url)
        raw = (r.text or '').strip()
        if not raw:
            return None, 'login', 'O servidor respondeu vazio para esse acesso.'

        try:
            data = r.json()
        except ValueError:
            raw_lower = raw.lower()
            if (
                '<html' in raw_lower or
                'access denied' in raw_lower or
                'unauthorized' in raw_lower or
                'invalid' in raw_lower or
                'username' in raw_lower or
                'password' in raw_lower
            ):
                return None, 'login', 'Não foi possível entrar. Verifique usuário, senha e servidor.'
            return None, 'invalid_response', 'O servidor respondeu em formato inválido.'

        user_info = data.get('user_info', {}) if isinstance(data, dict) else {}
        auth = str(user_info.get('auth', '1')).strip()
        status = str(user_info.get('status', '')).strip().lower()

        if auth == '0':
            return None, 'login', 'Não foi possível entrar. Verifique usuário, senha e servidor.'
        if status in ['disabled', 'banned']:
            return None, 'blocked', 'Sua conta está bloqueada ou desativada.'
        if status in ['expired', 'expirado']:
            return None, 'expired', 'Sua conta está vencida.'

        remember_validated_scope_state(base_url, username)
        return data, '', ''
    except requests.RequestException as exc:
        try:
            status_code = exc.response.status_code if getattr(exc, 'response', None) else None
        except Exception:
            status_code = None
        if status_code == 429:
            return None, 'rate_limit', 'Muitas requisições para a API. Tente novamente em instantes.'
        if status_code in (401, 403):
            return None, 'login', 'Não foi possível entrar. Verifique usuário, senha e servidor.'
        return None, 'connection', 'Não foi possível comunicar com o servidor.'

def show_probe_result_dialog(error_type='', error_message=''):
    title, message = probe_result_message(error_type, error_message)
    xbmcgui.Dialog().ok(title, message)

def show_server_test_result(server_idx, data, error_type='', error_message=''):
    server_info = get_server_summary(server_idx)
    if data:
        user_info = data.get('user_info', {}) if isinstance(data, dict) else {}
        status = str(user_info.get('status', 'ativo') or 'ativo')
        exp_date = user_info.get('exp_date', 0)
        days_left = days_until_expire(exp_date)
        lines = [
            f'[B]{server_info}[/B]',
            '',
            '[COLOR lime]Conexão OK[/COLOR]',
            f'Status: {status}',
        ]
        if days_left is not None:
            lines.append(f'Dias restantes: {days_left}')
        xbmcgui.Dialog().ok('Teste de servidor', '\n'.join(lines))
        return
    title, message = probe_result_message(error_type, error_message)
    xbmcgui.Dialog().ok(title, f'[B]{server_info}[/B]\n\n{message}')

def run_quick_setup_wizard():
    while True:
        selected_server = prompt_server_selection('Configuração Rápida - Servidor')
        if selected_server < 0:
            return False

        server_name = get_server_name(selected_server)

        username = prompt_text_input('Usuário', USERNAME or '', hidden=False)
        if username is None:
            return False
        if not username:
            show_dialog('Configuração Rápida', 'Informe o usuário para continuar.')
            continue

        password = prompt_text_input('Senha', PASSWORD or '', hidden=True)
        if password is None:
            return False
        if not password:
            show_dialog('Configuração Rápida', 'Informe a senha para continuar.')
            continue

        base_url = b64_decode(DNS_LIST_B64[selected_server]).strip()
        data, error_type, error_message = probe_player_api('', base_url=base_url, username=username, password=password)
        if data:
            if apply_login_settings(username, password, selected_server):
                notify('Acesso salvo com sucesso.', heading='Configuração Rápida', iconimage='INFO')
                return True
            show_dialog('Configuração Rápida', 'Não foi possível salvar os dados informados.')
            return False

        title, message = probe_result_message(error_type, error_message)
        if not xbmcgui.Dialog().yesno(title, f'{message}\n\nDeseja tentar novamente neste servidor ({server_name})?'):
            return False

def run_change_credentials_wizard():
    current_server = get_server_name()
    while True:
        username = prompt_text_input('Novo usuário', USERNAME or '', hidden=False)
        if username is None:
            return False
        if not username:
            show_dialog('Trocar Login e Senha', 'Informe o usuário para continuar.')
            continue

        password = prompt_text_input('Nova senha', PASSWORD or '', hidden=True)
        if password is None:
            return False
        if not password:
            show_dialog('Trocar Login e Senha', 'Informe a senha para continuar.')
            continue

        data, error_type, error_message = probe_player_api('', username=username, password=password)
        if data:
            if apply_login_settings(username, password):
                return True
            show_dialog('Trocar Login e Senha', 'Não foi possível salvar o novo login.')
            return False

        title, message = probe_result_message(error_type, error_message)
        retry_message = message + chr(10) + chr(10) + f'Deseja tentar novamente no servidor atual ({current_server})?'
        if not xbmcgui.Dialog().yesno(title, retry_message):
            return False

def run_access_retry_wizard():
    while True:
        selected_server = prompt_server_selection('Verificar acesso - Servidor')
        if selected_server < 0:
            return False

        username = prompt_text_input('Usuário', USERNAME or '', hidden=False)
        if username is None:
            return False
        if not username:
            show_dialog('Erro de acesso', 'Informe o usuário para continuar.')
            continue

        password = prompt_text_input('Senha', PASSWORD or '', hidden=True)
        if password is None:
            return False
        if not password:
            show_dialog('Erro de acesso', 'Informe a senha para continuar.')
            continue

        base_url = b64_decode(DNS_LIST_B64[selected_server]).strip()
        data, error_type, error_message = probe_player_api('', base_url=base_url, username=username, password=password)
        if data:
            if apply_login_settings(username, password, selected_server):
                notify('Acesso atualizado com sucesso.', heading='Acesso', iconimage='INFO')
                return True
            show_dialog('Erro de acesso', 'Não foi possível salvar os dados informados.')
            return False

        show_probe_result_dialog(error_type, error_message)

def switch_server_interactive():
    previous_choice = get_current_server_choice()
    while True:
        selected_server = prompt_server_selection('Trocar Servidor')
        if selected_server < 0:
            return False
        preserve_current_server_favorites()
        if not set_server_choice(selected_server):
            show_dialog('Servidor', 'Não foi possível salvar o servidor selecionado.')
            return False

        if not (USERNAME and PASSWORD):
            notify(f'Servidor padrão alterado para {get_server_name(selected_server)}.', heading='Servidor', iconimage='INFO')
            return True

        base_url = b64_decode(DNS_LIST_B64[selected_server]).strip()
        data, error_type, error_message = probe_player_api('', base_url=base_url, username=USERNAME, password=PASSWORD)
        if data:
            notify(f'{get_server_name(selected_server)} ativo e validado.', heading='Servidor', iconimage='INFO')
            return True

        title, message = probe_result_message(error_type, error_message)
        keep_choice = xbmcgui.Dialog().yesno(title, f'{message}\n\nManter {get_server_name(selected_server)} como servidor atual?')
        if keep_choice:
            return False
        set_server_choice(previous_choice)
        if not xbmcgui.Dialog().yesno('Servidor', 'Deseja escolher outro servidor agora?'):
            return False

def test_current_server():
    if not has_valid_credentials():
        show_dialog('Teste de servidor', 'Configure usuário, senha e servidor antes de testar a conexão.')
        return False
    current_idx = get_current_server_choice()
    base_url = b64_decode(DNS_LIST_B64[current_idx]).strip()
    data, error_type, error_message = probe_player_api('', base_url=base_url, username=USERNAME, password=PASSWORD)
    show_server_test_result(current_idx, data, error_type, error_message)
    return bool(data)

def test_all_servers():
    if not has_valid_credentials():
        show_dialog('Teste de servidores', 'Configure usuário, senha e servidor antes de testar.')
        return False

    progress = xbmcgui.DialogProgress()
    results = []
    try:
        progress.create('Teste de servidores', 'Validando servidores salvos...')
        for idx, _entry in enumerate(DNS_LIST_B64):
            if progress.iscanceled():
                break
            percent = int(((idx + 1) / max(1, len(DNS_LIST_B64))) * 100)
            progress.update(percent, f'Testando {get_server_name(idx)}...')
            base_url = b64_decode(DNS_LIST_B64[idx]).strip()
            data, error_type, error_message = probe_player_api('', base_url=base_url, username=USERNAME, password=PASSWORD)
            results.append((idx, bool(data), error_type or '', error_message or ''))
        progress.close()
    except Exception:
        try:
            progress.close()
        except Exception:
            pass

    if not results:
        return False

    lines = []
    for idx, ok, error_type, error_message in results:
        status_text = '[COLOR lime]OK[/COLOR]' if ok else '[COLOR red]FALHA[/COLOR]'
        extra = ''
        if not ok:
            _title, msg = probe_result_message(error_type, error_message)
            extra = f' - {msg}'
        lines.append(f'{get_server_summary(idx)}: {status_text}{extra}')
    xbmcgui.Dialog().textviewer('Teste de servidores', '\n'.join(lines))
    return True

def build_account_connection_items():
    current_server = get_server_summary()
    return [
        {
            'title': 'Informações da Conta',
            'mode': 'account_info',
            'plot': 'Mostra status da conta, validade, criação e limite de conexões.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': f'Servidor Atual: {current_server}',
            'mode': 'test_current_server',
            'plot': f'Testa a conexão com o servidor atual. Atual: {current_server}.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': 'Trocar Servidor',
            'mode': 'switch_server',
            'plot': 'Troca o servidor mantendo o usuário e a senha já salvos.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': 'Trocar Login e Senha',
            'mode': 'change_credentials',
            'plot': 'Troca somente o usuário e a senha, mantendo o servidor atual selecionado.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': 'Testar Todos os Servidores',
            'mode': 'test_all_servers',
            'plot': 'Valida todos os servidores configurados usando o login salvo.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': 'Limpeza',
            'mode': 'cleanup_tools',
            'plot': 'Limpa caches e estados do servidor atual.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': 'Sair da Conta',
            'mode': 'logout',
            'plot': 'Remove usuário e senha salvos e volta ao menu inicial do addon.',
            'fanart': addonFanart,
            'folder': False,
        },
    ]

def open_enter_menu_from_data(data, suppress_expire=False):
    user_info = (data or {}).get('user_info', {}) if isinstance(data, dict) else {}
    exp_date = user_info.get('exp_date', 0)
    days_left = days_until_expire(exp_date)
    if not suppress_expire:
        show_expire_popup(days_left, exp_date)
    cache_to_disc = not consume_menu_settings_dirty()
    build_menu(get_enter_menu_items(), cache_to_disc=cache_to_disc)
    return True

def try_open_enter_menu(suppress_expire=False):
    refresh_runtime_settings()
    if not has_valid_credentials():
        return False, 'missing_config', 'Configure usuário, senha e servidor para continuar.'
    data, error_type, error_message = probe_player_api('')
    if not data:
        return False, error_type, error_message
    open_enter_menu_from_data(data, suppress_expire=suppress_expire)
    return True, '', ''

def run_menu_settings_dialog():
    allowed_settings = [
        ('enable_global_search', 'Pesquisa Global'),
        ('enable_favorites', 'Favoritos'),
        ('enable_vod_resume', 'Continue Assistindo'),
    ]
    changed = False

    while True:
        refresh_runtime_settings()
        labels = []
        for setting_id, setting_label in allowed_settings:
            labels.append(f'{setting_label}: {colored_toggle_status(is_menu_toggle_enabled(setting_id))}')

        selected = xbmcgui.Dialog().select('Ajustes do Menu', labels)
        if selected < 0:
            break

        setting_id, setting_label = allowed_settings[selected]
        current_value = is_menu_toggle_enabled(setting_id)
        new_value = not current_value
        if set_menu_toggle(setting_id, new_value):
            changed = True
            status_text = 'ligado' if new_value else 'desligado'
            notify(f'{setting_label}: {status_text}.', heading='Ajustes do Menu', iconimage='INFO')
        else:
            show_dialog('Ajustes do Menu', f'Não foi possível alterar {setting_label}.')

    return changed

def get_server_labels():
    return external_get_server_labels(dns_list=DNS_LIST_B64)

def get_current_server_choice():
    return external_get_current_server_choice(ADDON, dns_list=DNS_LIST_B64)

def get_server_name(idx=None):
    return external_get_server_name(ADDON, idx=idx, dns_list=DNS_LIST_B64)

def get_server_summary(idx=None):
    return external_get_server_summary(ADDON, idx=idx, dns_list=DNS_LIST_B64)

def set_server_choice(choice_idx):
    return external_set_server_choice(
        ADDON,
        choice_idx,
        dns_list=DNS_LIST_B64,
        refresh_fn=refresh_runtime_settings,
        log_fn=lambda message: log(message, xbmc.LOGERROR),
    )

def is_live_proxy_enabled():
    return live_proxy_helper.is_live_proxy_enabled(ADDON)

def set_live_proxy_enabled(enabled):
    return live_proxy_helper.set_live_proxy_enabled(ADDON, enabled, log_fn=lambda message, level=xbmc.LOGERROR: log(message, level))

def ensure_live_proxy_started():
    return live_proxy_helper.ensure_live_proxy_started(log_fn=lambda message, level=xbmc.LOGERROR: log(message, level))

def stop_live_proxy_if_running():
    return live_proxy_helper.stop_live_proxy_if_running(log_fn=lambda message, level=xbmc.LOGDEBUG: log(message, level))

def wrap_live_url_with_proxy(url):
    return live_proxy_helper.wrap_live_url_with_proxy(
        url,
        ADDON,
        strip_kodi_url_headers,
        log_fn=lambda message, level=xbmc.LOGERROR: log(message, level),
    )

def probe_result_message(error_type, fallback_message=''):
    fallback_message = (fallback_message or '').strip()
    mapping = {
        'missing_config': ('Configuração necessária', 'Configure usuário, senha e servidor para continuar.'),
        'login': ('Erro de acesso', 'Não foi possível entrar. Verifique usuário, senha e servidor.'),
        'blocked': ('Acesso bloqueado', 'Sua conta está bloqueada ou desativada.'),
        'expired': ('Conta vencida', 'Sua conta está vencida.'),
        'invalid_response': ('Erro de comunicação', 'O servidor respondeu em formato inválido.'),
        'rate_limit': ('Erro 429', 'Muitas requisições para a API. Tente novamente em instantes.'),
        'connection': ('Erro de conexão', 'Não foi possível comunicar com o servidor.'),
    }
    title, default_message = mapping.get(error_type or '', ('Erro', 'Não foi possível concluir a operação.'))
    return title, fallback_message or default_message

def build_root_menu():
    current_server = get_server_summary()
    items = []
    if has_valid_credentials():
        items.append({
            'title': 'Acesso e Servidor',
            'mode': 'account_connection_menu',
            'plot': f'Gerencie login, servidor e testes de conexão. Atual: {current_server}.',
            'fanart': addonFanart,
        })
    else:
        items.append({
            'title': 'Configuração Rápida',
            'mode': 'quick_setup',
            'plot': 'Configure servidor, usuário e senha num fluxo guiado.',
            'fanart': addonFanart,
            'folder': False,
        })
    items.extend([
        {
            'title': 'Configurações',
            'mode': 'settings',
            'plot': 'Abra as configurações nativas do addon para opções estruturais e técnicas.',
            'fanart': addonFanart,
            'folder': False,
        },
        {
            'title': SUPPORT_CONTACT_LABEL,
            'mode': 'show_qr',
            'plot': 'Abra o QR Code / WhatsApp de suporte.',
            'fanart': addonFanart,
            'folder': False,
        },
    ])
    build_menu(items)

def get_param_map():
    params = {}
    if len(sys.argv) > 2 and sys.argv[2]:
        parsed = urllib.parse.urlparse(sys.argv[2])
        q = urllib.parse.parse_qs(parsed.query, keep_blank_values=True)
        for k, v in q.items():
            params[k] = v[0] if isinstance(v, list) else v
    return params

def get_param(name, default=""):
    return PARAMS.get(name, default)

def fingerprint():
    BASE_URL = get_base_url()
    return f"{BASE_URL}|{USERNAME}|{PASSWORD}"

def safe_requests_get(url, **kw):
    kw.setdefault('headers', HEADERS)
    kw.setdefault('timeout', 30)

    retries = int(kw.pop('retries', 2))
    backoff = float(kw.pop('backoff', 1.0))
    last_exc = None
    for attempt in range(retries + 1):
        try:
            r = requests.get(url, **kw)
            if r.status_code == 429 and attempt < retries:
                time.sleep(backoff * (2 ** attempt))
                continue
            r.raise_for_status()
            return r
        except requests.RequestException as e:
            last_exc = e
            if isinstance(e, requests.HTTPError):
                resp = getattr(e, 'response', None)
                if resp is not None and resp.status_code == 429 and attempt < retries:
                    time.sleep(backoff * (2 ** attempt))
                    continue
            break
    raise last_exc if last_exc else requests.RequestException("Falha na requisição")

def open_settings_after_error(context='erro'):
    if is_silent_action_mode():
        log(f"Abertura de configurações suprimida no modo {mode} após {context}", xbmc.LOGDEBUG)
        return
    try:
        ADDON.openSettings()
        refresh_runtime_settings()
        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
        raise SystemExit
    except SystemExit:
        raise
    except Exception as exc:
        log(f"Falha ao abrir configurações após {context}: {exc}", xbmc.LOGERROR)
        try:
            xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
            raise SystemExit
        except SystemExit:
            raise
        except Exception as ret_exc:
            log(f"Falha ao retornar ao menu Enter após {context}: {ret_exc}", xbmc.LOGERROR)

def show_settings_error(title, message, context='erro de configuração'):
    if mode in ('download_apk', 'install_help'):
        log(f"Aviso de configuração suprimido no modo {mode}: {title} - {message}", xbmc.LOGDEBUG)
        return
    xbmcgui.Dialog().ok(title, message)
    open_settings_after_error(context)

def show_login_error(open_settings=True):
    if mode in ('download_apk', 'install_help'):
        log(f"Aviso de login suprimido no modo {mode}", xbmc.LOGDEBUG)
        return
    msg = (
        "[B][COLOR red]Não foi possível entrar[/COLOR][/B]\n\n"
        "[COLOR white]Verifique se o [B]usuário[/B], a [B]senha[/B] e o [B]servidor[/B] estão corretos.[/COLOR]\n\n"
        "[COLOR gold]Dicas:[/COLOR]\n"
        "[COLOR white]• Confirme se não há espaço extra no login[/COLOR]\n"
        "[COLOR white]• Verifique se a conta ainda está ativa[/COLOR]\n"
        "[COLOR white]• Confira se o servidor selecionado é o certo[/COLOR]"
    )
    xbmcgui.Dialog().ok("Erro de acesso", msg)
    if open_settings:
        open_settings_after_error('erro de login')

def get_json(endpoint):
    data, error_type, error_message = probe_player_api(endpoint)
    if data is not None:
        return data

    if error_type == 'missing_config':
        show_settings_error('Configuração necessária', 'Configure: usuário, senha e servidor nas configurações.', 'configuração necessária')
    elif error_type == 'login':
        show_login_error()
    elif error_type == 'blocked':
        show_settings_error('Acesso bloqueado', 'Sua conta está bloqueada ou desativada.\nConfira o usuário/servidor ou entre em contato com o suporte.', 'acesso bloqueado')
    elif error_type == 'expired':
        show_settings_error('Conta vencida', 'Sua conta está vencida.\nRenove ou confira o usuário/servidor para continuar.', 'conta vencida')
    elif error_type == 'invalid_response':
        show_settings_error('Erro de comunicação', 'O servidor respondeu em formato inválido.\nVerifique o usuário/senha ou servidor e tente novamente.', 'erro de comunicação')
    elif error_type == 'rate_limit':
        show_dialog('Erro 429', 'Muitas requisições para a API.\nTente novamente em instantes.')
    else:
        show_settings_error('Erro de conexão', 'Não foi possível comunicar com o servidor.\nVerifique o usuário/senha ou servidor e tente novamente.', 'erro de conexão')
    return None

# =========================
# Descrições (helpers + cache)
# =========================
def clean_plot(text):
    text = html.unescape(text or '')
    text = _TAG_RE.sub('', text)
    return text.strip()

def desc_cache_load(path):
    ensure_profile_dir()
    ensure_parent_dir(path)
    if os.path.exists(path):
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f) or {}
        except Exception:
            return {}
    return {}

def desc_cache_save(path, cache):
    try:
        ensure_profile_dir()
        ensure_parent_dir(path)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(cache, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar cache de descrições: {e}", xbmc.LOGERROR)

def desc_cache_get(cache, key):
    k = str(key)
    e = cache.get(k)
    if not isinstance(e, dict):
        return (False, '')
    fetched_at = e.get('fetched_at', 0)
    if not fetched_at or (time.time() - fetched_at) > DESC_TTL:
        return (False, '')
    return (True, e.get('plot', '') or '')

def desc_cache_put(cache, key, plot):
    cache[str(key)] = {'plot': plot or '', 'fetched_at': time.time()}

def extract_vod_plot(vod_info_json):
    if not isinstance(vod_info_json, dict):
        return ''
    info = vod_info_json.get('info') or {}
    movie_data = vod_info_json.get('movie_data') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or movie_data.get('plot')
        or movie_data.get('description')
        or ''
    )
    return clean_plot(plot)

def extract_series_plot(series_info_json):
    if not isinstance(series_info_json, dict):
        return ''
    info = series_info_json.get('info') or {}
    plot = (
        info.get('plot')
        or info.get('description')
        or info.get('overview')
        or ''
    )
    return clean_plot(plot)

def get_vod_plot_cached(vod_id):
    cache = desc_cache_load(vod_desc_cache_storage_path())
    has, plot = desc_cache_get(cache, vod_id)
    if has:
        return plot

    vod_info = get_json(f"action=get_vod_info&vod_id={vod_id}")
    plot = extract_vod_plot(vod_info)
    desc_cache_put(cache, vod_id, plot)
    desc_cache_save(vod_desc_cache_storage_path(), cache)
    return plot

def get_series_plot_cached(series_id):
    cache = desc_cache_load(series_desc_cache_storage_path())
    has, plot = desc_cache_get(cache, series_id)
    if has:
        return plot

    series_info = get_json(f"action=get_series_info&series_id={series_id}")
    plot = extract_series_plot(series_info)
    desc_cache_put(cache, series_id, plot)
    desc_cache_save(series_desc_cache_storage_path(), cache)
    return plot

# =========================
# EPG (cache + parsing)
# =========================
def epg_meta_load():
    meta_path = epg_meta_storage_path()
    if os.path.exists(meta_path):
        try:
            with open(meta_path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except Exception:
            return {}
    return {}

def epg_meta_save(meta):
    try:
        meta_path = epg_meta_storage_path()
        ensure_parent_dir(meta_path)
        with open(meta_path, 'w', encoding='utf-8') as f:
            json.dump(meta, f, ensure_ascii=False, indent=2)
    except Exception as e:
        log(f"Falha ao salvar meta EPG: {e}", xbmc.LOGERROR)

def epg_should_refresh():
    meta = epg_meta_load()
    fp = fingerprint()
    meta_fp = meta.get('fingerprint')
    fetched_at = meta.get('fetched_at', 0)
    if meta_fp != fp:
        log("Fingerprint mudou (usuário/senha/servidor). Renovando EPG e limpando caches.")
        clear_desc_caches()
        return True
    epg_xml_path = epg_xml_storage_path()
    if not os.path.exists(epg_xml_path):
        log("EPG não existe. Baixando.")
        return True
    if (time.time() - fetched_at) >= EPG_TTL:
        log("EPG expirado. Renovando.")
        return True
    return False

def epg_build_urls():
    base_url = get_base_url().rstrip('/')
    return [
        (f"{base_url}/xmltv.php?username={USERNAME}&password={PASSWORD}", 'principal'),
        (f"{base_url}/epg.php?username={USERNAME}&password={PASSWORD}", 'fallback')
    ]

def epg_validate_xml_text(xml_text):
    if not xml_text:
        return False, 'resposta vazia'
    text = xml_text.strip()
    if len(text) < 32:
        return False, 'resposta muito curta'
    if not text.startswith('<'):
        return False, 'resposta não parece XML'
    try:
        root = ET.fromstring(text)
    except Exception as e:
        return False, f'xml inválido: {e}'
    if root.tag not in ('tv', 'xmltv', 'epg'):
        # Alguns provedores usam <tv>; qualquer raiz com programme/channel também serve.
        has_epg_nodes = bool(root.findall('.//channel') or root.findall('.//programme'))
        if not has_epg_nodes:
            return False, f'raiz XML inesperada: {root.tag}'
    has_programmes = bool(root.findall('.//programme'))
    has_channels = bool(root.findall('.//channel'))
    if not has_programmes and not has_channels:
        return False, 'XML sem canais nem programas'
    return True, 'ok'

def epg_download():
    ensure_profile_dir()
    last_error = None
    epg_xml_path = epg_xml_storage_path()
    ensure_parent_dir(epg_xml_path)

    for url, label in epg_build_urls():
        try:
            log(f"Baixando EPG ({label}): {url}")
            r = safe_requests_get(url)
            xml_text = r.text
            valid, reason = epg_validate_xml_text(xml_text)
            if not valid:
                log(f"EPG {label} rejeitado: {reason}", xbmc.LOGWARNING)
                last_error = reason
                continue
            with open(epg_xml_path, 'w', encoding='utf-8') as f:
                f.write(xml_text)
            epg_meta_save({'fingerprint': fingerprint(), 'fetched_at': time.time(), 'source': label})
            log(f"EPG salvo com sucesso pela fonte {label}")
            return
        except Exception as e:
            last_error = str(e)
            log(f"Falha ao baixar EPG ({label}): {e}", xbmc.LOGWARNING)

    raise Exception(last_error or 'falha desconhecida ao baixar EPG')

XMLTV_DEFAULT_OFFSET_SECS = -(3 * 3600)  # America/Sao_Paulo quando o feed vier sem timezone
EPG_BOUNDARY_TOLERANCE_SECS = 300  # tolera pequenos buracos/atrasos de grade e virada de bloco

def normalize_epoch_seconds(value):
    try:
        if value is None:
            return 0
        if isinstance(value, str):
            value = value.strip()
            if not value:
                return 0
        epoch = int(float(value))
    except Exception:
        return 0

    # Alguns painéis/feeds misturam segundos e milissegundos no mesmo XMLTV.
    # Se vier 13+ dígitos, normaliza para segundos.
    if epoch > 99999999999:
        epoch = epoch // 1000

    return epoch if epoch > 0 else 0

def parse_xmltv_time(ts):
    if not ts:
        return int(time.time())
    ts = ts.strip()
    if len(ts) < 14 or not ts[:14].isdigit():
        log(f"Timestamp XMLTV inválido: {ts}")
        return int(time.time())

    base = ts[:14]
    try:
        dt = datetime.strptime(base, "%Y%m%d%H%M%S")
    except Exception:
        return int(time.time())

    offset_secs = XMLTV_DEFAULT_OFFSET_SECS
    rest = ts[14:].strip()
    if rest:
        rest = rest.replace(' ', '')
        if rest.startswith(('+', '-')) and len(rest) >= 5:
            try:
                sign = 1 if rest[0] == '+' else -1
                hh = int(rest[1:3])
                mm = int(rest[3:5])
                offset_secs = sign * (hh * 3600 + mm * 60)
            except Exception:
                offset_secs = XMLTV_DEFAULT_OFFSET_SECS
        else:
            log(f"XMLTV sem timezone reconhecível, assumindo America/Sao_Paulo: {ts}")
    else:
        log(f"XMLTV sem timezone, assumindo America/Sao_Paulo: {ts}")

    epoch = calendar.timegm(dt.timetuple()) - offset_secs
    return epoch if epoch > 0 else int(time.time())

def normalize_epg_channel_id(cid):
    if not cid:
        return ''
    return cid.strip().lower().replace('&amp;', '&')

def epg_load_parsed():
    global _EPG_PARSED, _EPG_PARSED_SCOPE

    current_scope = current_server_scope_identity()
    if _EPG_PARSED is not None and _EPG_PARSED_SCOPE == current_scope:
        return _EPG_PARSED

    if epg_should_refresh():
        try:
            epg_download()
        except Exception as e:
            log(f"Falha ao baixar EPG: {e}", xbmc.LOGERROR)
            _EPG_PARSED = {'channels': {}, 'progs': {}}
            _EPG_PARSED_SCOPE = current_scope
            return _EPG_PARSED

    epg_xml_path = epg_xml_storage_path()
    if not os.path.exists(epg_xml_path):
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        _EPG_PARSED_SCOPE = current_scope
        return _EPG_PARSED

    try:
        tree = ET.parse(epg_xml_path)
        root = tree.getroot()

        channels = {}
        progs = {}

        for c in root.findall(".//channel"):
            cid = normalize_epg_channel_id(c.get('id'))
            dn = (c.findtext('display-name') or '').strip()
            channels[cid] = dn

        for p in root.findall(".//programme"):
            cid = normalize_epg_channel_id(p.get('channel'))

            start = normalize_epoch_seconds(p.get('start_timestamp'))
            if start <= 0:
                start = parse_xmltv_time(p.get('start'))

            stop = normalize_epoch_seconds(p.get('stop_timestamp') or p.get('end_timestamp'))
            if stop <= 0:
                stop = parse_xmltv_time(p.get('stop') or p.get('end'))

            if stop <= start:
                stop = start + 3600

            title = (p.findtext('title') or '').strip()
            desc = (p.findtext('desc') or '').strip()

            if cid not in progs:
                progs[cid] = []

            progs[cid].append({'start': start, 'end': stop, 'title': title, 'desc': desc})

        for cid, arr in progs.items():
            arr.sort(key=lambda x: x['start'])

        _EPG_PARSED = {'channels': channels, 'progs': progs}
        _EPG_PARSED_SCOPE = current_scope
        log(f"EPG carregado: canais={len(channels)}, programas={sum(len(v) for v in progs.values())}")
    except Exception as e:
        log(f"Erro parseando EPG: {e}", xbmc.LOGERROR)
        _EPG_PARSED = {'channels': {}, 'progs': {}}
        _EPG_PARSED_SCOPE = current_scope

    return _EPG_PARSED

def epg_lookup_current_next(epg_channel_id, epg):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    tolerance = max(0, int(EPG_BOUNDARY_TOLERANCE_SECS or 0))

    plist = epg['progs'].get(cid, [])
    current, nextp = None, None

    for i, pr in enumerate(plist):
        start = normalize_epoch_seconds(pr.get('start')) or now
        end = normalize_epoch_seconds(pr.get('end')) or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end

        if (start - tolerance) <= now < (end + tolerance):
            current = pr
            if i + 1 < len(plist):
                nextp = plist[i + 1]
            break
        if start > now:
            nextp = pr
            if i - 1 >= 0 and normalize_epoch_seconds(plist[i - 1].get('end')) >= (now - tolerance):
                current = plist[i - 1]
            break

    return current, nextp

def epg_lookup_day_schedule(epg_channel_id, epg, limit=12, include_current=False):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    tolerance = max(0, int(EPG_BOUNDARY_TOLERANCE_SECS or 0))
    end_of_day = int(datetime.fromtimestamp(now).replace(hour=23, minute=59, second=59, microsecond=0).timestamp())

    plist = epg['progs'].get(cid, [])
    out = []

    for pr in plist:
        start = normalize_epoch_seconds(pr.get('start')) or now
        end = normalize_epoch_seconds(pr.get('end')) or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end

        if end < (now - tolerance):
            continue
        if start > end_of_day:
            break
        if not include_current and (start - tolerance) <= now < (end + tolerance):
            continue

        out.append(pr)
        if len(out) >= max(0, int(limit or 0)):
            break

    return out

def epg_lookup_next_day_preview(epg_channel_id, epg, limit=3, after_hour=23):
    cid = normalize_epg_channel_id(epg_channel_id)
    now = int(time.time())
    now_dt = datetime.fromtimestamp(now)
    if int(now_dt.hour) < max(0, int(after_hour or 0)):
        return []

    end_of_day = int(now_dt.replace(hour=23, minute=59, second=59, microsecond=0).timestamp())
    tolerance = max(0, int(EPG_BOUNDARY_TOLERANCE_SECS or 0))
    plist = epg['progs'].get(cid, [])
    out = []

    for pr in plist:
        start = normalize_epoch_seconds(pr.get('start')) or now
        end = normalize_epoch_seconds(pr.get('end')) or (start + 3600)
        if end <= start:
            end = start + 3600
        pr['start'] = start
        pr['end'] = end

        if end <= (end_of_day - tolerance):
            continue
        if start <= end_of_day:
            continue

        out.append(pr)
        if len(out) >= max(0, int(limit or 0)):
            break

    return out

# =========================
# UI (menus)
# =========================
def build_menu(items, mode=None, is_playable=False, cache_to_disc=True):
    if not items:
        end_directory(cache_to_disc=cache_to_disc)
        return

    favorite_keys = favorites_key_set() if is_favorites_enabled() else set()

    for item in items:
        label = item.get('title', '')
        li = xbmcgui.ListItem(label=label)

        icon = item.get('icon', addonIcon) or addonIcon
        fanart = item.get('fanart', addonFanart) or addonFanart
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)

        plot = item.get('plot', '') or ''
        info = {'title': label}
        if plot:
            info['plot'] = plot
        apply_video_info(li, info)

        media_type = item.get('media_type') or ''
        if media_type:
            try:
                li.setProperty('mediatype', media_type)
            except Exception:
                pass

        item_is_adult = normalize_bool(item.get('is_adult', False))
        cm = []
        if item.get('vod_id'):
            cm_url = build_url(mode='show_vod_plot', vod_id=str(item['vod_id']), title=label, category_id=str(item.get('category_id', '') or ''), is_adult=str(item_is_adult).lower())
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))
        if item.get('series_id'):
            cm_url = build_url(mode='show_series_plot', series_id=str(item['series_id']), title=label, category_id=str(item.get('category_id', '') or ''), is_adult=str(item_is_adult).lower())
            cm.append(("Sinopse", f'RunPlugin({cm_url})'))

        favorite_entry = favorite_entry_from_item(item) if is_favorites_enabled() else None
        favorite_key_value = favorite_entry.get('key', '') if favorite_entry else ''
        favorite_kind = infer_favorite_kind(item) if is_favorites_enabled() else ''
        if is_favorites_enabled() and favorite_kind and favorite_key_value:
            base_params = {
                'fav_kind': favorite_kind,
                'title': label,
                'favorite_title': str(item.get('favorite_title') or favorite_base_title(favorite_kind, label)),
                'icon': icon,
                'fanart': fanart,
                'plot': plot,
                'category_id': str(item.get('category_id', '') or ''),
                'is_adult': str(item_is_adult).lower(),
                'stream_id': str(item.get('stream_id', '') or ''),
                'vod_id': str(item.get('vod_id', '') or ''),
                'series_id': str(item.get('series_id', '') or ''),
                'container_extension': str(item.get('container_extension', '') or ''),
                'stream_type': str(item.get('stream_type', '') or ''),
                'stream_kind': str(item.get('stream_kind', '') or ''),
                'epg_channel_id': str(item.get('epg_channel_id', '') or '')
            }
            if item.get('from_search'):
                base_params['from_search'] = str(item.get('from_search')).lower()
                if item.get('search_scope'):
                    base_params['search_scope'] = item.get('search_scope', '')
                if item.get('search_query'):
                    base_params['search_query'] = item.get('search_query', '')
            if favorite_key_value in favorite_keys:
                remove_params = {'mode': 'remove_favorite', 'favorite_key': favorite_key_value}
                if item.get('from_search'):
                    remove_params['from_search'] = str(item.get('from_search')).lower()
                    if item.get('search_scope'):
                        remove_params['search_scope'] = item.get('search_scope', '')
                    if item.get('search_query'):
                        remove_params['search_query'] = item.get('search_query', '')
                cm_url = build_url(**remove_params)
                cm.append(("Remover dos Favoritos do Addon", f'RunPlugin({cm_url})'))
            else:
                cm_url = build_url(mode='add_favorite', **base_params)
                cm.append(("Adicionar aos Favoritos do Addon", f'RunPlugin({cm_url})'))

        if cm:
            li.addContextMenuItems(cm, replaceItems=False)

        if 'url' in item and is_playable:
            play = ensure_play_url_headers(item['url'] or '', item.get('stream_kind', ''))
            if not play:
                log(f"Ignorando item reproduzível sem URL: {label}", xbmc.LOGDEBUG)
                continue

            li.setProperty('IsPlayable', 'true')

            params = {
                'mode': 'play',
                'url': play,
                'title': label,
                'icon': icon,
                'fanart': fanart,
                'normalplayer': str(item.get('normalplayer', 'false')).lower(),
                'stream_kind': item.get('stream_kind', ''),
                'container_extension': item.get('container_extension', ''),
                'category_id': str(item.get('category_id', '') or ''),
                'stream_id': str(item.get('stream_id', '') or ''),
                'epg_channel_id': str(item.get('epg_channel_id', '') or ''),
                'is_adult': str(item_is_adult).lower()
            }
            # Em filmes/episódios, evita o bookmark/resume nativo do Kodi
            # preso na URL do plugin (que pode disparar antes do fluxo interno do addon).
            if str(item.get('stream_kind', '') or '') in ('vod', 'episode'):
                params['play_nonce'] = str(int(time.time() * 1000))
            if item.get('vod_id'):
                params['vod_id'] = str(item['vod_id'])
            if item.get('series_id'):
                params['series_id'] = str(item['series_id'])
            if item.get('from_search'):
                params['from_search'] = str(item.get('from_search')).lower()
            if item.get('search_scope'):
                params['search_scope'] = item.get('search_scope', '')
            if item.get('search_query'):
                params['search_query'] = item.get('search_query', '')

            url = build_url(**params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, False)
        else:
            url_params = {'mode': mode} if mode else {'mode': item.get('mode')}
            if 'params' in item:
                qs = urllib.parse.parse_qs(item['params'], keep_blank_values=True)
                for k, v in qs.items():
                    url_params[k] = v[0] if isinstance(v, list) else v
            if item.get('category_id'):
                url_params['category_id'] = str(item.get('category_id', '') or '')
            if item.get('is_adult'):
                url_params['is_adult'] = str(item_is_adult).lower()
            if item.get('from_search'):
                url_params['from_search'] = str(item.get('from_search')).lower()
            if item.get('search_scope'):
                url_params['search_scope'] = item.get('search_scope', '')
            if item.get('search_query'):
                url_params['search_query'] = item.get('search_query', '')
            url = build_url(**url_params)
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, item.get('folder', True))

    end_directory(cache_to_disc=cache_to_disc)

# =========================
# Funções de dados
# =========================
# =========================
# Funções de dados
# =========================
def get_categories(endpoint):
    data = get_json(endpoint)
    if not data:
        return []

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    items = []
    for cat in cats:
        name = html.unescape(cat.get('category_name', 'Sem nome'))
        category_id = str(cat.get('category_id', '') or '').strip()
        item_is_adult = is_adult_name(name)
        if item_is_adult and not is_adult_enabled():
            continue
        items.append({'title': name, 'params': f"category_id={category_id}", 'category_id': category_id, 'is_adult': item_is_adult})
    return items

def get_adult_category_ids(endpoint):
    data = get_json(endpoint)
    if not data:
        return set()

    if isinstance(data, list):
        cats = data
    elif isinstance(data, dict) and 'categories' in data:
        cats = data['categories']
    else:
        cats = list(data.values()) if isinstance(data, dict) else []

    adult_ids = set()
    for cat in cats:
        name = html.unescape((cat.get('category_name', '') or '').strip())
        category_id = str(cat.get('category_id', '') or '').strip()
        if category_id and is_adult_name(name):
            adult_ids.add(category_id)
    return adult_ids

def get_adult_content_ids(endpoint, adult_category_ids=None):
    adult_category_ids = {str(x or '').strip() for x in (adult_category_ids or set()) if str(x or '').strip()}
    if not adult_category_ids:
        return set()

    key_name = 'stream_id'
    if endpoint == 'get_series':
        key_name = 'series_id'

    ids = set()
    for cid in adult_category_ids:
        try:
            items = get_items(endpoint, cid, True, adult_category_ids)
        except Exception as exc:
            log(f'Falha ao mapear conteúdo adulto em {endpoint}/{cid}: {exc}', xbmc.LOGERROR)
            continue
        for item in items:
            item_id = str(item.get(key_name, '') or '').strip()
            if item_id:
                ids.add(item_id)
    return ids

def ensure_epg_loaded():
    global _EPG_PARSED, _EPG_PARSED_SCOPE
    current_scope = current_server_scope_identity()
    if _EPG_PARSED is None or _EPG_PARSED_SCOPE != current_scope:
        _EPG_PARSED = epg_load_parsed()
    return _EPG_PARSED

def epg_format_range(pr):
    if not pr:
        return ''
    try:
        start = int(pr.get('start') or 0)
        end = int(pr.get('end') or 0)
    except Exception:
        start, end = 0, 0
    if start <= 0:
        return ''
    if end <= start:
        end = start + 3600
    return f"{datetime.fromtimestamp(start).strftime('%H:%M')} - {datetime.fromtimestamp(end).strftime('%H:%M')}"

def build_live_epg_plot(current=None, nextp=None, include_desc=True, day_schedule=None, compact=False, show_now_next=True, now_next_color=None, current_color=None, next_color=None, schedule_color=None, schedule_header_color=None, schedule_current_color=None, next_day_preview=None, next_day_header='Madrugada / Próximo dia', next_day_header_color=None, next_day_color=None):
    parts = []

    if current_color is None:
        current_color = now_next_color
    if next_color is None:
        next_color = now_next_color

    if show_now_next and current:
        current_title = str(current.get('title') or '').strip()
        current_desc = str(current.get('desc') or '').strip()
        current_range = epg_format_range(current)
        if current_range and current_title:
            current_line = f"Agora: {current_range} | {current_title}"
        elif current_title:
            current_line = f"Agora: {current_title}"
        else:
            current_line = ''
        if current_line:
            if current_color:
                parts.append(color(current_line, current_color))
            elif compact:
                parts.append(color(current_line, 'aquamarine'))
            else:
                parts.append(current_line)
        if include_desc and current_desc:
            parts.append(current_desc)

    if show_now_next and nextp:
        next_title = str(nextp.get('title') or '').strip()
        next_desc = str(nextp.get('desc') or '').strip()
        next_range = epg_format_range(nextp)
        if current and (next_title or (include_desc and next_desc)) and not compact:
            parts.append('')
        if next_range and next_title:
            next_line = f"Próximo: {next_range} | {next_title}"
        elif next_title:
            next_line = f"Próximo: {next_title}"
        else:
            next_line = ''
        if next_line:
            if next_color:
                parts.append(color(next_line, next_color))
            elif compact:
                parts.append(color(next_line, 'aquamarine'))
            else:
                parts.append(next_line)
        if include_desc and next_desc:
            parts.append(next_desc)

    schedule_lines = []
    now_ts = int(time.time())
    for pr in (day_schedule or []):
        title = str(pr.get('title') or '').strip()
        when = epg_format_range(pr)
        if when and title:
            line = f"{when} | {title}"
        elif title:
            line = title
        else:
            line = ''
        if not line:
            continue

        start = normalize_epoch_seconds(pr.get('start')) or 0
        end = normalize_epoch_seconds(pr.get('end')) or 0
        is_current = bool(start and ((start - max(0, int(EPG_BOUNDARY_TOLERANCE_SECS or 0))) <= now_ts < ((end if end > start else start + 3600) + max(0, int(EPG_BOUNDARY_TOLERANCE_SECS or 0)))))

        if is_current and schedule_current_color:
            schedule_lines.append(color(line, schedule_current_color))
        elif schedule_color:
            schedule_lines.append(color(line, schedule_color))
        else:
            schedule_lines.append(line)

    if schedule_lines:
        if parts and not compact:
            parts.append('')
        header = 'Grade do dia'
        if schedule_header_color:
            header = color(header, schedule_header_color)
        elif compact:
            header = color(header, 'gold')
        parts.append(header)
        parts.extend(schedule_lines)

    preview_lines = []
    for pr in (next_day_preview or []):
        title = str(pr.get('title') or '').strip()
        when = epg_format_range(pr)
        if when and title:
            line = f"{when} | {title}"
        elif title:
            line = title
        else:
            line = ''
        if not line:
            continue

        if next_day_color:
            preview_lines.append(color(line, next_day_color))
        else:
            preview_lines.append(line)

    if preview_lines:
        if parts:
            parts.append('')
        header = str(next_day_header or 'Madrugada / Próximo dia').strip() or 'Madrugada / Próximo dia'
        if next_day_header_color:
            header = color(header, next_day_header_color)
        elif schedule_header_color:
            header = color(header, schedule_header_color)
        elif compact:
            header = color(header, 'gold')
        parts.append(header)
        parts.extend(preview_lines)

    return "\n".join(parts).strip()

def annotate_live_with_epg(items_from_api):
    epg = ensure_epg_loaded()
    out = []
    for s in items_from_api:
        name = s.get('title') or s.get('name') or 'Sem nome'
        epg_id = s.get('epg_channel_id')
        current, nextp = epg_lookup_current_next(epg_id, epg) if epg_id else (None, None)
        day_schedule = epg_lookup_day_schedule(epg_id, epg, limit=12, include_current=True) if epg_id else []
        next_day_preview = epg_lookup_next_day_preview(epg_id, epg, limit=3, after_hour=23) if epg_id else []

        label = name
        if current:
            current_title = str(current.get('title') or '').strip()
            label = f"{name} - {color(current_title, 'aquamarine')}" if current_title else name

        # Grade compacta: programação do dia sem sinopse e, após 23h, prévia curta da madrugada.
        plot = build_live_epg_plot(
            current=current,
            nextp=nextp,
            include_desc=False,
            day_schedule=day_schedule,
            compact=True,
            show_now_next=False,
            schedule_color=None,
            schedule_current_color='aquamarine',
            schedule_header_color='gold',
            next_day_preview=next_day_preview,
            next_day_header='Madrugada / Próximo dia',
            next_day_header_color='gold',
            next_day_color=None
        )

        s2 = dict(s)
        s2['title'] = label
        if plot:
            s2['plot'] = plot
        out.append(s2)
    return out

def get_items(endpoint, category_id=None, category_is_adult=False, adult_category_ids=None):
    BASE_URL = get_base_url()
    params = f"&category_id={category_id}" if category_id else ""
    data = get_json(f"action={endpoint}{params}")
    if not data:
        return []

    if adult_category_ids is None:
        adult_category_ids = set()
    else:
        adult_category_ids = {str(x or '').strip() for x in adult_category_ids if str(x or '').strip()}

    items = []

    if endpoint in ['get_live_streams', 'get_vod_streams']:
        vod_cache = None
        if endpoint == 'get_vod_streams':
            vod_cache = desc_cache_load(vod_desc_cache_storage_path())

        for s in data:
            url = s.get('stream_url', '')
            sid = s.get('stream_id')
            stype = s.get('stream_type', '')
            name = html.unescape(s.get('name', 'Sem nome'))
            icon = s.get('stream_icon', '')
            epg_channel_id = s.get('epg_channel_id') or None
            container_extension = (s.get('container_extension') or 'mp4').lower()
            item_category_id = str(s.get('category_id') or category_id or '').strip()
            item_is_adult = bool(category_is_adult) or item_category_id in adult_category_ids or is_adult_name(name)

            if sid:
                if endpoint == 'get_live_streams':
                    url = f'{BASE_URL.rstrip("/")}/live/{USERNAME}/{PASSWORD}/{sid}.m3u8'
                else:
                    url = f'{BASE_URL.rstrip("/")}/{stype}/{USERNAME}/{PASSWORD}/{sid}.{container_extension}'

            if not url:
                log(f"Ignorando item sem URL retornado pela API: {name}", xbmc.LOGDEBUG)
                continue

            item = {'title': name, 'url': url, 'icon': icon, 'fanart': addonFanart, 'container_extension': container_extension, 'stream_id': str(sid or ''), 'stream_type': stype, 'category_id': item_category_id, 'is_adult': item_is_adult}

            if epg_channel_id:
                item['epg_channel_id'] = epg_channel_id

            if endpoint == 'get_live_streams':
                item['media_type'] = 'video'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'live'
                item['favorite_kind'] = 'live'
            else:
                item['media_type'] = 'movie'
                item['normalplayer'] = 'false'
                item['stream_kind'] = 'vod'
                item['favorite_kind'] = 'vod'

            if endpoint == 'get_vod_streams' and sid:
                item['vod_id'] = sid
                plot = clean_plot(s.get('plot') or s.get('description') or '')
                if not plot and vod_cache is not None:
                    has, cached_plot = desc_cache_get(vod_cache, sid)
                    if has:
                        plot = cached_plot
                if plot:
                    item['plot'] = plot

            items.append(item)

        if endpoint == 'get_live_streams' and ENABLE_EPG.lower() == 'true':
            items = annotate_live_with_epg(items)

    elif endpoint == 'get_series':
        series_cache = desc_cache_load(series_desc_cache_storage_path())

        for s in data:
            icon = (s.get('info', {}) or {}).get('cover_big') or (s.get('info', {}) or {}).get('movie_image', '')
            if not icon:
                backdrops = s.get('backdrop_path') or []
                if isinstance(backdrops, str):
                    backdrops = [backdrops]
                icon = s.get('cover') if s.get('cover') else (backdrops[0] if backdrops else '')

            series_id = s.get('series_id', '')
            title = html.unescape(s.get('name', 'Sem nome'))
            item_category_id = str(s.get('category_id') or category_id or '').strip()
            item_is_adult = bool(category_is_adult) or item_category_id in adult_category_ids or is_adult_name(title)

            if not series_id:
                log(f"Ignorando série sem series_id: {title}", xbmc.LOGDEBUG)
                continue

            item = {'title': title, 'params': f"series_id={series_id}&category_id={urllib.parse.quote(item_category_id, safe='')}&is_adult={'true' if item_is_adult else 'false'}", 'icon': icon, 'series_id': series_id, 'fanart': addonFanart, 'media_type': 'tvshow', 'category_id': item_category_id, 'is_adult': item_is_adult, 'favorite_kind': 'series'}

            plot = clean_plot(s.get('plot') or (s.get('info', {}) or {}).get('plot') or (s.get('info', {}) or {}).get('overview') or '')
            if not plot and series_id:
                has, cached_plot = desc_cache_get(series_cache, series_id)
                if has:
                    plot = cached_plot
            if plot:
                item['plot'] = plot

            items.append(item)

    return items

def get_seasons(series_id, category_id='', is_adult=False):
    BASE_URL = get_base_url()
    data = get_json(f"action=get_series_info&series_id={series_id}")
    if not data:
        return []

    try:
        plot = extract_series_plot(data)
        if plot and series_id:
            cache = desc_cache_load(series_desc_cache_storage_path())
            desc_cache_put(cache, series_id, plot)
            desc_cache_save(series_desc_cache_storage_path(), cache)
    except Exception as e:
        log(f"Falha ao cachear sinopse da série: {e}", xbmc.LOGDEBUG)

    seasons = data.get('episodes', {})
    items = []

    def _season_sort_key(raw_name):
        m = re.search(r'\d+', str(raw_name or ''))
        if m:
            try:
                return (0, int(m.group(0)))
            except Exception:
                pass
        return (1, str(raw_name or '').lower())

    for season_name in sorted(seasons.keys(), key=_season_sort_key):
        episodes = seasons.get(season_name) or []
        ep_list = []
        for index, ep in enumerate(episodes):
            index += 1
            title = html.unescape(ep.get('title', 'Sem título'))
            eid = ep.get('id') or ep.get('episode_id') or ep.get('stream_id')
            ext = (ep.get('info', {}) or {}).get('container_extension') or 'mp4'
            icon = (ep.get('info', {}) or {}).get('cover_big') or (ep.get('info', {}) or {}).get('movie_image', '')
            url = f"{BASE_URL.rstrip('/')}/series/{USERNAME}/{PASSWORD}/{eid}.{ext}" if eid else ep.get('direct_source', '')
            if not url:
                log(f"Ignorando episódio sem URL em {season_name}: {title}", xbmc.LOGDEBUG)
                continue

            ep_list.append({'title': str(index) + ' - ' + title, 'url': url, 'icon': icon, 'fanart': addonFanart, 'media_type': 'episode', 'normalplayer': 'false', 'stream_kind': 'episode', 'stream_id': str(eid or ''), 'series_id': str(series_id or ''), 'container_extension': ext.lower(), 'category_id': str(category_id or ''), 'is_adult': bool(is_adult)})

        if not ep_list:
            continue

        payload = urllib.parse.quote(json.dumps(ep_list, ensure_ascii=False), safe='')
        items.append({'title': f"Temporada {season_name}", 'params': f"episodes={payload}&series_id={series_id}&category_id={urllib.parse.quote(str(category_id or ''), safe='')}&is_adult={'true' if is_adult else 'false'}"})
    return items

def search_global(query, scope='all', max_results=120):
    query = (query or '').strip().lower()
    if not query:
        show_dialog("Aviso", "Digite algo para pesquisar.")
        return []

    if len(query) < 3:
        show_dialog("Aviso", "Digite pelo menos 3 caracteres para pesquisar.")
        return []

    scope_map = {
        'all': [('get_live_streams', 'Canal: ', True), ('get_vod_streams', 'Filme: ', True), ('get_series', 'Série: ', False)],
        'live': [('get_live_streams', 'Canal: ', True)],
        'vod': [('get_vod_streams', 'Filme: ', True)],
        'series': [('get_series', 'Série: ', False)]
    }
    plan = scope_map.get(scope, scope_map['all'])

    adult_category_map = {
        'get_live_streams': get_adult_category_ids('get_live_categories'),
        'get_vod_streams': get_adult_category_ids('get_vod_categories'),
        'get_series': get_adult_category_ids('get_series_categories')
    }
    adult_content_map = {
        'get_live_streams': get_adult_content_ids('get_live_streams', adult_category_map.get('get_live_streams', set())),
        'get_vod_streams': get_adult_content_ids('get_vod_streams', adult_category_map.get('get_vod_streams', set())),
        'get_series': get_adult_content_ids('get_series', adult_category_map.get('get_series', set()))
    }

    results = []
    seen = set()
    progress = xbmcgui.DialogProgress()
    progress.create('Pesquisa Global', 'Consultando catálogo...')

    try:
        total = len(plan)
        for idx, (endpoint, prefix, playable) in enumerate(plan, start=1):
            if progress.iscanceled():
                break
            label = {'get_live_streams': 'Buscando canais...', 'get_vod_streams': 'Buscando filmes...', 'get_series': 'Buscando séries...'}.get(endpoint, 'Pesquisando...')
            progress.update(int(((idx - 1) / float(total)) * 100), label)
            items = get_items(endpoint, adult_category_ids=adult_category_map.get(endpoint, set()))
            adult_content_ids = adult_content_map.get(endpoint, set())
            for i in items:
                title = (i.get('title', '') or '').strip()
                if not title or query not in title.lower():
                    continue
                item_is_adult = normalize_bool(i.get('is_adult', False))
                if not item_is_adult:
                    if endpoint == 'get_series':
                        lookup_id = str(i.get('series_id', '') or '').strip()
                    else:
                        lookup_id = str(i.get('stream_id', '') or i.get('vod_id', '') or '').strip()
                    if lookup_id and lookup_id in adult_content_ids:
                        item_is_adult = True
                if item_is_adult:
                    continue
                key = f"{endpoint}|{title.lower()}|{i.get('url', '')}|{i.get('params', '')}"
                if key in seen:
                    continue
                seen.add(key)
                entry = {'title': prefix + title, 'favorite_title': title, 'icon': i.get('icon', ''), 'fanart': i.get('fanart', addonFanart), 'plot': i.get('plot', ''), 'media_type': i.get('media_type', ''), 'category_id': str(i.get('category_id', '') or ''), 'is_adult': item_is_adult}
                entry['from_search'] = 'true'
                entry['search_scope'] = scope
                entry['search_query'] = query
                if playable:
                    entry['url'] = i.get('url', '')
                    entry['normalplayer'] = i.get('normalplayer', 'false')
                    entry['stream_kind'] = i.get('stream_kind', '')
                    entry['container_extension'] = i.get('container_extension', '')
                    entry['stream_id'] = i.get('stream_id', '')
                    entry['stream_type'] = i.get('stream_type', '')
                    entry['epg_channel_id'] = i.get('epg_channel_id', '')
                    if i.get('vod_id'):
                        entry['vod_id'] = i['vod_id']
                else:
                    entry['mode'] = 'seasons'
                    entry['params'] = i.get('params', '')
                    if i.get('series_id'):
                        entry['series_id'] = i['series_id']
                results.append(entry)
                if len(results) >= max_results:
                    progress.update(100, 'Limite de resultados atingido.')
                    return results
            progress.update(int((idx / float(total)) * 100), label)
    finally:
        progress.close()

    return results

def get_account_info():
    data = get_json("")
    if not data:
        return None
    user_info = data.get('user_info', {})
    if not user_info:
        log("Nenhuma informação de usuário retornada pela API.", xbmc.LOGERROR)
        show_dialog("Erro", "Não foi possível obter informações da conta.")
        return None
    username = user_info.get('username', 'Não informado')
    status = user_info.get('status', 'Não informado')
    max_connections = user_info.get('max_connections', 'Não informado')
    active_connections = user_info.get('active_cons', 'Não informado')
    created_at = user_info.get('created_at', 0)
    exp_date = user_info.get('exp_date', 0)
    try:
        created_at_str = datetime.fromtimestamp(int(created_at)).strftime('%d/%m/%Y') if created_at and str(created_at).isdigit() else 'Não informado'
    except Exception:
        created_at_str = 'Não informado'
    try:
        exp_date_str = datetime.fromtimestamp(int(exp_date)).strftime('%d/%m/%Y') if exp_date and str(exp_date).isdigit() else 'Não informado'
    except Exception:
        exp_date_str = 'Não informado'
    status_color = get_status_color(status)
    info_text = (
        f"[B]Usuário:[/B] {color(username, 'white')}\n"
        f"[B]Status:[/B] {color(status.upper(), status_color)}\n\n"
        f"[B]Criado em:[/B] {format_date(created_at_str)}\n"
        f"[B]Vencimento:[/B] {format_date(exp_date_str)}\n\n"
        f"[B]Conexões Máximas:[/B] {color(max_connections, 'white')}\n"
        f"[B]Conexões Ativas:[/B] {color(active_connections, 'orange')}\n\n"
        f"[B]{SUPPORT_CONTACT_LABEL}:[/B] {color(SUPPORT_WHATSAPP, 'gold')}\n"
        f"[B]QR Code:[/B] Feche esta tela para abrir o suporte via WhatsApp / QR Code."
    )
    return info_text

def play_item(url, title, icon, normalplayer, fanart=None, vod_id=None, series_id=None, stream_kind='', container_extension='', stream_id='', epg_channel_id='', is_adult=False):
    # Busca sinopse/informações de forma leve (apenas no item que vai tocar)
    plot = ''
    try:
        if stream_kind == 'live' and ENABLE_EPG.lower() == 'true' and epg_channel_id:
            epg = ensure_epg_loaded()
            current, nextp = epg_lookup_current_next(epg_channel_id, epg)
            plot = build_live_epg_plot(current=current, nextp=nextp, include_desc=True, current_color='aquamarine', next_color='aquamarine')
        elif vod_id:
            plot = get_vod_plot_cached(vod_id) or ''
        elif series_id:
            plot = get_series_plot_cached(series_id) or ''
    except Exception as e:
        log(f"Falha ao obter sinopse/informações no play: {e}", xbmc.LOGDEBUG)
        plot = ''

    if stream_kind == 'live':
        url = wrap_live_url_with_proxy(url)

    clean_play_url = strip_kodi_url_headers(url) if url else ''
    using_local_proxy = clean_play_url.startswith('http://127.0.0.1:') and '/hlsretry?url=' in clean_play_url

    if url and not using_local_proxy:
        url = ensure_play_url_headers(url, stream_kind)

    fanart = fanart or addonFanart
    resume_meta = {
        'url': url,
        'icon': icon,
        'fanart': fanart,
        'plot': plot,
        'normalplayer': normalplayer,
        'stream_kind': stream_kind,
        'container_extension': container_extension,
        'vod_id': vod_id or '',
        'series_id': series_id or '',
        'stream_id': stream_id or '',
        'is_adult': normalize_bool(is_adult)
    }

    # Resume leve para filmes e episódios sem sair do fluxo base da 0.0.5:
    # mantém setResolvedUrl e só adiciona seek/monitor por cima.
    use_resume = is_vod_resume_enabled() and (
        (stream_kind == 'vod' and bool(vod_id)) or
        (stream_kind == 'episode' and (bool(stream_id) or bool(url)))
    )
    resume_key = ''
    resume_entry = None
    resume_seconds = 0.0
    resume_total = 0.0
    if use_resume:
        resume_key = make_resume_key(stream_kind=stream_kind, vod_id=vod_id, stream_id=stream_id, url=url)
        resume_entry = get_resume_point(resume_key)
        resume_seconds = prompt_resume_position(title, resume_entry, resume_key=resume_key)
        try:
            resume_total = float((resume_entry or {}).get('total') or 0)
        except Exception:
            resume_total = 0.0

    use_resolved = normalplayer == 'false' or stream_kind in ('live', 'vod', 'episode')

    if use_resolved:
        li = xbmcgui.ListItem(path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        if stream_kind == 'vod':
            info['mediatype'] = 'movie'
        elif stream_kind == 'episode':
            info['mediatype'] = 'episode'
        apply_video_info(li, info)
        if stream_kind == 'live':
            configure_live_stream_listitem(li, url)
        elif stream_kind in ('vod', 'episode'):
            if container_extension and not detect_stream_extension(url):
                try:
                    li.setProperty('oneplay.container_extension', container_extension)
                except Exception:
                    pass
            configure_vod_stream_listitem(li, url, stream_kind)
            try:
                li.setProperty('IsPlayable', 'true')
            except Exception:
                pass
            if use_resume and resume_seconds > 0:
                try:
                    tag = li.getVideoInfoTag()
                    try:
                        tag.setResumePoint(float(resume_seconds), float(resume_total or 0))
                    except Exception:
                        pass
                except Exception:
                    pass
                try:
                    li.setProperty('ResumeTime', str(float(resume_seconds)))
                    if resume_total > 0:
                        li.setProperty('TotalTime', str(float(resume_total)))
                    li.setProperty('StartOffset', str(float(resume_seconds)))
                except Exception:
                    pass
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)
        if use_resume:
            player = xbmc.Player()
            if resume_seconds > 0:
                apply_resume_seek(player, resume_seconds)
            monitor_and_persist_resume(player, resume_key, title=title, meta=resume_meta)
    else:
        li = xbmcgui.ListItem(label=title, path=url)
        li.setArt({'icon': icon, 'thumb': icon, 'fanart': fanart})
        if fanart:
            li.setProperty('Fanart_Image', fanart)
        info = {'title': title}
        if plot:
            info['plot'] = plot
        apply_video_info(li, info)
        if stream_kind in ('vod', 'episode'):
            configure_vod_stream_listitem(li, url, stream_kind)
        player = xbmc.Player()
        player.play(item=url, listitem=li)

def days_until_expire(exp_date):
    try:
        exp_date = int(exp_date)
        if exp_date <= 0:
            return None
        now = int(time.time())
        seconds_left = exp_date - now
        return int(seconds_left // 86400)
    except Exception:
        return None

def get_enter_menu_items():
    settings_item = {'title': 'Configurações', 'mode': 'settings', 'plot': 'Abra as configurações do addon.', 'fanart': addonFanart, 'folder': False}
    menu_settings_item = {'title': 'Ajustes do Menu', 'mode': 'menu_settings', 'plot': 'Abra os toggles visuais do menu principal do addon.', 'fanart': addonFanart, 'folder': False}
    account_connection_item = {'title': 'Acesso e Servidor', 'mode': 'account_connection_menu', 'plot': f'Gerencie login, servidor e testes de conexão. Atual: {get_server_summary()}.', 'fanart': addonFanart}
    items = [account_connection_item]
    if is_global_search_enabled():
        items.append({'title': 'Pesquisa Global', 'mode': 'search', 'plot': 'Busca canais, filmes e séries em todo o catálogo.', 'fanart': addonFanart})
    if is_favorites_enabled():
        items.append({'title': 'Favoritos', 'mode': 'favorites', 'plot': 'Atalhos rápidos para canais, filmes e séries favoritados.', 'fanart': addonFanart})
    items.append({'title': 'TV (Canais Ao Vivo)', 'mode': 'tv', 'plot': 'Lista as categorias de canais ao vivo disponíveis.', 'fanart': addonFanart})
    if is_vod_resume_enabled():
        items.append({'title': 'Continue Assistindo', 'mode': 'continue_watching', 'plot': 'Mostra filmes e episódios com resume pendente para continuar de onde parou.', 'fanart': addonFanart})
    items.extend([
        {'title': 'Filmes', 'mode': 'movies', 'plot': 'Acesse as categorias de filmes disponíveis no servidor.', 'fanart': addonFanart},
        {'title': 'Séries', 'mode': 'series', 'plot': 'Acesse as categorias, temporadas e episódios das séries.', 'fanart': addonFanart},
        menu_settings_item,
        settings_item,
    ])
    return items

# =========================
# Rotas
# =========================
def guard_adult_flag_from_params(title='Conteúdo Adulto', fallback_flag='false'):
    if not normalize_bool(fallback_flag):
        return True
    if not is_adult_enabled():
        show_dialog('Conteúdo Adulto', 'O conteúdo adulto está desativado nas configurações do addon.')
        return False
    return True

# =========================
# Rotas
# =========================
PARAMS = get_param_map()
mode = get_param('mode', 'main')
suppress_expire_popup = normalize_bool(get_param('suppress_expire', 'false'))
log(f"Modo: {mode}")

def route_dispatch():
    if mode == 'download_apk':
        handle_apk_download()
        raise SystemExit
    elif mode == 'install_help':
        show_install_apk_help()
        raise SystemExit

    if mode == 'main':
        refresh_runtime_settings()
        if has_valid_credentials():
            success, error_type, error_message = try_open_enter_menu(suppress_expire=suppress_expire_popup)
            if not success:
                show_probe_result_dialog(error_type, error_message)
                if error_type == 'login' and run_access_retry_wizard():
                    success_retry, retry_type, retry_message = try_open_enter_menu(suppress_expire=True)
                    if not success_retry:
                        show_probe_result_dialog(retry_type, retry_message)
                        render_account_connection_menu()
                else:
                    render_account_connection_menu()
                raise SystemExit
        else:
            show_qr_code()
            if run_quick_setup_wizard():
                success_retry, retry_type, retry_message = try_open_enter_menu(suppress_expire=True)
                if not success_retry:
                    show_probe_result_dialog(retry_type, retry_message)
                    render_account_connection_menu()
                raise SystemExit
            render_root_menu()

    elif mode == 'enter':
        refresh_runtime_settings()
        success, error_type, error_message = try_open_enter_menu(suppress_expire=suppress_expire_popup)
        if not success:
            show_probe_result_dialog(error_type, error_message)
            if error_type == 'login' and run_access_retry_wizard():
                success_retry, retry_type, retry_message = try_open_enter_menu(suppress_expire=True)
                if not success_retry:
                    show_probe_result_dialog(retry_type, retry_message)
                    render_account_connection_menu()
            else:
                render_account_connection_menu()
            raise SystemExit

    elif mode == 'account_info':
        info_text = get_account_info()
        if info_text:
            xbmcgui.Dialog().textviewer("Informações da Conta", info_text)
            try:
                if xbmcgui.Dialog().yesno('Suporte', 'Abrir WhatsApp / QR Code do suporte agora?'):
                    show_qr_code()
            except Exception as e:
                log(f"Falha ao oferecer QR Code após informações da conta: {e}", xbmc.LOGDEBUG)
        else:
            show_dialog("Erro", "Não foi possível obter informações da conta.")

    elif mode == 'show_qr':
        show_qr_code()

    elif mode == 'account_connection_menu':
        build_menu(build_account_connection_items())

    elif mode == 'quick_setup':
        if run_quick_setup_wizard():
            try:
                xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
            except Exception:
                success_retry, retry_type, retry_message = try_open_enter_menu(suppress_expire=True)
                if not success_retry:
                    show_probe_result_dialog(retry_type, retry_message)
                    render_account_connection_menu()
        raise SystemExit

    elif mode == 'switch_server':
        switch_server_interactive()
        render_account_connection_menu()
        raise SystemExit

    elif mode == 'change_credentials':
        if run_change_credentials_wizard():
            notify('Login e senha atualizados com sucesso.', heading='Acesso e Servidor', iconimage='INFO')
        render_account_connection_menu()
        raise SystemExit

    elif mode == 'test_current_server':
        test_current_server()
        render_account_connection_menu()
        raise SystemExit

    elif mode == 'test_all_servers':
        test_all_servers()
        render_account_connection_menu()
        raise SystemExit

    elif mode == 'cleanup_tools':
        open_cleanup_dialog()
        render_account_connection_menu()
        raise SystemExit

    elif mode == 'logout':
        if xbmcgui.Dialog().yesno('Sair da conta', 'Remover o usuário e a senha salvos deste addon agora?'):
            if clear_login_settings(keep_server=True):
                notify('Conta removida. O servidor foi mantido salvo.', heading='Acesso e Servidor', iconimage='INFO')
                render_root_menu()
            else:
                show_dialog('Sair da conta', 'Não foi possível limpar os dados salvos.')
                render_account_connection_menu()
        else:
            render_account_connection_menu()
        raise SystemExit

    elif mode == 'settings':
        previous_proxy_state = is_live_proxy_enabled()
        ADDON.openSettings()
        refresh_runtime_settings()
        current_proxy_state = is_live_proxy_enabled()
        if previous_proxy_state and not current_proxy_state:
            stop_live_proxy_if_running()

    elif mode == 'menu_settings':
        changed = run_menu_settings_dialog()
        if changed:
            refresh_runtime_settings()
            try:
                xbmc.sleep(120)
            except Exception:
                pass
            try:
                xbmc.executebuiltin('Container.Refresh')
            except Exception as exc:
                log(f'Falha ao atualizar menu após ajustes: {exc}', xbmc.LOGDEBUG)
        raise SystemExit

    elif mode == 'toggle_menu_setting':
        setting_id = (get_param('setting_id', '') or '').strip()
        allowed_settings = {
            'enable_global_search': 'Pesquisa Global',
            'enable_favorites': 'Favoritos',
            'enable_vod_resume': 'Continue Assistindo',
        }
        setting_label = allowed_settings.get(setting_id, '')
        if not setting_label:
            show_dialog('Ajustes do Menu', 'Opção inválida.')
            raise SystemExit
        current_value = is_menu_toggle_enabled(setting_id)
        new_value = not current_value
        if set_menu_toggle(setting_id, new_value):
            status_text = 'ligado' if new_value else 'desligado'
            set_menu_settings_dirty(True)
            notify(f'{setting_label}: {status_text}. Volte para aplicar no menu.', heading='Ajustes do Menu', iconimage='INFO')
        else:
            show_dialog('Ajustes do Menu', f'Não foi possível alterar {setting_label}.')
        raise SystemExit

    elif mode == 'change_adult_pin':
        current_pin = get_adult_pin_value()
        prompt_title = 'PIN atual do Conteúdo Adulto'
        if current_pin == DEFAULT_ADULT_PIN:
            prompt_title += ' (padrão: 0000)'
        if current_pin and not prompt_current_adult_pin(prompt_title):
            show_dialog('PIN adulto', 'PIN atual inválido.')
            raise SystemExit
        entered = xbmcgui.Dialog().input('Novo PIN adulto (4 dígitos)', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if entered is None:
            raise SystemExit
        new_pin = sanitize_adult_pin(entered)
        if not new_pin:
            show_dialog('PIN adulto', 'Informe exatamente 4 dígitos numéricos.')
            raise SystemExit
        confirm = xbmcgui.Dialog().input('Confirme o novo PIN adulto', type=xbmcgui.INPUT_NUMERIC, option=xbmcgui.ALPHANUM_HIDE_INPUT)
        if confirm is None:
            raise SystemExit
        if sanitize_adult_pin(confirm) != new_pin:
            show_dialog('PIN adulto', 'A confirmação do PIN não confere.')
            raise SystemExit
        if not save_adult_pin(new_pin):
            show_dialog('PIN adulto', 'Não foi possível salvar o novo PIN.')
            raise SystemExit
        refresh_runtime_settings()
        clear_adult_session()
        notify('PIN adulto alterado com sucesso.', heading='Conteúdo Adulto', iconimage='INFO')

    elif mode == 'favorites':
        if not is_favorites_enabled():
            return_to_enter_menu_with_message('Favoritos', 'Favoritos do addon estão desativados.')
        build_favorites_menu()

    elif mode == 'continue_watching':
        if not is_vod_resume_enabled():
            return_to_enter_menu_with_message('Continue Assistindo', 'O recurso Continue Assistindo está desativado.')
        build_continue_watching_menu()

    elif mode == 'clear_resume_entry':
        if not is_vod_resume_enabled():
            return_to_enter_menu_with_message('Continue Assistindo', 'O recurso Continue Assistindo está desativado.')
        resume_key = get_param('resume_key', '')
        if not resume_key:
            show_dialog('Continue Assistindo', 'Resume inválido para remoção.')
        else:
            clear_resume_point(resume_key)
            notify('Item removido de Continue Assistindo.', heading='Continue Assistindo', iconimage='INFO')
            items, _legacy_count = list_continue_watching_items()
            try:
                if items:
                    xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='continue_watching'))
                else:
                    xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
            except Exception:
                refresh_container()
            raise SystemExit

    elif mode == 'add_favorite':
        if not is_favorites_enabled():
            return_to_enter_menu_with_message('Favoritos', 'Favoritos do addon estão desativados.')
        entry = favorite_entry_from_params(PARAMS)
        if not entry:
            show_dialog('Favoritos', 'Não foi possível adicionar este item aos favoritos.')
        elif add_favorite(entry):
            notify('Item adicionado aos favoritos.', heading='Favoritos', iconimage='INFO')
            if get_param('from_search', 'false') == 'true':
                mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
                refresh_container()
            else:
                refresh_container()
        else:
            show_dialog('Favoritos', 'Não foi possível salvar o favorito.')

    elif mode == 'remove_favorite':
        favorite_key_value = get_param('favorite_key', '')
        if not favorite_key_value:
            entry = favorite_entry_from_params(PARAMS)
            favorite_key_value = entry.get('key', '') if entry else ''
        if not favorite_key_value:
            show_dialog('Favoritos', 'Favorito inválido para remoção.')
        elif remove_favorite(favorite_key_value):
            notify('Item removido dos favoritos.', heading='Favoritos', iconimage='INFO')
            if get_param('from_search', 'false') == 'true':
                mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
                refresh_container()
            elif get_param('from_favorites', 'false') == 'true':
                items = list_favorites_items()
                try:
                    if items:
                        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='favorites'))
                    else:
                        xbmc.executebuiltin('Container.Update(%s,replace)' % build_url(mode='enter', suppress_expire='true'))
                except Exception:
                    refresh_container()
                raise SystemExit
            else:
                refresh_container()
        else:
            show_dialog('Favoritos', 'Não foi possível remover o favorito.')

    elif mode == 'tv':
        build_menu(get_categories('action=get_live_categories'), 'live_items')

    elif mode == 'live_items':
        cid = get_param('category_id')
        adult_flag = get_param('is_adult', 'false')
        if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
            build_menu(get_items('get_live_streams', cid, normalize_bool(adult_flag)), is_playable=True)

    elif mode == 'movies':
        build_menu(get_categories('action=get_vod_categories'), 'movie_items')

    elif mode == 'movie_items':
        cid = get_param('category_id')
        adult_flag = get_param('is_adult', 'false')
        if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
            build_menu(get_items('get_vod_streams', cid, normalize_bool(adult_flag)), is_playable=True)

    elif mode == 'series':
        build_menu(get_categories('action=get_series_categories'), 'series_items')

    elif mode == 'series_items':
        cid = get_param('category_id')
        adult_flag = get_param('is_adult', 'false')
        if guard_adult_flag_from_params(get_param('title', 'Categoria adulta'), adult_flag):
            build_menu(get_items('get_series', cid, normalize_bool(adult_flag)), 'seasons')

    elif mode == 'seasons':
        sid = get_param('series_id')
        adult_flag = get_param('is_adult', 'false')
        if guard_adult_flag_from_params(get_param('title', 'Série adulta'), adult_flag):
            build_menu(get_seasons(sid, get_param('category_id', ''), normalize_bool(adult_flag)), 'episodes')

    elif mode == 'episodes':
        if not guard_adult_flag_from_params(get_param('title', 'Temporada adulta'), get_param('is_adult', 'false')):
            raise SystemExit
        eps_json = urllib.parse.unquote(get_param('episodes', '[]'))
        try:
            eps = json.loads(eps_json)
            if not isinstance(eps, list):
                raise ValueError('episodes inválido')
        except Exception as e:
            log(f"Falha ao carregar episódios: {e}", xbmc.LOGERROR)
            eps = []
        build_menu(eps, is_playable=True)

    elif mode == 'search':
        if not is_global_search_enabled():
            return_to_enter_menu_with_message('Pesquisa Global', 'Pesquisa Global está desativada.')
        resumed = pop_resume_search()
        if resumed:
            cached_results = resumed.get('results') if isinstance(resumed, dict) else None
            if isinstance(cached_results, list):
                if cached_results:
                    build_menu(cached_results, is_playable=True)
                else:
                    return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
            else:
                results = search_global(resumed.get('query', ''), scope=resumed.get('scope', 'all'))
                if results:
                    remember_search(resumed.get('scope', 'all'), resumed.get('query', ''), results)
                    build_menu(results, is_playable=True)
                else:
                    return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
        else:
            scopes = [
                ('all', 'Tudo'),
                ('live', 'TV (Canais Ao Vivo)'),
                ('vod', 'Filmes'),
                ('series', 'Séries')
            ]
            labels = [label for _, label in scopes]
            sel = xbmcgui.Dialog().select('Onde deseja pesquisar?', labels)
            if sel >= 0:
                scope = scopes[sel][0]
                kb = xbmc.Keyboard('', 'Digite algo para pesquisar')
                kb.doModal()
                if kb.isConfirmed():
                    query = (kb.getText() or '').strip()
                    if query:
                        results = search_global(query, scope=scope)
                        if results:
                            remember_search(scope, query, results)
                            build_menu(results, is_playable=True)
                        else:
                            return_to_enter_menu_with_message('Pesquisa Global', 'Nenhum resultado encontrado no momento.')
                    else:
                        return_to_enter_menu_with_message('Pesquisa Global', 'Nenhuma pesquisa no momento.')
                else:
                    return_to_enter_menu_with_message('Pesquisa Global')
            else:
                return_to_enter_menu_with_message('Pesquisa Global')

    elif mode == 'show_vod_plot':
        vod_id = get_param('vod_id')
        title = get_param('title', 'Sinopse')
        if vod_id:
            plot = get_vod_plot_cached(vod_id) or ''
            if plot:
                xbmcgui.Dialog().textviewer(title, plot)
            else:
                show_dialog("Sinopse", "Sem descrição disponível.")
        else:
            show_dialog("Erro", "vod_id ausente.")

    elif mode == 'show_series_plot':
        series_id = get_param('series_id')
        title = get_param('title', 'Sinopse')
        if series_id:
            plot = get_series_plot_cached(series_id) or ''
            if plot:
                xbmcgui.Dialog().textviewer(title, plot)
            else:
                show_dialog("Sinopse", "Sem descrição disponível.")
        else:
            show_dialog("Erro", "series_id ausente.")

    elif mode == 'play':
        url = get_param('url')
        normalplayer = get_param('normalplayer', 'false')
        title = get_param('title', 'Reproduzindo')
        icon = get_param('icon', addonIcon)
        fanart = get_param('fanart', addonFanart)
        vod_id = get_param('vod_id', '') or None
        series_id = get_param('series_id', '') or None
        stream_kind = get_param('stream_kind', '')
        container_extension = get_param('container_extension', '')
        if normalize_bool(get_param('is_adult', 'false')) and not ensure_adult_access(title):
            raise SystemExit
        if get_param('from_search', 'false') == 'true' and stream_kind in ('live', 'vod', 'episode'):
            mark_resume_search(get_param('search_scope', 'all'), get_param('search_query', ''))
        play_item(url, title, icon, normalplayer, fanart=fanart, vod_id=vod_id, series_id=series_id, stream_kind=stream_kind, container_extension=container_extension, stream_id=get_param('stream_id', ''), epg_channel_id=get_param('epg_channel_id', ''), is_adult=normalize_bool(get_param('is_adult', 'false')))

    else:
        show_dialog("Erro", f"Modo desconhecido: {mode}")

try:
    route_dispatch()
except SystemExit:
    raise
except Exception as exc:
    log(f"Falha não tratada em mode={mode}: {exc}\n{traceback.format_exc()}", xbmc.LOGERROR)
    try:
        show_dialog('Erro interno', 'O addon encontrou um erro inesperado. Foi aplicado um retorno seguro.')
    except Exception:
        pass
    try:
        refresh_runtime_settings()
        if has_valid_credentials():
            build_menu(get_enter_menu_items())
        else:
            render_root_menu()
    except Exception as fallback_exc:
        log(f"Falha no retorno seguro: {fallback_exc}\n{traceback.format_exc()}", xbmc.LOGERROR)
        try:
            build_root_menu()
        except Exception:
            pass
