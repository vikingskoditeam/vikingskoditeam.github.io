# -*- coding: utf-8 -*-
import sys
import xbmcplugin
from urllib.parse import parse_qs
from lib.service import search_subtitle, download_subtitle

def main():
    args = sys.argv[2].lstrip('?') if len(sys.argv) > 2 else ''
    params = {k:v[0] for k,v in parse_qs(args, keep_blank_values=True).items() if v}
    action = params.get('action','search')
    if action in ('search','manualsearch'):
        search_subtitle(params.get('preferredlanguage','pt'), params.get('searchstring') if action == 'manualsearch' or params.get('searchstring') else None)
    elif action == 'download':
        download_subtitle(params.get('sub_download',''))
    else:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))

if __name__ == '__main__':
    main()
