# -*- coding: utf-8 -*-
try:
    from kodi_six import xbmc as xbmc_, xbmcgui as xbmcgui_, xbmcplugin as xbmcplugin_, xbmcaddon as xbmcaddon_, xbmcvfs as xbmcvfs_
except:
    pass
import six as six_
if six_.PY3:
    from urllib.parse import urlparse as urlparse_, parse_qs as parse_qs_, parse_qsl as parse_qsl_, quote as quote_, unquote as unquote_, quote_plus as quote_plus_, unquote_plus as unquote_plus_, urlencode as urlencode_ #python 3
else:
    from urlparse import urlparse as urlparse_, parse_qs as parse_qs_, parse_qsl as parse_qsl_ #python 2
    from urllib import quote as quote_, unquote as unquote_, quote_plus as quote_plus_, unquote_plus as unquote_plus_, urlencode as urlencode_
import sys
import os as os_
import requests as rq
try:
    import json as json_
except ImportError:
    import simplejson as json_
try:
    from bs4 import BeautifulSoup as bfs
except Exception:
    bfs = None
import base64
import threading
import time

six = six_
requests = rq
json = json_
BeautifulSoup = bfs
try:
    xbmc = xbmc_
    xbmcgui = xbmcgui_
    xbmcplugin = xbmcplugin_
    xbmcaddon = xbmcaddon_
    xbmcvfs = xbmcvfs_
except:
    pass
urlparse = urlparse_
parse_qs = parse_qs_
parse_qsl = parse_qsl_
quote = quote_
unquote = unquote_
quote_plus = quote_plus_
unquote_plus = unquote_plus_
urlencode = urlencode_
os = os_

# if six.PY2:
#     reload(sys)
#     sys.setdefaultencoding('utf-8')




try:
    class Progress_six:
        dp = xbmcgui.DialogProgress()
        @classmethod
        def create(cls,heading,msg):
            if six.PY3:
                cls.dp.create(str(heading),str(msg))
            else:
                cls.dp.create(str(heading),str(msg), '','')
        @classmethod
        def update(cls,update,heading):
            if six.PY3:
                cls.dp.update(int(update), str(heading))
            else:
                cls.dp.update(int(update), str(heading),'', '')

    class ProgressBG_six:
        dp = xbmcgui.DialogProgressBG()
        @classmethod
        def create(cls,heading,msg):
            if six.PY3:
                cls.dp.create(str(heading),str(msg))
            else:
                cls.dp.create(str(heading),str(msg), '','')
        @classmethod
        def update(cls,update,heading):
            if six.PY3:
                cls.dp.update(int(update), str(heading))
            else:
                cls.dp.update(int(update), str(heading),'', '')
except:
    pass

try:
    addon = xbmcaddon.Addon()
    addonID = addon.getAddonInfo('id')
    addonName = addon.getAddonInfo('name')
    addonVersion = addon.getAddonInfo('version')
    localLang = addon.getLocalizedString
    homeDir = addon.getAddonInfo('path')
    translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
    addonIcon = translate(os.path.join(homeDir, 'icon.jpg'))
    addonFanart = translate(os.path.join(homeDir, 'fanart.jpeg'))
    profile = translate(addon.getAddonInfo('profile'))
    kversion = int(xbmc.getInfoLabel('System.BuildVersion').split(".")[0])
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    dialog_ = xbmcgui.Dialog()
    executebuiltin = xbmc.executebuiltin
except:
    pass

def yesno(heading="",message="",nolabel="Nao",yeslabel="Sim"):
    if not heading:
        heading = addonName
    if six.PY2:
        q = dialog_.yesno(heading=heading, line1=message, nolabel=nolabel, yeslabel=yeslabel)
    else:
        q = dialog_.yesno(heading=heading, message=message, nolabel=nolabel, yeslabel=yeslabel)
    return q        

def opensettings():
    addon.openSettings()

def getsetting(text):
    return addon.getSetting(text)

def setsetting(key,value):
    return addon.setSetting(key, value)

def exists(path):
    return xbmcvfs.exists(path)

def mkdir(path):
    try:
        xbmcvfs.mkdir(path)
    except:
        pass

def dialog(msg):
    dialog = xbmcgui.Dialog()
    dialog.ok(addonName, msg)

def dialog2(title, msg):
    dialog = xbmcgui.Dialog()
    dialog.ok(title, msg)    

def dialog_text(msg):
    dialog = xbmcgui.Dialog()
    dialog.textviewer(addonName, msg)

def progress_six():
    dp = Progress_six()
    return dp 

def progressBG_six():
    pDialog = ProgressBG_six()
    return pDialog

def select(name,items):
    op = dialog_.select(name, items)
    return op 

def log(txt):
    try:
        message = ''.join([addonName, ' : ', txt])
        xbmc.log(msg=message, level=xbmc.LOGDEBUG)
    except:
        pass


# Estado por execucao do plugin. O proxy persistente e mantido pelo service.py;
# este start() apenas garante compatibilidade quando o addon acabou de ser instalado
# e o Kodi ainda nao reiniciou o servico.
_artwork_proxy_checked = False
_artwork_proxy_available = False


def _is_remote_http_url(value):
    try:
        text = to_utf8(value).strip().lower()
        return text.startswith('http://') or text.startswith('https://')
    except Exception:
        return False


def proxy_artwork_url(value, fallback=''):
    """Entrega artes remotas pelo proxy local do addon.

    O Kodi baixa thumbs/fanarts fora do processo do plugin. Sem essa reescrita,
    ele voltaria a consultar o DNS padrao da rede. Quando o proxy nao estiver
    disponivel, usa somente arte local de fallback — nunca devolve a URL remota
    direta para evitar uma saida fora do fluxo Cloudflare.
    """
    global _artwork_proxy_checked, _artwork_proxy_available
    if not value or not _is_remote_http_url(value):
        return value or fallback
    try:
        import localproxy
        if not _artwork_proxy_checked:
            _artwork_proxy_checked = True
            _artwork_proxy_available = bool(localproxy.start())
        if _artwork_proxy_available:
            return localproxy.proxy_url(value)
        log('Proxy de artes indisponivel; usando arte local.')
    except Exception as exc:
        try:
            log('Falha ao preparar arte pelo proxy: {0}'.format(str(exc)))
        except Exception:
            pass
    return fallback

def to_utf8(text):
    if isinstance(text, bytes):
        return text.decode('utf-8', errors='ignore')
    try:
        return str(text)
    except:
        return u''    

def string_utf8(string):
    if isinstance(string, bytes):
        return string

    return string.encode("utf-8", errors="ignore")

def normalize_text(text):
    if not text:
        return u''

    if six.PY3:
        return text

    # Python 2
    if isinstance(text, unicode):
        try:
            # corrige double-encoding comum (GÃªnio, GÃºnio, etc)
            return text.encode('latin-1').decode('utf-8')
        except:
            return text

    try:
        return text.decode('utf-8')
    except:
        try:
            return text.decode('latin-1')
        except:
            return unicode(text, errors='ignore')

def to_unicode(text, encoding='utf-8', errors='strict'):
    """Force text to unicode"""
    if isinstance(text, bytes):
        return text.decode(encoding, errors=errors)
    return text

def get_search_string(heading='', message=''):
    """Ask the user for a search string"""
    search_string = None
    keyboard = xbmc.Keyboard(message, heading)
    keyboard.doModal()
    if keyboard.isConfirmed():
        search_string = to_unicode(keyboard.getText())
    return search_string 

def input_text(heading='Put text'):
    vq = get_search_string(heading=heading, message="")        
    if ( not vq ): return False
    return vq

def infoDialog(message, iconimage='', time=3000, sound=False):
    heading = addonName

    if iconimage == '':
        iconimage = addonIcon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR

    message = to_utf8(message)
    heading = to_utf8(heading)

    dialog_.notification(heading, message, iconimage, time, sound=sound)


def notify(msg):
    try:
        infoDialog(msg,iconimage='INFO') 
    except:
        pass

def addMenuItem(params={}, destiny='', context=[], folder=True):
    name = params.get('name', '')
    description = params.get("description", "")
    originaltitle = params.get("originaltitle", "")        
    try:
        params.update({'name': string_utf8(name)})
    except:
        pass
    try:
        params.update({'description': string_utf8(description)})
    except:
        pass
    try:
        params.update({'originaltitle': string_utf8(originaltitle)})
    except:
        pass
    if 'plugin://' in destiny:
        u = destiny
    else: 
        try:
            destiny = destiny.split('/')[1]
        except:
            pass                     
        u = 'plugin://%s/%s/%s'%(plugin.split("/")[2],destiny,quote_plus(urlencode(params)))
    iconimage = params.get("iconimage", "")
    fanart = params.get("fanart", "")
    codec = params.get("codec", "")
    playable = params.get("playable", "")
    duration = params.get("duration", "")
    imdbnumber = params.get("imdbnumber", "")
    if not imdbnumber:
        imdbnumber = params.get("imdb", "")
    aired = params.get("aired", "")
    genre = params.get("genre", "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    year = params.get("year", "")
    mediatype = params.get("mediatype", "video")
    li=xbmcgui.ListItem(name)
    iconimage = proxy_artwork_url(iconimage, addonIcon)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
        infotag = True
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        infotag = False
    if year:
        if infotag:
            info.setYear(int(year))
        else:
            li.setInfo('video', {'year': int(year)})
    if codec:
        if infotag:
            info.addVideoStream(xbmc.VideoStreamDetail(codec='h264'))
        else:
            li.addStreamInfo('video', {'codec': codec})
    if duration:
        if infotag:
            info.setDuration(int(duration))
        else:
            li.setInfo('video', {'duration': int(duration)})
    if originaltitle:
        if infotag:
            info.setOriginalTitle(str(originaltitle))
        else:
            li.setInfo('video', {'originaltitle': str(originaltitle) })
    if imdbnumber:
        if infotag:
            info.setIMDBNumber(str(imdbnumber))
        else:
            li.setInfo('video', {'imdbnumber': str(imdbnumber)})
    if aired:
        if infotag:
            info.setFirstAired(str(aired))
        else:
            li.setInfo('video', {'aired': str(aired)})
    if genre:
        if infotag:
            info.setGenres([str(genre)])
        else:
            li.setInfo('video', {'genre': str(genre)})
    if season:
        if infotag:
            info.setSeason(int(season))
        else:
            li.setInfo('video', {'season': int(season)})
    if episode:
        if infotag:
            info.setEpisode(int(episode))
        else:
            li.setInfo('video', {'episode': int(episode)})
    if mediatype:
        if infotag:
            info.setMediaType(str(mediatype))
        else:
            li.setInfo('video', {'mediatype': str(mediatype)})       
    if playable and folder == False and not playable == 'false':
        li.setProperty('IsPlayable', 'true')        
    fanart = proxy_artwork_url(fanart, addonFanart)
    li.setProperty('fanart_image', fanart)
    if context:
        li.addContextMenuItems(context)        
    xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=li, isFolder=folder)


# Vigia apenas a abertura inicial do player. O objetivo e avisar quando a fonte
# foi entregue ao Kodi, mas nao consegue iniciar a reproducao. Cancelamento
# manual nao gera alerta para evitar falso positivo.
_PLAYBACK_STARTUP_TIMEOUT = 15.0
_PLAYBACK_POLL_INTERVAL = 0.25
_playback_watch_lock = threading.RLock()
_playback_watches = []


def _offline_content_message():
    message = 'Conteúdo offline no momento.\nTente novamente mais tarde.'
    try:
        xbmcgui.Dialog().ok(addonName, message)
        return
    except Exception:
        pass
    try:
        infoDialog('Conteúdo offline no momento. Tente novamente mais tarde.', iconimage='WARNING', time=6000)
    except Exception:
        pass


def _discard_playback_watch(watch):
    try:
        with _playback_watch_lock:
            if watch in _playback_watches:
                _playback_watches.remove(watch)
    except Exception:
        pass


class _PlaybackStartupWatch(xbmc.Player):
    def __init__(self, title=''):
        xbmc.Player.__init__(self)
        self.title = title or ''
        self.started = threading.Event()
        self.failed = threading.Event()
        self.stopped = threading.Event()

    def _mark_started(self):
        self.started.set()

    def onAVStarted(self):
        self._mark_started()

    def onPlayBackStarted(self):
        self._mark_started()

    def onPlayBackError(self):
        self.failed.set()

    def onPlayBackStopped(self):
        self.stopped.set()

    def onPlayBackEnded(self):
        self.stopped.set()

    def is_actually_playing(self):
        try:
            if self.isPlayingVideo():
                return True
        except Exception:
            pass
        try:
            return bool(self.isPlaying())
        except Exception:
            return False


def _monitor_player_start(watch):
    try:
        deadline = time.time() + float(_PLAYBACK_STARTUP_TIMEOUT)
        while time.time() < deadline:
            if watch.failed.is_set():
                _offline_content_message()
                return
            if watch.started.is_set() or watch.is_actually_playing():
                return
            # A parada antes da abertura normalmente e acao do usuario. Nao tratar
            # como fonte offline para nao mostrar uma mensagem indevida.
            if watch.stopped.is_set():
                return
            time.sleep(_PLAYBACK_POLL_INTERVAL)

        if not watch.started.is_set() and not watch.failed.is_set() and not watch.stopped.is_set() and not watch.is_actually_playing():
            _offline_content_message()
    except Exception as exc:
        try:
            log('Monitor de abertura do player falhou: {0}'.format(str(exc)))
        except Exception:
            pass
    finally:
        _discard_playback_watch(watch)


def play_with_startup_watch(url, listitem, title=''):
    watch = None
    try:
        watch = _PlaybackStartupWatch(title)
        with _playback_watch_lock:
            _playback_watches.append(watch)
        watch.play(item=url, listitem=listitem)
        worker = threading.Thread(target=_monitor_player_start, args=(watch,))
        worker.daemon = True
        worker.start()
        return True
    except Exception as exc:
        _discard_playback_watch(watch)
        try:
            log('Falha ao iniciar player: {0}'.format(str(exc)))
        except Exception:
            pass
        _offline_content_message()
        return False

def play_video(params):
    name = params.get('name', '')
    url = params.get('url', '')
    sub = params.get('sub', [])
    description = params.get("description", "")
    originaltitle = params.get("originaltitle", "") 
    iconimage = params.get("iconimage", "")
    fanart = params.get("fanart", "")
    codec = params.get("codec", "")
    playable = params.get("playable", "")
    duration = params.get("duration", "")
    imdbnumber = params.get("imdbnumber", "")
    if not imdbnumber:
        imdbnumber = params.get("imdb", "")
    aired = params.get("aired", "")
    genre = params.get("genre", "")
    season = params.get("season", "")
    episode = params.get("episode", "")
    year = params.get("year", "")
    mediatype = params.get("mediatype", "video")
    li=xbmcgui.ListItem(name)
    iconimage = proxy_artwork_url(iconimage, addonIcon)
    li.setArt({"icon": "DefaultVideo.png", "thumb": iconimage})
    if kversion > 19:
        info = li.getVideoInfoTag()
        info.setTitle(name)
        info.setPlot(description)
        infotag = True
    else:
        li.setInfo(type="Video", infoLabels={"Title": name, "Plot": description})
        infotag = False
    if year:
        if infotag:
            info.setYear(int(year))
        else:
            li.setInfo('video', {'year': int(year)})
    if codec:
        if infotag:
            info.addVideoStream(xbmc.VideoStreamDetail(codec='h264'))
        else:
            li.addStreamInfo('video', {'codec': codec})
    if duration:
        if infotag:
            info.setDuration(int(duration))
        else:
            li.setInfo('video', {'duration': int(duration)})
    if originaltitle:
        if infotag:
            info.setOriginalTitle(str(originaltitle))
        else:
            li.setInfo('video', {'originaltitle': str(originaltitle) })
    if imdbnumber:
        if infotag:
            info.setIMDBNumber(str(imdbnumber))
        else:
            li.setInfo('video', {'imdbnumber': str(imdbnumber)})
    if aired:
        if infotag:
            info.setFirstAired(str(aired))
        else:
            li.setInfo('video', {'aired': str(aired)})
    if genre:
        if infotag:
            info.setGenres([str(genre)])
        else:
            li.setInfo('video', {'genre': str(genre)})
    if season:
        if infotag:
            info.setSeason(int(season))
        else:
            li.setInfo('video', {'season': int(season)})
    if episode:
        if infotag:
            info.setEpisode(int(episode))
        else:
            li.setInfo('video', {'episode': int(episode)})
    if mediatype:
        if infotag:
            info.setMediaType(str(mediatype))
        else:
            li.setInfo('video', {'mediatype': str(mediatype)})
    fanart = proxy_artwork_url(fanart, addonFanart)
    li.setProperty('fanart_image', fanart)                
    li.setPath(url)
    if sub:
        li.setSubtitles(sub)               
    if playable and not playable == 'false':
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, li)
    else:
        play_with_startup_watch(url, li, name)

def setcontent(name):
    xbmcplugin.setContent(handle, name)  

def end(cache=True):
    xbmcplugin.endOfDirectory(handle,cacheToDisc=cache)

def setview(name):
    mode = {'Wall': '500',
            'List': '50',
            'Poster': '51',
            'Shift': '53',
            'InfoWall': '54',
            'WideList': '55',
            'Fanart': '502'
            }.get(name, '50')
    view = 'Container.SetViewMode(%s)'%mode
    xbmc.executebuiltin(view)  

def extract_params():
    try:
        plugin_route = sys.argv[0].split('/')[3:]
        route_sys = plugin_route[0] if plugin_route else ''
        params = {}
        try:
            param_root = plugin_route[1] # params from sys
            param_root = unquote_plus(param_root).split('&')
            for command in param_root:
                if '=' in command:
                    split_command = command.split('=', 1)
                    key = unquote_plus(split_command[0])
                    value = unquote_plus(split_command[1])
                    params[key] = value
                else:
                    params[command] = ''
        except:
            pass
        #params = dict(parse_qsl(unquote_plus(plugin_route[1]))) if len(plugin_route) > 1 else {}
        return route_sys, params
    except Exception as e:
        log('Failed to extract parameters: {0}'.format(str(e)))
        return '', {} 
    
def route(route_path):
    def decorator(func):
        route_sys, params = extract_params()
        if route_sys == route_path.strip('/'):
            try:
                if params:
                    func(params)
                else:
                    func()
            except Exception as e:
                log('Route execution error: {0}'.format(str(e)))
        return func
    return decorator


