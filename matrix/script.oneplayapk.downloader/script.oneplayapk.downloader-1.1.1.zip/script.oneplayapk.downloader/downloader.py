# downloader.py
# -*- coding: utf-8 -*-
"""Downloader MediaFire para Kodi/Android.

Fluxo esperado:
  página pública do arquivo
    -> extrai botão MediaFire (href direto ou data-scrambled-url Base64)
    -> PRIMEIRO GET da URL downloadNNNN.mediafire.com já grava o APK
    -> se a chave expirar/falhar, chama download_repair.php
    -> volta à página do arquivo, obtém nova chave e tenta uma vez novamente.

A sessão/cookies é preservada. Requests de RUM/Cloudflare não fazem parte do
fluxo funcional e não são reproduzidos.
"""

import base64
import gzip
import html
import os
import re
import time
import zlib
from http.cookiejar import CookieJar
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlencode, urljoin, urlparse
from urllib.request import Request, build_opener, HTTPCookieProcessor

import xbmc
import xbmcgui
import xbmcaddon

addon = xbmcaddon.Addon()
icon = addon.getAddonInfo('icon')

USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/153.0.0.0 Safari/537.36'
)
TIMEOUT = 30
CHUNK_SIZE = 256 * 1024
REPAIR_WAIT_SECONDS = 5.2

DIRECT_HOST_RE = re.compile(r'^download\d+\.mediafire\.com$', re.I)
QUICKKEY_RE = re.compile(r'/file/([a-z0-9]{11}|[a-z0-9]{15})(?:/|$)', re.I)


def _log(message, level=None):
    try:
        xbmc.log('[ONEPLAY APK Downloader] %s' % message, level if level is not None else xbmc.LOGINFO)
    except Exception:
        pass


def _safe_url_for_log(url):
    """Reduz URLs transitórias a informações úteis, sem expor assinatura/dkey."""
    try:
        parsed = urlparse(url or '')
        host = (parsed.hostname or '').lower()
        path = parsed.path or ''
        if DIRECT_HOST_RE.match(host):
            parts = [p for p in path.split('/') if p]
            if len(parts) >= 2:
                tail = '/'.join(parts[-2:])
                return 'https://%s/.../%s' % (host, tail)
            return 'https://%s/...' % host
        if host in ('mediafire.com', 'www.mediafire.com'):
            query = parse_qs(parsed.query or '')
            if 'dkey' in query:
                if path.endswith('/download_repair.php'):
                    qkey = query.get('qkey', [''])[0]
                    if qkey:
                        return 'https://www.mediafire.com/download_repair.php?qkey=%s&dkey=<redacted>' % qkey
                    return 'https://www.mediafire.com/download_repair.php?dkey=<redacted>'
                return 'https://%s%s?dkey=<redacted>' % (host, path)
        return url
    except Exception:
        return '<url>'


def infoDialog(message, heading=None, iconimage=None, time=3000, sound=False):
    if heading is None:
        heading = addon.getAddonInfo('name')
    if iconimage is None:
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR
    xbmcgui.Dialog().notification(heading, message, iconimage, time, sound=sound)


def _browser_opener():
    jar = CookieJar()
    opener = build_opener(HTTPCookieProcessor(jar))
    opener.addheaders = [
        ('User-Agent', USER_AGENT),
        ('Accept-Language', 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7'),
        ('Accept-Encoding', 'identity'),
    ]
    return opener


def _request(url, referer=None, accept=None):
    headers = {
        'User-Agent': USER_AGENT,
        'Accept': accept or 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
        'Upgrade-Insecure-Requests': '1',
    }
    if referer:
        headers['Referer'] = referer
    return Request(url, headers=headers)


def _is_direct_mediafire_url(url):
    try:
        host = (urlparse(url).hostname or '').lower().rstrip('.')
    except Exception:
        return False
    return bool(DIRECT_HOST_RE.match(host))


def _looks_binary(content_type, content_disposition, url):
    ctype = (content_type or '').lower()
    dispo = (content_disposition or '').lower()
    path = (urlparse(url).path or '').lower()
    if 'attachment' in dispo:
        return True
    if path.endswith('.apk') and 'text/html' not in ctype and 'application/xhtml' not in ctype:
        return True
    if 'application/vnd.android.package-archive' in ctype:
        return True
    if 'application/octet-stream' in ctype:
        return True
    return False


def _decode_html_url(value):
    value = html.unescape(value or '').strip()
    # MediaFire pode serializar links em HTML/JS com vários níveis de escape.
    replacements = (
        ('\\/', '/'),
        ('\\u002f', '/'), ('\\u002F', '/'),
        ('\\x2f', '/'), ('\\x2F', '/'),
        ('\\u003a', ':'), ('\\u003A', ':'),
        ('\\x3a', ':'), ('\\x3A', ':'),
        ('\\u0026', '&'),
        ('\\u003d', '='), ('\\u003D', '='),
        ('\\x3d', '='), ('\\x3D', '='),
        ('\\u003f', '?'), ('\\u003F', '?'),
        ('\\x3f', '?'), ('\\x3F', '?'),
    )
    for old, new in replacements:
        value = value.replace(old, new)
    return value


def _normalize_page(page):
    return _decode_html_url(page or '')


def _decode_scrambled_url(value):
    """Decodifica data-scrambled-url e normaliza escapes HTML/JS."""
    raw = html.unescape(value or '').strip()
    if not raw:
        return None
    padded = raw + ('=' * ((4 - len(raw) % 4) % 4))
    for decoder in (base64.b64decode, base64.urlsafe_b64decode):
        try:
            decoded = decoder(padded.encode('ascii')).decode('utf-8', 'strict').strip()
            decoded = _decode_html_url(decoded)
            if decoded.startswith(('http://', 'https://', '//')):
                if decoded.startswith('//'):
                    decoded = 'https:' + decoded
                return decoded
        except Exception:
            continue
    return None


def _extract_attr(tag, name):
    # Aceita atributos entre aspas simples/duplas e, como fallback, sem aspas.
    m = re.search(r'\b%s\s*=\s*(["\'])(.*?)\1' % re.escape(name), tag, re.I | re.S)
    if m:
        return html.unescape(m.group(2)).strip()
    m = re.search(r'\b%s\s*=\s*([^\s>]+)' % re.escape(name), tag, re.I | re.S)
    return html.unescape(m.group(1)).strip() if m else None


def _is_mediafire_intermediate_url(url):
    """URL do próprio MediaFire que ainda precisa gerar/redirecionar para a CDN."""
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or '').lower().rstrip('.')
        path = (parsed.path or '').lower()
        query = (parsed.query or '').lower()
    except Exception:
        return False
    if host not in ('mediafire.com', 'www.mediafire.com'):
        return False
    if 'dkey=' in query and path.startswith(('/file/', '/view/', '/download/')):
        return True
    return False


def _classify_download_target(candidate, base_url):
    candidate = _decode_html_url(candidate or '')
    if not candidate or candidate.lower().startswith(('javascript:', '#')):
        return None, None
    candidate = urljoin(base_url, candidate)
    if _is_direct_mediafire_url(candidate):
        return candidate, 'direct'
    if _is_mediafire_intermediate_url(candidate):
        return candidate, 'intermediate'
    return None, None


def _extract_download_target(page, base_url):
    """Retorna (URL, tipo), onde tipo é direct ou intermediate."""
    page = page or ''

    # 1) Âncoras de download reais. O HTML do MediaFire varia conforme UA/região.
    for m in re.finditer(r'<a\b[^>]*>', page, re.I | re.S):
        tag = m.group(0)
        ident = (_extract_attr(tag, 'id') or '').lower()
        aria = (_extract_attr(tag, 'aria-label') or '').lower()
        classes = (_extract_attr(tag, 'class') or '').lower()
        relevant = (
            ident == 'downloadbutton'
            or 'download file' in aria
            or 'download_link' in classes
            or 'downloadbutton' in classes
        )
        if not relevant:
            continue

        scrambled = _extract_attr(tag, 'data-scrambled-url')
        if scrambled:
            decoded = _decode_scrambled_url(scrambled)
            target, kind = _classify_download_target(decoded, base_url)
            if target:
                _log('Botão MediaFire resolvido por data-scrambled-url (%s).' % kind)
                return target, kind

        href = _extract_attr(tag, 'href')
        target, kind = _classify_download_target(href, base_url)
        if target:
            _log('Botão MediaFire resolvido por href (%s).' % kind)
            return target, kind

    # 2) Página inteira normalizada: cobre URLs em objetos JS/atributos fora do botão.
    normalized = _normalize_page(page)
    direct_patterns = [
        r'(https?://download\d+\.mediafire\.com/[^"\'< >\s]+)',
        r'["\'](?:download_url|downloadUrl|direct_download|directDownload)["\']\s*:\s*["\']([^"\']+)["\']',
    ]
    for pattern in direct_patterns:
        for match in re.finditer(pattern, normalized, re.I | re.S):
            target, kind = _classify_download_target(match.group(1), base_url)
            if target:
                _log('URL MediaFire encontrada por fallback HTML/JS (%s).' % kind)
                return target, kind

    # 3) Variação pré-download usada atualmente: link do MediaFire com dkey.
    pre_pattern = re.compile(
        r'((?:https?:)?//(?:www\.)?mediafire\.com/(?:file|view|download)/[^"\'<>\s?]+\?[^"\'<>\s]*\bdkey=[^"\'<>\s&]+[^"\'<>\s]*)',
        re.I,
    )
    for match in pre_pattern.finditer(normalized):
        target, kind = _classify_download_target(match.group(1), base_url)
        if target:
            _log('URL intermediária MediaFire encontrada por dkey.')
            return target, kind

    return None, None


def _extract_download_url(page, base_url):
    # Compatibilidade interna com chamadas/testes anteriores.
    target, kind = _extract_download_target(page, base_url)
    return target if kind == 'direct' else None

def _extract_repair_url(page, base_url):
    # Prefere a URL fornecida pelo próprio MediaFire.
    m = re.search(r'href\s*=\s*(["\'])([^"\']*download_repair\.php\?[^"\']+)\1', page or '', re.I | re.S)
    if m:
        return urljoin(base_url, html.unescape(m.group(2)))
    return None


def _security_block_message(page):
    lower = (page or '').lower()
    signals = (
        'file access blocked',
        'proceed with caution',
        'download at your own risk',
        'detected by google safe browsing',
        'malware detected',
    )
    if any(signal in lower for signal in signals):
        return (
            'O MediaFire marcou este arquivo com um alerta de segurança. '
            'O downloader não ignora automaticamente essa confirmação.'
        )
    return None


def _read_html(response):
    try:
        charset = response.headers.get_content_charset() or 'utf-8'
    except Exception:
        charset = 'utf-8'
    raw = response.read()
    encoding = (response.headers.get('Content-Encoding') or '').lower().strip()
    try:
        if encoding == 'gzip':
            raw = gzip.decompress(raw)
        elif encoding == 'deflate':
            try:
                raw = zlib.decompress(raw)
            except zlib.error:
                raw = zlib.decompress(raw, -zlib.MAX_WBITS)
    except Exception as exc:
        _log('Falha ao descompactar HTML (%s): %s' % (encoding, exc), xbmc.LOGWARNING)
    return raw.decode(charset, 'replace')

def _get_download_page(page_url, opener):
    """Resolve página/intermediários até a CDN, sem pré-consumir a URL CDN."""
    current_url = page_url
    referer = 'https://www.mediafire.com/'

    for hop in range(3):
        try:
            response = opener.open(_request(current_url, referer=referer), timeout=TIMEOUT)
        except HTTPError as exc:
            raise RuntimeError('MediaFire respondeu HTTP %s ao abrir a página do APK.' % exc.code)
        except URLError as exc:
            raise RuntimeError('Falha de rede ao abrir o MediaFire: %s' % exc)

        final_url = response.geturl()
        ctype = response.headers.get('Content-Type') or ''
        dispo = response.headers.get('Content-Disposition') or ''
        cenc = response.headers.get('Content-Encoding') or ''

        # Se uma URL intermediária/redirect já entregou o APK, preserve o stream.
        if _looks_binary(ctype, dispo, final_url):
            _log('MediaFire entregou binário no hop %d: %s' % (hop + 1, _safe_url_for_log(final_url)))
            return {
                'response': response,
                'direct_url': final_url,
                'referer': referer,
                'page_url': page_url,
                'repair_url': None,
            }

        try:
            page = _read_html(response)
        finally:
            try:
                response.close()
            except Exception:
                pass

        blocked = _security_block_message(page)
        if blocked:
            raise RuntimeError(blocked)

        _log(
            'HTML MediaFire hop %d: url=%s bytes=%d type=%s encoding=%s markers[id=%s aria=%s scrambled=%s cdn=%s dkey=%s]'
            % (
                hop + 1,
                _safe_url_for_log(final_url),
                len(page),
                ctype,
                cenc or 'identity',
                'yes' if re.search(r'id\s*=\s*["\']downloadButton["\']', page, re.I) else 'no',
                'yes' if 'aria-label="Download file"' in page or "aria-label='Download file'" in page else 'no',
                'yes' if 'data-scrambled-url' in page else 'no',
                'yes' if re.search(r'download\d+\.mediafire\.com', _normalize_page(page), re.I) else 'no',
                'yes' if 'dkey=' in _normalize_page(page).lower() else 'no',
            )
        )

        target, kind = _extract_download_target(page, final_url)
        repair_url = _extract_repair_url(page, final_url)

        if target and kind == 'direct':
            _log('URL CDN resolvida sem pré-download: %s' % _safe_url_for_log(target))
            if repair_url:
                _log('URL de repair fornecida pela página: %s' % _safe_url_for_log(repair_url))
            return {
                'response': None,
                'direct_url': target,
                'referer': final_url,
                'page_url': final_url,
                'repair_url': repair_url,
            }

        if target and kind == 'intermediate':
            _log('Seguindo etapa intermediária MediaFire (dkey), hop %d.' % (hop + 1))
            referer = final_url
            current_url = target
            continue

        raise RuntimeError(
            'A página do MediaFire foi aberta, mas o botão de download não forneceu uma URL CDN/intermediária reconhecida.'
        )

    raise RuntimeError('O MediaFire excedeu o limite de redirecionamentos intermediários do download.')

def _build_repair_url(page_url, direct_url):
    q = QUICKKEY_RE.search(urlparse(page_url).path or '')
    if not q:
        return None
    quickkey = q.group(1)

    parts = [p for p in (urlparse(direct_url).path or '').split('/') if p]
    if not parts:
        return None
    dkey = parts[0][:11]
    if len(dkey) < 5:
        return None

    params = {
        'qkey': quickkey,
        'dkey': dkey,
        'template': '75',
        'origin': 'click_button',
    }
    return 'https://www.mediafire.com/download_repair.php?' + urlencode(params)


def _run_repair(page_url, direct_url, opener, repair_url=None):
    repair_url = repair_url or _build_repair_url(page_url, direct_url)
    if not repair_url:
        raise RuntimeError('Não foi possível montar a URL de reparo do MediaFire.')

    _log('Executando repair da chave MediaFire: %s' % _safe_url_for_log(repair_url))
    try:
        response = opener.open(_request(repair_url, referer=page_url), timeout=TIMEOUT)
        try:
            # Consumir a resposta garante processamento completo/set-cookie na mesma sessão.
            response.read()
        finally:
            response.close()
    except HTTPError as exc:
        raise RuntimeError('MediaFire repair respondeu HTTP %s.' % exc.code)
    except URLError as exc:
        raise RuntimeError('Falha de rede no MediaFire repair: %s' % exc)

    # A própria página de repair informa espera de 5 segundos antes de continuar.
    time.sleep(REPAIR_WAIT_SECONDS)
    _log('Repair concluído; solicitando uma nova chave CDN.')
    return _get_download_page(page_url, opener)


def _open_direct_once(opener, direct_url, referer):
    """Primeiro GET da CDN já é o stream real do download."""
    try:
        return opener.open(
            _request(
                direct_url,
                referer=referer or 'https://www.mediafire.com/',
                accept='application/vnd.android.package-archive,application/octet-stream,*/*',
            ),
            timeout=TIMEOUT,
        )
    except HTTPError as exc:
        raise RuntimeError('CDN MediaFire respondeu HTTP %s.' % exc.code)
    except URLError as exc:
        raise RuntimeError('Falha de rede ao abrir a CDN MediaFire: %s' % exc)


def _validate_download_response(response):
    final_url = response.geturl()
    content_type = response.headers.get('Content-Type') or ''
    content_disposition = response.headers.get('Content-Disposition') or ''
    return _looks_binary(content_type, content_disposition, final_url)


def _format_progress(downloaded, total, started):
    elapsed = max(time.time() - started, 0.001)
    speed_bps = downloaded / elapsed
    current_mb = float(downloaded) / (1024 * 1024)

    if total and total > 0:
        percent = int(min((downloaded * 100.0) / float(total), 100))
        total_mb = float(total) / (1024 * 1024)
        eta_seconds = max((total - downloaded) / speed_bps, 0) if speed_bps > 0 else 0
        mins, secs = divmod(int(eta_seconds), 60)
        msg = '%.2f MB de %.2f MB\n' % (current_mb, total_mb)
        msg += '[COLOR yellow]Velocidade:[/COLOR] %.02f KB/s ' % (speed_bps / 1024)
        msg += '[COLOR yellow]Restante:[/COLOR] %02d:%02d' % (mins, secs)
    else:
        percent = 0
        msg = '%.2f MB baixados\n' % current_mb
        msg += '[COLOR yellow]Velocidade:[/COLOR] %.02f KB/s' % (speed_bps / 1024)

    return percent, msg


def _stream_to_file(response, dest, dp):
    total = 0
    try:
        total = int(response.headers.get('Content-Length') or 0)
    except Exception:
        total = 0

    downloaded = 0
    started = time.time()
    dp.update(0, 'Conectando ao servidor de download...')

    try:
        with open(dest, 'wb') as output:
            while True:
                if dp.iscanceled():
                    raise RuntimeError('Download cancelado pelo usuário.')
                chunk = response.read(CHUNK_SIZE)
                if not chunk:
                    break
                output.write(chunk)
                downloaded += len(chunk)
                percent, msg = _format_progress(downloaded, total, started)
                dp.update(percent, msg)
    finally:
        try:
            response.close()
        except Exception:
            pass

    if downloaded <= 0:
        raise RuntimeError('O MediaFire retornou um arquivo vazio.')
    if total > 0 and downloaded != total:
        raise RuntimeError('Download incompleto: recebido %d de %d bytes.' % (downloaded, total))

    try:
        with open(dest, 'rb') as check:
            magic = check.read(4)
        if len(magic) >= 2 and magic[:2] != b'PK':
            raise RuntimeError('O arquivo recebido não possui assinatura básica de APK/ZIP.')
    except RuntimeError:
        raise
    except Exception:
        pass


def download_py3(url, dest, dp):
    opener = _browser_opener()
    _log('Abrindo página MediaFire: %s' % url)

    resolved = _get_download_page(url, opener)
    response = resolved.get('response')

    # Caminho normal: ainda não tocamos na URL CDN. O primeiro GET abaixo já baixa.
    if response is None:
        try:
            response = _open_direct_once(opener, resolved['direct_url'], resolved['referer'])
        except RuntimeError as first_error:
            _log('Primeira chave CDN falhou: %s' % first_error, xbmc.LOGWARNING)
            resolved = _run_repair(
                resolved['page_url'], resolved['direct_url'], opener, resolved.get('repair_url')
            )
            if resolved.get('response') is not None:
                response = resolved['response']
            else:
                response = _open_direct_once(opener, resolved['direct_url'], resolved['referer'])

    # Se a CDN devolveu HTML em vez do APK, trate como chave expirada e tente repair uma vez.
    if not _validate_download_response(response):
        try:
            response.close()
        except Exception:
            pass
        _log('A CDN não retornou binário; tentando MediaFire repair.', xbmc.LOGWARNING)
        resolved = _run_repair(
            resolved['page_url'], resolved['direct_url'], opener, resolved.get('repair_url')
        )
        if resolved.get('response') is not None:
            response = resolved['response']
        else:
            response = _open_direct_once(opener, resolved['direct_url'], resolved['referer'])
        if not _validate_download_response(response):
            try:
                response.close()
            except Exception:
                pass
            raise RuntimeError('Mesmo após o repair, o MediaFire não retornou o APK.')

    _log('Download binário iniciado: %s' % _safe_url_for_log(response.geturl()))
    _stream_to_file(response, dest, dp)


def download(url, name, dest, dp=None):
    if dp is None:
        dp = xbmcgui.DialogProgress()
        dp.create('Baixando %s...' % name, 'Por favor, aguarde...')

    dp.update(0)
    try:
        download_py3(url, dest, dp)
    except Exception:
        try:
            os.remove(dest)
        except Exception:
            pass
        raise
