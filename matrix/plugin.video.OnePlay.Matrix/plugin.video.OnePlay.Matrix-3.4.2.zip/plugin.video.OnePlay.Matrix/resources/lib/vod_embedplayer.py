# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Provider VOD EmbedPlayer integrado ao OnePlay Matrix.

Contrato periciado em setembro/2026 a partir de HARs reais + kodi.log:

* filme público: ``https://api.embedplayer.site/<imdb>/`` (IMDb obrigatório);
* série pública: ``https://api.embedplayer.site/tv/<tmdb>/<season>/<episode>/dub``
  (TMDB obrigatório, temporada/episódio explícitos, áudio dublado);
* a página pública contém identificadores temporários ``idS`` (128 hex). O
  navegador envia cada identificador por XHR ``POST /stream``;
* ``/stream`` responde JSON e publica o iframe real em
  ``resources.sources[].file`` como ``embedplayer*.xyz/video/<hash>``;
* o player resolve a mídia por POST same-origin em
  ``/player/index.php?data=<hash>&do=getVideo``;
* a resposta fornece ``videoSource`` (preferido) e/ou ``securedLink``;
* o HLS observado usa ``master.txt`` e pode apontar para playlists ``/m3/...``
  cujos segmentos são mascarados como .js/.css/.woff. A Matrix classifica
  esses filhos pelo contexto HLS, não pela extensão.

O provider não executa JavaScript, não carrega anúncios/JWPlayer e não persiste
credenciais. Reproduz somente o caminho HTTP mínimo necessário observado nos
HARs e entrega o HLS ao proxy VOD já homologado da Matrix.
"""

import html
import ipaddress
import json
import re
import time
try:
    from urllib.parse import urlparse
except ImportError:  # pragma: no cover
    from urlparse import urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None


ROOT = 'https://api.embedplayer.site'
PROVIDER_NAME = 'EmbedPlayer'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/153.0.0.0 Safari/537.36'
)
BASE_HEADERS = {
    'User-Agent': USER_AGENT,
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.7,en;q=0.6',
    'Cache-Control': 'no-cache',
}
PAGE_HEADERS = dict(BASE_HEADERS, **{
    'Accept': 'text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8',
})
MEDIA_HEADERS = dict(BASE_HEADERS, **{'Accept': '*/*'})
REQUEST_TIMEOUT = (2.5, 5.5)
PROBE_TIMEOUT = (2.0, 4.0)
BUDGET_SECONDS = 10.0
PAGE_MAX_BYTES = 1024 * 1024
PLAYER_MAX_BYTES = 1024 * 1024
JSON_MAX_BYTES = 128 * 1024
HLS_PROBE_MAX_BYTES = 128 * 1024
MAX_STREAM_TOKENS = 8
MAX_PLAYER_CANDIDATES = 6
MAX_STREAMS = 4

TMDB_RE = re.compile(r'^\d+$')
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
PLAYER_HOST_RE = re.compile(r'^(?:www\.)?embedplayer\d*\.xyz$', re.I)
PLAYER_URL_RE = re.compile(
    r'(?i)(?:https?:)?//(?:www\.)?embedplayer\d*\.xyz/video/[A-Za-z0-9_-]{8,128}'
)
PLAYER_PATH_RE = re.compile(r'^/video/([A-Za-z0-9_-]{8,128})(?:/|$)')
STREAM_TOKEN_RE = re.compile(r'(?<![A-Fa-f0-9])([A-Fa-f0-9]{128})(?![A-Fa-f0-9])')
STRONG_STREAM_TOKEN_PATTERNS = (
    re.compile(
        r'''(?is)\b(?:idS|stream[_-]?id|streamId|data[-_:](?:id|stream|ids))\b'''
        r'''[^A-Fa-f0-9]{0,180}([A-Fa-f0-9]{128})'''
    ),
    re.compile(
        r'''(?is)\b(?:run|play|load)\s*\(\s*["']([A-Fa-f0-9]{128})["']'''
    ),
)
STREAM_CONTEXT_MARKERS = (
    'ids', 'stream', 'server', 'assistir', 'player', 'gstream', 'run(', 'play('
)


def _text(value):
    try:
        if isinstance(value, bytes):
            return value.decode('utf-8', 'replace')
        return str(value or '')
    except Exception:
        return ''


def _valid_imdb(value):
    return bool(IMDB_RE.match(_text(value).strip()))


def _valid_tmdb(value):
    return bool(TMDB_RE.match(_text(value).strip()))


def _series_numbers(season, episode):
    try:
        season = int(season)
        episode = int(episode)
        if season < 0 or episode < 1:
            return None
        return season, episode
    except Exception:
        return None


def _safe_public_url(value):
    """Aceita somente HTTP(S) público sem normalizar query/token."""
    value = html.unescape(_text(value)).strip().strip('"\'')
    if not value:
        return ''
    value = value.replace('\\/', '/')
    if value.startswith('//'):
        value = 'https:' + value
    try:
        parsed = urlparse(value)
        if (parsed.scheme or '').lower() not in ('http', 'https') or not parsed.hostname:
            return ''
        host = parsed.hostname.strip().lower().rstrip('.')
        if host == 'localhost' or host.endswith('.localhost') or host.endswith('.local'):
            return ''
        try:
            ip_value = ipaddress.ip_address(host)
            if not ip_value.is_global:
                return ''
        except ValueError:
            pass
        return value
    except Exception:
        return ''


def _host(value):
    try:
        return (urlparse(value).hostname or '').strip().lower().rstrip('.')
    except Exception:
        return ''


def _origin(value):
    try:
        parsed = urlparse(value)
        if (parsed.scheme or '').lower() not in ('http', 'https') or not parsed.netloc:
            return ''
        return '{}://{}'.format(parsed.scheme.lower(), parsed.netloc)
    except Exception:
        return ''


def _is_player_host_url(value):
    value = _safe_public_url(value)
    return bool(value and PLAYER_HOST_RE.match(_host(value)))


def _read_limited(response, max_bytes):
    """Lê resposta bounded sem confiar em Content-Length."""
    chunks = []
    total = 0
    try:
        iterator = response.iter_content(chunk_size=32768)
    except Exception:
        raw = getattr(response, 'content', b'') or b''
        if len(raw) > max_bytes:
            raise ValueError('resposta-grande')
        return raw
    for chunk in iterator:
        if not chunk:
            continue
        total += len(chunk)
        if total > max_bytes:
            raise ValueError('resposta-grande')
        chunks.append(chunk)
    return b''.join(chunks)


def _decode_body(raw, response=None):
    if isinstance(raw, str):
        return raw
    encoding = ''
    try:
        encoding = getattr(response, 'encoding', '') or ''
    except Exception:
        pass
    for candidate in (encoding, 'utf-8', 'latin-1'):
        if not candidate:
            continue
        try:
            return raw.decode(candidate, 'replace')
        except Exception:
            continue
    return _text(raw)


def _player_hash(url):
    try:
        parsed = urlparse(url)
        host = (parsed.hostname or '').strip().lower().rstrip('.')
        if not PLAYER_HOST_RE.match(host):
            return ''
        match = PLAYER_PATH_RE.match(parsed.path or '')
        return match.group(1) if match else ''
    except Exception:
        return ''


def _audio_from_context(source, position, public_url):
    """Infere rótulo só para UI; não altera a rota consultada."""
    if '/dub' in (public_url or '').lower():
        return 'Dublado'
    source = _text(source)
    position = max(0, int(position or 0))
    start = max(0, position - 1800)
    end = min(len(source), position + 450)
    context = source[start:end].lower()
    rel = position - start
    candidates = []
    for label, words in (
        ('Dublado', ('dublado', 'dub')),
        ('Legendado', ('legendado', 'leg')),
    ):
        best = None
        for word in words:
            scan = 0
            while True:
                idx = context.find(word, scan)
                if idx < 0:
                    break
                distance = abs(idx - rel)
                # Rótulos imediatamente anteriores ao botão/token são mais
                # confiáveis que palavras posteriores ou muito distantes.
                penalty = 0 if idx <= rel else 300
                score = distance + penalty
                if best is None or score < best:
                    best = score
                scan = idx + len(word)
        if best is not None:
            candidates.append((best, label))
    if candidates:
        candidates.sort(key=lambda item: item[0])
        return candidates[0][1]
    return ''


def _extract_player_candidates(source, public_url):
    """Extrai players conhecidos em ordem de aparição."""
    text = html.unescape(_text(source)).replace('\\/', '/')
    rows = []
    seen = set()
    for match in PLAYER_URL_RE.finditer(text):
        value = _safe_public_url(match.group(0))
        if not value or not _player_hash(value) or value in seen:
            continue
        seen.add(value)
        rows.append((value, _audio_from_context(text, match.start(), public_url), 'pagina'))
        if len(rows) >= MAX_PLAYER_CANDIDATES:
            break
    return rows


def _extract_stream_tokens(source, public_url):
    """Extrai ``idS`` dinâmicos da página sem depender do markup exato.

    Os HARs provam que ``idS`` é um token hexadecimal de 128 caracteres, mas a
    captura começou após o carregamento do documento e não preservou o HTML
    inicial. Para evitar acoplamento frágil a um atributo específico, primeiro
    usamos padrões contextuais fortes e depois aceitamos tokens de 128 hex que
    estejam próximos de marcadores de player/servidor. Como último fallback,
    em páginas que claramente são telas de reprodução, aceitamos os poucos
    tokens de 128 hex presentes no documento. O número de POSTs é limitado.
    """
    text = html.unescape(_text(source)).replace('\\/', '/')
    rows = []
    seen = set()

    def add(token, position, strength):
        token = _text(token).strip()
        if not STREAM_TOKEN_RE.fullmatch(token) or token in seen:
            return
        seen.add(token)
        rows.append((position, token, _audio_from_context(text, position, public_url), strength))

    # 1) Referências explícitas a idS/run/play.
    for pattern in STRONG_STREAM_TOKEN_PATTERNS:
        for match in pattern.finditer(text):
            add(match.group(1), match.start(1), 0)

    # 2) Token exato de 128 hex próximo de contexto de player.
    generic = list(STREAM_TOKEN_RE.finditer(text))
    for match in generic:
        if match.group(1) in seen:
            continue
        start = max(0, match.start(1) - 900)
        end = min(len(text), match.end(1) + 450)
        context = text[start:end].lower()
        if any(marker in context for marker in STREAM_CONTEXT_MARKERS):
            add(match.group(1), match.start(1), 1)

    # 3) Fallback controlado para markup/JS minificado diferente. A página
    # pública observada é explicitamente uma tela "ASSISTIR AGORA"; 128 hex é
    # suficientemente específico, e nunca enviamos mais que MAX_STREAM_TOKENS.
    page_hint = text.lower()
    looks_like_player_page = any(
        marker in page_hint for marker in ('assistir', 'servidor', 'gstream', '/stream', 'player')
    )
    if looks_like_player_page:
        for match in generic:
            if match.group(1) not in seen:
                add(match.group(1), match.start(1), 2)

    rows.sort(key=lambda item: (item[3], item[0]))
    return [(token, audio) for _, token, audio, _ in rows[:MAX_STREAM_TOKENS]]


def _players_from_stream_payload(payload, audio_label=''):
    """Lê somente ``resources.sources[].file`` de hosts de player permitidos."""
    if not isinstance(payload, dict):
        return []
    resources = payload.get('resources')
    if not isinstance(resources, dict):
        return []
    sources = resources.get('sources')
    if isinstance(sources, dict):
        sources = [sources]
    if not isinstance(sources, list):
        return []
    rows = []
    seen = set()
    for item in sources:
        if not isinstance(item, dict):
            continue
        value = _safe_public_url(item.get('file'))
        if not value or not _player_hash(value) or value in seen:
            continue
        seen.add(value)
        rows.append((value, audio_label, 'stream'))
        if len(rows) >= MAX_PLAYER_CANDIDATES:
            break
    return rows


class EmbedPlayerVodProvider(object):
    def __init__(self, requests_module=None, logger=None, root_url=None,
                 monotonic=None):
        self.requests = requests_module or _requests
        self.logger = logger
        self.root_url = (root_url or ROOT).rstrip('/')
        self.monotonic = monotonic or time.monotonic
        self.session = None
        if self.requests is not None:
            try:
                self.session = self.requests.Session()
                self.session.headers.update(BASE_HEADERS)
            except Exception:
                self.session = None

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    def _public_url(self, media_type, tmdb_id='', imdb_id='', season=None, episode=None):
        media_type = _text(media_type).strip().lower()
        if media_type == 'movie':
            imdb_id = _text(imdb_id).strip()
            if not _valid_imdb(imdb_id):
                return '', 'sem-imdb'
            return '{}/{}/'.format(self.root_url, imdb_id), 'imdb'
        if media_type == 'series':
            tmdb_id = _text(tmdb_id).strip()
            pair = _series_numbers(season, episode)
            if not _valid_tmdb(tmdb_id):
                return '', 'sem-tmdb'
            if pair is None:
                return '', 'episodio-invalido'
            return '{}/tv/{}/{}/{}/dub'.format(
                self.root_url, tmdb_id, pair[0], pair[1]), 'tmdb'
        return '', 'tipo-nao-suportado'

    def _get_text(self, url, deadline, max_bytes, headers=None):
        if self.monotonic() >= deadline:
            raise TimeoutError('budget-timeout')
        response = self.session.get(
            url, headers=headers or PAGE_HEADERS, timeout=REQUEST_TIMEOUT,
            allow_redirects=True, stream=True
        )
        status = int(getattr(response, 'status_code', 0) or 0)
        final_url = _safe_public_url(getattr(response, 'url', '') or url)
        if status < 200 or status >= 300:
            try:
                response.close()
            except Exception:
                pass
            return '', final_url or url, status
        try:
            raw = _read_limited(response, max_bytes)
            return _decode_body(raw, response), final_url or url, status
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _post_json(self, url, data, headers, deadline, max_bytes=JSON_MAX_BYTES,
                   allow_redirects=False):
        if self.monotonic() >= deadline:
            raise TimeoutError('budget-timeout')
        response = self.session.post(
            url, data=data, headers=headers, timeout=REQUEST_TIMEOUT,
            allow_redirects=allow_redirects, stream=True,
        )
        status = int(getattr(response, 'status_code', 0) or 0)
        try:
            if status < 200 or status >= 300:
                return None, status
            raw = _read_limited(response, max_bytes)
            text = _decode_body(raw, response).strip()
            value = json.loads(text)
            return value if isinstance(value, dict) else None, status
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _stream_json(self, stream_token, public_url, deadline):
        """Reproduz o XHR ``POST /stream`` observado nos HARs."""
        endpoint = self.root_url.rstrip('/') + '/stream'
        root_origin = _origin(self.root_url)
        headers = dict(MEDIA_HEADERS)
        headers.update({
            'Origin': root_origin,
            'Referer': public_url,
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        })
        return self._post_json(
            endpoint, {'idS': stream_token}, headers, deadline,
            max_bytes=JSON_MAX_BYTES, allow_redirects=False
        )

    def _get_video_json(self, player_url, player_hash, deadline):
        if self.monotonic() >= deadline:
            raise TimeoutError('budget-timeout')
        parsed = urlparse(player_url)
        origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
        endpoint = '{}/player/index.php?data={}&do=getVideo'.format(origin, player_hash)
        headers = dict(MEDIA_HEADERS)
        headers.update({
            'Origin': origin,
            'X-Requested-With': 'XMLHttpRequest',
            'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
        })
        # O navegador observado envia document.referrer, que no player é a raiz
        # da API, e não a URL /tv/... ou /tt.../ do conteúdo.
        referrer_root = self.root_url.rstrip('/') + '/'
        return self._post_json(
            endpoint, {'hash': player_hash, 'r': referrer_root}, headers,
            deadline, max_bytes=JSON_MAX_BYTES, allow_redirects=False
        )

    def _probe_hls(self, url, deadline):
        if self.monotonic() >= deadline:
            raise TimeoutError('budget-timeout')
        response = self.session.get(
            url, headers=MEDIA_HEADERS, timeout=PROBE_TIMEOUT,
            allow_redirects=True, stream=True
        )
        status = int(getattr(response, 'status_code', 0) or 0)
        final_url = _safe_public_url(getattr(response, 'url', '') or url)
        content_type = _text((getattr(response, 'headers', {}) or {}).get('Content-Type')).lower()
        try:
            if status < 200 or status >= 300:
                return False, final_url or url, status, content_type
            raw = _read_limited(response, HLS_PROBE_MAX_BYTES)
            body = _decode_body(raw, response).lstrip('\ufeff\r\n\t ')
            return bool(body.startswith('#EXTM3U')), final_url or url, status, content_type
        finally:
            try:
                response.close()
            except Exception:
                pass

    def _resolve_player(self, player_url, audio_label, id_kind, media_type,
                        tmdb_id, imdb_id, index, deadline, audit):
        player_hash = _player_hash(player_url)
        if not player_hash:
            audit.append('player-{}-hash-invalido'.format(index))
            return None

        # A sequência real abre /video/<hash> antes do POST getVideo. Os HARs
        # não mostram cookie obrigatório, mas manter esta etapa replica o
        # contrato do navegador e deixa espaço para sessão leve futura.
        _, final_player_url, player_status = self._get_text(
            player_url, deadline, PLAYER_MAX_BYTES, headers=PAGE_HEADERS
        )
        if player_status != 200:
            audit.append('player-{}-http-{}'.format(index, player_status or 0))
            return None
        if not _is_player_host_url(final_player_url or player_url):
            audit.append('player-{}-redirect-host'.format(index))
            return None
        player_url = final_player_url or player_url
        player_hash = _player_hash(player_url) or player_hash

        payload, post_status = self._get_video_json(player_url, player_hash, deadline)
        if post_status != 200 or not payload:
            audit.append('getvideo-{}-http-{}'.format(index, post_status or 0))
            return None

        media_candidates = []
        for key in ('videoSource', 'securedLink'):
            media_url = _safe_public_url(payload.get(key))
            # O ponto de entrada HLS observado fica no mesmo conjunto de hosts
            # embedplayer*.xyz. Os filhos da playlist podem apontar a CDNs
            # externas e são tratados depois pelo proxy homologado.
            if media_url and PLAYER_HOST_RE.match(_host(media_url)) and media_url not in media_candidates:
                media_candidates.append(media_url)

        selected = ''
        selected_type = ''
        for media_url in media_candidates:
            ok, final_media_url, media_status, content_type = self._probe_hls(media_url, deadline)
            if not ok:
                audit.append('hls-{}-http-{}'.format(index, media_status or 0))
                continue
            final_media_url = final_media_url or media_url
            if not PLAYER_HOST_RE.match(_host(final_media_url)):
                audit.append('hls-{}-redirect-host'.format(index))
                continue
            selected = final_media_url
            selected_type = content_type
            break
        if not selected:
            audit.append('player-{}-sem-hls'.format(index))
            return None

        try:
            host = (urlparse(selected).hostname or '').lower()
        except Exception:
            host = ''
        ui_audio = audio_label or ('Dublado' if media_type == 'series' else 'Áudio do servidor')
        label = '{} • {}'.format(ui_audio, PROVIDER_NAME)
        return {
            'name': label,
            'title': label,
            'description': '{} • HLS'.format(ui_audio),
            'url': selected,
            '__vod_kind': 'hls',
            '__vod_source_family': PROVIDER_NAME,
            '__vod_source_host': host,
            '__vod_playable': True,
            '__vod_caution': False,
            '__vod_caution_reasons': (),
            '__vod_raw_title': label,
            '__vod_raw_name': PROVIDER_NAME,
            '__vod_target_type': 'url',
            '__vod_target_value': selected,
            '__request_rank': 71 + max(0, index - 1),
            '__request_label': 'embedplayer-{}'.format(id_kind),
            '__vod_provider_id': _text(imdb_id if id_kind == 'imdb' else tmdb_id).strip(),
            '__vod_provider_id_kind': id_kind,
            '__vod_provider': PROVIDER_NAME,
            '__vod_request_headers': dict(MEDIA_HEADERS),
            '__vod_probe_content_type': selected_type,
        }

    def resolve(self, media_type, tmdb_id='', imdb_id='', season=None, episode=None):
        media_type = _text(media_type).strip().lower()
        public_url, id_kind = self._public_url(
            media_type, tmdb_id=tmdb_id, imdb_id=imdb_id,
            season=season, episode=episode
        )
        if not public_url:
            reason_map = {
                'sem-imdb': 'IMDb exato não disponível para EmbedPlayer.',
                'sem-tmdb': 'TMDB exato não disponível para EmbedPlayer.',
                'episodio-invalido': 'Episódio inválido para EmbedPlayer.',
                'tipo-nao-suportado': 'Tipo não suportado pelo EmbedPlayer.',
            }
            return {'streams': [], 'reason': reason_map.get(id_kind, 'Identificador inválido.'), 'audit': [id_kind]}
        if self.session is None:
            return {'streams': [], 'reason': 'Cliente HTTP indisponível para EmbedPlayer.', 'audit': ['sem-http']}
        # Tokens/cookies do player são efêmeros. Mantemos sessão apenas dentro da
        # consulta atual e limpamos qualquer cookie herdado da busca anterior.
        try:
            self.session.cookies.clear()
        except Exception:
            pass

        deadline = self.monotonic() + BUDGET_SECONDS
        audit = ['contrato={}'.format(id_kind)]
        try:
            page, final_public_url, status = self._get_text(
                public_url, deadline, PAGE_MAX_BYTES, headers=PAGE_HEADERS
            )
            if status != 200 or not page:
                audit.append('pagina-http-{}'.format(status or 0))
                return {
                    'streams': [],
                    'reason': 'EmbedPlayer indisponível nesta consulta (HTTP {}).'.format(status or 0),
                    'audit': audit,
                }
            # O endpoint público é fixo e controlado pelo provider. Não aceitamos
            # que um redirect transforme a etapa de descoberta em fetch arbitrário.
            root_host = _host(self.root_url)
            if final_public_url and _host(final_public_url) != root_host:
                return {
                    'streams': [],
                    'reason': 'EmbedPlayer redirecionou para host inesperado.',
                    'audit': audit + ['pagina-redirect-host'],
                }
            public_referrer = final_public_url or public_url

            # Contrato atual: HTML -> idS -> POST /stream -> resources.sources[].file.
            stream_tokens = _extract_stream_tokens(page, public_referrer)
            audit.append('ids={}'.format(len(stream_tokens)))
            players = []
            seen_players = set()
            stream_ok = 0
            for token_index, (stream_token, audio_label) in enumerate(stream_tokens, 1):
                if self.monotonic() >= deadline or len(players) >= MAX_PLAYER_CANDIDATES:
                    break
                payload, stream_status = self._stream_json(
                    stream_token, public_referrer, deadline
                )
                if stream_status != 200 or not payload:
                    audit.append('stream-{}-http-{}'.format(token_index, stream_status or 0))
                    continue
                rows = _players_from_stream_payload(payload, audio_label)
                if not rows:
                    audit.append('stream-{}-sem-player'.format(token_index))
                    continue
                stream_ok += 1
                for row in rows:
                    if row[0] in seen_players:
                        continue
                    seen_players.add(row[0])
                    players.append(row)
                    if len(players) >= MAX_PLAYER_CANDIDATES:
                        break
            audit.append('stream-ok={}'.format(stream_ok))

            # Fallback compatível com a primeira auditoria: se a origem voltar a
            # expor iframe direto no HTML, não dependemos de /stream.
            for row in _extract_player_candidates(page, public_referrer):
                if row[0] in seen_players:
                    continue
                seen_players.add(row[0])
                players.append(row)
                if len(players) >= MAX_PLAYER_CANDIDATES:
                    break
            audit.append('players={}'.format(len(players)))
            if not players:
                final_audit = audit + ['sem-player']
                self._log('sem fonte após descoberta: {}.'.format('|'.join(final_audit[-8:])), 1)
                return {
                    'streams': [],
                    'reason': 'EmbedPlayer sem servidor de vídeo reconhecido.',
                    'audit': final_audit,
                }

            streams = []
            seen_hls = set()
            for index, (player_url, audio_label, source_kind) in enumerate(players, 1):
                if self.monotonic() >= deadline:
                    audit.append('budget-timeout')
                    break
                stream = self._resolve_player(
                    player_url, audio_label, id_kind, media_type,
                    tmdb_id, imdb_id, index, deadline, audit
                )
                if not stream:
                    continue
                if stream.get('url') in seen_hls:
                    audit.append('player-{}-hls-duplicado'.format(index))
                    continue
                seen_hls.add(stream.get('url'))
                # Se houver múltiplos servidores/áudios, deixe a UI distingui-los
                # pela ordem Fonte N; o nome técnico do provider continua oculto
                # pelo apresentador VOD existente.
                streams.append(stream)
                audit.append('player-{}-online-hls-{}'.format(index, source_kind))
                if len(streams) >= MAX_STREAMS:
                    break

            if streams:
                self._log('{} resolveu {}: {} fonte(s).'.format(PROVIDER_NAME, media_type, len(streams)), 1)
                return {'streams': streams, 'reason': '', 'audit': audit + ['ok={}'.format(len(streams))]}
            final_audit = audit + ['sem-stream']
            self._log('sem fonte após resolução: {}.'.format('|'.join(final_audit[-10:])), 1)
            return {
                'streams': [],
                'reason': 'EmbedPlayer sem HLS reproduzível nesta consulta.',
                'audit': final_audit,
            }
        except TimeoutError:
            return {
                'streams': [],
                'reason': 'EmbedPlayer excedeu o budget local desta consulta.',
                'audit': audit + ['budget-timeout'],
            }
        except Exception as exc:
            self._log('EmbedPlayer falhou de forma isolada: {}.'.format(exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': 'EmbedPlayer indisponível nesta consulta.',
                'audit': audit + ['erro:{}'.format(exc.__class__.__name__)],
            }


_DEFAULT_PROVIDER = None


def _kodi_logger(message, level=1):
    try:
        from resources.lib.common import log, log_debug
        log('[VOD][EmbedPlayer] {}'.format(message), level=level)
        log_debug(message, component='EmbedPlayer')
    except Exception:
        pass


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        _DEFAULT_PROVIDER = EmbedPlayerVodProvider(logger=_kodi_logger)
    return _DEFAULT_PROVIDER


def reset_default_provider_for_tests():
    global _DEFAULT_PROVIDER
    _DEFAULT_PROVIDER = None
