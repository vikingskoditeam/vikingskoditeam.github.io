# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Provider VOD HDHub isolado, usado como última origem do agregador.

Contrato conservador:
* usa somente IMDb exato já resolvido pela Matrix;
* uma única requisição GET por filme/episódio, sem probe/HEAD e sem retry;
* filmes: /stream/movie/<imdb>.json;
* séries: /stream/series/<imdb>:<season>:<episode>.json;
* publica somente progressive com Range 0-0 validado ou torrent com magnet válido;
* filtra Download, HLS/DASH não validados, links opacos e hosts instáveis antes da UI;
* oculta tamanho de arquivo somente nas fontes HDHub;
* falha/timeout desta fonte nunca invalida FrostStream/FenixFlix/SuperStream.
"""

import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from urllib.parse import urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None

from resources.lib import vod_engine as _vod_engine


HDHUB_API_ROOT = (
    'https://hdhub.thevolecitor.qzz.io/'
    'eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAsNDgwcCIs'
    'InNvcnQiOiJhc2MiLCJjYXRhbG9ncyI6IiJ9'
)
HDHUB_PROVIDER_NAME = 'HDHub'
HDHUB_REFERER = 'https://hdhub.thevolecitor.qzz.io/'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/151.0.0.0 Safari/537.36'
)
REQUEST_TIMEOUT = (2.0, 5.0)
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
HEALTH_NAMESPACE = 'vod_hdhub_provider_health_v1'
HEALTH_KEY = 'cooldown'
NETWORK_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60
SERVER_COOLDOWN_SECONDS = 30
MAX_STREAMS = 80
# Perícia real de 02/09/2026: no HDHub, as fontes HLS observadas retornaram
# playlist inválida; as fontes progressivas só foram estáveis quando aceitaram
# Range 0-0 com HTTP 206. Por isso o provider só publica progressive
# previamente validado e torrent com magnet válido.
DIRECT_PLAY_KINDS = frozenset(('progressive',))
PREFLIGHT_TIMEOUT = (1.2, 2.2)
PREFLIGHT_TTL_OK = 120.0
PREFLIGHT_TTL_BAD = 60.0
PREFLIGHT_WORKERS = 8
PREFLIGHT_MAX_CANDIDATES = 24
CONTENT_RANGE_RE = re.compile(r'^\s*bytes\s+(\d+)\s*-\s*(\d+)\s*/\s*(\d+)\s*$', re.I)
# Hosts que falharam de forma consistente/estrutural no log real.
# Cloudflare R2 NÃO entra aqui porque o mesmo host apresentou URLs boas e ruins;
# essas são decididas por preflight individual da URL.
UNSTABLE_HOST_SUFFIXES = (
    'lenin.buzz',
    'hakunaymatata.com',
    'cocktail.beer',
)
DOWNLOAD_MARKER_RE = re.compile(r'(?i)(?:^|[^a-z0-9])(?:download(?:[ -]?only)?|baixar)(?:[^a-z0-9]|$)')
SIZE_LABEL_RE = re.compile(r'(?i)(?:\s*[|•\-]\s*)?\b\d+(?:[.,]\d+)?\s*(?:kb|mb|gb|tb|kib|mib|gib|tib)\b')


class HdHubVodProvider(object):
    """Resolvedor HDHub pequeno e sem dependência do Kodi."""

    def __init__(self, requests_module=None, cache_api=None, logger=None, clock=None,
                 api_root=HDHUB_API_ROOT):
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.api_root = (api_root or HDHUB_API_ROOT).rstrip('/')
        self._preflight_cache = {}
        self._preflight_lock = Lock()
        # Usado estritamente para normalizar Stream Objects. Não consulta o
        # manifesto FrostStream nem usa o cache/rede dele neste provider.
        self._normalizer = _vod_engine.FrostStreamVodEngine(
            requests_module=self.requests, cache_api=None, clock=self.clock
        )

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def _valid_imdb(imdb_id):
        return bool(IMDB_RE.match((imdb_id or '').strip()))

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(HEALTH_NAMESPACE, HEALTH_KEY)
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return str(value.get('reason') or 'cooldown')
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                HEALTH_NAMESPACE, HEALTH_KEY,
                {'reason': str(reason or 'provider-indisponivel')},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    def _build_api_url(self, media_type, imdb_id, season=None, episode=None):
        imdb_id = (imdb_id or '').strip()
        if not self._valid_imdb(imdb_id):
            return ''
        if media_type == 'movie':
            return '{}/stream/movie/{}.json'.format(self.api_root, imdb_id)
        if media_type != 'series':
            return ''
        try:
            season_value = int(season)
            episode_value = int(episode)
        except Exception:
            return ''
        if season_value < 0 or episode_value < 1:
            return ''
        return '{}/stream/series/{}:{}:{}.json'.format(
            self.api_root, imdb_id, season_value, episode_value
        )

    @staticmethod
    def _raw_text(raw):
        if not isinstance(raw, dict):
            return ''
        return ' '.join(str(raw.get(key) or '') for key in ('name', 'title', 'description'))

    @classmethod
    def _is_download_entry(cls, raw):
        # O HDHub publica itens explicitamente chamados "Download" que no log
        # real resolveram para páginas/links gpdl e falharam com HTTP 400.
        return bool(DOWNLOAD_MARKER_RE.search(cls._raw_text(raw)))

    @staticmethod
    def _strip_size_label(value):
        text = str(value or '')
        text = SIZE_LABEL_RE.sub(' ', text)
        text = re.sub(r'\s*[|•]\s*(?=[|•]|$)', ' ', text)
        return re.sub(r'\s{2,}', ' ', text).strip(' |•-')

    @classmethod
    def _is_reproducible_item(cls, item):
        if not isinstance(item, dict):
            return False, 'normalizacao-invalida'
        kind = (item.get('__vod_kind') or '').strip().lower()
        target_type = (item.get('__vod_target_type') or '').strip().lower()

        # Torrent com magnet válido continua sendo uma fonte reproduzível porque
        # a Matrix já possui a ponte homologada para o PureTorrent.
        if kind == 'torrent':
            if item.get('__vod_torrent_magnet'):
                return True, 'torrent'
            return False, 'torrent-invalido'

        # Para o HDHub, URL HTTP apenas "existir" não basta. Links unknown
        # incluem páginas/intermediários de download; só entram formatos de mídia
        # que o motor reconhece como HLS, DASH ou arquivo progressivo.
        if target_type != 'url' or not item.get('__vod_playable'):
            return False, 'nao-reproduzivel'
        if kind not in DIRECT_PLAY_KINDS:
            return False, 'url-opaca'
        return True, kind

    @staticmethod
    def _host(value):
        try:
            return (urlparse(str(value or '')).hostname or '').lower().strip('.')
        except Exception:
            return ''

    @classmethod
    def _known_unstable_host(cls, item):
        host = cls._host(item.get('url') if isinstance(item, dict) else '')
        if not host:
            return False
        return any(host == suffix or host.endswith('.' + suffix) for suffix in UNSTABLE_HOST_SUFFIXES)

    @staticmethod
    def _parse_content_range(value):
        try:
            match = CONTENT_RANGE_RE.match(str(value or ''))
            if not match:
                return None
            start, end, total = [int(piece) for piece in match.groups()]
            if start != 0 or end != 0 or total <= 1:
                return None
            return start, end, total
        except Exception:
            return None

    def _preflight_cache_get(self, url):
        now = self.clock()
        key = str(url or '').strip()
        if not key:
            return None
        with self._preflight_lock:
            item = self._preflight_cache.get(key)
            if not item:
                return None
            if float(item.get('until') or 0) <= now:
                self._preflight_cache.pop(key, None)
                return None
            return bool(item.get('ok'))

    def _preflight_cache_put(self, url, ok):
        key = str(url or '').strip()
        if not key:
            return
        ttl = PREFLIGHT_TTL_OK if ok else PREFLIGHT_TTL_BAD
        with self._preflight_lock:
            self._preflight_cache[key] = {'ok': bool(ok), 'until': self.clock() + ttl}

    def _probe_progressive(self, item):
        """Confirma que a URL progressiva aceita Range real antes de ir à UI.

        Para o HDHub, timeout/erro é tratado como não-confiável nesta listagem.
        Isso é deliberadamente mais conservador que o player global porque HDHub
        é a última origem e o objetivo aqui é não oferecer falso positivo.
        """
        if not isinstance(item, dict):
            return False, 'item-invalido'
        url = str(item.get('url') or '').strip()
        if not url:
            return False, 'url-vazia'
        cached = self._preflight_cache_get(url)
        if cached is not None:
            return cached, 'cache-ok' if cached else 'cache-reprovada'
        if self._known_unstable_host(item):
            self._preflight_cache_put(url, False)
            return False, 'host-instavel'

        response = None
        try:
            headers = dict(item.get('__vod_request_headers') or {})
            headers.setdefault('User-Agent', USER_AGENT)
            headers.setdefault('Referer', HDHUB_REFERER)
            headers.setdefault('Accept', '*/*')
            headers['Accept-Encoding'] = 'identity'
            headers['Connection'] = 'close'
            headers['Range'] = 'bytes=0-0'
            response = self.requests.get(
                url,
                headers=headers,
                timeout=PREFLIGHT_TIMEOUT,
                allow_redirects=True,
                stream=True,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            response_headers = getattr(response, 'headers', {}) or {}
            content_type = str(response_headers.get('Content-Type', '') or '').lower()
            parsed_range = self._parse_content_range(response_headers.get('Content-Range', ''))
            media_like = not any(token in content_type for token in (
                'text/', 'application/json', 'application/xml', 'text/html'
            ))
            body_started = False
            if status == 206 and parsed_range and media_like:
                try:
                    for chunk in response.iter_content(chunk_size=1):
                        if chunk:
                            body_started = True
                            break
                except Exception:
                    body_started = False
            ok = bool(status == 206 and parsed_range and media_like and body_started)
            self._preflight_cache_put(url, ok)
            if ok:
                return True, 'range-ok'
            if status >= 400:
                return False, 'http-{}'.format(status)
            if not media_like:
                return False, 'nao-midia'
            return False, 'range-inseguro'
        except Exception as exc:
            self._preflight_cache_put(url, False)
            return False, 'erro-{}'.format(exc.__class__.__name__)
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def _preflight_progressive_batch(self, items):
        if not items:
            return [], {'aprovada': 0, 'reprovada': 0, 'host-instavel': 0, 'nao-testada': 0}
        selected = list(items[:PREFLIGHT_MAX_CANDIDATES])
        skipped = max(0, len(items) - len(selected))
        results = [None] * len(selected)
        workers = max(1, min(PREFLIGHT_WORKERS, len(selected)))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {
                executor.submit(self._probe_progressive, item): index
                for index, item in enumerate(selected)
            }
            for future in as_completed(future_map):
                index = future_map[future]
                try:
                    results[index] = future.result()
                except Exception as exc:
                    results[index] = (False, 'erro-{}'.format(exc.__class__.__name__))
        approved = []
        stats = {'aprovada': 0, 'reprovada': 0, 'host-instavel': 0, 'nao-testada': skipped}
        for item, result in zip(selected, results):
            ok, reason = result or (False, 'erro-desconhecido')
            if ok:
                approved.append(item)
                stats['aprovada'] += 1
            else:
                stats['reprovada'] += 1
                if reason == 'host-instavel':
                    stats['host-instavel'] += 1
        return approved, stats

    def _normalize_streams(self, raw_streams, imdb_id):
        if not isinstance(raw_streams, list):
            return [], 'streams-invalidos'
        direct_candidates = []
        torrent_items = []
        seen = set()
        rejected = 0
        filtered_download = 0
        filtered_nonplay = 0
        filtered_hls = 0
        filtered_dash = 0

        for index, raw in enumerate(raw_streams[:MAX_STREAMS]):
            if self._is_download_entry(raw):
                filtered_download += 1
                continue
            item, reason = self._normalizer._normalize_stream(raw, imdb_id, 90 + index)
            if item is None:
                rejected += 1
                continue
            item = dict(item)
            kind = (item.get('__vod_kind') or '').strip().lower()
            if kind == 'hls':
                # Perícia real: as entradas HLS publicadas pelo HDHub nos testes
                # retornaram playlist_invalida e terminaram em 502 no proxy.
                filtered_hls += 1
                continue
            if kind == 'dash':
                # Nenhum DASH reproduzível foi observado no conjunto periciado;
                # não expomos tipo não validado como se fosse confiável.
                filtered_dash += 1
                continue

            reproducible, filter_reason = self._is_reproducible_item(item)
            if not reproducible:
                filtered_nonplay += 1
                continue

            item['__vod_provider'] = HDHUB_PROVIDER_NAME
            item['__vod_provider_id'] = imdb_id
            item['__vod_provider_id_kind'] = 'imdb'
            item['__request_label'] = 'hdhub-imdb'
            item['__vod_size_label'] = ''
            for raw_key in ('__vod_raw_name', '__vod_raw_title', '__vod_raw_description'):
                item[raw_key] = self._strip_size_label(item.get(raw_key, ''))
            item['__request_rank'] = 90 + index
            headers = dict(item.get('__vod_request_headers') or {})
            headers.setdefault('User-Agent', USER_AGENT)
            headers.setdefault('Referer', HDHUB_REFERER)
            item['__vod_request_headers'] = headers

            dedupe_key = (
                item.get('__vod_target_type', ''),
                item.get('url') or item.get('__vod_target_value', ''),
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

            if kind == 'torrent':
                torrent_items.append(item)
            else:
                direct_candidates.append(item)

        verified_direct, preflight = self._preflight_progressive_batch(direct_candidates)
        normalized = verified_direct + torrent_items

        if (filtered_download or filtered_nonplay or filtered_hls or filtered_dash or rejected or
                preflight.get('reprovada') or preflight.get('nao-testada')):
            self._log(
                ('VOD HDHub perícia antes da UI: download={} hls={} dash={} '
                 'nao-reproduzivel={} invalido={} range-ok={} range-reprovada={} '
                 'host-instavel={} nao-testada={}.').format(
                    filtered_download, filtered_hls, filtered_dash,
                    filtered_nonplay, rejected,
                    preflight.get('aprovada', 0), preflight.get('reprovada', 0),
                    preflight.get('host-instavel', 0), preflight.get('nao-testada', 0),
                ),
                1,
            )
        if normalized:
            return normalized, 'ok'
        if filtered_download or filtered_nonplay or filtered_hls or filtered_dash or rejected or direct_candidates:
            return [], 'sem-stream-reproduzivel'
        return [], 'sem-stream'

    def resolve(self, media_type, imdb_id, season=None, episode=None):
        api_url = self._build_api_url(media_type, imdb_id, season, episode)
        if not api_url:
            return {'streams': [], 'reason': 'IMDb/episódio inválido ou ausente', 'audit': ['sem-id']}
        if self.requests is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}

        cooldown = self._cooldown_state()
        if cooldown:
            self._log('VOD HDHub em cooldown temporário: {}.'.format(cooldown), 1)
            return {'streams': [], 'reason': 'HDHub temporariamente em cooldown', 'audit': ['cooldown']}

        response = None
        try:
            response = self.requests.get(
                api_url,
                headers={
                    'User-Agent': USER_AGENT,
                    'Accept': 'application/json, */*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Referer': HDHUB_REFERER,
                },
                timeout=REQUEST_TIMEOUT,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status != 200:
                if status == 429:
                    self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
                elif status >= 500 or status <= 0:
                    self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
                return {
                    'streams': [],
                    'reason': 'HDHub respondeu HTTP {}'.format(status or 'desconhecido'),
                    'audit': ['http-{}'.format(status or 'erro')],
                }
            try:
                payload = response.json()
            except Exception:
                return {'streams': [], 'reason': 'resposta JSON inválida', 'audit': ['json-invalido']}
            if not isinstance(payload, dict):
                return {'streams': [], 'reason': 'resposta fora do contrato', 'audit': ['payload-invalido']}
            streams, outcome = self._normalize_streams(payload.get('streams'), (imdb_id or '').strip())
            if not streams:
                return {'streams': [], 'reason': 'nenhuma fonte HDHub compatível agora', 'audit': [outcome]}
            self._log('VOD HDHub resolveu {} por IMDb: {} fontes.'.format(media_type, len(streams)), 1)
            return {'streams': streams, 'reason': '', 'audit': ['imdb={}'.format(len(streams))]}
        except Exception as exc:
            self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('VOD HDHub indisponível nesta consulta: {}.'.format(exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': 'HDHub indisponível nesta consulta',
                'audit': ['erro-rede:{}'.format(exc.__class__.__name__)],
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


_DEFAULT_PROVIDER = None


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        def _kodi_log(message, level=1):
            try:
                from resources.lib.common import log, log_debug
                log('[VOD Extra] {}'.format(message), level=level)
                log_debug(message, component='HDHub')
            except Exception:
                pass
        _DEFAULT_PROVIDER = HdHubVodProvider(logger=_kodi_log)
    return _DEFAULT_PROVIDER


def reset_default_provider_for_tests():
    global _DEFAULT_PROVIDER
    _DEFAULT_PROVIDER = None
