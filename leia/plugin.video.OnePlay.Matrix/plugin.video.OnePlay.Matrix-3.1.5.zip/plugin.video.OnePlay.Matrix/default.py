# -*- coding: utf-8 -*-
'''
    ONEPLAY ADDON (2023) - TODOS OS DIREITOS RESERVADOS.
     - O ADDON ONEPLAY USA LINKS DE TERCEIROS, NÃO HOSPEDAMOS CONTEUDO
     - NÃO SOMOS FILIADOS A KODI MEDIA CENTER, ISSO É APENAS UM PLUGIN AGREGADOR DE CONTEUDO ENCONTRADO NA INTERNET
     DOCUMENTAÇÃO INPUTSTREAM-ADAPTATIVE: https://github.com/xbmc/inputstream.adaptive/wiki/Integration
'''
import six
import os
from fasthttp import req
from bs4 import BeautifulSoup
import jsunpack
try:
    import json
except:
    import simplejson as json
if six.PY3:
    from urllib.parse import urlparse, parse_qs, quote, unquote, quote_plus, unquote_plus, urlencode #python 3
else:
    from urlparse import urlparse, parse_qs #python 2
    from urllib import quote, unquote, quote_plus, unquote_plus, urlencode
if six.PY3:
    from urllib.request import build_opener, install_opener, Request, urlopen, URLError, urlretrieve  # Python 3
else:
    from urllib2 import build_opener, install_opener, Request, urlopen, URLError # Python 2
    from urllib import urlretrieve
import threading        
import sys
import re
import base64
import random
import time
import random
# if six.PY2:
#     import datetime
# else:
#     from datetime import datetime
from datetime import datetime, timedelta
import xml.etree.ElementTree as ET
try:
    from kodi_six import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs
    kodi_mode = True
    addon = xbmcaddon.Addon()
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    addonname = addon.getAddonInfo('name')
    addonid = addon.getAddonInfo('id')
    icon = addon.getAddonInfo('icon')    
    translate = xbmcvfs.translatePath if six.PY3 else xbmc.translatePath
    profile = translate(addon.getAddonInfo('profile')) if six.PY3 else translate(addon.getAddonInfo('profile')).decode('utf-8')
    home = translate(addon.getAddonInfo('path')) if six.PY3 else translate(addon.getAddonInfo('path')).decode('utf-8')
    fanart_default = os.path.join(home, 'fanart.jpg')
    dontate_qr = os.path.join(home, 'resources', 'pix', 'qrcode-pix.png')
    pesquisar_icon = os.path.join(home, 'resources', 'images', 'pesquisar.png')
    proximo_icon = os.path.join(home, 'resources', 'images', 'proximo.png')
    donate_icon = os.path.join(home, 'resources', 'images', 'donate.jpg')
    filmes_icon = os.path.join(home, 'resources', 'images', 'filmes.png')
    series_icon = os.path.join(home, 'resources', 'images', 'series.png')
    animes_icon = os.path.join(home, 'resources', 'images', 'animes.png')
    desenhos_icon = os.path.join(home, 'resources', 'images', 'desenhos.png')
    tv_icon = os.path.join(home, 'resources', 'images', 'tv.png')
    novelas_icon = os.path.join(home, 'resources', 'images', 'novelas.png')
    radios_icon = os.path.join(home, 'resources', 'images', 'radios.png')
    configuracoes_icon = os.path.join(home, 'resources', 'images', 'configuracoes.png')
    filmeseseries_icon = os.path.join(home, 'resources', 'images', 'filmeseseries.png')
    vip_icon = os.path.join(home, 'resources', 'images', 'vip.jpg')
    doacao_icon = os.path.join(home, 'resources', 'images', 'doacao.png')
    pix_icon = os.path.join(home, 'resources', 'images', 'pix.png')
    cache_proxy =  os.path.join(home, 'cache_proxy.txt')
    epgEnabled = addon.getSetting('exibirepg')
    log =  os.path.join(home, 'log.txt')
    dialog = xbmcgui.Dialog()
    if not os.path.exists(profile):
        try:
            os.mkdir(profile)
        except:
            pass
    epg_file = os.path.join(profile, 'epg.xml')
    epg_version = os.path.join(profile, 'epg_version.txt')
except:
    kodi_mode = False
    dir_path = os.path.dirname(os.path.realpath(__file__))
    cache_proxy = os.path.join(dir_path, "cache_proxy.txt")

class oneplay:
    def __init__(self):
        self.desc_addon = 'https://gist.githubusercontent.com/zoreu/ed4f3d92f995bfcc01891a2e94404ce8/raw/descricao_oneplay.txt'
        self.desc_vip = 'https://oneplayhd.com/download/vip_oneplay.txt'
        self.vip_downloader = 'https://oneplayhd.com/download/apks_oneplay.txt'
        self.downloads_android = '/storage/emulated/0/download'
        self.canais_servidor1 = 'https://gist.github.com/zoreu/b1912aa40daaec0eabf1a74c51e310a0/raw/canais_servidor1.txt'
        self.f4m_servers = 'https://gist.github.com/zoreu/cfac084dfc41cb204496254c5b3c49a3/raw/f4m_servers.txt'
        self.epg_url_version = 'https://github.com/zoreu/epgoneplay/raw/output/update.txt'
        self.url_epg = 'https://github.com/zoreu/epgoneplay/raw/output/epg.xml'
        self.IE_USER_AGENT = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko'
        self.FF_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:68.0) Gecko/20100101 Firefox/68.0'
        self.OPERA_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/80.0.3987.132 Safari/537.36 OPR/67.0.3575.97'
        self.IOS_USER_AGENT = 'Mozilla/5.0 (iPhone; CPU iPhone OS 13_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.0.5 Mobile/15E148 Safari/604.1'
        self.IPAD_USER_AGENT = 'Mozilla/5.0 (iPad; U; CPU OS 3_2 like Mac OS X; en-us) AppleWebKit/531.21.10 (KHTML, like Gecko) Version/4.0.4 Mobile/7B334b Safari/531.21.10'
        self.ANDROID_USER_AGENT = 'Mozilla/5.0 (Linux; Android 9; SM-G973F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Mobile Safari/537.36'
        self.EDGE_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/70.0.3538.102 Safari/537.36 Edge/18.18363'
        self.CHROME_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/84.0.4136.7 Safari/537.36'        
        self.SAFARI_USER_AGENT = 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_4) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/13.1 Safari/605.1.15'
        self._USER_AGENTS = [self.FF_USER_AGENT, self.OPERA_USER_AGENT, self.EDGE_USER_AGENT, self.CHROME_USER_AGENT, self.SAFARI_USER_AGENT]        
        self.headers = {'User-Agent': self.ANDROID_USER_AGENT,
                    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
                    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,es;q=0.6',
                    'sec-ch-ua': '"Chromium";v="110", "Not A(Brand";v="24", "Google Chrome";v="110"',
                    'sec-ch-ua-mobile': '?1',
                    'sec-ch-ua-platform': '"Android"',
                    'Sec-Fetch-Dest': 'document',
                    'Sec-Fetch-Mode': 'navigate',
                    'Sec-Fetch-Site': 'none',
                    'Sec-Fetch-User': '?1',
                    'Upgrade-Insecure-Requests': '1'   
                        }
    
    def get_headers(self):
        return self.headers
    
    def rand_ua(self):
        RAND_UA = random.choice(self._USER_AGENTS)
        return RAND_UA

    def descricao_addon(self):
        desc = ''
        try:
            r = req.get(self.desc_addon)
            desc += r.text
        except:
            pass
        return desc
    
    def vip_descricao(self):
        desc = ''
        try:
            r = req.get(self.desc_vip)
            desc += r.text
        except:
            pass
        return desc
    
    def get_proxy(self):
        proxy = []      
        try:
            r = req.get('https://www.sslproxies.org/',verify=False)
            html = r.text
            soup = BeautifulSoup(html, 'html.parser')
            tr = soup.find('tbody').find_all('tr')
            for t in tr:
                td_tags = t.find_all('td')
                ip_address = td_tags[0].text
                port_number = td_tags[1].text
                code = td_tags[2].text
                country = td_tags[3].text
                anonymity = td_tags[4].text
                google = td_tags[5].text
                https = td_tags[6].text
                checked = td_tags[7].text
                if https == 'yes' and anonymity == 'anonymous':
                    string_p = 'https://' + str(ip_address) + ':' + str(port_number)
                    proxy.append(string_p)
        except:
            pass
        if proxy:
            return random.choice(proxy)
        else:
            p = ''
            return p

    def req_proxy(self,url,user_agent=False):
        count = 0
        html = ''
        while count < 5:
            if os.path.exists(cache_proxy):
                with open(cache_proxy, 'r') as f:
                    file = f.read()
                    try:
                        p = re.findall('proxy="(.*?)".*?status="(.*?)"', file, re.IGNORECASE | re.DOTALL)
                        proxy = p[0][0]
                        status = p[0][1]
                        if status == 'false':
                            proxy = self.get_proxy()            
                    except:
                        proxy = self.get_proxy()
            else:
                proxy = self.get_proxy()
            if not proxy:
                html = 'falha proxy'
                break                   
            try:
                if user_agent:
                   r = req.get(url, headers={'User-Agent': user_agent, 'X-Forwarded-For': '\x31\x34\x32\x2e\x32\x35\x30\x2e\x37\x39\x2e\x31\x34'}, replace_headers=True, proxy=proxy)
                else:
                    r = req.get(url, headers={'User-Agent': '\x4d\x6f\x7a\x69\x6c\x6c\x61\x2f\x35\x2e\x30\x20\x28\x63\x6f\x6d\x70\x61\x74\x69\x62\x6c\x65\x3b\x20\x47\x6f\x6f\x67\x6c\x65\x62\x6f\x74\x2f\x32\x2e\x31\x3b\x20\x2b\x68\x74\x74\x70\x3a\x2f\x2f\x77\x77\x77\x2e\x67\x6f\x6f\x67\x6c\x65\x2e\x63\x6f\x6d\x2f\x62\x6f\x74\x2e\x68\x74\x6d\x6c)', 'X-Forwarded-For': '\x31\x34\x32\x2e\x32\x35\x30\x2e\x37\x39\x2e\x31\x34'}, replace_headers=True, proxy=proxy)
                html = r.text               
                if not 'cloudflare' in html:
                    if proxy:
                        with open(cache_proxy, 'w') as f:
                            t = 'proxy="%s"\nstatus="true"'%proxy
                            f.write(t)                       
                    break
            except:
                with open(cache_proxy, 'w') as f:
                    if proxy:
                        t = 'proxy="%s"\nstatus="false"'%proxy
                        f.write(t)                
                count += 1
        return html         
    
    def append_headers(self,headers):
        return '|%s' % '&'.join(['%s=%s' % (key, quote_plus(headers[key])) for key in headers])
    
    def append_headers2(self,headers):
        return '|%s' % '&'.join(['%s=%s' % (key, headers[key]) for key in headers])     
    
    def get_ip(self):
        ip = ''
        try:
            r = req.get('https://api4.my-ip.io/ip.jsonp?format=jsonp&callback=getIP')
            src = r.text
            ip += re.findall(r'getIP\({"success": true, "ip": "(.*?)"', src)[0]
        except:
            pass
        return ip
    
    # def teste_embedflix(self,url):
    #     # url = url.split('&wmsAuthSign')[0]
    #     # url = url + '&wmsAuthSign=undefined'
    #     headers = self.headers
    #     referer = 'https://embedflix.net/tv/'
    #     origin = 'https://embedflix.net'        
    #     headers.update({'Host': 'br.embedflix.net','Origin': origin, 'Referer': referer, 'Sec-Fetch-Dest': 'empty', 'Sec-Fetch-Mode': 'cors', 'Sec-Fetch-Site': 'same-site', 'Accept-Language': 'pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3', 'Accept-Encoding': 'gzip, deflate, br'})
    #     r = req.get(url,headers=headers,replace_headers=True)
    #     print(r.text)

    # def abrir_embedflix(self,url):
    #     try:
    #         base = url.split('playlist.m3u8')[0]
    #     except:
    #         base = ''
    #     stream = base
    #     try:
    #         headers = self.headers
    #         #headers.update({'Host': 'br.embedflix.net','Origin': 'https://embedflix.net', 'Referer': 'https://embedflix.net/'})
    #         headers.update({'Origin': 'https://embedflix.net', 'Referer': 'https://embedflix.net/'})
    #         r = req.get(url,headers=headers,replace_headers=True)
    #         headers.pop('User-Agent')
    #         headers.pop('Accept')
    #         src = r.text
    #         stream += re.findall(r'.*chunks\.m3u8.*',src)[0]
    #         print(stream)
    #         #stream = stream + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0&Origin=https://embedflix.net&Referer=https://embedflix.net/&Accept-Language=pt-BR,pt;q=0.8,en-US;q=0.5,en;q=0.3&Sec-Fetch-Dest=empty&Sec-Fetch-Mode=cors&Sec-Fetch-Site=same-site'
    #         self.teste_embedflix(stream)
    #         #stream += re.findall(r'.*chunks\.m3u8.*',src)[0] + self.append_headers2(headers)
    #         #stream += re.findall(r'.*chunks\.m3u8.*',src)[0] + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0&Origin=https://embedflix.net&Referer=https://embedflix.net/'
    #     except:
    #         pass
    #     return stream

    def get_action_embedflix(self):
        url = 'https://embedflix.net/tv/tnt'
        referer = 'https://embedflix.net/tv/'
        headers = self.headers
        headers.update({'Referer': referer})
        action = ''
        try:
            r = req.get(url,headers=headers,replace_headers=True)
            src = r.text
            pattern = r"data\s*:\s*\{[\s\S]*?action\s*:\s*'([^']*)'"
            # Procura o padrão no script JavaScript
            result = re.search(pattern, src)
            if result:
                action += result.group(1)
        except:
            pass
        return action
        
    
    def embedflix_stream(self,myid):
        referer = 'https://embedflix.net/tv/'
        origin = 'https://embedflix.net'
        url = 'https://embedflix.net/api'
        ip = self.get_ip()
        headers = self.headers
        headers.update({'Origin': origin, 'Referer': referer})
        #data_post = {'action': 'getPlayer', 'client_ip': ip, 'video_id': myid}
        data_post = {'action': self.get_action_embedflix(), 'client_ip': ip, 'video_id': myid}
        stream = ''
        try:
            r = req.post(url,headers=headers,data=data_post,replace_headers=True)
            src = r.json()
            #print(src)
            if src:
                data = src.get('data')
                #print(data)
                if data:
                    video_url = data.get('video_url')
                    url_signature = data.get('url_signature')
                    if video_url and url_signature:
                        headers.update({'Origin': 'https://embedflix.net', 'Referer': 'https://embedflix.net/'})
                        #stream = '%s?wmsAuthSign=%s'%(video_url,url_signature) + self.append_headers(headers)
                        stream = '%s?wmsAuthSign=%s'%(video_url,url_signature) + '|User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/114.0&Origin=https://embedflix.net&Referer=https://embedflix.net/&Sec-Fetch-Dest=empty&Sec-Fetch-Mode=cors&Sec-Fetch-Site=same-site&Connection=keep-alive'
                        #stream = '%s?wmsAuthSign=%s'%(video_url,url_signature)
                        #print(stream)
                        #stream = self.abrir_embedflix(stream)
                        #print(stream)
        except:
            pass
        return stream
    
    def get_packed_data(self,html):
        packed_data = ''
        try:
            for match in re.finditer(r'''(eval\s*\(function\(p,a,c,k,e,.*?)</script>''', html, re.DOTALL | re.I):
                r = match.group(1)
                t = re.findall(r'(eval\s*\(function\(p,a,c,k,e,)', r, re.DOTALL | re.IGNORECASE)
                if len(t) == 1:
                    if jsunpack.detect(r):
                        packed_data += jsunpack.unpack(r)
                else:
                    t = r.split('eval')
                    t = ['eval' + x for x in t if x]
                    for r in t:
                        if jsunpack.detect(r):
                            packed_data += jsunpack.unpack(r)
        except:
            pass
        return packed_data
    
    def get_host(self,url):
        url_parsed = urlparse(url)
        host = '%s://%s'%(url_parsed.scheme,url_parsed.netloc)
        return host

    def aovivogratis(self,channel):
        user_agent_fasthttp = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/111.0.0.0 Safari/537.36 Edg/111.0.1661'
        stream = ''
        try:
            url = 'https://player.aovivotv.xyz/channels/%s'%channel
            referer = 'https://www.tibiadown.com/'
            origin = self.get_host(url)
            referer2 = origin + '/'
            r = req.get(url,headers={'Referer': referer})
            src = r.text
            if src:
                unpack = self.get_packed_data(src)
                items = re.findall(r'src:\s*(.+?),type', unpack)[0].split('+')
                src = [chr(int(re.findall(r'\d+', x)[0])) if 'String.' in x else x.replace("'", "") for x in items]
                src = ''.join(src)
                src = src.encode("utf-8").decode("unicode-escape")
                src = 'https:' + src
                stream = src + '|User-Agent=' + user_agent_fasthttp + '&Referer=' + referer2 + '&Origin=' + origin
        except:
            pass
        return stream
    
    def last_url(self,url,headers):
        if six.PY3:
            r = Request(url, method='HEAD', headers=headers)
        else:
            r = Request(url,headers=headers)
            r.get_method = lambda : 'HEAD'
        try:
            response = urlopen(r)
            if six.PY3:
                final_url = response.url
            else:
                final_url = response.geturl()
        except:
            final_url = url
        return final_url

    
    def resolve_streamtape(self,url):
        correct_url = url.replace('/v/', '/e/')
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        referer = '%s://%s/'%(protocol,host)
        headers = self.headers
        headers.update({'Referer': referer})
        r = req.get(correct_url,headers=headers,replace_headers=True)
        data = r.text
        link_part1_re = re.compile('<div.+?style="display:none;">(.*?)&token=.+?</div>').findall(data)
        link_part2_re = re.compile("&token=(.*?)'").findall(data)
        if link_part1_re and link_part2_re:
            part1 = link_part1_re[0]
            part2 = link_part2_re[-1]
            part1 = part1.replace(' ', '')
            if 'streamtape' in part1:
                try:
                    part1 = part1.split('streamtape')[1]
                    final = 'streamtape' + part1 + '&token=' + part2
                    stream = 'https://' + final + '&stream=1'
                    headers.update({'Referer': referer})
                    #r2 = req.get(stream,headers=headers,replace_headers=True)
                    #link = r2.url + self.append_headers(headers)
                    link = self.last_url(stream,headers=headers) + self.append_headers(headers)
                except:
                    link = False
            elif 'get_video' in part1:
                try:
                    part1_1 = part1.split('get_video')[0]
                    part1_2 = part1.split('get_video')[1]
                    part1_1 = part1_1.replace('/', '')
                    part1 = part1_1 + '/get_video' + part1_2
                    final = part1 + '&token=' + part2
                    stream = 'https://' + final + '&stream=1'
                    headers.update({'Referer': referer})
                    # r2 = req.get(stream,headers=headers,replace_headers=True)
                    # link = r2.url + self.append_headers(headers)
                    link = self.last_url(stream,headers=headers) + self.append_headers(headers)
                except:
                    link = False
        else:
            link = False
        return link

    # CDN
    def resolve_warezcdn(self,url):
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        referer = '%s://%s'%(protocol,host)
        headers = self.headers
        try:
            _id = url.split("id=")[1]
        except:
            _id = ''
        if _id:
            try:
                headers.update({'Referer': referer})
                r = req.get(url,headers=headers,replace_headers=True)
                src = r.text
                key = re.findall('allowanceKey = "(.+?)"', src,re.DOTALL|re.MULTILINE|re.IGNORECASE)[0]
                cdn = re.findall('cdnListing = \[(.+?)\]', src,re.DOTALL|re.MULTILINE|re.IGNORECASE)[0].split(',')
                cdn = random.choice(cdn)
                param = {'getVideo': _id, 'key': key}
                headers.update({'Referer': url})
                r2 = req.post('https://warezcdn.com/player/functions.php', headers=headers, replace_headers=True, data=param)
                src = r2.json()
                code = src['id']
                sub = src.get('substatus',False)
                if sub == True:
                    sub = src.get('sublink','')
                    sub = sub + '|User-Agent=' + headers['User-Agent'] + '&Referer=' + url
                else:
                    sub = ''
                base = base64.b64decode(code).decode('utf-8')[::-1]
                base = base[:+9] + base[13] + base[+10:+13][::-1] + base[9]
                url_player = 'https://cloclo%s.cloud.mail.ru/weblink/view//%s'%(cdn,base)
                referer2 = url_player
                headers.update({'Referer': referer2})
                #lasturl = req.get(url_player, headers=headers,replace_headers=True).url
                lasturl = self.last_url(url_player,headers)
                stream = lasturl + '|User-Agent=' + headers['User-Agent'] + '&Referer=https://warezcdn.com/'
            except:
                stream = ''

        return stream

    
    def resolve_mixdrop(self,url):
        url = url.replace('.club', '.co')
        try:
            url = url.split('?')[0]
        except:
            pass
        stream = ''
        parsed_uri = urlparse(url)
        protocol = parsed_uri.scheme
        host = parsed_uri.netloc
        # if host.endswith('.club'):
        #     host = host.replace('.club', '.co')
        rurl = 'https://%s/'%host     
        headers = {'Origin': rurl[:-1],'Referer': rurl, 'User-Agent': self.rand_ua()}
        try:
            html = req.get(url,headers=headers,replace_headers=True).text
            r = re.search(r'location\s*=\s*"([^"]+)', html)
            if r:
                url = 'https://%s%s'%(host,r.group(1))
                html = req.get(url,headers=headers,replace_headers=True).text
            if '(p,a,c,k,e,d)' in html:
                html = self.get_packed_data(html)
            r = re.search(r'(?:vsr|wurl|surl)[^=]*=\s*"([^"]+)', html)
            if r:
                surl = r.group(1)
                if surl.startswith('//'):
                    surl = 'https:' + surl
                headers.pop('Origin')
                headers.update({'Referer': url})
                stream = surl + self.append_headers(headers)
        except:
            pass
        return stream

    
    # RESOLVE
    def resolverurl(self,url):
        stream = ''
        sub = ''
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        domain = domain.replace('www.', '')
        if domain in ['streamtape.com', 'strtape.cloud', 'streamtape.net', 'streamta.pe', 'streamtape.site',
               'strcloud.link', 'strtpe.link', 'streamtape.cc', 'scloud.online', 'stape.fun',
               'streamadblockplus.com', 'shavetape.cash', 'streamtape.to', 'streamta.site',
               'streamadblocker.xyz', 'tapewithadblock.org', 'adblocktape.wiki']:
            stream = self.resolve_streamtape(url)
        elif domain in ['warezcdn.com']:
            stream = self.resolve_warezcdn(url)
        elif domain in ['mixdrop.co', 'mixdrop.to', 'mixdrop.sx', 'mixdrop.bz', 'mixdrop.ch',
               'mixdrp.co', 'mixdrp.to', 'mixdrop.gl', 'mixdrop.club', 'mixdroop.bz']:
            stream = self.resolve_mixdrop(url)
        return stream


#print(oneplay().resolverurl('https://streamtape.com/e/akb9P7RK3LsxVqR?color=140,122,230&c1_file=https://subs.warezcdn.com/224011-PTB.srt&c1_label=Portugu%C3%AAs'))

#print(oneplay().resolverurl('https://warezcdn.com/player/player.php?id=7003'))

#print(oneplay().resolverurl('https://mixdrop.to/e/rwr0egwos1mpdv?sub=https://subs.warezcdn.com/224011-PTB.srt&c1_label=Portugu%C3%AAs'))
            

# oneplay().get_action_embedflix()




        
# s = oneplay().embedflix_stream('3276')
# print(s)
# oneplay().get_ip()

#script,referer,origin = oneplay().get_script_futebolplay('megapix')


if kodi_mode:
    class Donate(xbmcgui.WindowDialog):
        def __init__(self):
            self.image = xbmcgui.ControlImage(440, 145, 400, 400, pix_icon)
            self.text = xbmcgui.ControlLabel(x=150,y=570,width=1100,height=25,label='[B]SE ESSE ADD-ON LHE AGRADA, FAÇA UMA DOAÇÃO VIA PIX ACIMA E MANTENHA ESSE SERVIÇO ATIVO[/B]',textColor='white')
            self.text2 = xbmcgui.ControlLabel(x=495,y=600,width=1000,height=25,label='[B]PRESSIONE VOLTAR PARA SAIR[/B]',textColor='white')
            self.addControl(self.image)
            self.addControl(self.text)
            self.addControl(self.text2) 

    def route(f):
        param_string = sys.argv[2]
        if param_string:
            params_dict = {}
            split_commands = param_string[param_string.find('?') + 1:].split('&')
            for command in split_commands:
                if command:
                    if '=' in command:
                        split_command = command.split('=')
                        key = split_command[0]
                        value = split_command[1]
                        try:
                            key = unquote_plus(key)
                        except:
                            pass
                        try:
                            value = unquote_plus(value)
                        except:
                            pass
                        params_dict[key] = value
                    else:
                        params_dict[command] = ''
            # EXECUTAR EM THREAD PRA EVITAR TRAVAMENTO
            if params_dict['action'] == f.__name__:
                thread = threading.Thread(target=f, args=(params_dict,))
                thread.start()
        else:
            # FUNÇÃO PRINCIPAL
            if f.__name__ == 'main':
                f()

        # action = params_dict.get('action')
        # if action is None and action_f == 'main':
        #     f()
        # elif action == action_f:         
        #     # Crie um pool de threads
        #     thread = threading.Thread(target=f, args=(params_dict,))
        #     thread.start()

  

    def infoDialog(message, heading=addonname, iconimage='', time=3000, sound=False):
        if iconimage == '':
            iconimage = icon
        elif iconimage == 'INFO':
            iconimage = xbmcgui.NOTIFICATION_INFO
        elif iconimage == 'WARNING':
            iconimage = xbmcgui.NOTIFICATION_WARNING
        elif iconimage == 'ERROR':
            iconimage = xbmcgui.NOTIFICATION_ERROR
        dialog.notification(heading, message, iconimage, time, sound=sound)

    def notify(msg):
        infoDialog(msg, iconimage='INFO')


    def check_epg():
        url_version = oneplay().epg_url_version
        url_epg = oneplay().url_epg
        if not os.path.exists(epg_version):
            r = req.get(url_version)
            src = r.text
            with open(epg_version, 'w') as f:
                f.write(src)
            with open(epg_file, 'wb') as f:
                notify('BAIXANDO EPG AGUARDE...')
                res = req.get(url_epg,headers=oneplay().get_headers(),replace_headers=True)
                for chunk in res.iter_content(chunk_size=1024):
                    f.write(chunk)         
        else:
            ver = ''
            ver2 = '' 
            with open(epg_version, 'r') as f:
                src = f.read()
                ver += re.findall(r"\d+", src)[0]
            r = req.get(url_version)
            src = r.text
            ver2 += re.findall(r"\d+", src)[0]
            if int(ver2) > int(ver):
                with open(epg_version, 'w') as f:
                    f.write(src)                
                down = True
            else:
                down = False
            if down:
                with open(epg_file, 'wb') as f:
                    notify('BAIXANDO EPG AGUARDE...')
                    res = req.get(url_epg,headers=oneplay().get_headers(),replace_headers=True)
                    for chunk in res.iter_content(chunk_size=1024):
                        f.write(chunk)

    def epgParseData():
        try:
            check_epg()
            notify('AGUARDE EPG...')
            return ET.parse(epg_file).getroot()
        except:
            notify('FALHA AO USAR EPG...')
            return None
        
    def getID_EPG(channel):
        if re.search("A&E",channel,re.IGNORECASE): # ok
            channel_id = 'AEBrazil.br'
        elif re.search("AMC",channel,re.IGNORECASE): #ok
            channel_id = 'AMCBrazil.br'
        elif re.search("Animal Planet",channel,re.IGNORECASE): # ok
            channel_id = 'AnimalPlanetBrazil.br'
        elif re.search("Arte 1",channel,re.IGNORECASE): # ok
            channel_id = 'Arte1.br'
        elif re.search("AXN",channel,re.IGNORECASE): # ok
            channel_id = 'AXNBrazil.br'
        elif re.search("Baby TV",channel,re.IGNORECASE) or re.search("BabyTV",channel,re.IGNORECASE):
            channel_id = 'BabyTV.br'
        elif re.search("Band",channel,re.IGNORECASE) and not re.search("Band News",channel,re.IGNORECASE) and not re.search("Band Sports",channel,re.IGNORECASE):
            channel_id = 'BandSaoPaulo.br' # ok
        elif re.search("Band News",channel,re.IGNORECASE): # ok
            channel_id = 'BandNews.br'
        elif re.search("Band Sports",channel,re.IGNORECASE): # ok
            channel_id = 'BandSports.br'
        elif re.search("BIS",channel,re.IGNORECASE):
            channel_id = 'Bis.br'
        elif re.search("Boomerang",channel,re.IGNORECASE): #ok
            channel_id = 'BoomerangBrazil.br'
        elif re.search("Canal Brasil",channel,re.IGNORECASE):
            channel_id = 'CanalBrasil.br'
        elif re.search("Cancao Nova",channel,re.IGNORECASE) or re.search("Canção Nova",channel,re.IGNORECASE):
            channel_id = 'TVCancaoNova.br'
        elif re.search("Cartoon Network",channel,re.IGNORECASE): # ok
            channel_id = 'CartoonNetworkBrazil.br'
        elif re.search("Cinemax",channel,re.IGNORECASE):
            channel_id = 'CinemaxBrazil.br'
        elif re.search("Combate",channel,re.IGNORECASE):
            channel_id = 'Combatehd.br'
        elif re.search("Comedy Central",channel,re.IGNORECASE): # ok
            channel_id = 'ComedyCentralBrazil.br'
        elif re.search("Cultura",channel,re.IGNORECASE):
            channel_id = 'TVCulturaNacional.br'
        elif re.search("Curta!",channel,re.IGNORECASE) or re.search("Curta",channel,re.IGNORECASE):
            channel_id = 'Curta.br'
        elif re.search("Discovery Channel",channel,re.IGNORECASE): # ok
            channel_id = 'DiscoveryChannelBrazil.br'
        elif re.search("Discovery Civilization",channel,re.IGNORECASE):
            channel_id = 'DiscoveryCivilization.br'
        elif re.search("Discovery Home Health",channel,re.IGNORECASE) or re.search("Discovery H&H",channel,re.IGNORECASE):
            channel_id = 'DiscoveryHomeHealthBrazil.br'
        elif re.search("Discovery Kids",channel,re.IGNORECASE):
            channel_id = 'DiscoveryKidsBrazil.br'
        elif re.search("Discovery Science",channel,re.IGNORECASE):
            channel_id = 'DiscoveryScienceBrazil.br'
        elif re.search("Discovery Theater",channel,re.IGNORECASE):
            channel_id = 'DiscoveryTheaterBrazil.br'
        elif re.search("Discovery Turbo",channel,re.IGNORECASE): # ok
            channel_id = 'DiscoveryTurboBrazil.br'
        elif re.search("Discovery World",channel,re.IGNORECASE):
            channel_id = 'DiscoveryWorldBrazil.br'
        elif re.search("Disney Junior",channel,re.IGNORECASE) or re.search("Disney Jr",channel,re.IGNORECASE):
            channel_id = 'Disneyjrhd.br'
        elif re.search("Disney XD",channel,re.IGNORECASE):
            channel_id = 'Disneyxd.br'
        elif re.search("Disney",channel,re.IGNORECASE) and not re.search("Cine",channel,re.IGNORECASE) or re.search("Disney Channel",channel,re.IGNORECASE): # ok
            channel_id = 'DisneyChannelBrazil.br'
        elif re.search("E!",channel,re.IGNORECASE):
            channel_id = 'EBrazil.br'
        elif re.search("Espn Extra",channel,re.IGNORECASE):
            channel_id = 'ESPNExtraBrazil.br'
        elif re.search("ESPN Brasil",channel,re.IGNORECASE):
            channel_id = 'ESPNBrazil.br' 
        elif re.search("ESPN 2",channel,re.IGNORECASE): # ok
            channel_id = 'ESPN.us'
        elif re.search("ESPN",channel,re.IGNORECASE): # ok
            channel_id = 'ESPNExtraBrazil.br'                              
        elif re.search("FishTV",channel,re.IGNORECASE) or re.search("Fish TV",channel,re.IGNORECASE):
            channel_id = 'FishTV.br'
        elif re.search("Food Network",channel,re.IGNORECASE):
            channel_id = 'FoodNetworkBrazil.br'
        elif re.search("Fox News",channel,re.IGNORECASE):
            channel_id = 'FoxNewsChannel.us'  
        elif re.search("Fox Sports 2",channel,re.IGNORECASE):
            channel_id = 'FoxSports2Brazil.br' 
        elif re.search("ESPN 4",channel,re.IGNORECASE) or re.search("Fox Sports",channel,re.IGNORECASE):
            channel_id = 'FoxSportsBrazil.br'                                    
        elif re.search("Futura",channel,re.IGNORECASE):
            channel_id = 'CanalFutura.br'
        elif re.search("FX",channel,re.IGNORECASE) and not re.search("US",channel,re.IGNORECASE):
            channel_id = 'FXBrazil.br'
        elif re.search("Film & Arts",channel,re.IGNORECASE):
            channel_id = 'FilmArtsBrazil.br'
        elif re.search("Globo Brasilia",channel,re.IGNORECASE) or re.search("Globo Brasília",channel,re.IGNORECASE):
            channel_id = 'TVGloboBrasilia.br'
        elif re.search("Globo Campinas",channel,re.IGNORECASE) or re.search("Globo EPTV Campinas",channel,re.IGNORECASE):
            channel_id = 'GloboEPTVCampinas.br'
        elif re.search("Globo Minas",channel,re.IGNORECASE):
            channel_id = 'Globominas.br'
        elif re.search("Globo News",channel,re.IGNORECASE):
            channel_id = 'GloboNews.br'
        elif re.search("Globo RJ",channel,re.IGNORECASE):
            channel_id = 'TVGloboRiodeJaneiro.br'
        elif re.search("Globo SP",channel,re.IGNORECASE):
            channel_id = 'TVGloboSaoPaulo.br'
        elif re.search("Globo Nordeste",channel,re.IGNORECASE):
            channel_id = 'TVGloboNordeste.br'
        elif re.search("Gloob",channel,re.IGNORECASE):
            channel_id = 'Gloob.br'
        elif re.search("GNT",channel,re.IGNORECASE):
            channel_id = 'GNT.br'
        elif re.search("HBO 2",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBO2Brazil.br'
        elif re.search("HBO Family",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOFamilyBrazil.br'                         
        elif re.search("HBO Mundi",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOMundiBrazil.br'
        elif re.search("HBO Plus",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOPlusBrazil.br'
        elif re.search("HBO Pop",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOPopBrazil.br'
        elif re.search("HBO Signature",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOSignatureBrazil.br'
        elif re.search("HBO Xtreme",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOXtremeBrazil.br'
        elif re.search("HBO",channel,re.IGNORECASE) and not re.search("Max",channel,re.IGNORECASE) and not re.search("TNT",channel,re.IGNORECASE):
            channel_id = 'HBOBrazil.br'
        elif re.search("History 2",channel,re.IGNORECASE):
            channel_id = 'History2Brazil.br'                                                                          
        elif re.search("History",channel,re.IGNORECASE):
            channel_id = 'HistoryBrazil.br'
        elif re.search("Ideal TV",channel,re.IGNORECASE):
            channel_id = 'IdealTV.br'
        elif re.search("Investigação Discovery",channel,re.IGNORECASE) or re.search("Investigacao Discovery",channel,re.IGNORECASE):
            channel_id = 'InvestigationDiscoveryBrazil.br'
        elif re.search("i.Sat",channel,re.IGNORECASE):
            channel_id = 'iSat.br'
        elif re.search("i.Sat",channel,re.IGNORECASE):
            channel_id = 'Lifetime.br'
        elif re.search("Lifetime",channel,re.IGNORECASE):
            channel_id = 'LifetimeBrazil.br'
        elif re.search("Mais GloboSat",channel,re.IGNORECASE) or re.search("Mais na Tela",channel,re.IGNORECASE):
            channel_id = 'MaisnaTela.br'
        elif re.search("Megapix",channel,re.IGNORECASE):
            channel_id = 'Megapix.br'
        elif re.search("MTV Live",channel,re.IGNORECASE):
            channel_id = 'MTVLive.uk'            
        elif re.search("MTV",channel,re.IGNORECASE) and not re.search("US",channel,re.IGNORECASE):
            channel_id = 'MTVBrazil.br'
        elif re.search("Multishow",channel,re.IGNORECASE):
            channel_id = 'Multishow.br'
        elif re.search("Nat Geo Kids",channel,re.IGNORECASE) and not re.search("Nat Geo Wild",channel,re.IGNORECASE) and not re.search("National Geographic",channel,re.IGNORECASE):
            channel_id = 'NatGeoKidsBrazil.br'
        elif re.search("Nat Geo Wild",channel,re.IGNORECASE) or re.search("National Geographic Wild",channel,re.IGNORECASE):
            channel_id = 'NationalGeographicWildBrazil.br'
        elif re.search("National Geographic",channel,re.IGNORECASE):
            channel_id = 'NationalGeographicBrazil.br'
        elif re.search("NBR",channel,re.IGNORECASE):
            channel_id = 'Nbr.br'
        elif re.search("Nickelodeon",channel,re.IGNORECASE) and not re.search("Nick Jr",channel,re.IGNORECASE) and not re.search("Nick Junior",channel,re.IGNORECASE):
            channel_id = 'NickelodeonBrazil.br'
        elif re.search("Nick Jr",channel,re.IGNORECASE):
            channel_id = 'NickJrBrazil.br'
        elif re.search("Novo Tempo",channel,re.IGNORECASE):
            channel_id = 'TVNovoTempoBrasil.br'
        elif re.search("Off",channel,re.IGNORECASE) and not re.search("CNN",channel,re.IGNORECASE):
            channel_id = 'CanalOff.br'
        elif re.search("PlayBoy",channel,re.IGNORECASE):
            channel_id = 'PlayboyTVBrazil.br'
        elif re.search("Paramount",channel,re.IGNORECASE) and not re.search("+",channel,re.IGNORECASE) and not re.search("Plus",channel,re.IGNORECASE):
            channel_id = 'ParamountNetworkBrazil.br'
        elif re.search("Premiere 2",channel,re.IGNORECASE):
            channel_id = 'Premiere2.br'
        elif re.search("Premiere 3",channel,re.IGNORECASE):
            channel_id = 'Premiere3.br'
        elif re.search("Premiere 4",channel,re.IGNORECASE):
            channel_id = 'Premiere4.br'
        elif re.search("Premiere 5",channel,re.IGNORECASE):
            channel_id = 'Premiere5.br'
        elif re.search("Premiere 6",channel,re.IGNORECASE):
            channel_id = 'Premiere6.br'
        elif re.search("Premiere 7",channel,re.IGNORECASE):
            channel_id = 'Premiere7.br'
        elif re.search("Premiere 8",channel,re.IGNORECASE):
            channel_id = 'Premiere8.br'
        elif re.search("Premiere 9",channel,re.IGNORECASE):
            channel_id = 'Premiere9.br'
        elif re.search("Premiere Clubes",channel,re.IGNORECASE):
            channel_id = 'PremiereClubes.br'
        elif re.search("Prime Box",channel,re.IGNORECASE):
            channel_id = 'PrimeBoxBrazil.br'
        elif re.search("Ra Tim Bum",channel,re.IGNORECASE):
            channel_id = 'TVRaTimBum.br'
        elif re.search("Record News",channel,re.IGNORECASE):
            channel_id = 'RecordNews.br'
        elif re.search("Record SP",channel,re.IGNORECASE):
            channel_id = 'RecordTVSaoPaulo.br'
        elif re.search("Record Rio",channel,re.IGNORECASE):
            channel_id = 'RecordTVRio.br'                        
        elif re.search("RecordTV",channel,re.IGNORECASE) or re.search("Record TV",channel,re.IGNORECASE):
            channel_id = 'RecordTV.br'
        elif re.search("Rede Brasil",channel,re.IGNORECASE):
            channel_id = 'RedeBrasil.br'
        elif re.search("Rede TV",channel,re.IGNORECASE) or re.search("RedeTV",channel,re.IGNORECASE):
            channel_id = 'RedeTV.br'
        elif re.search("Rede Vida",channel,re.IGNORECASE):
            channel_id = 'RedeVida.br'
        elif re.search("Rede Amazonica",channel,re.IGNORECASE) or re.search("Rede Amazonas",channel,re.IGNORECASE):
            channel_id = 'RedeAmazonica.br'
        elif re.search("RIT",channel,re.IGNORECASE):
            channel_id = 'RedeInternacionaldeTV.br'          
        elif re.search("SBT",channel,re.IGNORECASE): # ok
            channel_id = 'SBTNacional.br'
        elif re.search("Sexy Hot",channel,re.IGNORECASE) or re.search("SexyHot",channel,re.IGNORECASE):
            channel_id = 'SexyHot.br'
        elif re.search("Sony",channel,re.IGNORECASE):
            channel_id = 'SonyChannelBrazil.br'
        elif re.search("Space",channel,re.IGNORECASE) and not re.search("HBO",channel,re.IGNORECASE):
            channel_id = 'SpaceBrazil.br'
        elif re.search("Sportv 3",channel,re.IGNORECASE):
            channel_id = 'SporTV3.br'  
        elif re.search("Sportv 2",channel,re.IGNORECASE):
            channel_id = 'SporTV2.br'                    
        elif re.search("Sportv",channel,re.IGNORECASE) and not re.search("Sportv 2",channel,re.IGNORECASE) and not re.search("Sportv 3",channel,re.IGNORECASE):
            channel_id = 'SporTV.br'
        elif re.search("Studio Universal",channel,re.IGNORECASE): # ok
            channel_id = 'StudioUniversalBrazil.br'
        elif re.search("Syfy",channel,re.IGNORECASE):
            channel_id = 'SyfyBrazil.br'
        elif re.search("TBS",channel,re.IGNORECASE):
            channel_id = 'TBSBrazil.br'
        elif re.search("TCM",channel,re.IGNORECASE):
            channel_id = 'TCMBrazil.br'
        elif re.search("Telecine Action",channel,re.IGNORECASE):
            channel_id = 'TelecineAction.br'
        elif re.search("Telecine Cult",channel,re.IGNORECASE):
            channel_id = 'TelecineCult.br'
        elif re.search("Telecine Fun",channel,re.IGNORECASE):
            channel_id = 'TelecineFun.br'
        elif re.search("Telecine Pipoca",channel,re.IGNORECASE):
            channel_id = 'TelecinePipoca.br'
        elif re.search("Telecine Premium",channel,re.IGNORECASE):
            channel_id = 'TelecinePremium.br'
        elif re.search("Telecine Touch",channel,re.IGNORECASE):
            channel_id = 'TelecineTouch.br'
        elif re.search("Terra Viva",channel,re.IGNORECASE): # ok
            channel_id = 'TerraViva.br'
        elif re.search("TLC",channel,re.IGNORECASE):
            channel_id = 'TLCBrazil.br'
        elif re.search("TNT Series",channel,re.IGNORECASE) or re.search("TNT Séries",channel,re.IGNORECASE):
            channel_id = 'TNTSeriesBrazil.br'            
        elif re.search("TNT",channel,re.IGNORECASE) and not re.search("TNT Series",channel,re.IGNORECASE) and not re.search("TNT Séries",channel,re.IGNORECASE) and not re.search("HBO",channel,re.IGNORECASE):
            channel_id = 'TNTBrazil.br'
        elif re.search("Tooncast",channel,re.IGNORECASE): # ok
            channel_id = 'Tooncast.us'
        elif re.search("truTV",channel,re.IGNORECASE):
            channel_id = 'truTVBrazil.br'
        elif re.search("TV Aparecida",channel,re.IGNORECASE):
            channel_id = 'TVAparecida.br'
        elif re.search("Tv Brasil",channel,re.IGNORECASE):
            channel_id = 'TVBrasil.br'
        elif re.search("Tv Camara",channel,re.IGNORECASE) or re.search("Tv Câmara",channel,re.IGNORECASE):
            channel_id = 'TVCamara.br'
        elif re.search("Tv Diario Fortaleza",channel,re.IGNORECASE):
            channel_id = 'TVDiario.br'
        elif re.search("Tv Escola",channel,re.IGNORECASE): # ok
            channel_id = 'TVEscola.br'
        elif re.search("TV Gazeta Alagoas",channel,re.IGNORECASE):
            channel_id = 'TVGazetaal.br'
        elif re.search("TV Gazeta",channel,re.IGNORECASE) and not re.search("TV Gazeta Sul",channel,re.IGNORECASE) and not re.search("TV Gazeta Vitoria",channel,re.IGNORECASE):
            channel_id = 'TVGazeta.br'
        elif re.search("Tv Justica",channel,re.IGNORECASE):
            channel_id = 'TVJustica.br'
        elif re.search("TV Liberal Belem",channel,re.IGNORECASE) or re.search("TV Liberal",channel,re.IGNORECASE):
            channel_id = 'TVLiberal.br'
        elif re.search("Tv Senado",channel,re.IGNORECASE):
            channel_id = 'TVSenado.br'
        elif re.search("Tv Verdes Mares",channel,re.IGNORECASE):
            channel_id = 'TVVerdesMares.br'
        elif re.search("VH1",channel,re.IGNORECASE) and not re.search("VH1 Megahits",channel,re.IGNORECASE):
            channel_id = 'VH1Europe.uk'
        elif re.search("VH1 Megahits",channel,re.IGNORECASE):
            channel_id = 'VH1MegaHits.br'
        elif re.search("Viva",channel,re.IGNORECASE):
            channel_id = 'CanalViva.br'
        elif re.search("Warner Channel",channel,re.IGNORECASE) or re.search("Warner",channel,re.IGNORECASE):
            channel_id = 'WarnerChannelBrazil.br'
        elif re.search("WooHoo",channel,re.IGNORECASE):
            channel_id = 'WooHoo.br'
        elif re.search("Zoomoo",channel,re.IGNORECASE):
            channel_id = 'ZooMoo.sg'
        elif re.search("CNN Brasil",channel,re.IGNORECASE) and not re.search("CNN INTERNACIONAL",channel,re.IGNORECASE):
            channel_id = 'CNNBrasil.br'
        elif re.search("Jovem Pan News",channel,re.IGNORECASE):
            channel_id = 'JPNews.br'            
        elif re.search("H2",channel,re.IGNORECASE) or re.search("History 2",channel,re.IGNORECASE):
            channel_id = 'History2Brazil.br'
        else:
            channel_id = ''
        return channel_id

    def epg_get_program(agora,programas,tipo):
        for item in programas:
            start = str(item.get('start')[:-6]).replace(' ', '').replace('+0000', '')
            stop = str(item.get('stop')[:-6]).replace(' ', '').replace('+0000', '')
            if int(start) <= int(agora) < int(stop) and tipo == 'atual':
                agora = stop
                epg = '\n[COLOR aquamarine][B]' + start[8:-4] + ':' + start[10:-2] + ' ' + item.find('title').text + '[/B][/COLOR]'
                desc = item.find('desc')
                if desc is None:
                    sinopse = '\n\nIndisponivel'
                else:
                    sinopse = '\n\n'+ desc.text
                desc_epg = sinopse
                return agora,epg,desc_epg
            if int(start) <= int(agora) < int(stop) and tipo == 'proximo':
                epg2 = '\n\n[COLOR aquamarine][B]' + start[8:-4] + ':' + start[10:-2] + ' ' + item.find('title').text + '[/COLOR][/B]'
                desc2 = item.find('desc')
                if desc2 is None:
                    sinopse2 = '\n\nIndisponivel'
                else:
                    sinopse2 = '\n\n'+ desc2.text
                desc_epg = sinopse2
                return agora,epg2,desc_epg
        return '','',''              




    def getEPG(root,chan):
        try:
            programas = root.findall("./programme[@channel='"+chan+"']")
            if programas:
                agora = datetime.now()
                agora = agora.strftime("%Y%m%d%H%M%S")
                # atual
                agora, epg1, desc1 = epg_get_program(agora,programas,'atual')
                # proximo
                _, epg2, desc2 = epg_get_program(agora,programas,'proximo')
                epg = epg1
                desc_epg = desc1 + epg2 + desc2
            else:
                epg = '\n[COLOR orange]Epg Indisponível[/COLOR]'
                desc_epg = ''
            return epg, desc_epg
        except:
            epg = '\n[COLOR orange]Epg Indisponível[/COLOR]'
            desc_epg = ''
            return epg, desc_epg            

                   
        
       
        
    def parental_password():
        folder = 'special://home/userdata/addon_data'
        folder = translate(folder)
        addon_path = os.path.join(folder, addonid)
        if not os.path.exists(addon_path):
            os.mkdir(addon_path)
        xbmc.sleep(7)
        arquivo = os.path.join(addon_path, "password.txt")
        if not os.path.isfile(arquivo):
            password = '0069'
            p_encoded = base64.b64encode(password.encode()).decode('utf-8')
            with open(arquivo,'w') as f:
                f.write(p_encoded)  

    def setnewpassaord():
        folder = 'special://home/userdata/addon_data'
        folder = translate(folder)
        addon_path = os.path.join(folder, addonid)    
        arquivo = os.path.join(addon_path, "password.txt")
        p_file = open(arquivo,'r+')
        p_file_read = p_file.read()
        p_file.close()
        p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
        ps = dialog.numeric(0, 'Insira a senha atual:')
        if ps == p_file_b64_decode:
            ps2 = dialog.numeric(0, 'Insira a nova senha:')
            if ps2 != '':
                ps2_b64 = base64.b64encode(ps2.encode()).decode('utf-8')
                p_file = open(arquivo,'w')
                p_file.write(ps2_b64)
                p_file.close()
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','A Senha foi alterada com sucesso!')
            else:
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Não foi possivel alterar a senha!')
        else:
            dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')                      
            


    

    def SetView(name):
        if name == 'Wall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(500)')
            except:
                pass
        elif name == 'List':
            try:
                xbmc.executebuiltin('Container.SetViewMode(50)')
            except:
                pass
        elif name == 'Poster':
            try:
                xbmc.executebuiltin('Container.SetViewMode(51)')
            except:
                pass
        elif name == 'Shift':
            try:
                xbmc.executebuiltin('Container.SetViewMode(53)')
            except:
                pass
        elif name == 'InfoWall':
            try:
                xbmc.executebuiltin('Container.SetViewMode(54)')
            except:
                pass
        elif name == 'WideList':
            try:
                xbmc.executebuiltin('Container.SetViewMode(55)')
            except:
                pass
        elif name == 'Fanart':
            try:
                xbmc.executebuiltin('Container.SetViewMode(502)')
            except:
                pass

    def get_kversion():
        full_version_info = xbmc.getInfoLabel('System.BuildVersion')
        baseversion = full_version_info.split(".")
        intbase = int(baseversion[0])
        return intbase

    def get_url(params):
        if params:
            url = '%s?%s'%(plugin, urlencode(params))
        else:
            url = ''
        return url

    def item(params,folder=True):
        u = get_url(params)
        if not u:
            u = ''
        name = params.get("name")
        if name:
            name = name
        else:
            name = 'Unknow'
        iconimage = params.get("iconimage")
        if not iconimage:
            iconimage = icon
        fanart = params.get("fanart")
        if not fanart:
            fanart = fanart_default
        description = params.get("description")
        if not description:
            description = ''           
        playable = params.get("playable")
        liz = xbmcgui.ListItem(name)
        liz.setArt({'fanart': fanart, 'thumb': iconimage, 'icon': "DefaultFolder.png"})
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:
            liz.setInfo(type="Video", infoLabels={"Title": name, 'mediatype': 'video', "Plot": description})                                              
        if playable:
            if playable == 'true':
                liz.setProperty('IsPlayable', 'true')
        ok = xbmcplugin.addDirectoryItem(handle=handle, url=u, listitem=liz, isFolder=folder)
        return ok
    
    def platform():
        from kodi_six import xbmc

        if xbmc.getCondVisibility('system.platform.android'):
            return 'android'
        elif xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
            return 'linux'
        elif xbmc.getCondVisibility('system.platform.windows'):
            return 'windows'
        elif xbmc.getCondVisibility('system.platform.osx'):
            return 'osx'
        elif xbmc.getCondVisibility('system.platform.atv2'):
            return 'atv2'
        elif xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
            return 'ios'
        
    def selectapks(items):
        op = xbmcgui.Dialog().select('SELECIONE UM APK ABAIXO', items)
        return op

    def listar_apks():
        import ntpath
        temp = []
        try:
            apks = req.get(oneplay().vip_downloader).text
            if apks:
                mylist = apks.split("\n")
                if len(mylist) > 0:
                    for url in mylist:
                        if '.apk' in url:
                            name = ntpath.basename(url)
                            temp.append((name,url))
                    return temp
        except:
            pass
        return False
    
    def build_itens():
        itens = listar_apks()
        namelist = []
        urllist = []
        if itens:
            for name, url in itens:
                namelist.append(name)
                urllist.append(url)
            select = selectapks(namelist)
            try:
                if select >=0:
                    return urllist[select]
            except:
                pass
        return False

    def download_py2(url, dest, dp):
        from contextlib import closing
        req = Request(url)  
        req.add_header('User-Agent', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36')   
        msg = 'Baixando, Aguarde....'
        dp.update(0, msg, '')
        with closing(urlopen(req)) as dl_file:
            with open(dest, 'wb') as out_file:
                out_file.write(dl_file.read())
        notify('Download completo.')

    def download_py3(url, dest, dp):
        opener = build_opener()
        opener.addheaders = [('User-agent', 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.75 Mobile Safari/537.36')]
        install_opener(opener)        
        urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

    def _pbhook(numblocks, blocksize, filesize, url, dp):
        try:
            percent = int(min((numblocks*blocksize*100)/filesize, 100))
            currently_downloaded = float(numblocks) * blocksize / (1024 * 1024)
            kbps_speed = numblocks * blocksize / (time.time() - start_time)
            if kbps_speed > 0:
                eta = (filesize - numblocks * blocksize) / kbps_speed
            else:
                eta = 0
            kbps_speed = kbps_speed / 1024
            total = float(filesize) / (1024 * 1024)
            if six.PY3:
                msg = '%.02f MB de %.02f MB\n' % (currently_downloaded, total)
                msg += '[COLOR yellow]Speed:[/COLOR] %.02d Kb/s ' % kbps_speed
                msg += '[COLOR yellow]Time left:[/COLOR] %02d:%02d' % divmod(eta, 60)   
                dp.update(percent, msg)
            else:
                mbs = '%.02f MB de %.02f MB' % (currently_downloaded, total)
                e = '[COLOR yellow]Speed:[/COLOR] %.02d Kb/s ' % kbps_speed
                e += '[COLOR yellow]Time left:[/COLOR] %02d:%02d' % divmod(eta, 60)
                dp.update(percent, mbs, e)
        except:
            percent = 100
            dp.update(percent)
        if percent == 100:
            notify('Download completo.')
        elif dp.iscanceled(): 
            dp.close()
            raise notify('Download parado.')        

    def download_apk(url, name, dest, dp = None):
        global start_time
        start_time=time.time()
        if not dp:
            dp = xbmcgui.DialogProgress() 
            if six.PY3:
                dp.create('Baixando '+name+'...','Por favor espere...')
            else:
                dp.create('Baixando '+name+'...','Por favor espere...', '', '')
            
        dp.update(0)
        try:
            if six.PY3:
                download_py3(url, dest, dp)
            else:
                download_py2(url, dest, dp)
        except:
            try:
                os.remove(dest)
            except:
                pass
            raise Exception

    def apk_manager(url,dest):       
        try:
            import ntpath
            filename = ntpath.basename(url)
            dp = xbmcgui.DialogProgress()
            if six.PY3:
                dp.create('Baixando '+filename+'...','Por favor espere...')
            else:
                dp.create('Baixando '+filename+'...','Por favor espere...', '', '')
            download_apk(url,filename,dest,dp=dp)
            infoDialog('Download completo', iconimage='INFO')
        except:
            infoDialog('Erro ao baixar apk', iconimage='WARNING')                             

    @route
    def baixar_apk(param):
        if platform() == 'android':
            if six.PY2:
                q = dialog.yesno(heading="ONEPLAY VIP", line1='DESEJA BAIXAR APK DO ONEPLAY VIP?', nolabel='NÃO', yeslabel='SIM')
            else:
                q = dialog.yesno(heading="ONEPLAY VIP", message='DESEJA BAIXAR APK DO ONEPLAY VIP?', nolabel='NÃO', yeslabel='SIM')
            if q:
                import ntpath
                url = build_itens()
                if url:
                    if url.endswith('.apk'):
                        name = ntpath.basename(url)
                        if not xbmcvfs.exists(oneplay().downloads_android): xbmcvfs.mkdir(oneplay().downloads_android)
                        dest = translate(os.path.join(oneplay().downloads_android,name))
                        try:
                            os.remove(dest)
                        except:
                            pass
                        apk_manager(url,dest)
                        if os.path.isfile(dest):
                            xbmcgui.Dialog().ok(addonname, 'Verifique a pasta download e instale o apk!')

            
        else:
           dialog.ok(addonname, 'SEU DISPOSITIVO NÃO É ANDROID!')

    # PROCESSAR GRUPOS SERVIDOR 1
    def rodar_grupo(info):
        grupo, tipo, nome, url, iconimage, fanart, info, epgid = info
        if grupo not in temp_grupo:
            temp_grupo.add(grupo)
            name = '[B]' + grupo + '[/B]'
            item_data = {
                'name': name,
                'action': 'tv_servidor1_abrir',
                'iconimage': '',
                'description': '',
                'grupo': grupo
            }
            item(item_data, folder=True)

    # PROCESSAR CANAIS SERVIDOR 1    
    def rodar_grupo2(info):        
        grupo, tipo, nome, url, iconimage, fanart, info, epgid = info
        if grupo_nome == grupo:
            if epginfo:
                if epgid:
                    try:
                        epg, desc_epg = getEPG(epginfo,epgid)
                        try:
                            nome = nome.decode('utf-8')
                        except:
                            pass                        
                        nome = nome + epg
                        info = desc_epg
                    except:
                        pass
            if re.search("Adult",grupo_nome,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo_nome,re.IGNORECASE):
                if tipo == 'NORMAL':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_normal', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')},folder=False)
                elif tipo == 'NORMAL2':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_normal2', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')},folder=False)                
                elif tipo == 'EMBEDFLIX':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_embedflix', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')},folder=False)
                elif tipo == 'AOVIVOGRATIS':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_aovivogratis', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore')},folder=False)
            else:
                if tipo == 'NORMAL':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_normal', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'},folder=False)
                elif tipo == 'NORMAL2':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_normal2', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'},folder=False)                
                elif tipo == 'EMBEDFLIX':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_embedflix', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'},folder=False)
                elif tipo == 'AOVIVOGRATIS':
                    item({'name': nome.encode('utf-8', 'ignore'), 'action': 'player_aovivogratis', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'playable': 'true'},folder=False)         

    @route
    def tv_servidor1_grupo(param):
        xbmcplugin.setContent(handle, 'movies')
        try:
            url_canais = oneplay().canais_servidor1
            PROXY = False
            if PROXY:
                infoDialog('AGUARDE O PROXY', iconimage='INFO')
                try:
                    src = oneplay().req_proxy(url_canais)
                except:
                    src = ''
            else:
                try:
                    r = req.get(url_canais,cache_time=1)
                    if r.status_code == 200:
                        src = r.text
                    else:
                        infoDialog('AGUARDE O PROXY', iconimage='INFO')
                        try:
                            src = oneplay().req_proxy(url_canais)
                        except:
                            src = ''
                except:
                    infoDialog('AGUARDE O PROXY', iconimage='INFO')
                    try:
                        src = oneplay().req_proxy(url_canais)
                    except:
                        src = ''
            regex_pattern = r'GRUPO="([^"]*)"\s+TIPO="([^"]*)"\s+NOME="([^"]*)"\s+URL="([^"]*)"\s+ICONIMAGE="([^"]*)"\s+FANART="([^"]*)"\s+INFO="([^"]*)"\s+EPGID="([^"]*)"'
            canais_info = re.findall(regex_pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
            global temp_grupo
            temp_grupo = set()
            list(map(rodar_grupo, canais_info))
            xbmcplugin.endOfDirectory(handle)
            #SetView('WideList')
            SetView('List')
        except Exception as e:
            pass


    @route
    def tv_servidor1_abrir(param):
        global grupo_nome
        global epginfo   
        xbmcplugin.setContent(handle, 'movies')
        grupo_nome = param.get('grupo', '')
        try:
            grupo_nome = grupo_nome.decode('utf-8')
        except:
            pass
        if re.search("Adult",grupo_nome,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo_nome,re.IGNORECASE):
            folder = 'special://home/userdata/addon_data'
            folder = translate(folder)
            addon_path = os.path.join(folder, addonid)
            arquivo = os.path.join(addon_path, "password.txt")
            p_file = open(arquivo,'r+')
            p_file_read = p_file.read()
            p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
            ps = dialog.numeric(0, 'Insira a senha atual:')
            if ps == p_file_b64_decode:
                notify('DIVIRTA-SE!')
                pass
            else:
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')
                return        
        try:
            url_canais = oneplay().canais_servidor1
            PROXY = False
            if PROXY:
                infoDialog('AGUARDE O PROXY', iconimage='INFO')
                try:
                    src = oneplay().req_proxy(url_canais)
                except:
                    src = ''
            else:
                try:
                    r = req.get(url_canais,cache_time=1)
                    if r.status_code == 200:
                        src = r.text
                    else:
                        infoDialog('AGUARDE O PROXY', iconimage='INFO')
                        try:
                            src = oneplay().req_proxy(url_canais)
                        except:
                            src = ''
                except:
                    infoDialog('AGUARDE O PROXY', iconimage='INFO')
                    try:
                        src = oneplay().req_proxy(url_canais)
                    except:
                        src = ''
            regex_pattern = r'GRUPO="([^"]*)"\s+TIPO="([^"]*)"\s+NOME="([^"]*)"\s+URL="([^"]*)"\s+ICONIMAGE="([^"]*)"\s+FANART="([^"]*)"\s+INFO="([^"]*)"\s+EPGID="([^"]*)"'
            canais_info = re.findall(regex_pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
            if epgEnabled == "true": 
                epginfo = epgParseData()
            else:
                epginfo = False            
            list(map(rodar_grupo2, canais_info))  
            xbmcplugin.endOfDirectory(handle)
            #SetView('WideList')
            SetView('List')
        except Exception as e:
            pass

    def exibir_f4mtester(info):
        nome, url, iconimage, fanart, info, agent = info
        url = base64.b64encode(url.encode()).decode('utf-8')
        agent = base64.b64encode(agent.encode()).decode('utf-8')
        nome = '[B]' + nome + '[/B]'
        item({'name': nome.encode('utf-8', 'ignore'), 'action': 'abrir_m3u8', 'url': url, 'iconimage': iconimage, 'fanart': fanart, 'description': info.encode('utf-8', 'ignore'), 'user': agent},folder=True)         

    @route
    def tv_servidor2(param):
        xbmcplugin.setContent(handle, 'movies')
        try:
            url_canais = oneplay().f4m_servers
            PROXY = False
            if PROXY:
                infoDialog('AGUARDE O PROXY', iconimage='INFO')
                try:
                    src = oneplay().req_proxy(url_canais)
                except:
                    src = ''
            else:
                try:
                    r = req.get(url_canais,cache_time=1)
                    if r.status_code == 200:
                        src = r.text
                    else:
                        infoDialog('AGUARDE O PROXY', iconimage='INFO')
                        try:
                            src = oneplay().req_proxy(url_canais)
                        except:
                            src = ''
                except:
                    infoDialog('AGUARDE O PROXY', iconimage='INFO')
                    try:
                        src = oneplay().req_proxy(url_canais)
                    except:
                        src = ''
            pattern = r'NAME="([^"]*)"[\s\S]*?URL="([^"]*)"[\s\S]*?ICONIMAGE="([^"]*)"[\s\S]*?FANART="([^"]*)"[\s\S]*?INFO="([^"]*)"[\s\S]*?AGENT="([^"]*)"'
            canais_info = re.findall(pattern, src, re.DOTALL | re.IGNORECASE | re.MULTILINE)
            list(map(exibir_f4mtester, canais_info))  
            xbmcplugin.endOfDirectory(handle)
            #SetView('WideList')
            SetView('List')            
        except Exception as e:
            pass

    def grupo_m3u(match):
        tvg_logo, group_title, channel_name, channel_link = match
        tvg_logo = tvg_logo.strip() if tvg_logo else ""
        group_title = group_title.strip() if group_title else ""
        if group_title:
            if group_title not in temp_grupo:
                temp_grupo.add(group_title)
                name = '[B]' + group_title + '[/B]'
                item_data = {
                    'name': name,
                    'url': url,
                    'user': agent,
                    'action': 'exibir_grupo_m3u',
                    'iconimage': '',
                    'description': '',
                    'grupo': group_title
                } 
                item(item_data, folder=True) 

    def grupo_m3u2(match):
        tvg_logo, group_title, channel_name, channel_link = match
        tvg_logo = tvg_logo.strip() if tvg_logo else ""
        group_title = group_title.strip() if group_title else ""
        if group_title == grupo:
            try:
                channel_name = channel_name.decode('utf-8')
            except:
                pass            
            if epginfo:
                try:
                    epg, desc_epg = getEPG(epginfo,getID_EPG(channel_name))
                    name = '[B]' + channel_name + '[/B]' + epg
                    #name = channel_name + epg
                    info = desc_epg
                except:
                    name = '[B]' + channel_name + '[/B]'
                    info = ''
            else:
                name = '[B]' + channel_name + '[/B]'
                info = ''
            if '.mp4' in channel_link:
                item_data = {
                'name': name.encode('utf-8', 'ignore'),
                'url': channel_link,
                'action': 'player_video',
                'iconimage': tvg_logo,
                'description': info.encode('utf-8', 'ignore'),
                'playable': 'true'
                }
            else: 
                item_data = {
                'name': name.encode('utf-8', 'ignore'),
                'url': channel_link,
                'action': 'player_f4mtester',
                'iconimage': tvg_logo,
                'description': info.encode('utf-8', 'ignore')
                } 
            item(item_data, folder=False)                   


    @route
    def abrir_m3u8(param):
        global temp_grupo
        global url
        global agent
        url = param.get('url', '')
        agent = param.get('user', '')
        try:
            url = base64.b64decode(url).decode('utf-8')
        except:
            pass
        try:
            agent = base64.b64decode(agent).decode('utf-8')
        except:
            pass        
        try:
            r = req.get(url,headers={'User-Agent': agent},cache_time=1)
            if r.status_code == 200:
                xbmcplugin.setContent(handle, 'movies')
                src = r.text
                # Encontrar a lista M3U dentro do texto
                m3u_match = re.search(r'#EXTM3U.*', src, re.DOTALL)
                if m3u_match:
                    m3u_content = m3u_match.group()
                else:
                    # Se a lista M3U não for encontrada, encerrar a execução
                    return
                pattern = r'#EXTINF:(?:-?\d+)?\s.*?(?:tvg-logo="([^"]*)")?.*?(?:group-title="([^"]*)")?,(.*?)\n(.*?)\n'
                matches = re.findall(pattern, m3u_content, re.IGNORECASE)
                temp_grupo = set()
                url = base64.b64encode(url.encode()).decode('utf-8')
                agent = base64.b64encode(agent.encode()).decode('utf-8')                 
                list(map(grupo_m3u, matches))
                xbmcplugin.endOfDirectory(handle)
                #SetView('WideList')
                SetView('List')
        except Exception as e:
            pass

    @route
    def exibir_grupo_m3u(param):
        global grupo
        global epginfo  
        url = param.get('url', '')
        agent = param.get('user', '')
        grupo = param.get('grupo', '')
        try:
            grupo  = grupo.decode('utf-8')
        except:
            pass
        try:
            url = base64.b64decode(url).decode('utf-8')
        except:
            pass
        try:
            agent = base64.b64decode(agent).decode('utf-8')
        except:
            pass
        if re.search("Adult",grupo,re.IGNORECASE) or re.search("A Casa das Brasileirinhas",grupo,re.IGNORECASE):
            folder = 'special://home/userdata/addon_data'
            folder = translate(folder)
            addon_path = os.path.join(folder, addonid)
            arquivo = os.path.join(addon_path, "password.txt")
            p_file = open(arquivo,'r+')
            p_file_read = p_file.read()
            p_file_b64_decode = base64.b64decode(p_file_read).decode('utf-8')
            ps = dialog.numeric(0, 'Insira a senha atual:')
            if ps == p_file_b64_decode:
                notify('DIVIRTA-SE!')
                pass
            else:
                dialog.ok('[B][COLOR white]AVISO[/COLOR][/B]','Senha invalida!, se não alterou utilize a senha padrão')
                return
        try:
            r = req.get(url,headers={'User-Agent': agent},cache_time=1)
            if r.status_code == 200:
                xbmcplugin.setContent(handle, 'movies')
                src = r.text
                # Encontrar a lista M3U dentro do texto
                m3u_match = re.search(r'#EXTM3U.*', src, re.DOTALL)
                if m3u_match:
                    m3u_content = m3u_match.group()
                else:
                    # Se a lista M3U não for encontrada, encerrar a execução
                    return
                pattern = r'#EXTINF:(?:-?\d+)?\s.*?(?:tvg-logo="([^"]*)")?.*?(?:group-title="([^"]*)")?,(.*?)\n(.*?)\n'
                matches = re.findall(pattern, m3u_content, re.IGNORECASE) 
                if epgEnabled == "true": 
                    epginfo = epgParseData()
                else:
                    epginfo = False                             
                list(map(grupo_m3u2, matches))
                xbmcplugin.endOfDirectory(handle)
                #SetView('WideList')
                SetView('List')
        except Exception as e:
            pass     





    @route
    def player_normal(param):
        name = param.get('name', '')
        if name:
            try:
                name = name.split('\n')[0]
            except:
                pass
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subtitle', '')
        url = param.get('url', '')
        playable = param.get('playable', '')
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage}) 
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        if '.m3u8' in url:
            liz.setMimeType('application/x-mpegURL')
        elif '.mpd' in url:
            liz.setMimeType('application/xml+dash')
        elif '.ism' in url:
            liz.setMimeType('application/vnd.ms-sstr+xml')
        if six.PY3:
            liz.setProperty('inputstream', 'inputstream.adaptive')
        else:
            liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        if '.m3u8' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        elif '.mpd' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        elif '.ism' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'ism')
        liz.setProperty('inputstream.adaptive.live_delay', '20')
        if playable:          
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
            xbmc.Player().play(item=url, listitem=liz)

    @route
    def player_normal2(param):
        name = param.get('name', '')
        if name:
            try:
                name = name.split('\n')[0]
            except:
                pass            
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subtitle', '')
        url = param.get('url', '')
        playable = param.get('playable', '')
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage}) 
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        # if '.m3u8' in url:
        #     liz.setMimeType('application/x-mpegURL')
        # elif '.mpd' in url:
        #     liz.setMimeType('application/xml+dash')
        # elif '.ism' in url:
        #     liz.setMimeType('application/vnd.ms-sstr+xml')
        # if six.PY3:
        #     liz.setProperty('inputstream', 'inputstream.adaptive')
        # else:
        #     liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        # if '.m3u8' in url:
        #     liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # elif '.mpd' in url:
        #     liz.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        # elif '.ism' in url:
        #     liz.setProperty('inputstream.adaptive.manifest_type', 'ism')
        # liz.setProperty('inputstream.adaptive.live_delay', '35')           
        if playable:          
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
            xbmc.Player().play(item=url, listitem=liz)       

    @route
    def player_embedflix(param):
        name = param.get('name', '')
        if name:
            try:
                name = name.split('\n')[0]
            except:
                pass           
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subtitle', '')
        url = param.get('url', '')
        playable = param.get('playable', '')
        url = oneplay().embedflix_stream(url)
        # plugin = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+quote_plus(str(name))+'&iconImage='+quote_plus(iconimage)+'&thumbnailImage='+quote_plus(iconimage)+'&url='+quote_plus(url)
        # xbmc.executebuiltin('RunPlugin(%s)'%plugin)
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})         
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        # liz.setMimeType('application/x-mpegURL')
        # if six.PY3:
        #     liz.setProperty('inputstream', 'inputstream.adaptive')
        # else:
        #     liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        # liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        # liz.setProperty('inputstream.adaptive.live_delay', '26')
        # liz.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        if playable:          
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
            xbmc.Player().play(item=url, listitem=liz)  

    @route
    def player_f4mtester(param):
        name = param.get('name', '')
        if name:
            try:
                name = name.split('\n')[0]
            except:
                pass           
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        url = param.get('url', '')
        plugin = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+quote_plus(str(name))+'&iconImage='+quote_plus(iconimage)+'&thumbnailImage='+quote_plus(iconimage)+'&url='+quote_plus(url)
        xbmc.executebuiltin('RunPlugin(%s)'%plugin)

    @route
    def player_video(param):
        name = param.get('name', '')    
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subtitle', '')
        url = param.get('url', '')
        playable = param.get('playable', '')
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage}) 
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        if playable:          
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
            xbmc.Player().play(item=url, listitem=liz)                   


    @route
    def player_aovivogratis(param):
        name = param.get('name', '')
        if name:
            try:
                name = name.split('\n')[0]
            except:
                pass           
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subititle', '')
        url = param.get('url', '')
        playable = param.get('playable', '')
        url = oneplay().aovivogratis(url)      
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})         
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        liz.setMimeType('application/x-mpegURL')
        if six.PY3:
            liz.setProperty('inputstream', 'inputstream.adaptive')
        else:
            liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        #liz.setProperty('inputstream.adaptive.live_delay', '26')
        #liz.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        if playable:          
            xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)
        else:
            xbmc.Player().play(item=url, listitem=liz)  

    @route
    def player_testecdn(param):
        name = param.get('name', '')    
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subititle', '') 
        #url = oneplay().resolverurl('https://warezcdn.com/player/player.php?id=225660')   
        #url = oneplay().resolverurl('https://mixdrop.to/e/rwr0egwos1mpdv?sub=https://subs.warezcdn.com/224011-PTB.srt&c1_label=Portugu%C3%AAs')   
        #url = oneplay().resolverurl('https://www.dailymotion.com/embed/video/x7txn7q')  
        # tv diario
        #url = 'https://d1zpubcqwsvgqw.cloudfront.net/out/v1/d33c00c8ecbe4aa9b7e834e607fbbacb/index.mpd' 
        #url = 'http://trenduhd.xyz:80/live/robe7864/57522807/188461.m3u8'
        # url = 'http://acsa.ws:80/live/Rose661/Salmos23/191199.m3u8' 
        # # http://trenduhd.xyz:80/robe7864/57522807/188461
        # plugin = 'plugin://plugin.video.f4mTester/?streamtype=HLSRETRY&name='+quote_plus(str(name))+'&iconImage='+quote_plus(iconimage)+'&thumbnailImage='+quote_plus(iconimage)+'&url='+quote_plus(url)
        # xbmc.executebuiltin('RunPlugin(%s)'%plugin)
        #url = 'https://0117-vos.dtvott.com/DASH/manifest.mpd'
        url = 'https://ctr-01277-claro-br.claro-tv-live.qwilted-cds.cqloud.com/Content/Channel/SPOAXNHD/DASH_KR2/manifest.mpd|Origin=https://z34xxx44.art'

        # license_headers = {
        #     'Content-Type': 'application/xml+dash',
        #     'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:109.0) Gecko/20100101 Firefox/115.0',
        # }

        # license_config = { # for Python < v3.7 you should use OrderedDict to keep order
        # 'license_server_url': 'https://gist.githubusercontent.com/zoreu/ab4edd53ce9e459621ca2f079a5cc3b6/raw/63d1fc54158b04159ebc59a2934f4f0eb8392de3/licence_drm',
        # 'headers': urlencode(license_headers),
        # 'post_data': 'R{SSM}',
        # 'response_data': 'R'
        # }

        liz = xbmcgui.ListItem(name)
        liz.setPath(url)   
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage}) 
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        if '.m3u8' in url:
            liz.setMimeType('application/x-mpegURL')
        elif '.mpd' in url:
            liz.setMimeType('application/xml+dash')
        elif '.ism' in url:
            liz.setMimeType('application/vnd.ms-sstr+xml')
        if six.PY3:
            liz.setProperty('inputstream', 'inputstream.adaptive')
        else:
            liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        if '.m3u8' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        elif '.mpd' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        elif '.ism' in url:
            liz.setProperty('inputstream.adaptive.manifest_type', 'ism')
        liz.setContentLookup(False)
        #liz.setProperty('inputstream.adaptive.live_delay', '60')
        #liz.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true') 
        #liz.setProperty('inputstream.adaptive.license_data', '6MNfYHMauPPF49p9Q+Lbfrht/u52oo8M9KfKV/zi73uL1t5csUzFm6SNeycQiY9TqyiQI2uUAudhAiVl14WmWXH585xbroA4VHnZn+s7QMo=')           
        liz.setProperty('inputstream.adaptive.license_type', 'com.microsoft.playready')
        #liz.setProperty('inputstream.adaptive.license_key',  'f8c8554dddf931fbcad55c95462e9091:5dd1b03b203faeea44b8ab1ad5043920')
        liz.setProperty('inputstream.adaptive.license_key',  'eyJmOGM4NTU0ZGRkZjkzMWZiY2FkNTVjOTU0NjJlOTA5MSI6IjVkZDFiMDNiMjAzZmFlZWE0NGI4YWIxYWQ1MDQzOTIwIn0JCQkJCQkJCQk=')

        # liz.setProperty('inputstream.adaptive.license_key', '6MNfYHMauPPF49p9Q+Lbfrht/u52oo8M9KfKV/zi73uL1t5csUzFm6SNeycQiY9TqyiQI2uUAudhAiVl14WmWXH585xbroA4VHnZn+s7QMo=')
        #liz.setProperty('inputstream.adaptive.license_key', 'https://gist.githubusercontent.com/zoreu/ab4edd53ce9e459621ca2f079a5cc3b6/raw/63d1fc54158b04159ebc59a2934f4f0eb8392de3/licence_drm')
        #liz.setProperty('inputstream.adaptive.license_key',  {"keys" :[{"xkey":"6MNfYHMauPPF49p9Q+Lbfrht/u52oo8M9KfKV/zi73uL1t5csUzFm6SNeycQiY9TqyiQI2uUAudhAiVl14WmWXH585xbroA4VHnZn+s7QMo="}]})
        # issue - https://github.com/PiotrDabkowski/Js2Py/issues/312
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)   

    @route
    def teste_embed(param):
        name = param.get('name', '')    
        iconimage = param.get('iconimage', '')
        fanart = param.get('fanart', '')
        description = param.get('description', '')
        sub = param.get('subititle', '')
        url = param.get('url', '')
        url = oneplay().embedflix_stream(url)    
        liz = xbmcgui.ListItem(name)
        liz.setPath(url)      
        liz.setArt({"fanart": fanart, "icon": iconimage, "thumb": iconimage})         
        if sub:
            liz.setSubtitles([sub])
        if get_kversion() > 19:
            info = liz.getVideoInfoTag()
            info.setTitle(name)
            info.setMediaType('video')
            info.setPlot(description)
        else:           
            liz.setInfo(type='video', infoLabels={'Title': name, 'plot': description })
        liz.setMimeType('application/x-mpegURL')
        if six.PY3:
            liz.setProperty('inputstream', 'inputstream.adaptive')
        else:
            liz.setProperty('inputstreamaddon', 'inputstream.adaptive')
        liz.setProperty('inputstream.adaptive.manifest_type', 'hls')
        #liz.setProperty('inputstream.adaptive.live_delay', '26')
        #liz.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, liz)                       

    # ABRIR AJUSTES
    @route
    def abrir_config(param):
        addon.openSettings()

    # MENU PRINCIPAL
    @route
    def main():
        parental_password()
        xbmcplugin.setContent(handle, 'movies')
        item({'name': '[B][COLOR aquamarine]:::[/COLOR]BEM-VINDOS AO ONEPLAY[COLOR aquamarine]:::[/COLOR][/B]', 'action': '', 'iconimage': icon, 'description': oneplay().descricao_addon()},folder=True)
        item({'name': '[B]VIP[/B]', 'action': 'baixar_apk','iconimage': vip_icon, 'description': oneplay().vip_descricao()},folder=True)
        item({'name': '[B]TV[/B]', 'action': 'tv','iconimage': tv_icon, 'description': 'area para canais, incluindo servidor 1 e servidor 2'},folder=True)
        #item({'name': '[B]TESTE CDN[/B]', 'action': 'player_testecdn','iconimage': tv_icon, 'description': 'area para canais, incluindo servidor 1 e servidor 2', 'playable': 'true'},folder=False)
        #item({'name': '[B]TESTE CDN[/B]', 'url': '3554', 'action': 'teste_embed','iconimage': tv_icon, 'description': 'area para canais, incluindo servidor 1 e servidor 2', 'playable': 'true'},folder=False)
        item({'name': '[B]AJUSTES[/B]', 'action': 'abrir_config','iconimage': '', 'description': 'Faça ajustes no addon por meio dessa opção'},folder=True)
        #item({'name': '[B]TESTE[/B]', 'action': 'player_teste','iconimage': tv_icon, 'description': 'area para canais, incluindo servidor 1 e servidor 2', 'playable': 'true'},folder=False)
        xbmcplugin.endOfDirectory(handle)
        SetView('List')

    # TV
    @route
    def tv(param):
        #gerar_log()
        item({'name': '[B]SERVIDOR 1[/B]', 'action': 'tv_servidor1_grupo','iconimage': tv_icon, 'description': ''},folder=True)
        item({'name': '[B]SERVIDOR 2 (F4MTESTER)[/B]', 'action': 'tv_servidor2','iconimage': tv_icon, 'description': ''},folder=True)
        xbmcplugin.endOfDirectory(handle)
        SetView('WideList')

    # ALTERAR SENHA
    @route
    def setpassword(param):
        parental_password()
        setnewpassaord()