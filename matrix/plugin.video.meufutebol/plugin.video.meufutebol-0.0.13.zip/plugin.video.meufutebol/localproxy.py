# -*- coding: utf-8 -*-
from helpers import *
import threading
import socket
import struct
import time
import os
import requests
import re
import ssl
import json
from contextlib import contextmanager
try:
    requests.packages.urllib3.disable_warnings()
except Exception:
    pass
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
try:
    from urllib.parse import urljoin
except Exception:
    from urlparse import urljoin

HOST = '127.0.0.1'
PORT = 9098
PORT_CANDIDATES = (9098, 9099, 9100)
HEALTH_PATH = '/_meufutebol_health'
HEALTH_TOKEN = 'MEU_FUTEBOL_PROXY_V013'
URL_PROXY = 'http://{}:{}/?url='.format(HOST, PORT)

WINDOW = xbmcgui.Window(10000)
PROPERTY_NAME = 'meufutebol.proxy.running'
PORT_PROPERTY_NAME = 'meufutebol.proxy.port'

_proxy_instance = None
_owned_port = None

DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'


class CloudflareDNSResolver(object):
    """Resolvedor DNS privado ao addon, usando os recursivos 1.1.1.1/1.0.0.1.

    Ele só substitui getaddrinfo enquanto uma requisição HTTP deste addon está em
    andamento. Isso evita mudar a configuração DNS do dispositivo ou deixar uma
    alteração permanente no Kodi. Respostas ficam em cache curto e, se Cloudflare
    não responder, o DNS nativo permanece como fallback seguro.
    """

    SERVERS = ('1.1.1.1', '1.0.0.1')
    CACHE_TTL_MIN = 60
    CACHE_TTL_MAX = 1800
    UDP_TIMEOUT = 2.0
    TCP_TIMEOUT = 3.5
    DOH_TIMEOUT = (3, 6)

    def __init__(self):
        self._native_getaddrinfo = socket.getaddrinfo
        self._cache = {}
        self._cache_lock = threading.RLock()
        self._patch_lock = threading.RLock()
        self._patch_depth = 0
        self._resolving = threading.local()
        self._logged_active = False

    @staticmethod
    def _host_text(host):
        if isinstance(host, bytes):
            try:
                return host.decode('idna')
            except Exception:
                return host.decode('utf-8', 'ignore')
        return str(host or '')

    @staticmethod
    def _is_ip_literal(host):
        try:
            socket.inet_pton(socket.AF_INET, host)
            return True
        except Exception:
            pass
        try:
            socket.inet_pton(socket.AF_INET6, host)
            return True
        except Exception:
            return False

    def _skip_name(self, packet, offset):
        seen = 0
        length = len(packet)
        while offset < length:
            if seen > 128:
                raise ValueError('Loop de nome DNS')
            seen += 1
            size = packet[offset]
            if size == 0:
                return offset + 1
            if size & 0xC0 == 0xC0:
                if offset + 1 >= length:
                    raise ValueError('Ponteiro DNS truncado')
                return offset + 2
            if size & 0xC0:
                raise ValueError('Label DNS invalido')
            offset += 1 + size
        raise ValueError('Nome DNS truncado')

    def _build_query(self, host):
        labels = []
        for label in host.rstrip('.').split('.'):
            raw = label.encode('idna')
            if not raw or len(raw) > 63:
                raise ValueError('Hostname DNS invalido')
            labels.append(bytes([len(raw)]) + raw)
        question = b''.join(labels) + b'\x00' + struct.pack('!HH', 1, 1)
        query_id = struct.unpack('!H', os.urandom(2))[0]
        return query_id, struct.pack('!HHHHHH', query_id, 0x0100, 1, 0, 0, 0) + question

    def _parse_response(self, packet, query_id):
        if not packet or len(packet) < 12:
            return [], self.CACHE_TTL_MIN
        response_id, flags, qdcount, ancount, _, _ = struct.unpack('!HHHHHH', packet[:12])
        if response_id != query_id or (flags & 0x8000) == 0 or (flags & 0x000F):
            return [], self.CACHE_TTL_MIN
        offset = 12
        for _ in range(qdcount):
            offset = self._skip_name(packet, offset)
            offset += 4
            if offset > len(packet):
                return [], self.CACHE_TTL_MIN

        addresses = []
        ttl_values = []
        for _ in range(ancount):
            offset = self._skip_name(packet, offset)
            if offset + 10 > len(packet):
                break
            rtype, rclass, ttl, rdlength = struct.unpack('!HHIH', packet[offset:offset + 10])
            offset += 10
            rdata_end = offset + rdlength
            if rdata_end > len(packet):
                break
            if rtype == 1 and rclass == 1 and rdlength == 4:
                addresses.append(socket.inet_ntoa(packet[offset:rdata_end]))
                ttl_values.append(ttl)
            offset = rdata_end

        ttl = min(ttl_values) if ttl_values else self.CACHE_TTL_MIN
        ttl = max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
        return addresses, ttl

    def _query_udp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.settimeout(self.UDP_TIMEOUT)
            sock.sendto(packet, (server, 53))
            response, _ = sock.recvfrom(8192)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _query_tcp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(self.TCP_TIMEOUT)
            sock.connect((server, 53))
            payload = struct.pack('!H', len(packet)) + packet
            sock.sendall(payload)
            header = self._recv_exact(sock, 2)
            if not header:
                return [], self.CACHE_TTL_MIN
            size = struct.unpack('!H', header)[0]
            response = self._recv_exact(sock, size)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    @staticmethod
    def _recv_exact(sock, amount):
        data = b''
        while len(data) < amount:
            block = sock.recv(amount - len(data))
            if not block:
                return b''
            data += block
        return data

    def _query_doh(self, host):
        """Fallback DoH cifrado sem consultar o DNS padrao do aparelho.

        A conexao TLS vai direto aos IPs publicos da Cloudflare e preserva SNI
        cloudflare-dns.com; portanto nao existe bootstrap pelo DNS da operadora.
        """
        request_path = '/dns-query?{}'.format(urlencode({'name': host, 'type': 'A'}))
        request = (
            'GET {} HTTP/1.1\r\n'
            'Host: cloudflare-dns.com\r\n'
            'Accept: application/dns-json\r\n'
            'Accept-Encoding: identity\r\n'
            'User-Agent: {}\r\n'
            'Connection: close\r\n\r\n'
        ).format(request_path, DEFAULT_UA).encode('ascii', 'ignore')
        for server in self.SERVERS:
            raw_sock = None
            tls_sock = None
            try:
                raw_sock = socket.create_connection((server, 443), self.DOH_TIMEOUT[1])
                context = ssl.create_default_context()
                tls_sock = context.wrap_socket(raw_sock, server_hostname='cloudflare-dns.com')
                raw_sock = None
                tls_sock.settimeout(self.DOH_TIMEOUT[1])
                tls_sock.sendall(request)
                response = b''
                while True:
                    block = tls_sock.recv(65536)
                    if not block:
                        break
                    response += block
                    if len(response) > 1024 * 1024:
                        raise ValueError('Resposta DoH grande demais')
                header, sep, body = response.partition(b'\r\n\r\n')
                if not sep or not header.startswith(b'HTTP/'):
                    continue
                try:
                    status = int(header.split(b'\r\n', 1)[0].split()[1])
                except Exception:
                    status = 0
                if status != 200:
                    continue
                payload = json.loads(body.decode('utf-8', 'replace'))
                ips = []
                ttls = []
                for answer in payload.get('Answer') or []:
                    if answer.get('type') == 1 and answer.get('data'):
                        ip = str(answer.get('data'))
                        if self._is_ip_literal(ip):
                            ips.append(ip)
                            ttls.append(answer.get('TTL') or self.CACHE_TTL_MIN)
                if ips:
                    ttl = min(ttls) if ttls else self.CACHE_TTL_MIN
                    return ips, max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
            except Exception as exc:
                try:
                    xbmc.log('[MEU FUTEBOL DNS] DoH direto indisponivel em {}: {}'.format(server, str(exc)), xbmc.LOGDEBUG)
                except Exception:
                    pass
            finally:
                for candidate in (tls_sock, raw_sock):
                    try:
                        if candidate:
                            candidate.close()
                    except Exception:
                        pass
        return [], self.CACHE_TTL_MIN

    def resolve(self, host):
        host = self._host_text(host).strip().rstrip('.').lower()
        if not host or self._is_ip_literal(host) or host in ('localhost', 'localhost.localdomain') or host.endswith('.local'):
            return []
        now = time.time()
        with self._cache_lock:
            cached = self._cache.get(host)
            if cached and cached[0] > now:
                return list(cached[1])

        if getattr(self._resolving, 'active', False):
            return []

        self._resolving.active = True
        try:
            query_id, packet = self._build_query(host)
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_udp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_tcp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            addresses, ttl = self._query_doh(host)
            if addresses:
                self._save_cache(host, addresses, ttl)
                return addresses
        finally:
            self._resolving.active = False
        return []

    def _save_cache(self, host, addresses, ttl):
        with self._cache_lock:
            self._cache[host] = (time.time() + ttl, tuple(addresses))

    def _patched_getaddrinfo(self, host, port, family=0, type=0, proto=0, flags=0):
        # Não recursar quando o próprio fallback DoH precisa alcançar cloudflare-dns.com.
        if getattr(self._resolving, 'active', False):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        host_text = self._host_text(host)
        if not host_text or self._is_ip_literal(host_text) or host_text in ('localhost', 'localhost.localdomain') or host_text.endswith('.local'):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        # O addon trabalha somente com A/IPv4 neste fluxo. Nunca cai no DNS nativo
        # para um hostname externo: se Cloudflare falhar, a requisicao falha de forma
        # explicita em vez de escapar para o resolvedor padrao da rede.
        if family == socket.AF_INET6:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS: IPv6 nao disponivel neste fluxo')
        addresses = self.resolve(host_text)
        if not addresses:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS nao respondeu para {}'.format(host_text))
        results = []
        for ip in addresses:
            try:
                results.extend(self._native_getaddrinfo(ip, port, family, type, proto, flags))
            except Exception:
                pass
        if not results:
            raise socket.gaierror(socket.EAI_NONAME, 'Cloudflare DNS nao retornou endereco utilizavel para {}'.format(host_text))
        return results

    @contextmanager
    def scoped(self):
        with self._patch_lock:
            if self._patch_depth == 0:
                socket.getaddrinfo = self._patched_getaddrinfo
            self._patch_depth += 1
        try:
            yield
        finally:
            with self._patch_lock:
                self._patch_depth -= 1
                if self._patch_depth <= 0:
                    self._patch_depth = 0
                    socket.getaddrinfo = self._native_getaddrinfo

    def mark_active(self):
        if self._logged_active:
            return
        self._logged_active = True
        try:
            xbmc.log('[MEU FUTEBOL DNS] Cloudflare interno estrito habilitado (sem DNS padrao da rede).', xbmc.LOGINFO)
        except Exception:
            pass


_cloudflare_dns = CloudflareDNSResolver()


def install_cloudflare_dns():
    """Marca o resolvedor como ativo; não troca o DNS do sistema nem grava configurações."""
    _cloudflare_dns.mark_active()
    return True


def cloudflare_request(method, url, **kwargs):
    """Requisição HTTP limitada ao resolvedor Cloudflare deste addon."""
    install_cloudflare_dns()
    with _cloudflare_dns.scoped():
        return requests.request(method, url, **kwargs)


def cloudflare_get(url, **kwargs):
    """GET do requests com resolução Cloudflare limitada a esta requisição."""
    return cloudflare_request('GET', url, **kwargs)


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


def is_port_in_use(port, host=HOST):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.8)
            return s.connect_ex((host, int(port))) == 0
    except Exception:
        return False


def _valid_port(value):
    try:
        value = int(value)
        return value if 1 <= value <= 65535 else 0
    except Exception:
        return 0


def _current_proxy_port():
    try:
        value = _valid_port(WINDOW.getProperty(PORT_PROPERTY_NAME))
        if value:
            return value
    except Exception:
        pass
    return PORT


def _proxy_base(port=None):
    port = _valid_port(port) or _current_proxy_port()
    return 'http://{}:{}/?url='.format(HOST, port)


def _health_check(port, timeout=0.8):
    """Confirma que uma porta em loopback é realmente deste addon.

    Não basta a porta estar aberta: outro addon/processo pode usar 9098.
    """
    port = _valid_port(port)
    if not port:
        return False
    sock = None
    try:
        sock = socket.create_connection((HOST, port), timeout)
        request = ('GET {} HTTP/1.1\r\nHost: {}:{}\r\nConnection: close\r\n\r\n'
                   .format(HEALTH_PATH, HOST, port)).encode('ascii')
        sock.sendall(request)
        data = b''
        while len(data) < 4096:
            chunk = sock.recv(1024)
            if not chunk:
                break
            data += chunk
            if b'\r\n\r\n' in data:
                break
        return (b' 200 ' in data.split(b'\r\n', 1)[0] and
                ('X-Meu-Futebol-Proxy: {}'.format(HEALTH_TOKEN)).encode('ascii') in data)
    except Exception:
        return False
    finally:
        try:
            if sock:
                sock.close()
        except Exception:
            pass


def _mark_proxy_running(port):
    try:
        WINDOW.setProperty(PROPERTY_NAME, 'true')
        WINDOW.setProperty(PORT_PROPERTY_NAME, str(int(port)))
    except Exception:
        pass


def _clear_proxy_properties():
    try:
        WINDOW.clearProperty(PROPERTY_NAME)
        WINDOW.clearProperty(PORT_PROPERTY_NAME)
    except Exception:
        pass


def _split_kodi_url(raw):
    if '|' in raw:
        url, options = raw.split('|', 1)
    else:
        url, options = raw, ''
    parsed_options = parse_qs(options, keep_blank_values=True)
    return url, parsed_options


def _opt(options, key, default=''):
    value = options.get(key, [default])
    return value[0] if value else default


def proxy_url(raw_url):
    """Encapsula URL HTTP externa no proxy local sem alterar URLs locais."""
    if not raw_url:
        return ''
    try:
        value = str(raw_url)
        current_prefix = _proxy_base()
        if value.startswith(current_prefix) or value.startswith(URL_PROXY):
            return value
        raw_target, _ = _split_kodi_url(value)
        lower = raw_target.lower()
        if not lower.startswith(('http://', 'https://')):
            return value
        return current_prefix + quote_plus(value)
    except Exception:
        return raw_url


def _build_proxy_url(url, options):
    params = {}
    user_agent = _opt(options, 'User-Agent', DEFAULT_UA)
    referer = _opt(options, 'Referer', '')
    origin = _opt(options, 'Origin', '')
    upstream_proxy = _opt(options, 'Proxy', '')
    if user_agent:
        params['User-Agent'] = user_agent
    if referer:
        params['Referer'] = referer
    if origin:
        params['Origin'] = origin
    if upstream_proxy:
        params['Proxy'] = upstream_proxy
    kodi_url = url + ('|' + urlencode(params) if params else '')
    return _proxy_base() + quote_plus(kodi_url)


def _rewrite_attr_uris(line, base_url, options):
    def repl(match):
        quote_char = match.group(1)
        uri = match.group(2)
        absolute = urljoin(base_url, uri)
        return 'URI={}{}{}'.format(quote_char, _build_proxy_url(absolute, options), quote_char)
    return re.sub(r'URI=(["\'])(.*?)\1', repl, line)


def _rewrite_playlist(content, base_url, options):
    lines = []
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            lines.append(line)
            continue
        if stripped.startswith('#'):
            if 'URI=' in stripped:
                lines.append(_rewrite_attr_uris(line, base_url, options))
            else:
                lines.append(line)
            continue
        absolute = urljoin(base_url, stripped)
        lines.append(_build_proxy_url(absolute, options))
    return '\n'.join(lines) + '\n'


class M3UProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def _send_headers(self, status, content_type='', content_length=None, upstream_headers=None, cache_images=False):
        self.send_response(status)
        self.send_header('Content-Type', content_type or 'application/octet-stream')
        if cache_images and (content_type or '').lower().startswith('image/'):
            self.send_header('Cache-Control', 'public, max-age=21600')
        else:
            self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        if content_length is not None:
            self.send_header('Content-Length', str(content_length))
        if upstream_headers:
            for header in ('Content-Range', 'Accept-Ranges'):
                value = upstream_headers.get(header)
                if value:
                    self.send_header(header, value)
        self.end_headers()

    def _send_playlist(self, body, send_body):
        self._send_headers(
            200,
            'application/vnd.apple.mpegurl',
            len(body),
            upstream_headers=None,
            cache_images=False
        )
        if send_body and body:
            self.wfile.write(body)

    def _handle_health(self, send_body):
        body = (HEALTH_TOKEN + '\n').encode('ascii')
        self.send_response(200)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('X-Meu-Futebol-Proxy', HEALTH_TOKEN)
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Connection', 'close')
        self.send_header('Content-Length', str(len(body)))
        self.end_headers()
        if send_body:
            self.wfile.write(body)

    @staticmethod
    def _looks_like_playlist(chunk):
        try:
            return bool(chunk and chunk.lstrip().startswith(b'#EXTM3U'))
        except Exception:
            return False

    def _handle_request(self, send_body=True):
        parsed_path = urlparse(self.path)
        if parsed_path.path == HEALTH_PATH:
            self._handle_health(send_body)
            return

        query = parse_qs(parsed_path.query)
        # parse_qs já desfaz quote_plus. Decodificar uma segunda vez corrompia
        # tokens assinados com "+" e parâmetros "%2F" de URLs HLS.
        target_url = query.get('url', [None])[0]
        if not target_url:
            self.send_error(400)
            return

        try:
            url, options = _split_kodi_url(target_url)
            upstream_proxy = _opt(options, 'Proxy', '')
            headers = {
                'User-Agent': _opt(options, 'User-Agent', DEFAULT_UA),
                'Referer': _opt(options, 'Referer', ''),
                'Origin': _opt(options, 'Origin', '')
            }
            client_range = self.headers.get('Range', '')
            if client_range:
                headers['Range'] = client_range
            headers = {k: v for k, v in headers.items() if v}

            proxies = {'http': upstream_proxy, 'https': upstream_proxy} if upstream_proxy else None
            response = cloudflare_get(
                url,
                headers=headers,
                proxies=proxies,
                timeout=(8, 25),
                verify=False,
                allow_redirects=True,
                stream=True
            )
            response.raise_for_status()

            content_type = response.headers.get('Content-Type', '')
            final_url = response.url or url
            base_url = final_url.rsplit('/', 1)[0] + '/'
            declared_playlist = (
                '.m3u8' in final_url.lower() or
                'mpegurl' in (content_type or '').lower()
            )

            # HEAD não precisa ler/regravar o corpo. Ele responde apenas com
            # metadados locais e não expõe a URL remota ao Kodi.
            if not send_body:
                status = response.status_code if response.status_code in (200, 206) else 200
                self._send_headers(
                    status,
                    content_type,
                    response.headers.get('Content-Length'),
                    upstream_headers=response.headers,
                    cache_images=True
                )
                return

            if declared_playlist:
                source_body = response.content
                text = source_body.decode(response.encoding or 'utf-8', 'replace').replace('\\/', '/')
                body = _rewrite_playlist(text, base_url, options).encode('utf-8')
                self._send_playlist(body, True)
                return

            # Alguns provedores devolvem HLS como application/octet-stream ou
            # sem ".m3u8" na URL. Lemos somente o primeiro bloco para detectar
            # #EXTM3U; se for playlist, reescrevemos os segmentos/chaves.
            iterator = response.iter_content(chunk_size=64 * 1024)
            first_chunk = next(iterator, b'')
            if self._looks_like_playlist(first_chunk):
                chunks = [first_chunk]
                total = len(first_chunk)
                for chunk in iterator:
                    if not chunk:
                        continue
                    total += len(chunk)
                    if total > 2 * 1024 * 1024:
                        raise ValueError('Playlist HLS grande demais')
                    chunks.append(chunk)
                source_body = b''.join(chunks)
                text = source_body.decode(response.encoding or 'utf-8', 'replace').replace('\\/', '/')
                body = _rewrite_playlist(text, base_url, options).encode('utf-8')
                self._send_playlist(body, True)
                return

            status = response.status_code if response.status_code in (200, 206) else 200
            self._send_headers(
                status,
                content_type,
                response.headers.get('Content-Length'),
                upstream_headers=response.headers,
                cache_images=True
            )
            if first_chunk:
                self.wfile.write(first_chunk)
            for chunk in iterator:
                if chunk:
                    self.wfile.write(chunk)

        except (BrokenPipeError, ConnectionResetError):
            return
        except Exception as exc:
            try:
                xbmc.log('[MEU FUTEBOL PROXY ERROR] ' + str(exc), xbmc.LOGERROR)
            except Exception:
                pass
            try:
                self.send_error(500)
            except Exception:
                pass

    def do_GET(self):
        self._handle_request(send_body=True)

    def do_HEAD(self):
        self._handle_request(send_body=False)


class ProxyServer(threading.Thread):
    def __init__(self, port):
        threading.Thread.__init__(self)
        self.daemon = True
        self.port = int(port)
        self.server = None
        self.monitor = xbmc.Monitor()
        self.bound = threading.Event()
        self.failed = threading.Event()

    def run(self):
        try:
            self.server = ThreadedHTTPServer((HOST, self.port), M3UProxyHandler)
            self.bound.set()
            xbmc.log('[MEU FUTEBOL PROXY] Rodando em http://{}:{}'.format(HOST, self.port), xbmc.LOGINFO)
            threading.Thread(target=self.server.serve_forever, kwargs={'poll_interval': 0.25}, daemon=True).start()
            while not self.monitor.abortRequested():
                self.monitor.waitForAbort(1)
            self.stop()
        except OSError as exc:
            self.failed.set()
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Porta {} ocupada: {}'.format(self.port, str(exc)), xbmc.LOGINFO)
            except Exception:
                pass
        except Exception as exc:
            self.failed.set()
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Falha no servidor local: {}'.format(str(exc)), xbmc.LOGERROR)
            except Exception:
                pass

    def stop(self):
        server = self.server
        self.server = None
        if server:
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Encerrando...', xbmc.LOGINFO)
            except Exception:
                pass
            try:
                server.shutdown()
            except Exception:
                pass
            try:
                server.server_close()
            except Exception:
                pass


def _wait_for_proxy(instance, port, timeout=2.5):
    deadline = time.time() + float(timeout)
    while time.time() < deadline:
        if instance.bound.is_set() and _health_check(port):
            return True, True
        if instance.failed.is_set():
            # Em uma largada simultânea, outro processo do mesmo addon pode ter
            # vencido a disputa pela porta. Aceita somente se o health-check
            # comprovar que é o proxy MEU FUTEBOL.
            return _health_check(port), False
        time.sleep(0.05)
    return _health_check(port), bool(instance.bound.is_set())


def _candidate_ports():
    ports = []
    for candidate in (_current_proxy_port(),) + tuple(PORT_CANDIDATES):
        port = _valid_port(candidate)
        if port and port not in ports:
            ports.append(port)
    return ports


def start():
    global _proxy_instance, _owned_port
    install_cloudflare_dns()

    # Prioriza o proxy que o service.py já iniciou. Propriedade sem health é
    # considerada stale; nunca encaminha tráfego para uma porta desconhecida.
    current_port = _current_proxy_port()
    if WINDOW.getProperty(PROPERTY_NAME) == 'true' and _health_check(current_port):
        _mark_proxy_running(current_port)
        return True
    if WINDOW.getProperty(PROPERTY_NAME) == 'true':
        _clear_proxy_properties()
        try:
            xbmc.log('[MEU FUTEBOL PROXY] Marcacao antiga sem health-check; reiniciando.', xbmc.LOGWARNING)
        except Exception:
            pass

    if _proxy_instance and _owned_port and _health_check(_owned_port):
        _mark_proxy_running(_owned_port)
        return True

    for candidate in _candidate_ports():
        if _health_check(candidate):
            _proxy_instance = None
            _owned_port = None
            _mark_proxy_running(candidate)
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Reutilizando proxy validado na porta {}.'.format(candidate), xbmc.LOGINFO)
            except Exception:
                pass
            return True

        if is_port_in_use(candidate):
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Porta {} ocupada por outro processo; tentando alternativa.'.format(candidate), xbmc.LOGWARNING)
            except Exception:
                pass
            continue

        instance = ProxyServer(candidate)
        instance.start()
        confirmed, owned = _wait_for_proxy(instance, candidate)
        if confirmed:
            if owned:
                _proxy_instance = instance
                _owned_port = candidate
            else:
                _proxy_instance = None
                _owned_port = None
            _mark_proxy_running(candidate)
            try:
                xbmc.log('[MEU FUTEBOL PROXY] Iniciado com sucesso na porta {}.'.format(candidate), xbmc.LOGINFO)
            except Exception:
                pass
            return True

        try:
            instance.stop()
        except Exception:
            pass

    _proxy_instance = None
    _owned_port = None
    _clear_proxy_properties()
    try:
        xbmc.log('[MEU FUTEBOL PROXY] Nenhuma porta local disponivel para o proxy.', xbmc.LOGERROR)
    except Exception:
        pass
    return False


def stop():
    global _proxy_instance, _owned_port
    instance = _proxy_instance
    owned_port = _owned_port
    _proxy_instance = None
    _owned_port = None
    if instance:
        try:
            instance.stop()
        except Exception:
            pass
        _clear_proxy_properties()
        try:
            xbmc.log('[MEU FUTEBOL PROXY] Finalizado.', xbmc.LOGINFO)
        except Exception:
            pass
    elif owned_port:
        _clear_proxy_properties()
