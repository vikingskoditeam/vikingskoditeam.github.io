# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Provider VOD HDHub isolado, usado como última origem do agregador.

Contrato conservador:
* usa somente IMDb exato já resolvido pela Matrix;
* uma requisição de catálogo por filme/episódio; candidatos HTTP passam por preflight curto, limitado e sem retry agressivo;
* filmes: /stream/movie/<imdb>.json;
* séries: /stream/series/<imdb>:<season>:<episode>.json;
* publica HLS/DASH quando o manifesto raiz é válido, progressive/URL opaca quando Range e bytes provam mídia, ou torrent com magnet válido;
* separa formato incompatível de origem suportável porém offline/bloqueada; hosts historicamente instáveis são sondados por URL em vez de blacklist permanente;
* oculta tamanho de arquivo somente nas fontes HDHub;
* falha/timeout desta fonte nunca invalida FrostStream/FenixFlix/SuperStream.
"""

import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from threading import Lock
from urllib.parse import urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None

from resources.lib import vod_engine as _vod_engine


HDHUB_API_ROOT = (
    'https://hdhub.thevolecitor.qzz.io/'
    'eyJ0b3Jib3giOiJ1bnNldCIsInF1YWxpdGllcyI6IjIxNjBwLDEwODBwLDcyMHAsNDgwcCIs'
    'InNvcnQiOiJhc2MiLCJjYXRhbG9ncyI6IiJ9'
)
HDHUB_PROVIDER_NAME = 'HDHub'
HDHUB_REFERER = 'https://hdhub.thevolecitor.qzz.io/'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/151.0.0.0 Safari/537.36'
)
REQUEST_TIMEOUT = (2.0, 5.0)
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
HEALTH_NAMESPACE = 'vod_hdhub_provider_health_v1'
HEALTH_KEY = 'cooldown'
NETWORK_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60
SERVER_COOLDOWN_SECONDS = 30
MAX_STREAMS = 80
# Perícia 09/09/2026: o histórico antigo de HLS inválido não pode virar bloqueio
# permanente de capacidade. HLS/DASH são aceitos quando o manifesto raiz prova
# o formato; progressive/unknown HTTP são aceitos quando Range + bytes provam mídia.
DIRECT_PLAY_KINDS = frozenset(('hls', 'dash', 'progressive', 'unknown'))
PREFLIGHT_TIMEOUT = (1.2, 2.2)
PREFLIGHT_TTL_OK = 120.0
PREFLIGHT_TTL_BAD = 60.0
# Limite conservador para TV Box de 2 GB: o HDHub já roda após o lote principal
# e cada worker mantém resposta/buffer TLS. Quatro preservam paralelismo sem o
# pico de oito conexões simultâneas observado na versão periciada.
PREFLIGHT_WORKERS = 4
PREFLIGHT_MAX_CANDIDATES = 24
CONTENT_RANGE_RE = re.compile(r'^\s*bytes\s+(\d+)\s*-\s*(\d+)\s*/\s*(\d+)\s*$', re.I)
# Hosts que falharam de forma consistente/estrutural no log real.
# Cloudflare R2 NÃO entra aqui porque o mesmo host apresentou URLs boas e ruins;
# essas são decididas por preflight individual da URL.
UNSTABLE_HOST_SUFFIXES = (
    'lenin.buzz',
    'hakunaymatata.com',
    'cocktail.beer',
)
DOWNLOAD_MARKER_RE = re.compile(r'(?i)(?:^|[^a-z0-9])(?:download(?:[ -]?only)?|baixar)(?:[^a-z0-9]|$)')
SIZE_LABEL_RE = re.compile(r'(?i)(?:\s*[|•\-]\s*)?\b\d+(?:[.,]\d+)?\s*(?:kb|mb|gb|tb|kib|mib|gib|tib)\b')


def _is_timeout_exception(exc):
    """Timeout é local à consulta; não deve bloquear outros títulos/episódios."""
    return 'timeout' in (exc.__class__.__name__ if exc is not None else '').lower()


class HdHubVodProvider(object):
    """Resolvedor HDHub pequeno e sem dependência do Kodi."""

    def __init__(self, requests_module=None, cache_api=None, logger=None, clock=None,
                 api_root=HDHUB_API_ROOT):
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.api_root = (api_root or HDHUB_API_ROOT).rstrip('/')
        self._preflight_cache = {}
        self._preflight_lock = Lock()
        # Usado estritamente para normalizar Stream Objects. Não consulta o
        # manifesto FrostStream nem usa o cache/rede dele neste provider.
        self._normalizer = _vod_engine.FrostStreamVodEngine(
            requests_module=self.requests, cache_api=None, clock=self.clock
        )

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def _valid_imdb(imdb_id):
        return bool(IMDB_RE.match((imdb_id or '').strip()))

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(HEALTH_NAMESPACE, HEALTH_KEY)
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return str(value.get('reason') or 'cooldown')
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                HEALTH_NAMESPACE, HEALTH_KEY,
                {'reason': str(reason or 'provider-indisponivel')},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    def _build_api_url(self, media_type, imdb_id, season=None, episode=None):
        imdb_id = (imdb_id or '').strip()
        if not self._valid_imdb(imdb_id):
            return ''
        if media_type == 'movie':
            return '{}/stream/movie/{}.json'.format(self.api_root, imdb_id)
        if media_type != 'series':
            return ''
        try:
            season_value = int(season)
            episode_value = int(episode)
        except Exception:
            return ''
        if season_value < 0 or episode_value < 1:
            return ''
        return '{}/stream/series/{}:{}:{}.json'.format(
            self.api_root, imdb_id, season_value, episode_value
        )

    @staticmethod
    def _raw_text(raw):
        if not isinstance(raw, dict):
            return ''
        return ' '.join(str(raw.get(key) or '') for key in ('name', 'title', 'description'))

    @classmethod
    def _is_download_entry(cls, raw):
        # O HDHub publica itens explicitamente chamados "Download" que no log
        # real resolveram para páginas/links gpdl e falharam com HTTP 400.
        return bool(DOWNLOAD_MARKER_RE.search(cls._raw_text(raw)))

    @staticmethod
    def _strip_size_label(value):
        text = str(value or '')
        text = SIZE_LABEL_RE.sub(' ', text)
        text = re.sub(r'\s*[|•]\s*(?=[|•]|$)', ' ', text)
        return re.sub(r'\s{2,}', ' ', text).strip(' |•-')

    @classmethod
    def _is_reproducible_item(cls, item):
        if not isinstance(item, dict):
            return False, 'normalizacao-invalida'
        kind = (item.get('__vod_kind') or '').strip().lower()
        target_type = (item.get('__vod_target_type') or '').strip().lower()

        # Torrent com magnet válido continua sendo uma fonte reproduzível porque
        # a Matrix já possui a ponte homologada para o PureTorrent.
        if kind == 'torrent':
            if item.get('__vod_torrent_magnet'):
                return True, 'torrent'
            return False, 'torrent-invalido'

        # URL HTTP apenas existir não basta. Esta checagem é estrutural; a
        # disponibilidade/assinatura real é decidida pelo preflight por URL.
        if target_type != 'url' or not item.get('__vod_playable'):
            return False, 'nao-reproduzivel'
        if kind not in DIRECT_PLAY_KINDS:
            return False, 'url-opaca'
        return True, kind

    @staticmethod
    def _host(value):
        try:
            return (urlparse(str(value or '')).hostname or '').lower().strip('.')
        except Exception:
            return ''

    @classmethod
    def _known_unstable_host(cls, item):
        host = cls._host(item.get('url') if isinstance(item, dict) else '')
        if not host:
            return False
        return any(host == suffix or host.endswith('.' + suffix) for suffix in UNSTABLE_HOST_SUFFIXES)

    @staticmethod
    def _parse_content_range(value):
        try:
            match = CONTENT_RANGE_RE.match(str(value or ''))
            if not match:
                return None
            start, end, total = [int(piece) for piece in match.groups()]
            if start != 0 or end < start or total <= end:
                return None
            return start, end, total
        except Exception:
            return None

    @staticmethod
    def _binary_media_kind(payload, content_type='', url=''):
        """Reconhece mídia pelos bytes antes de confiar no MIME do servidor."""
        data = bytes(payload or b'')
        lower_type = str(content_type or '').lower()
        lower_url = str(url or '').lower()
        stripped = data.lstrip()
        if stripped.startswith(b'#EXTM3U'):
            return 'hls'
        if b'<MPD' in stripped[:8192] and (stripped.startswith(b'<?xml') or stripped.startswith(b'<MPD')):
            return 'dash'
        if data.startswith(b'\x1a\x45\xdf\xa3'):
            return 'progressive'  # Matroska/WebM
        if len(data) >= 12 and data[4:8] == b'ftyp':
            return 'progressive'  # MP4/fMP4
        if data.startswith(b'FLV'):
            return 'progressive'
        if data.startswith(b'OggS'):
            return 'progressive'
        if len(data) >= 12 and data[:4] == b'RIFF' and data[8:12] in (b'AVI ', b'WAVE'):
            return 'progressive'
        if data and data[0] == 0x47:
            return 'progressive'  # MPEG-TS
        if '.m3u8' in lower_url or 'mpegurl' in lower_type:
            return 'hls' if stripped.startswith(b'#EXTM3U') else ''
        if '.mpd' in lower_url or 'dash+xml' in lower_type:
            return 'dash' if b'<MPD' in stripped[:8192] else ''
        if data and (lower_type.startswith('video/') or lower_type.startswith('audio/') or
                     'octet-stream' in lower_type or 'matroska' in lower_type):
            return 'progressive'
        return ''

    @staticmethod
    def _availability_from_http(status):
        try:
            status = int(status or 0)
        except Exception:
            status = 0
        if status in (401, 403):
            return 'bloqueada', 'http-{}'.format(status)
        if status == 429:
            return 'limitada', 'http-429'
        if status in (404, 408, 410, 425):
            return 'offline', 'http-{}'.format(status)
        if status >= 500 or status <= 0:
            return 'offline', 'http-{}'.format(status or 'erro')
        if status >= 400:
            return 'indeterminado', 'http-{}'.format(status)
        return 'online', 'http-{}'.format(status)

    def _preflight_cache_get(self, url):
        now = self.clock()
        key = str(url or '').strip()
        if not key:
            return None
        with self._preflight_lock:
            item = self._preflight_cache.get(key)
            if not item:
                return None
            if float(item.get('until') or 0) <= now:
                self._preflight_cache.pop(key, None)
                return None
            result = item.get('result')
            return dict(result) if isinstance(result, dict) else None

    def _preflight_cache_put(self, url, result):
        """Cacheia apenas prova estável; falha operacional deve poder recuperar."""
        key = str(url or '').strip()
        if not key or not isinstance(result, dict):
            return
        classification = str(result.get('classification') or '')
        if classification == 'online':
            ttl = PREFLIGHT_TTL_OK
        elif classification in ('incompativel', 'contrato'):
            ttl = PREFLIGHT_TTL_BAD
        else:
            # timeout/401/403/404/429/5xx não vira falso "não suportado" em cache.
            return
        with self._preflight_lock:
            self._preflight_cache[key] = {
                'result': dict(result),
                'until': self.clock() + ttl,
            }

    def _probe_media_candidate(self, item):
        """Separa capacidade do formato da disponibilidade atual do host."""
        if not isinstance(item, dict):
            return {'ok': False, 'classification': 'incompativel', 'reason': 'item-invalido', 'kind': ''}
        url = str(item.get('url') or '').strip()
        if not url:
            return {'ok': False, 'classification': 'incompativel', 'reason': 'url-vazia', 'kind': ''}

        cached = self._preflight_cache_get(url)
        if cached is not None:
            cached['cached'] = True
            return cached

        declared_kind = (item.get('__vod_kind') or '').strip().lower()
        known_degraded = self._known_unstable_host(item)
        response = None
        try:
            headers = dict(item.get('__vod_request_headers') or {})
            headers.setdefault('User-Agent', USER_AGENT)
            headers.setdefault('Referer', HDHUB_REFERER)
            headers.setdefault('Accept', '*/*')
            headers['Accept-Encoding'] = 'identity'
            headers['Connection'] = 'close'

            adaptive = declared_kind in ('hls', 'dash')
            if not adaptive:
                headers['Range'] = 'bytes=0-4095'

            response = self.requests.get(
                url,
                headers=headers,
                timeout=PREFLIGHT_TIMEOUT,
                allow_redirects=True,
                stream=True,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            response_headers = getattr(response, 'headers', {}) or {}
            content_type = str(response_headers.get('Content-Type', '') or '').lower()
            effective_url = str(getattr(response, 'url', '') or url)
            if status not in (200, 206):
                classification, reason = self._availability_from_http(status)
                return {
                    'ok': False, 'classification': classification, 'reason': reason,
                    'kind': declared_kind or 'unknown', 'host_degradado': known_degraded,
                }

            payload = b''
            try:
                limit = 65536 if adaptive else 4096
                chunks = []
                size = 0
                for chunk in response.iter_content(chunk_size=min(4096, limit)):
                    if not chunk:
                        continue
                    chunks.append(chunk)
                    size += len(chunk)
                    if size >= limit:
                        break
                payload = b''.join(chunks)[:limit]
            except Exception as exc:
                return {
                    'ok': False, 'classification': 'offline',
                    'reason': 'leitura-{}'.format(exc.__class__.__name__),
                    'kind': declared_kind or 'unknown', 'host_degradado': known_degraded,
                }

            detected_kind = self._binary_media_kind(payload, content_type, effective_url)
            if adaptive:
                if declared_kind == 'hls':
                    if detected_kind == 'hls':
                        result = {
                            'ok': True, 'classification': 'online', 'reason': 'hls-raiz-ok',
                            'kind': 'hls', 'host_degradado': known_degraded,
                        }
                        self._preflight_cache_put(url, result)
                        return result
                    # .m3u8 pode entregar TS/fMP4 direto; o proxy já suporta.
                    if detected_kind == 'progressive':
                        result = {
                            'ok': True, 'classification': 'online', 'reason': 'hls-midia-direta',
                            'kind': 'hls', 'host_degradado': known_degraded,
                        }
                        self._preflight_cache_put(url, result)
                        return result
                    result = {
                        'ok': False, 'classification': 'incompativel',
                        'reason': 'resposta-nao-hls', 'kind': 'hls',
                        'host_degradado': known_degraded,
                    }
                    self._preflight_cache_put(url, result)
                    return result
                if declared_kind == 'dash':
                    if detected_kind == 'dash':
                        result = {
                            'ok': True, 'classification': 'online', 'reason': 'dash-raiz-ok',
                            'kind': 'dash', 'host_degradado': known_degraded,
                        }
                        self._preflight_cache_put(url, result)
                        return result
                    result = {
                        'ok': False, 'classification': 'incompativel',
                        'reason': 'resposta-nao-dash', 'kind': 'dash',
                        'host_degradado': known_degraded,
                    }
                    self._preflight_cache_put(url, result)
                    return result

            parsed_range = self._parse_content_range(response_headers.get('Content-Range', ''))
            if status == 206 and parsed_range and detected_kind == 'progressive' and payload:
                result = {
                    'ok': True, 'classification': 'online', 'reason': 'range-ok',
                    'kind': 'progressive', 'host_degradado': known_degraded,
                }
                self._preflight_cache_put(url, result)
                return result

            if status in (200, 206) and detected_kind == 'progressive' and payload:
                # Formato é reproduzível, mas sem Range seguro a Matrix não deve
                # expor a fonte porque quebraria seek/Stop. Isso é contrato de
                # entrega incompatível, NÃO formato não suportado.
                result = {
                    'ok': False, 'classification': 'contrato',
                    'reason': 'sem-range-seguro', 'kind': 'progressive',
                    'host_degradado': known_degraded,
                }
                self._preflight_cache_put(url, result)
                return result

            result = {
                'ok': False, 'classification': 'incompativel',
                'reason': 'conteudo-nao-midia', 'kind': declared_kind or 'unknown',
                'host_degradado': known_degraded,
            }
            self._preflight_cache_put(url, result)
            return result
        except Exception as exc:
            return {
                'ok': False, 'classification': 'offline',
                'reason': 'erro-{}'.format(exc.__class__.__name__),
                'kind': declared_kind or 'unknown', 'host_degradado': known_degraded,
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def _preflight_media_batch(self, items):
        if not items:
            return [], {
                'online': 0, 'offline': 0, 'bloqueada': 0, 'limitada': 0,
                'contrato': 0, 'incompativel': 0, 'indeterminado': 0,
                'host-degradado': 0, 'nao-testada': 0,
            }
        selected = list(items[:PREFLIGHT_MAX_CANDIDATES])
        skipped = max(0, len(items) - len(selected))
        results = [None] * len(selected)
        workers = max(1, min(PREFLIGHT_WORKERS, len(selected)))
        with ThreadPoolExecutor(max_workers=workers) as executor:
            future_map = {
                executor.submit(self._probe_media_candidate, item): index
                for index, item in enumerate(selected)
            }
            for future in as_completed(future_map):
                index = future_map[future]
                try:
                    results[index] = future.result()
                except Exception as exc:
                    results[index] = {
                        'ok': False, 'classification': 'offline',
                        'reason': 'erro-{}'.format(exc.__class__.__name__),
                        'kind': '',
                    }

        approved = []
        stats = {
            'online': 0, 'offline': 0, 'bloqueada': 0, 'limitada': 0,
            'contrato': 0, 'incompativel': 0, 'indeterminado': 0,
            'host-degradado': 0, 'nao-testada': skipped,
        }
        for item, result in zip(selected, results):
            result = result or {'ok': False, 'classification': 'indeterminado', 'reason': 'sem-resultado'}
            classification = str(result.get('classification') or 'indeterminado')
            if classification not in stats:
                classification = 'indeterminado'
            stats[classification] += 1
            if result.get('host_degradado'):
                stats['host-degradado'] += 1
            if result.get('ok'):
                clean = dict(item)
                detected = str(result.get('kind') or '').lower()
                if detected in ('hls', 'dash', 'progressive'):
                    clean['__vod_kind'] = detected
                approved.append(clean)
        return approved, stats

    def _normalize_streams(self, raw_streams, imdb_id):
        if not isinstance(raw_streams, list):
            return [], 'streams-invalidos', ['streams-invalidos']

        media_candidates = []
        torrent_items = []
        seen = set()
        invalid = 0
        filtered_download = 0
        structural_incompatible = 0

        for index, raw in enumerate(raw_streams[:MAX_STREAMS]):
            if self._is_download_entry(raw):
                filtered_download += 1
                continue
            item, reason = self._normalizer._normalize_stream(raw, imdb_id, 90 + index)
            if item is None:
                invalid += 1
                continue
            item = dict(item)
            kind = (item.get('__vod_kind') or '').strip().lower()
            target_type = (item.get('__vod_target_type') or '').strip().lower()

            if kind == 'torrent':
                if not item.get('__vod_torrent_magnet'):
                    structural_incompatible += 1
                    continue
            elif target_type != 'url' or not item.get('__vod_playable'):
                structural_incompatible += 1
                continue
            elif kind not in ('hls', 'dash', 'progressive', 'unknown'):
                structural_incompatible += 1
                continue

            item['__vod_provider'] = HDHUB_PROVIDER_NAME
            item['__vod_provider_id'] = imdb_id
            item['__vod_provider_id_kind'] = 'imdb'
            item['__request_label'] = 'hdhub-imdb'
            item['__vod_size_label'] = ''
            for raw_key in ('__vod_raw_name', '__vod_raw_title', '__vod_raw_description'):
                item[raw_key] = self._strip_size_label(item.get(raw_key, ''))
            item['__request_rank'] = 90 + index
            headers = dict(item.get('__vod_request_headers') or {})
            headers.setdefault('User-Agent', USER_AGENT)
            headers.setdefault('Referer', HDHUB_REFERER)
            item['__vod_request_headers'] = headers

            dedupe_key = (
                item.get('__vod_target_type', ''),
                item.get('url') or item.get('__vod_target_value', ''),
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)

            if kind == 'torrent':
                torrent_items.append(item)
            else:
                media_candidates.append(item)

        verified, preflight = self._preflight_media_batch(media_candidates)
        normalized = verified + torrent_items
        online_total = int(preflight.get('online', 0)) + len(torrent_items)
        audit = [
            'raw={}'.format(min(len(raw_streams), MAX_STREAMS)),
            'online={}'.format(online_total),
            'offline={}'.format(preflight.get('offline', 0)),
            'bloqueado={}'.format(preflight.get('bloqueada', 0)),
            'limitado={}'.format(preflight.get('limitada', 0)),
            'contrato-incompativel={}'.format(preflight.get('contrato', 0)),
            'incompativel={}'.format(preflight.get('incompativel', 0) + structural_incompatible + invalid),
            'nao-testada={}'.format(preflight.get('nao-testada', 0)),
        ]
        if preflight.get('host-degradado'):
            audit.append('host-degradado={}'.format(preflight.get('host-degradado', 0)))
        if filtered_download:
            audit.append('download={}'.format(filtered_download))

        if (filtered_download or structural_incompatible or invalid or media_candidates or torrent_items):
            self._log(
                ('VOD HDHub perícia CAP/DISP: raw={} online={} offline={} bloqueada={} '
                 'limitada={} contrato={} incompativel={} download={} '
                 'host-degradado={} nao-testada={}.').format(
                    min(len(raw_streams), MAX_STREAMS), online_total,
                    preflight.get('offline', 0), preflight.get('bloqueada', 0),
                    preflight.get('limitada', 0), preflight.get('contrato', 0),
                    preflight.get('incompativel', 0) + structural_incompatible + invalid,
                    filtered_download, preflight.get('host-degradado', 0),
                    preflight.get('nao-testada', 0),
                ),
                1,
            )

        if normalized:
            return normalized, 'ok', audit
        if (preflight.get('offline', 0) or preflight.get('bloqueada', 0) or
                preflight.get('limitada', 0) or preflight.get('indeterminado', 0)):
            return [], 'supported-offline', audit
        if preflight.get('nao-testada', 0):
            return [], 'indeterminado-nao-testado', audit
        if (preflight.get('contrato', 0) or preflight.get('incompativel', 0) or
                structural_incompatible or invalid):
            return [], 'sem-stream-compativel', audit
        if filtered_download:
            return [], 'sem-stream-compativel', audit
        return [], 'sem-stream', audit

    def resolve(self, media_type, imdb_id, season=None, episode=None):
        api_url = self._build_api_url(media_type, imdb_id, season, episode)
        if not api_url:
            return {'streams': [], 'reason': 'IMDb/episódio inválido ou ausente', 'audit': ['sem-id']}
        if self.requests is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}

        cooldown = self._cooldown_state()
        if cooldown:
            self._log('VOD HDHub em cooldown temporário: {}.'.format(cooldown), 1)
            return {'streams': [], 'reason': 'HDHub temporariamente em cooldown', 'audit': ['cooldown']}

        response = None
        try:
            response = self.requests.get(
                api_url,
                headers={
                    'User-Agent': USER_AGENT,
                    'Accept': 'application/json, */*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Referer': HDHUB_REFERER,
                },
                timeout=REQUEST_TIMEOUT,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status != 200:
                if status == 429:
                    self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
                elif status >= 500 or status <= 0:
                    self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
                return {
                    'streams': [],
                    'reason': 'HDHub respondeu HTTP {}'.format(status or 'desconhecido'),
                    'audit': ['http-{}'.format(status or 'erro')],
                }
            try:
                payload = response.json()
            except Exception:
                return {'streams': [], 'reason': 'resposta JSON inválida', 'audit': ['json-invalido']}
            if not isinstance(payload, dict):
                return {'streams': [], 'reason': 'resposta fora do contrato', 'audit': ['payload-invalido']}
            streams, outcome, audit = self._normalize_streams(payload.get('streams'), (imdb_id or '').strip())
            if not streams:
                if outcome == 'supported-offline':
                    reason = 'fontes HDHub suportáveis, porém indisponíveis nesta consulta'
                elif outcome == 'sem-stream-compativel':
                    reason = 'fontes HDHub presentes, mas sem entrega compatível agora'
                elif outcome == 'indeterminado-nao-testado':
                    reason = 'fontes HDHub presentes, mas não foi possível periciar todas nesta consulta'
                else:
                    reason = 'HDHub sem fonte para este título'
                return {'streams': [], 'reason': reason, 'audit': list(audit or []) + [outcome]}
            self._log('VOD HDHub resolveu {} por IMDb: {} fontes.'.format(media_type, len(streams)), 1)
            return {'streams': streams, 'reason': '', 'audit': list(audit or []) + ['imdb={}'.format(len(streams))]}
        except Exception as exc:
            if not _is_timeout_exception(exc):
                self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('VOD HDHub indisponível nesta consulta: {}.'.format(exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': 'HDHub indisponível nesta consulta',
                'audit': ['erro-rede:{}'.format(exc.__class__.__name__)],
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


_DEFAULT_PROVIDER = None


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        def _kodi_log(message, level=1):
            try:
                from resources.lib.common import log, log_debug
                log('[VOD Extra] {}'.format(message), level=level)
                log_debug(message, component='HDHub')
            except Exception:
                pass
        _DEFAULT_PROVIDER = HdHubVodProvider(logger=_kodi_log)
    return _DEFAULT_PROVIDER


def reset_default_provider_for_tests():
    global _DEFAULT_PROVIDER
    _DEFAULT_PROVIDER = None
