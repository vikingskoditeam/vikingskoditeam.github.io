# -*- coding: utf-8 -*-
"""Atualizador interno do OnePlay Matrix.

Mantém dois contratos complementares:

* hotfix cumulativo de arquivos Python dentro da mesma versão oficial;
* promoção integral de versão quando o painel publica um ``addon.xml`` maior.

Hotfixes continuam transacionais por arquivo. Promoções de versão baixam o ZIP
completo, validam addon_id/versão/SHA-256/caminhos, preparam tudo em staging,
criam backup integral do addon e só então sincronizam a instalação. Em falha,
o conjunto anterior é restaurado. A troca oficial de versão exige reinício do
Kodi para recarregar service.py/addon.xml de forma limpa.
"""
from __future__ import unicode_literals

import ast
import hashlib
import json
import os
import re
import shutil
import ssl
import time
import zipfile
from io import BytesIO
import xml.etree.ElementTree as ET
from urllib.parse import quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

try:
    import xbmc
    import xbmcaddon
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover - útil apenas para teste fora do Kodi
    xbmc = xbmcaddon = xbmcgui = xbmcvfs = None

ADDON_ID = 'plugin.video.OnePlay.Matrix'
BASE_URL = 'https://addon.oneplayhd.com/'
API_URL = BASE_URL + 'api.php'
MANIFEST_URL = BASE_URL + 'manifest.json'  # fallback legado
MANIFEST_MAX_BYTES = 128 * 1024
FILE_MAX_BYTES = 2 * 1024 * 1024
TOTAL_MAX_BYTES = 12 * 1024 * 1024
MAX_FILES = 64
PACKAGE_MAX_BYTES = 64 * 1024 * 1024
PACKAGE_MAX_FILES = 2048
PACKAGE_UNCOMPRESSED_MAX = 128 * 1024 * 1024
NETWORK_TIMEOUT = 5
USER_AGENT = 'Mozilla/5.0 (Kodi; OnePlay Matrix Updater) AppleWebKit/537.36 Safari/537.36'
CLIENT_HEADER = 'OnePlay-Matrix-Updater/2.0'
RUNTIME_GUARD_STALE_SECS = 180.0


def _addon():
    if xbmcaddon is None:
        raise RuntimeError('Kodi indisponível')
    return xbmcaddon.Addon(ADDON_ID)


def _translate(path):
    if xbmcvfs is not None:
        try:
            return xbmcvfs.translatePath(path)
        except Exception:
            pass
    return path


def _addon_path():
    return os.path.realpath(_translate(_addon().getAddonInfo('path')))


def _profile_path():
    return os.path.realpath(_translate(_addon().getAddonInfo('profile')))


def _addon_version():
    return str(_addon().getAddonInfo('version') or '').strip()


def _runtime_update_block_reason():
    """Retorna o motivo que impede uma atualização segura neste instante.

    ``isPlaying()`` cobre reprodução já iniciada. Os arquivos de guarda do
    OnePlay Live cobrem a janela anterior ao A/V, quando o canal ainda está em
    bootstrap/preflight e o Kodi pode continuar reportando player ocioso.
    Guardas órfãos antigos não bloqueiam indefinidamente uma atualização.
    """
    if xbmc is not None:
        try:
            player = xbmc.Player()
            for method_name in ('isPlaying', 'isPlayingVideo', 'isPlayingAudio'):
                try:
                    method = getattr(player, method_name, None)
                    if method is not None and bool(method()):
                        return 'reproducao_ativa'
                except Exception:
                    pass
        except Exception:
            pass

    if xbmcaddon is None:
        return ''
    try:
        profile = _profile_path()
    except Exception:
        return ''
    now = time.time()
    guards = (
        ('oneplay_live_startup.lock', 'live_startup'),
        ('oneplay_live_session.json', 'live_session'),
    )
    for filename, reason in guards:
        path = os.path.join(profile, filename)
        try:
            if not os.path.isfile(path):
                continue
            age = max(0.0, now - os.path.getmtime(path))
            if age <= RUNTIME_GUARD_STALE_SECS:
                return reason
        except Exception:
            # Em dúvida transitória sobre um guarda recém-detectado, prefira
            # preservar a sessão e tentar a atualização mais tarde.
            try:
                if os.path.exists(path):
                    return reason
            except Exception:
                pass
    return ''


def _deferred_runtime_result(state, now, revision=0, reason=''):
    state.update({
        'last_check': int(now),
        'last_result': 'adiado_atividade',
        'last_runtime_block': str(reason or 'atividade_kodi'),
    })
    state.pop('last_error', None)
    try:
        _save_state(state)
    except Exception:
        pass
    _log('atualização adiada por atividade runtime motivo=%s revision=%s' % (
        str(reason or 'atividade_kodi'), int(revision or 0) or '?'))
    return {'status': 'adiado_atividade', 'revision': int(revision or 0), 'reason': str(reason or 'atividade_kodi')}


def _log(message, warning=False):
    text = '[OnePlayHotfix] %s' % message
    if xbmc is not None:
        try:
            xbmc.log(text, xbmc.LOGWARNING if warning else xbmc.LOGINFO)
            return
        except Exception:
            pass
    try:
        print(text)
    except Exception:
        pass


def _notify(title, message, error=False):
    if xbmcgui is None:
        return
    try:
        icon = xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_INFO
        xbmcgui.Dialog().notification(title, message, icon, 7000)
    except Exception:
        pass


def _atomic_json(path, obj):
    folder = os.path.dirname(path)
    os.makedirs(folder, exist_ok=True)
    temp = path + '.tmp'
    raw = json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True).encode('utf-8')
    with open(temp, 'wb') as fh:
        fh.write(raw)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except Exception:
            pass
    os.replace(temp, path)


def _read_json(path, max_bytes=MANIFEST_MAX_BYTES):
    try:
        with open(path, 'rb') as fh:
            raw = fh.read(max_bytes + 1)
        if len(raw) > max_bytes:
            return None
        obj = json.loads(raw.decode('utf-8'))
        return obj if isinstance(obj, dict) else None
    except Exception:
        return None


def _sha256_bytes(data):
    return hashlib.sha256(data).hexdigest().lower()


def _sha256_file(path):
    h = hashlib.sha256()
    with open(path, 'rb') as fh:
        while True:
            chunk = fh.read(128 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest().lower()


def _fetch_bytes(url, limit, timeout=NETWORK_TIMEOUT):
    if not str(url or '').lower().startswith('https://'):
        raise ValueError('somente HTTPS é permitido')
    headers = {
        'User-Agent': USER_AGENT,
        'X-OnePlay-Client': CLIENT_HEADER,
        'Accept': 'application/json,text/plain,*/*;q=0.8',
        'Referer': BASE_URL,
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache',
    }
    req = Request(url, headers=headers, method='GET')
    context = ssl.create_default_context()
    with urlopen(req, timeout=timeout, context=context) as response:
        data = response.read(int(limit) + 1)
    if len(data) > int(limit):
        raise ValueError('download excedeu limite')
    return data


def _safe_relative_py(path):
    value = str(path or '').replace('\\', '/').strip().lstrip('/')
    if not value or not value.endswith('.py'):
        return ''
    parts = value.split('/')
    if any(part in ('', '.', '..') for part in parts):
        return ''
    # Impede qualquer tentativa de atualizar artefatos fora do código Python.
    if value.lower() == 'addon.xml' or value.lower().endswith('/addon.xml'):
        return ''
    return '/'.join(parts)


def _target_path(relative_path):
    root = _addon_path()
    target = os.path.realpath(os.path.join(root, relative_path.replace('/', os.sep)))
    prefix = root.rstrip(os.sep) + os.sep
    if not target.startswith(prefix):
        raise ValueError('caminho fora do addon')
    return target


def _parse_python_38(data, filename):
    try:
        text = data.decode('utf-8-sig')
    except Exception as exc:
        raise ValueError('arquivo Python não é UTF-8: %s' % exc)
    # Em Pythons novos, força gramática 3.8. Em Python 3.8, usa o formato de
    # feature_version aceito por aquela runtime; em último caso compila local.
    last = None
    for feature in ((3, 8), 8, None):
        try:
            if feature is None:
                ast.parse(text, filename=filename, mode='exec')
            else:
                ast.parse(text, filename=filename, mode='exec', feature_version=feature)
            return True
        except TypeError as exc:
            last = exc
            continue
        except SyntaxError:
            raise
    if last:
        compile(text, filename, 'exec')
    return True


def _state_file():
    return os.path.join(_profile_path(), 'oneplay_hotfix', 'state.json')


def _load_state():
    state = _read_json(_state_file(), max_bytes=256 * 1024)
    return state if isinstance(state, dict) else {}


def _save_state(state):
    _atomic_json(_state_file(), state)


def _numeric_version_tuple(value):
    parts = [int(x) for x in re.findall(r'\d+', str(value or ''))]
    if not parts:
        return ()
    return tuple((parts + [0] * 8)[:8])


def _compare_versions(left, right):
    a = _numeric_version_tuple(left)
    b = _numeric_version_tuple(right)
    if not a or not b:
        return (str(left) > str(right)) - (str(left) < str(right))
    return (a > b) - (a < b)


def _addon_xml_version_on_disk():
    try:
        path = os.path.join(_addon_path(), 'addon.xml')
        root = ET.parse(path).getroot()
        if str(root.attrib.get('id') or '').strip() != ADDON_ID:
            return ''
        return str(root.attrib.get('version') or '').strip()
    except Exception:
        return ''


def _validate_version_package_meta(manifest, installed_version):
    target = str(manifest.get('target_version') or '').strip()
    if not target or _compare_versions(target, installed_version) <= 0:
        raise ValueError('transição de versão não é progressiva')
    raw = manifest.get('version_package')
    if not isinstance(raw, dict):
        raise ValueError('manifesto não contém pacote integral da nova versão')
    if str(raw.get('version') or '').strip() != target:
        raise ValueError('versão do pacote integral não confere')
    sha = str(raw.get('sha256') or '').strip().lower()
    if not re_full_sha256(sha):
        raise ValueError('SHA-256 do pacote integral inválido')
    size = int(raw.get('size') or 0)
    if size <= 0 or size > PACKAGE_MAX_BYTES:
        raise ValueError('tamanho do pacote integral inválido')
    package_revision = int(raw.get('package_revision') or 0)
    revision = int(manifest.get('revision') or 0)
    if package_revision <= 0 or package_revision > revision:
        raise ValueError('revision do pacote integral inválida')
    endpoint = str(raw.get('endpoint') or 'package.php').strip()
    if endpoint != 'package.php':
        raise ValueError('endpoint do pacote integral não autorizado')
    return {'version': target, 'sha256': sha, 'size': size, 'package_revision': package_revision}


def _package_url(meta):
    return BASE_URL + 'package.php?v=%s&k=%s' % (quote(meta['version'], safe=''), meta['sha256'])


def _fetch_version_package(meta):
    data = _fetch_bytes(_package_url(meta), min(PACKAGE_MAX_BYTES, int(meta['size']) + 1), timeout=max(NETWORK_TIMEOUT, 12))
    if len(data) != int(meta['size']):
        raise ValueError('tamanho divergente no pacote integral')
    if _sha256_bytes(data) != meta['sha256']:
        raise ValueError('SHA-256 divergente no pacote integral')
    _log('download pacote versão=%s bytes=%d' % (meta['version'], len(data)))
    return data


def _safe_package_relative(name):
    value = str(name or '').replace('\\', '/').strip()
    if not value or value.startswith('/') or re.match(r'^[A-Za-z]:/', value):
        return ''
    parts = value.split('/')
    if any(part in ('', '.', '..') for part in parts):
        return ''
    return '/'.join(parts)


def _prepare_version_package(data, meta, revision):
    stage_root = os.path.join(_profile_path(), 'oneplay_hotfix', 'version_stage', '%d-%s' % (int(revision), meta['sha256'][:12]))
    if os.path.isdir(stage_root):
        shutil.rmtree(stage_root, ignore_errors=True)
    addon_stage = os.path.join(stage_root, 'addon')
    os.makedirs(addon_stage, exist_ok=True)
    files = {}
    addon_candidates = []
    total = 0
    with zipfile.ZipFile(BytesIO(data), 'r') as zf:
        infos = zf.infolist()
        if len(infos) > PACKAGE_MAX_FILES:
            raise ValueError('pacote integral excedeu limite de entradas')
        for info in infos:
            raw_name = str(info.filename or '').replace('\\', '/')
            if not raw_name:
                continue
            # Bit UNIX de symlink.
            mode = (int(info.external_attr) >> 16) & 0o170000
            if mode == 0o120000:
                raise ValueError('pacote integral contém symlink')
            if int(info.flag_bits) & 0x1:
                raise ValueError('pacote integral criptografado não é permitido')
            if raw_name == 'addon.xml' or raw_name.endswith('/addon.xml'):
                addon_candidates.append(raw_name)
        if len(addon_candidates) != 1:
            raise ValueError('pacote integral deve conter exatamente um addon.xml')
        addon_entry = addon_candidates[0]
        root_prefix = addon_entry[:-len('addon.xml')]
        for info in infos:
            raw_name = str(info.filename or '').replace('\\', '/')
            if not raw_name:
                continue
            if not raw_name.startswith(root_prefix):
                raise ValueError('arquivo fora da raiz do addon no pacote integral')
            rel_raw = raw_name[len(root_prefix):]
            if not rel_raw or rel_raw.endswith('/'):
                continue
            rel = _safe_package_relative(rel_raw)
            if not rel or rel in files:
                raise ValueError('caminho inválido/duplicado no pacote integral')
            total += int(info.file_size)
            if total > PACKAGE_UNCOMPRESSED_MAX:
                raise ValueError('pacote integral excedeu limite descompactado')
            blob = zf.read(info)
            if len(blob) != int(info.file_size):
                raise ValueError('leitura incompleta no pacote integral')
            target = os.path.join(addon_stage, rel.replace('/', os.sep))
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with open(target, 'wb') as fh:
                fh.write(blob)
            files[rel] = {'sha256': _sha256_bytes(blob), 'size': len(blob)}
    addon_xml = os.path.join(addon_stage, 'addon.xml')
    if not os.path.isfile(addon_xml):
        raise ValueError('addon.xml ausente após staging')
    try:
        root = ET.parse(addon_xml).getroot()
    except Exception as exc:
        raise ValueError('addon.xml inválido: %s' % exc)
    if str(root.attrib.get('id') or '').strip() != ADDON_ID:
        raise ValueError('addon_id do pacote integral não confere')
    version = str(root.attrib.get('version') or '').strip()
    if version != meta['version']:
        raise ValueError('versão do addon.xml não confere com manifesto')
    if 'resources/lib/hotfix_updater.py' not in files:
        raise ValueError('nova versão não preserva hotfix_updater.py')
    return stage_root, addon_stage, files


def _copy_tree_exact(src, dst):
    if os.path.isdir(dst):
        shutil.rmtree(dst, ignore_errors=True)
    os.makedirs(dst, exist_ok=True)
    for base, dirs, names in os.walk(src):
        rel = os.path.relpath(base, src)
        out_base = dst if rel == '.' else os.path.join(dst, rel)
        os.makedirs(out_base, exist_ok=True)
        for name in names:
            source = os.path.join(base, name)
            target = os.path.join(out_base, name)
            if os.path.isfile(source):
                shutil.copy2(source, target)


def _clear_addon_contents(root):
    for name in os.listdir(root):
        path = os.path.join(root, name)
        try:
            if os.path.isdir(path) and not os.path.islink(path):
                shutil.rmtree(path)
            else:
                os.remove(path)
        except FileNotFoundError:
            pass


def _apply_version_stage(addon_stage, files, meta, revision):
    addon_root = _addon_path()
    backup_root = os.path.join(_profile_path(), 'oneplay_hotfix', 'version_backups', '%d-%s' % (int(revision), meta['version']))
    backup_addon = os.path.join(backup_root, 'addon')
    os.makedirs(os.path.dirname(backup_root), exist_ok=True)
    _copy_tree_exact(addon_root, backup_addon)
    desired = set(files)
    try:
        # Copia addon.xml por último: o marcador oficial de versão é o commit final.
        ordered = sorted([p for p in desired if p != 'addon.xml']) + ['addon.xml']
        for rel in ordered:
            source = os.path.join(addon_stage, rel.replace('/', os.sep))
            target = os.path.realpath(os.path.join(addon_root, rel.replace('/', os.sep)))
            prefix = addon_root.rstrip(os.sep) + os.sep
            if not target.startswith(prefix):
                raise ValueError('caminho fora do addon durante promoção')
            os.makedirs(os.path.dirname(target), exist_ok=True)
            temp = target + '.oneplay-version-new'
            shutil.copyfile(source, temp)
            if _sha256_file(temp) != files[rel]['sha256']:
                raise ValueError('verificação final falhou em %s' % rel)
            os.replace(temp, target)
        # Remove arquivos antigos que não pertencem ao novo pacote.
        for base, dirs, names in os.walk(addon_root, topdown=False):
            for name in names:
                path = os.path.join(base, name)
                rel = os.path.relpath(path, addon_root).replace(os.sep, '/')
                if rel not in desired:
                    try:
                        os.remove(path)
                    except FileNotFoundError:
                        pass
            for name in dirs:
                path = os.path.join(base, name)
                try:
                    if not os.listdir(path):
                        os.rmdir(path)
                except Exception:
                    pass
        # Confirma todo o pacote após sincronização.
        for rel, expected in files.items():
            target = os.path.join(addon_root, rel.replace('/', os.sep))
            if not os.path.isfile(target) or os.path.getsize(target) != int(expected['size']) or _sha256_file(target) != expected['sha256']:
                raise ValueError('estado final da nova versão divergiu em %s' % rel)
        if _addon_xml_version_on_disk() != meta['version']:
            raise ValueError('addon.xml final não assumiu a nova versão')
        return backup_root
    except Exception:
        try:
            _clear_addon_contents(addon_root)
            for base, dirs, names in os.walk(backup_addon):
                rel = os.path.relpath(base, backup_addon)
                out_base = addon_root if rel == '.' else os.path.join(addon_root, rel)
                os.makedirs(out_base, exist_ok=True)
                for name in names:
                    shutil.copy2(os.path.join(base, name), os.path.join(out_base, name))
        except Exception as restore_exc:
            _log('restauração integral falhou: %s' % restore_exc, True)
        raise


def _cleanup_version_backups(keep=2):
    root = os.path.join(_profile_path(), 'oneplay_hotfix', 'version_backups')
    try:
        names = [n for n in os.listdir(root) if os.path.isdir(os.path.join(root, n))]
        names.sort(key=lambda n: os.path.getmtime(os.path.join(root, n)), reverse=True)
        for name in names[int(keep):]:
            shutil.rmtree(os.path.join(root, name), ignore_errors=True)
    except Exception:
        pass


def _apply_version_package(manifest, meta, state, stored_generation, manifest_generation, now, notify):
    target = meta['version']
    if (str(state.get('pending_version_restart') or '') == target and
            str(state.get('version_package_sha256') or '').lower() == meta['sha256'] and
            _addon_xml_version_on_disk() == target):
        state['last_check'] = now
        state['last_result'] = 'versao_aguarda_reinicio'
        _save_state(state)
        _log('nova versão %s já gravada; aguardando reinício do Kodi' % target)
        return {'status': 'versao_aguarda_reinicio', 'revision': int(manifest['revision']), 'version': target}
    runtime_reason = _runtime_update_block_reason()
    if runtime_reason:
        return _deferred_runtime_result(state, now, int(manifest.get('revision') or 0), runtime_reason)
    data = _fetch_version_package(meta)
    stage_root = None
    try:
        stage_root, addon_stage, files = _prepare_version_package(data, meta, int(manifest['revision']))
        runtime_reason = _runtime_update_block_reason()
        if runtime_reason:
            return _deferred_runtime_result(state, now, int(manifest.get('revision') or 0), runtime_reason)
        backup_root = _apply_version_stage(addon_stage, files, meta, int(manifest['revision']))
    finally:
        if stage_root:
            shutil.rmtree(stage_root, ignore_errors=True)
    if manifest_generation:
        _remember_generation_change(state, stored_generation, manifest_generation)
    state.update({
        'applied_revision': int(meta['package_revision']),
        'manifest_state_sha256': '',
        'last_check': now,
        'last_success': now,
        'last_result': 'versao_aplicada',
        'pending_version_restart': target,
        'version_package_sha256': meta['sha256'],
        'version_package_revision': int(meta['package_revision']),
        'version_backup': backup_root,
        'target_version': target,
        'contract': 'full-addon-version-v1',
    })
    state.pop('last_error', None)
    _save_state(state)
    _cleanup_version_backups(2)
    try:
        if xbmc is not None:
            xbmc.executebuiltin('UpdateLocalAddons')
    except Exception:
        pass
    _log('nova versão aplicada version=%s package_revision=%d; reinício obrigatório' % (target, int(meta['package_revision'])))
    if notify:
        _notify('OnePlay', 'Nova versão %s instalada. Reinicie o Kodi para concluir.' % target)
    return {'status': 'versao_aplicada', 'revision': int(manifest['revision']), 'version': target, 'package_revision': int(meta['package_revision'])}


def _manifest():
    stamp = int(time.time())
    last_exc = None
    raw = None
    installed = _addon_version()
    urls = (
        API_URL + '?op=manifest&v=%s&_t=%d' % (quote(installed, safe=''), stamp),
        MANIFEST_URL + '?_t=%d' % stamp,
    )
    for url in urls:
        try:
            raw = _fetch_bytes(url, MANIFEST_MAX_BYTES)
            break
        except Exception as exc:
            last_exc = exc
    if raw is None:
        raise last_exc if last_exc is not None else RuntimeError('manifesto indisponível')
    obj = json.loads(raw.decode('utf-8'))
    if not isinstance(obj, dict):
        raise ValueError('manifesto inválido')
    if int(obj.get('schema') or 0) != 1:
        raise ValueError('schema de manifesto não suportado')
    if str(obj.get('addon_id') or '') != ADDON_ID:
        raise ValueError('addon_id do manifesto não confere')
    target_version = str(obj.get('target_version') or '').strip()
    if not target_version:
        raise ValueError('manifesto sem versão alvo')
    version_cmp = _compare_versions(target_version, installed)
    # Cliente mais novo que o painel é um estado válido (ex.: repositório Kodi
    # atualizou primeiro). Não tente downgrade e não exija pacote de promoção.
    if version_cmp > 0:
        _validate_version_package_meta(obj, installed)
    revision = int(obj.get('revision') or 0)
    if revision <= 0:
        raise ValueError('revision inválida')
    generation = str(obj.get('channel_generation') or '').strip().lower()
    if generation and (len(generation) != 32 or any(ch not in '0123456789abcdef' for ch in generation)):
        raise ValueError('channel_generation inválida')
    files = obj.get('files')
    if not isinstance(files, list) or len(files) > MAX_FILES:
        raise ValueError('lista de arquivos inválida')
    return obj


def _normalize_entries(manifest):
    entries = []
    total_expected = 0
    seen = set()
    for raw in manifest.get('files') or []:
        if not isinstance(raw, dict):
            raise ValueError('entrada de arquivo inválida')
        rel = _safe_relative_py(raw.get('path'))
        if not rel or rel in seen:
            raise ValueError('caminho de hotfix inválido/duplicado')
        seen.add(rel)
        sha = str(raw.get('sha256') or '').strip().lower()
        if not re_full_sha256(sha):
            raise ValueError('SHA-256 inválido em %s' % rel)
        size = int(raw.get('size') or 0)
        if size <= 0 or size > FILE_MAX_BYTES:
            raise ValueError('tamanho inválido em %s' % rel)
        total_expected += size
        if total_expected > TOTAL_MAX_BYTES:
            raise ValueError('hotfix excedeu limite total')
        entries.append({'path': rel, 'sha256': sha, 'size': size})
    return entries




def _manifest_state_sha256(manifest, entries=None):
    """Calcula a identidade estável do estado Python publicado."""
    if entries is None:
        entries = _normalize_entries(manifest)
    contract = str(manifest.get('contract') or 'legacy-patch').strip()
    target_version = str(manifest.get('target_version') or '').strip()
    lines = [ADDON_ID, target_version, contract]
    for entry in sorted(entries, key=lambda row: row['path']):
        lines.append('%s\t%s\t%d' % (entry['path'], entry['sha256'], int(entry['size'])))
    computed = _sha256_bytes(('\n'.join(lines) + '\n').encode('utf-8'))
    declared = str(manifest.get('state_sha256') or '').strip().lower()
    if declared:
        if not re_full_sha256(declared):
            raise ValueError('state_sha256 inválido')
        if declared != computed:
            raise ValueError('state_sha256 divergente do manifesto')
    return computed


def re_full_sha256(value):
    if len(value) != 64:
        return False
    try:
        int(value, 16)
        return True
    except Exception:
        return False


def _transport_error(exc):
    if isinstance(exc, HTTPError):
        return 'HTTP %s' % getattr(exc, 'code', '?')
    if isinstance(exc, URLError):
        return 'rede: %s' % getattr(exc, 'reason', exc)
    return '%s: %s' % (exc.__class__.__name__, exc)


def _file_candidates(entry, revision):
    """Rotas em ordem de robustez. As três primeiras não expõem caminho .py.

    O identificador k é o próprio SHA-256 já autenticado pelo manifesto. Isso
    evita encoded slash/path de .py na URL pública, que alguns WAF/ModSecurity
    bloqueiam com 403 mesmo quando o manifesto é permitido.
    """
    relative_path = entry['path']
    sha = entry['sha256']
    encoded_path = quote(relative_path, safe='')
    legacy = '/'.join(quote(part, safe='') for part in relative_path.split('/'))
    rev = int(revision)
    return (
        ('payload', BASE_URL + 'payload.php?r=%d&k=%s' % (rev, sha)),
        ('api-key', API_URL + '?op=file&r=%d&k=%s' % (rev, sha)),
        ('download-key', BASE_URL + 'download.php?r=%d&k=%s' % (rev, sha)),
        ('api-path-legacy', API_URL + '?op=file&r=%d&path=%s' % (rev, encoded_path)),
        ('files-legacy', BASE_URL + 'files/' + legacy + '?r=%d' % rev),
    )


def _fetch_hotfix_file(entry, revision, limit):
    errors = []
    for label, url in _file_candidates(entry, revision):
        try:
            data = _fetch_bytes(url, limit)
            _log('download arquivo=%s via=%s bytes=%d' % (entry['path'], label, len(data)))
            return data
        except Exception as exc:
            errors.append('%s=%s' % (label, _transport_error(exc)))
    raise RuntimeError('transporte falhou em %s [%s]' % (entry['path'], '; '.join(errors)))


def _entries_needing_update(entries):
    pending = []
    for entry in entries:
        target = _target_path(entry['path'])
        try:
            if os.path.isfile(target) and _sha256_file(target) == entry['sha256']:
                continue
        except Exception:
            pass
        pending.append(entry)
    return pending


def _stage_entries(entries, revision):
    root = os.path.join(_profile_path(), 'oneplay_hotfix', 'stage', str(revision))
    if os.path.isdir(root):
        shutil.rmtree(root, ignore_errors=True)
    os.makedirs(root, exist_ok=True)
    staged = []
    total = 0
    for entry in entries:
        rel = entry['path']
        data = _fetch_hotfix_file(entry, revision, min(FILE_MAX_BYTES, entry['size'] + 1))
        total += len(data)
        if total > TOTAL_MAX_BYTES:
            raise ValueError('download total excedeu limite')
        if len(data) != entry['size']:
            raise ValueError('tamanho divergente em %s' % rel)
        if _sha256_bytes(data) != entry['sha256']:
            raise ValueError('SHA-256 divergente em %s' % rel)
        _parse_python_38(data, rel)
        stage_path = os.path.join(root, rel.replace('/', os.sep))
        os.makedirs(os.path.dirname(stage_path), exist_ok=True)
        with open(stage_path, 'wb') as fh:
            fh.write(data)
            fh.flush()
            try:
                os.fsync(fh.fileno())
            except Exception:
                pass
        staged.append((entry, stage_path))
    return root, staged


def _all_local_hashes_match(entries):
    for entry in entries:
        target = _target_path(entry['path'])
        if not os.path.isfile(target):
            return False
        try:
            if _sha256_file(target) != entry['sha256']:
                return False
        except Exception:
            return False
    return True


def _apply_staged(staged, revision):
    backup_root = os.path.join(_profile_path(), 'oneplay_hotfix', 'backups', str(revision))
    os.makedirs(backup_root, exist_ok=True)
    applied = []
    try:
        for entry, stage_path in staged:
            rel = entry['path']
            target = _target_path(rel)
            existed = os.path.isfile(target)
            backup = os.path.join(backup_root, rel.replace('/', os.sep))
            if existed:
                os.makedirs(os.path.dirname(backup), exist_ok=True)
                shutil.copy2(target, backup)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            temp_target = target + '.oneplay-hotfix-new'
            shutil.copyfile(stage_path, temp_target)
            if _sha256_file(temp_target) != entry['sha256']:
                raise ValueError('verificação final falhou em %s' % rel)
            os.replace(temp_target, target)
            applied.append((rel, target, backup, existed))
        return backup_root, [x[0] for x in applied]
    except Exception:
        for rel, target, backup, existed in reversed(applied):
            try:
                if existed and os.path.isfile(backup):
                    temp_restore = target + '.oneplay-hotfix-restore'
                    shutil.copyfile(backup, temp_restore)
                    os.replace(temp_restore, target)
                elif not existed and os.path.isfile(target):
                    os.remove(target)
            except Exception as rollback_exc:
                _log('rollback falhou em %s: %s' % (rel, rollback_exc), True)
        raise


def _cleanup_old_backups(keep=3):
    root = os.path.join(_profile_path(), 'oneplay_hotfix', 'backups')
    try:
        names = [n for n in os.listdir(root) if n.isdigit()]
        names.sort(key=lambda n: int(n), reverse=True)
        for name in names[int(keep):]:
            shutil.rmtree(os.path.join(root, name), ignore_errors=True)
    except Exception:
        pass


def _retired_generations(state):
    raw = state.get('retired_channel_generations') or []
    out = []
    if isinstance(raw, list):
        for value in raw:
            value = str(value or '').strip().lower()
            if len(value) == 32 and all(ch in '0123456789abcdef' for ch in value) and value not in out:
                out.append(value)
    return out[-8:]


def _remember_generation_change(state, previous_generation, new_generation):
    retired = _retired_generations(state)
    previous_generation = str(previous_generation or '').strip().lower()
    new_generation = str(new_generation or '').strip().lower()
    if previous_generation and previous_generation != new_generation and previous_generation not in retired:
        retired.append(previous_generation)
    state['retired_channel_generations'] = retired[-8:]
    if new_generation:
        state['channel_generation'] = new_generation


def check_and_apply_once(notify=True, force=False):
    """Converge o addon para a publicação ativa do painel.

    Se a versão oficial é a mesma, aplica apenas os ``.py`` divergentes.
    Se o painel anuncia uma versão oficial maior, instala primeiro o pacote ZIP
    integral validado e exige reinício; hotfixes dessa nova versão serão
    aplicados normalmente na checagem seguinte ao reinício.
    """
    state = _load_state()
    now = int(time.time())
    stage = 'manifesto'
    revision = 0
    try:
        runtime_reason = _runtime_update_block_reason()
        if runtime_reason:
            return _deferred_runtime_result(state, now, revision, runtime_reason)
        state.pop('last_runtime_block', None)

        manifest = _manifest()
        revision = int(manifest['revision'])
        installed_version = _addon_version()
        target_version = str(manifest.get('target_version') or '').strip()
        version_cmp = _compare_versions(target_version, installed_version)
        if version_cmp < 0:
            state.update({
                'last_check': now,
                'last_success': now,
                'last_result': 'cliente_mais_novo',
                'installed_version': installed_version,
                'target_version': target_version,
            })
            state.pop('last_error', None)
            state.pop('last_runtime_block', None)
            _save_state(state)
            _log('cliente mais novo que painel installed=%s target=%s; downgrade ignorado' % (
                installed_version, target_version))
            return {
                'status': 'cliente_mais_novo',
                'revision': revision,
                'installed_version': installed_version,
                'target_version': target_version,
            }

        entries = _normalize_entries(manifest)
        contract = str(manifest.get('contract') or 'desired-python-state-v3')
        state_sha = _manifest_state_sha256(manifest, entries)
        current_revision = int(state.get('applied_revision') or 0)
        stored_sha = str(state.get('manifest_state_sha256') or '').strip().lower()
        manifest_generation = str(manifest.get('channel_generation') or '').strip().lower()
        stored_generation = str(state.get('channel_generation') or '').strip().lower()
        retired_generations = _retired_generations(state)
        generation_changed = bool(manifest_generation and stored_generation and manifest_generation != stored_generation)
        generation_migration = bool(manifest_generation and not stored_generation)

        if generation_changed and manifest_generation in retired_generations:
            state['last_check'] = now
            state['last_result'] = 'geracao_antiga'
            state['last_error'] = 'geração de canal já aposentada'
            _save_state(state)
            _log('geração de canal antiga recusada generation=%s' % manifest_generation[:12], True)
            return {'status': 'geracao_antiga', 'revision': revision}

        compare_revision = current_revision
        compare_sha = stored_sha
        if generation_changed:
            _log('nova geração de canal detectada old=%s new=%s; revision local %d será isolada' % (
                stored_generation[:12], manifest_generation[:12], current_revision))
            compare_revision = 0
            compare_sha = ''

        if not force and revision < compare_revision:
            state['last_check'] = now
            state['last_result'] = 'manifesto_antigo'
            _save_state(state)
            _log('verificação concluída revision=%d status=manifesto_antigo local=%d' % (revision, compare_revision))
            return {'status': 'manifesto_antigo', 'revision': revision}

        # Transição oficial de versão: não mistura addon.xml com hotfix Python.
        if target_version != installed_version:
            meta = _validate_version_package_meta(manifest, installed_version)
            _log('manifesto revision=%d generation=%s nova_versao=%s->%s package_revision=%d' % (
                revision, (manifest_generation[:12] if manifest_generation else 'legacy'),
                installed_version, target_version, int(meta['package_revision'])))
            stage = 'pacote-versao'
            return _apply_version_package(manifest, meta, state, stored_generation, manifest_generation, now, notify)

        # Reinício ocorreu e Kodi já reconhece a versão que havia sido gravada.
        if str(state.get('pending_version_restart') or '') == installed_version:
            state.pop('pending_version_restart', None)
            state.pop('version_package_sha256', None)
            state.pop('version_package_revision', None)

        pending = _entries_needing_update(entries)
        _log('manifesto revision=%d generation=%s contrato=%s arquivos=%d pendentes=%d state=%s' % (
            revision, (manifest_generation[:12] if manifest_generation else 'legacy'),
            contract, len(entries), len(pending), state_sha[:12]))

        same_revision = (revision == compare_revision and compare_revision > 0)
        if same_revision and compare_sha and compare_sha != state_sha:
            state['last_check'] = now
            state['last_result'] = 'revision_mutada'
            state['last_error'] = 'conteúdo do manifesto mudou sem incrementar revision'
            _save_state(state)
            _log('revisão %d mudou de identidade sem incremento; hotfix recusado' % revision, True)
            return {'status': 'revision_mutada', 'revision': revision}

        if not pending:
            if manifest_generation:
                _remember_generation_change(state, stored_generation, manifest_generation)
            state.update({
                'applied_revision': revision if generation_changed else max(current_revision, revision),
                'manifest_state_sha256': state_sha,
                'last_check': now,
                'last_success': now,
                'last_result': 'ja_aplicado',
                'files': [e['path'] for e in entries],
                'contract': contract,
                'target_version': target_version,
            })
            state.pop('last_error', None)
            _save_state(state)
            if generation_migration:
                _log('canal vinculado generation=%s revision=%d' % (manifest_generation[:12], revision))
            _log('verificação concluída revision=%d status=ja_aplicado' % revision)
            return {'status': 'ja_aplicado', 'revision': revision, 'files': []}

        if same_revision and not force:
            if not compare_sha:
                state['last_check'] = now
                state['last_result'] = 'revision_sem_fingerprint'
                state['last_error'] = 'estado legado da mesma revisão requer publicação de revisão nova'
                _save_state(state)
                _log('mesma revisão %d com pendências e sem fingerprint; publique revisão nova' % revision, True)
                return {'status': 'revision_sem_fingerprint', 'revision': revision}
            _log('autorreparo revision=%d pendentes=%d' % (revision, len(pending)))

        runtime_reason = _runtime_update_block_reason()
        if runtime_reason:
            return _deferred_runtime_result(state, now, revision, runtime_reason)

        stage = 'download-validacao'
        _log('preparando revision=%d pendentes=%d' % (revision, len(pending)))
        stage_root, staged = _stage_entries(pending, revision)
        try:
            runtime_reason = _runtime_update_block_reason()
            if runtime_reason:
                return _deferred_runtime_result(state, now, revision, runtime_reason)
            stage = 'aplicacao'
            backup_root, applied_files = _apply_staged(staged, revision)
        finally:
            shutil.rmtree(stage_root, ignore_errors=True)

        stage = 'estado-final'
        remaining = _entries_needing_update(entries)
        if remaining:
            raise ValueError('estado final divergente em %d arquivo(s)' % len(remaining))

        if manifest_generation:
            _remember_generation_change(state, stored_generation, manifest_generation)
        state.update({
            'applied_revision': revision,
            'manifest_state_sha256': state_sha,
            'last_check': now,
            'last_success': now,
            'last_result': 'aplicado',
            'files': [e['path'] for e in entries],
            'applied_files': applied_files,
            'backup': backup_root,
            'restart_required': bool(manifest.get('restart_required', True)),
            'contract': contract,
            'target_version': target_version,
        })
        state.pop('last_error', None)
        _save_state(state)
        _cleanup_old_backups(3)
        _log('hotfix aplicado revision=%d arquivos=%d' % (revision, len(applied_files)))
        if notify:
            _notify('OnePlay', 'Atualização interna aplicada.')
        return {'status': 'aplicado', 'revision': revision, 'files': applied_files}
    except Exception as exc:
        state.update({
            'last_check': now,
            'last_result': 'falha',
            'last_stage': stage,
            'last_error': '%s: %s' % (exc.__class__.__name__, exc),
        })
        try:
            _save_state(state)
        except Exception:
            pass
        _log('atualização não aplicada stage=%s revision=%s: %s: %s' % (
            stage, revision or '?', exc.__class__.__name__, exc), True)
        if notify and force:
            _notify('OnePlay', 'Atualização não aplicada; instalação atual preservada.', error=True)
        return {'status': 'falha', 'stage': stage, 'revision': revision, 'error': '%s: %s' % (exc.__class__.__name__, exc)}

