from _r06e8ad8f462e28a7 import __run__
__run__(__name__, __file__, 'service')
