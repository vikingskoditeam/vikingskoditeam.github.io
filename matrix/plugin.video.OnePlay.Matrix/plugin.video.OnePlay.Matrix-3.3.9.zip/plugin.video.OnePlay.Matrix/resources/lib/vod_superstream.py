# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Provider VOD Stremio adicional, isolado do FrostStream/Fenix.

Contrato V2 conservador, ajustado ao backend SuperStream real:
* usa TMDB numérico como identificador primário (evita consulta TMDB /find extra);
* IMDb é fallback somente quando TMDB não existe;
* séries usam ``<id>:<season>:<episode>`` sem prefixo ``tmdb:``;
* uma única requisição ao resource ``stream`` por filme/episódio;
* sem retry automático;
* cooldown persistente e classificado para uma origem ruim não atrasar cliques
  consecutivos;
* reaproveita o normalizador Stremio homologado do ``vod_engine``;
* não cria player, proxy, porta ou servidor próprios;
* falha deste provider nunca invalida os demais providers VOD.

O nome técnico do provider é mantido apenas em metadados internos/logs. A UI
principal apresenta somente ``Fonte N`` com cor própria.
"""

import re
import time
try:
    from urllib.parse import quote
except ImportError:  # pragma: no cover
    from urllib import quote

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None

from resources.lib.vod_engine import FrostStreamVodEngine


SUPER_MANIFEST_URL = 'https://da5f663b4690-superstream.baby-beamup.club/manifest.json'
SUPER_ROOT = 'https://da5f663b4690-superstream.baby-beamup.club'
SUPER_PROVIDER_NAME = 'SuperStream'
USER_AGENT = 'OnePlay-Matrix/3.3.9 Kodi'
# O backend real agrega TMDB + múltiplos Xtream. A conexão continua curta para
# não congelar a UI; o read timeout só cresce o suficiente para um backend
# saudável terminar um cold miss. Falha DNS pode escapar do connect timeout do
# requests no Windows, por isso o cooldown classificado abaixo é essencial.
REQUEST_TIMEOUT = (2.5, 9.0)
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
TMDB_RE = re.compile(r'^\d+$')
MAX_STREAMS = 32
HEALTH_NAMESPACE = 'vod_superstream_provider_health_v2'
HEALTH_KEY = 'cooldown'
DNS_COOLDOWN_SECONDS = 600
CONNECT_COOLDOWN_SECONDS = 180
READ_COOLDOWN_SECONDS = 90
NETWORK_COOLDOWN_SECONDS = 180
RATE_LIMIT_COOLDOWN_SECONDS = 120
SERVER_COOLDOWN_SECONDS = 90


class SuperStreamVodProvider(object):
    """Resolvedor pequeno: descoberta remota + normalização Stremio existente."""

    def __init__(self, requests_module=None, cache_api=None, logger=None, clock=None,
                 api_root=SUPER_ROOT):
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.api_root = (api_root or SUPER_ROOT).rstrip('/')
        # Reuso estritamente local do parser/normalizador Stream Object. Nenhuma
        # consulta de manifesto FrostStream é executada por este helper.
        self.normalizer = FrostStreamVodEngine(
            requests_module=self.requests, cache_api=None, logger=None, clock=self.clock
        )

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def _valid_imdb(imdb_id):
        return bool(IMDB_RE.match((imdb_id or '').strip()))

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(HEALTH_NAMESPACE, HEALTH_KEY)
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return str(value.get('reason') or 'cooldown')
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                HEALTH_NAMESPACE, HEALTH_KEY,
                {'reason': str(reason or 'provider-indisponivel')},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    @staticmethod
    def _normalize_tmdb(tmdb_id):
        value = str(tmdb_id or '').strip()
        if value.lower().startswith('tmdb:'):
            value = value.split(':', 1)[1].strip()
        return value if TMDB_RE.match(value) else ''

    def _identifier(self, imdb_id='', tmdb_id=''):
        # O servidor já recebe o TMDB da Matrix. Usá-lo diretamente elimina a
        # consulta /find que o backend faria ao receber um IMDb.
        tmdb = self._normalize_tmdb(tmdb_id)
        if tmdb:
            return tmdb, 'tmdb'
        imdb_id = (imdb_id or '').strip()
        if self._valid_imdb(imdb_id):
            return imdb_id, 'imdb'
        return '', ''

    def _build_api_url(self, media_type, imdb_id='', tmdb_id='', season=None, episode=None):
        identifier, _kind = self._identifier(imdb_id, tmdb_id)
        if not identifier:
            return ''
        if media_type == 'movie':
            video_id = identifier
        elif media_type == 'series':
            try:
                season_value = int(season)
                episode_value = int(episode)
            except Exception:
                return ''
            if season_value < 0 or episode_value < 1:
                return ''
            # O source do servidor interpreta os ':' como temporada/episódio.
            # Prefixar com "tmdb:" deslocaria todos os campos e quebraria a rota.
            video_id = '{}:{}:{}'.format(identifier, season_value, episode_value)
        else:
            return ''
        return '{}/stream/{}/{}.json'.format(
            self.api_root, media_type, quote(video_id, safe=':')
        )

    @staticmethod
    def _sanitize_superstream_raw(raw):
        """Neutraliza somente qualidade comprovadamente ambígua do SUP antigo.

        O source antigo usa o emoji 📺 para a categoria interna SD/indefinida,
        mas por um bug textual publica essa categoria como "1080p". O teste real
        mostrou que alguns desses arquivos são de fato 1920px e outros podem não
        ser. Portanto essa combinação NÃO é evidência segura de SD nem de 1080p.

        Em vez de inventar uma resolução, removemos apenas o token conflitante e
        marcamos o item como ambíguo. Nenhum probe ou chamada adicional é feito.
        """
        if not isinstance(raw, dict):
            return raw
        clean = dict(raw)
        title = clean.get('title')
        if isinstance(title, str) and '📺' in title and re.search(r'(?i)\b1080p\b', title):
            clean['__oneplay_quality_ambiguous'] = True
            # Remove somente o rótulo enganoso; mantém título, idioma e demais
            # metadados do provider intactos para normalização e reprodução.
            title = re.sub(r'(?i)\s*🎯\s*1080p\b', '', title)
            title = re.sub(r'(?i)\b1080p\b', '', title)
            clean['title'] = re.sub(r'[ \t]+(?=\n|$)', '', title).strip()
        return clean

    def _normalize_streams(self, raw_streams, identifier, identifier_kind):
        if not isinstance(raw_streams, list):
            return [], {'streams-invalidos': 1}
        normalized = []
        reasons = {}
        seen = set()
        for index, raw in enumerate(raw_streams[:MAX_STREAMS]):
            raw = self._sanitize_superstream_raw(raw)
            item, reason = self.normalizer._normalize_stream(raw, identifier, 60 + index)
            if item is None:
                reasons[reason or 'rejeitado'] = reasons.get(reason or 'rejeitado', 0) + 1
                continue
            item = dict(item)
            if isinstance(raw, dict) and raw.get('__oneplay_quality_ambiguous'):
                item['__vod_quality_ambiguous'] = True
            item['__vod_provider'] = SUPER_PROVIDER_NAME
            item['__vod_provider_id'] = identifier
            item['__vod_provider_id_kind'] = identifier_kind
            item['__request_label'] = 'sup-{}'.format(identifier_kind or 'id')
            item['__request_rank'] = 60 + index
            dedupe_key = (
                item.get('__vod_target_type', ''),
                item.get('url') or item.get('__vod_target_value', ''),
            )
            if dedupe_key in seen:
                continue
            seen.add(dedupe_key)
            normalized.append(item)
        return normalized, reasons

    @staticmethod
    def _network_error_kind(exc):
        name = exc.__class__.__name__.lower()
        message = str(exc or '').lower()
        if ('nameresolution' in message or 'name resolution' in message or
                'failed to resolve' in message or 'getaddrinfo failed' in message or
                'nodename nor servname' in message):
            return 'dns', DNS_COOLDOWN_SECONDS
        if 'readtimeout' in name or 'read timed out' in message:
            return 'read-timeout', READ_COOLDOWN_SECONDS
        if 'connecttimeout' in name or 'connect timed out' in message:
            return 'connect-timeout', CONNECT_COOLDOWN_SECONDS
        if 'ssl' in name or 'certificate' in message or 'tls' in message:
            return 'tls', NETWORK_COOLDOWN_SECONDS
        if 'connection' in name:
            return 'connection', NETWORK_COOLDOWN_SECONDS
        return exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS

    def resolve(self, media_type, imdb_id='', tmdb_id='', season=None, episode=None):
        identifier, identifier_kind = self._identifier(imdb_id, tmdb_id)
        api_url = self._build_api_url(media_type, imdb_id, tmdb_id, season, episode)
        if not api_url:
            return {'streams': [], 'reason': 'identificador/episódio inválido ou ausente', 'audit': ['sem-id']}
        if self.requests is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}

        cooldown = self._cooldown_state()
        if cooldown:
            self._log('cooldown ativo: {}.'.format(cooldown), 1)
            return {'streams': [], 'reason': 'fonte temporariamente em cooldown', 'audit': ['cooldown:{}'.format(cooldown)]}

        response = None
        started = self.clock()
        try:
            response = self.requests.get(
                api_url,
                headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
                timeout=REQUEST_TIMEOUT,
            )
            elapsed = max(0.0, float(self.clock()) - float(started))
            status = int(getattr(response, 'status_code', 0) or 0)
            if status != 200:
                if status == 429:
                    self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
                elif status >= 500 or status <= 0:
                    self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
                self._log('HTTP {} em {:.2f}s.'.format(status or 'desconhecido', elapsed), 1)
                return {
                    'streams': [],
                    'reason': 'fonte respondeu HTTP {}'.format(status or 'desconhecido'),
                    'audit': ['http-{}'.format(status or 'erro')],
                }
            try:
                payload = response.json()
            except Exception:
                return {'streams': [], 'reason': 'resposta JSON inválida', 'audit': ['json-invalido']}
            if not isinstance(payload, dict):
                return {'streams': [], 'reason': 'resposta fora do contrato', 'audit': ['payload-invalido']}
            streams, reasons = self._normalize_streams(payload.get('streams'), identifier, identifier_kind)
            if not streams:
                audit = ['sem-stream-compativel']
                if reasons:
                    audit.extend('{}={}'.format(key, value) for key, value in sorted(reasons.items()))
                self._log('sem fonte {} por {} em {:.2f}s.'.format(media_type, identifier_kind.upper(), elapsed), 1)
                return {'streams': [], 'reason': 'nenhuma fonte compatível agora', 'audit': audit}
            self._log('resolveu {} por {}: {} fonte(s) em {:.2f}s.'.format(
                media_type, identifier_kind.upper(), len(streams), elapsed), 1)
            return {'streams': streams, 'reason': '', 'audit': ['{}={}'.format(identifier_kind, len(streams))]}
        except Exception as exc:
            error_kind, ttl = self._network_error_kind(exc)
            self._remember_cooldown(error_kind, ttl)
            elapsed = max(0.0, float(self.clock()) - float(started))
            self._log('indisponível: {} em {:.2f}s; cooldown={}s.'.format(error_kind, elapsed, ttl), 1)
            return {
                'streams': [],
                'reason': 'fonte indisponível nesta consulta',
                'audit': ['erro-rede:{}'.format(error_kind)],
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


_DEFAULT_PROVIDER = None


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        def _kodi_log(message, level=1):
            try:
                from resources.lib.common import log, log_debug
                log('[VOD][SUP] {}'.format(message), level=level)
                log_debug(message, component='SUP')
            except Exception:
                pass
        _DEFAULT_PROVIDER = SuperStreamVodProvider(logger=_kodi_log)
    return _DEFAULT_PROVIDER


def reset_default_provider_for_tests():
    global _DEFAULT_PROVIDER
    _DEFAULT_PROVIDER = None
