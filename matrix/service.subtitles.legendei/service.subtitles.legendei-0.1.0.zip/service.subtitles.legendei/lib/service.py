# -*- coding: utf-8 -*-

import os
import sys
import re
import json
import zipfile
import shutil
import unicodedata
from urllib.parse import urljoin, urlparse, urlencode
from difflib import SequenceMatcher

# Kodi 19+ supplies these Python API modules natively.
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
translatePath = xbmcvfs.translatePath

import requests
from bs4 import BeautifulSoup

from urllib.parse import quote, unquote_plus, parse_qs

try:
    plugin = sys.argv[0]
    handle = int(sys.argv[1])
    __addon__ = xbmcaddon.Addon()
    __addonname__ = __addon__.getAddonInfo('name')
    __profile__ = translatePath(__addon__.getAddonInfo('profile'))
    __temp__ = translatePath(os.path.join(__profile__, 'temp', ''))
except:
    __addonname__ = 'Legendei'
    __temp__ = '/tmp/legendei/'

__headers__ = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/115.0.0.0 Safari/537.36'
}
__website__ = 'https://legendei.net/'
MAX_DOWNLOAD = 20 * 1024 * 1024
MAX_UNPACKED = 50 * 1024 * 1024
MAX_FILES = 80
ALLOWED_EXT = ('.srt', '.ass', '.ssa', '.vtt', '.sub')
_SESSION = requests.Session()
_LAST_HTTP = {'status': 'NOT_RUN'}

def _safe_url(url, base=__website__):
    try:
        parsed = urlparse(urljoin(base, url))
        if parsed.scheme not in ('http', 'https') or parsed.username or parsed.password:
            return None
        host = (parsed.hostname or '').lower()
        if host not in ('legendei.net', 'www.legendei.net'):
            return None
        return parsed.geturl()
    except Exception:
        return None

def _get(url, timeout=8):
    global _LAST_HTTP
    url = _safe_url(url)
    if not url:
        _LAST_HTTP = {'status': 'INVALID_URL'}
        return None
    try:
        r = _SESSION.get(url, headers=__headers__, timeout=timeout, stream=True, allow_redirects=False)
        for _ in range(4):
            if r.status_code not in (301,302,303,307,308):
                break
            next_url = _safe_url(r.headers.get('Location',''),r.url)
            r.close()
            if not next_url: return None
            r = _SESSION.get(next_url, headers=__headers__, timeout=timeout, stream=True, allow_redirects=False)
        if r.status_code != 200:
            _LAST_HTTP = {'status': 'HTTP_%s' % r.status_code}
            r.close(); return None
        length = int(r.headers.get('Content-Length') or 0)
        if length > MAX_DOWNLOAD:
            _LAST_HTTP = {'status': 'TOO_LARGE'}
            r.close(); return None
        chunks=[]; total=0
        for chunk in r.iter_content(65536):
            total += len(chunk)
            if total > MAX_DOWNLOAD:
                _LAST_HTTP = {'status': 'TOO_LARGE'}
                r.close(); return None
            chunks.append(chunk)
        r._legendei_body=b''.join(chunks)
        r.close()
        _LAST_HTTP = {'status': 'HTTP_200', 'bytes': total}
        return r
    except requests.Timeout:
        _LAST_HTTP = {'status': 'TIMEOUT'}
        return None
    except (requests.RequestException, ValueError, TypeError) as exc:
        _LAST_HTTP = {'status': 'NETWORK_OR_FORMAT_ERROR', 'error': type(exc).__name__}
        return None

def _body_text(r):
    return r._legendei_body.decode(r.encoding or 'utf-8', errors='replace')

def _normalize(text):
    text = unicodedata.normalize('NFKD', text or '')
    text = ''.join(x for x in text if not unicodedata.combining(x))
    return ' '.join(re.sub(r'[^a-z0-9]+',' ',text.lower()).split())

def _episode(text):
    m=re.search(r'(?i)\bS(\d{1,2})[. _-]*E(\d{1,3})\b',text or '')
    return (int(m.group(1)),int(m.group(2))) if m else None


# Episode markers may be embedded in playback titles. The identity is the show,
# not the episode name, release name, or season/episode label.
_RELEASE_TOKENS = {'web', 'webdl', 'webrip', 'bluray', 'brrip', 'hdtv', 'dvdrip', 'proper', 'repack',
                   '720p', '1080p', '2160p', 'x264', 'x265', 'h264', 'h265', 'hevc', 'aac'}

# Known UI/release metadata is not part of the show's identity.  Keep unknown
# bracketed content: it may be a real part of the title.
_METADATA_TAGS = {
    'l', 'legendado', 'legenda', 'subtitle', 'sub', 'subs', 'dual', 'dual audio',
    'dublado', 'dub', 'pt', 'pt br', 'pt pt', 'br', 'por', 'portugues',
    'portugues brasileiro', 'english', 'eng', 'en', 'es', 'spa', 'espanol',
    '720p', '1080p', '2160p', '480p', '4k', 'uhd', 'hdr', 'hdr10', 'dv',
    'web', 'web dl', 'webrip', 'bluray', 'blu ray', 'brrip', 'hdtv', 'dvdrip',
    'x264', 'x265', 'h264', 'h265', 'hevc', 'aac', 'proper', 'repack'
}

def _strip_title_metadata(text):
    """Remove only standalone, recognized tags, never arbitrary title words."""
    value = str(text or '')
    def replace_tag(match):
        tag = _normalize(match.group(1))
        return ' ' if tag in _METADATA_TAGS else match.group(0)
    value = re.sub(r'\[([^\[\]\r\n]{1,48})\]', replace_tag, value)
    value = re.sub(r'\(([^()\r\n]{1,48})\)', replace_tag, value)
    return ' '.join(value.split())

def _show_identity(text):
    value = re.split(r'(?i)\bS\d{1,2}[. _-]*E\d{1,3}\b', _strip_title_metadata(text), maxsplit=1)[0]
    value = _normalize(value)
    value = re.sub(r'^(?:(?:tv|serie|series|legenda|subtitle)\s+)+', '', value)
    tokens = value.split()
    while tokens and (tokens[-1] in _RELEASE_TOKENS or re.fullmatch(r'(?:19|20)\d{2}', tokens[-1])):
        tokens.pop()
    return ' '.join(tokens)

def _show_identity_match(wanted, candidate):
    a, b = _show_identity(wanted), _show_identity(candidate)
    return bool(a and b and a == b)

def _canonical_episode_query(title, season, episode):
    # Kodi sometimes supplies "SHOW S01E01 Episode name" as the show title.
    show = re.split(r'(?i)\bS\d{1,2}[. _-]*E\d{1,3}\b', _strip_title_metadata(title), maxsplit=1)[0].strip(' ._-')
    return ('%s S%02dE%02d' % (show, int(season), int(episode))) if show else ''

def _archive_series_compatible(filename, show, ep):
    """Only reject when the archive filename provides a recognizable episode identity.
    Generic subtitles remain eligible but cannot be considered identity-verified.
    """
    found = _episode(filename)
    if not found:
        return True
    return found == ep and _show_identity_match(show, filename)

def _language(text):
    t = (text or '').lower()
    # Explicit locale identifiers take precedence over generic language words.
    if '🇧🇷' in t or re.search(r'(?<!\w)(?:pt[-_. ]?br|por[-_. ]?br|brazilian|portugu[eê]s brasileiro)(?!\w)', t):
        return 'Portuguese (Brazil)'
    if '🇵🇹' in t or re.search(r'(?<!\w)(?:pt[-_. ]?pt|portugu[eê]s europeu|portugu[eê]s de portugal)(?!\w)', t):
        return 'Portuguese'
    if '🇪🇸' in t or re.search(r'(?<!\w)(?:es[-_. ]?es|espa[nñ]ol|spanish|castellano)(?!\w)', t):
        return 'Spanish'
    if '🇺🇸' in t or re.search(r'(?<!\w)(?:en[-_. ]?us|english subtitle)(?!\w)', t):
        return 'English'
    # Generic Portuguese is not proof of Brazilian or European Portuguese.
    if re.search(r'(?<!\w)(?:portuguese|portugu[eê]s)(?!\w)', t):
        return 'Portuguese'
    return 'Unknown'



if not os.path.exists(__temp__):
    try:
        os.makedirs(__temp__)
    except:
        pass


_IMDB_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/131.0.0.0 Safari/537.36'
)

_imdb_session = None


def _get_imdb_session():
    global _imdb_session
    if _imdb_session is None:
        _imdb_session = requests.Session()
    return _imdb_session


def _imdb_extract_next_data(html_text):
    m = re.search(
        r'<script id="__NEXT_DATA__" type="application/json">(.+?)</script>',
        html_text, re.DOTALL
    )
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except Exception:
        return None


def get_info_from_imdb(imdb_id):
    if not imdb_id or not re.fullmatch(r'tt\d{5,12}', str(imdb_id)):
        return None, None, None

    url = f'https://www.imdb.com/pt/title/{imdb_id}/'
    headers = {
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'User-Agent': _IMDB_UA,
        'sec-fetch-dest': 'document',
        'sec-fetch-mode': 'navigate',
        'sec-fetch-site': 'none',
        'sec-fetch-user': '?1',
        'upgrade-insecure-requests': '1',
    }

    try:
        session = _get_imdb_session()
        r = session.get(url, headers=headers, timeout=6)

        if r.status_code in (403, 429) or (
            r.status_code == 200 and 'challenge' in r.url.lower()
        ):
            global _imdb_session
            _imdb_session = None
            session = _get_imdb_session()
            r = session.get(url, headers=headers, timeout=6)

        if not r or r.status_code != 200:
            return None, None, None

        data = _imdb_extract_next_data(r.text)
        if not data:
            return None, None, None

        above = (
            data.get('props', {})
                .get('pageProps', {})
                .get('aboveTheFoldData', {})
        )

        original_title = (
            above.get('originalTitleText', {}).get('text', '')
            or above.get('titleText', {}).get('text', '')
        ).strip()

        title_local = above.get('titleText', {}).get('text', '').strip()

        year_data = above.get('releaseYear', {})
        year = str(year_data.get('year', '') if isinstance(year_data, dict) else year_data or '').strip()
        if year == '0':
            year = ''

        return original_title or None, title_local or None, year or None

    except Exception:
        return None, None, None


def clean_search_term(term):
    if not term:
        return ''
    
    term = term.replace(':', ' ')
    term = term.replace('-', ' ')
    term = ' '.join(term.split())
    
    return term


class FileManager:
    
    @staticmethod
    def clear_temp():
        if not os.path.exists(__temp__):
            return
        
        for root, dirs, files in os.walk(__temp__):
            for file in files:
                if file.endswith(('.srt', '.url', '.rar', '.zip')):
                    try:
                        os.remove(os.path.join(root, file))
                    except:
                        pass
        
        for name in os.listdir(__temp__):
            try:
                path = os.path.join(__temp__, name)
                if os.path.isdir(path):
                    shutil.rmtree(path)
            except:
                pass
    
    @staticmethod
    def extract_archive(archive_path, dest_path):
        if zipfile.is_zipfile(archive_path):
            try:
                with zipfile.ZipFile(archive_path) as archive:
                    entries = [x for x in archive.infolist() if not x.is_dir()]
                    if len(entries) > MAX_FILES or sum(x.file_size for x in entries) > MAX_UNPACKED:
                        log('Extract', 'ZIP_LIMIT entries=%s' % len(entries))
                        return False
                    extracted = 0
                    for entry in entries:
                        name = entry.filename.replace('\\', '/')
                        if name.startswith('/') or '..' in name.split('/') or not name.lower().endswith(ALLOWED_EXT):
                            continue
                        if entry.file_size > MAX_DOWNLOAD:
                            continue
                        basename = os.path.basename(name)
                        if not basename:
                            continue
                        target = os.path.join(dest_path, basename)
                        with archive.open(entry) as src, open(target, 'wb') as dst:
                            copied = 0
                            while True:
                                piece = src.read(65536)
                                if not piece: break
                                copied += len(piece)
                                if copied > MAX_DOWNLOAD or copied > entry.file_size:
                                    raise ValueError('archive entry size limit exceeded')
                                dst.write(piece)
                        extracted += 1
                    log('Extract', 'ZIP_EXTRACTED files=%s' % extracted)
                    return extracted > 0
            except (OSError, zipfile.BadZipFile, RuntimeError, ValueError, NotImplementedError) as exc:
                log('Extract', 'ZIP_FAILED error=%s' % type(exc).__name__)
                return False
        # Kodi VFS handles RAR when the relevant VFS plugin is installed.
        log('Extract', 'RAR_VFS_ATTEMPT')
        result = FileManager._extract_rar_vfs(archive_path, dest_path)
        log('Extract', 'RAR_VFS_%s' % ('EXTRACTED' if result else 'UNAVAILABLE_OR_INVALID'))
        return result

    @staticmethod
    def _extract_rar_vfs(rar_path, dest_path):
        try:
            root = 'rar://' + quote(rar_path, safe='') + '/'
            state = {'files': 0, 'bytes': 0}
            return FileManager._extract_rar_recursive(root, dest_path, state, 0)
        except Exception:
            return False

    @staticmethod
    def _extract_rar_recursive(src_path, dst_path, state, depth):
        if depth > 5: return False
        try:
            dirs, files = xbmcvfs.listdir(src_path)
            any_extracted = False
            for file in files:
                if not file.lower().endswith(ALLOWED_EXT) or '/' in file or '\\' in file or file in ('.','..'):
                    continue
                if state['files'] >= MAX_FILES: break
                target = os.path.join(dst_path, file)
                if xbmcvfs.copy(src_path.rstrip('/') + '/' + file, target):
                    size = os.path.getsize(target)
                    state['files'] += 1
                    state['bytes'] += size
                    if state['bytes'] > MAX_UNPACKED or size > MAX_DOWNLOAD:
                        os.remove(target)
                        return False
                    any_extracted = True
            for directory in dirs:
                if directory in ('.','..') or '/' in directory or '\\' in directory: continue
                any_extracted = FileManager._extract_rar_recursive(src_path.rstrip('/') + '/' + directory + '/', dst_path, state, depth+1) or any_extracted
            return any_extracted
        except Exception:
            return False

    @staticmethod
    def find_subtitles():
        subtitles = []
        
        for root, dirs, files in os.walk(__temp__):
            for file in files:
                if file.lower().endswith(ALLOWED_EXT):
                    full_path = os.path.join(root, file)
                    subtitles.append((file, full_path))
        
        return subtitles


class VideoDetector:
    
    @staticmethod
    def get_info():
        info = {
            'title': None,
            'original_name': None,
            'originaltitle': None,
            'localized_title': None,
            'season': None,
            'episode': None,
            'year': None,
            'imdb': None
        }
        
        
        try:
            tag = xbmc.Player().getVideoInfoTag()
            
            info['imdb'] = tag.getIMDBNumber() or None
            try:
                info['title'] = tag.getTVShowTitle() or tag.getTitle() or None
                info['original_name'] = tag.getOriginalTitle() or None
                info['year'] = str(tag.getYear()) if tag.getYear() > 0 else None
            except Exception:
                pass
            
            # The localized Kodi title may differ from the release name used by Legendei.
            # Enrich only when Kodi did not supply a distinct original title.
            if info['imdb'] and (not info.get('original_name') or _normalize(info.get('original_name')) == _normalize(info.get('title'))):
                imdb_original, imdb_localized, imdb_year = get_info_from_imdb(info['imdb'])
                
                if imdb_original:
                    info['original_name'] = imdb_original
                
                if imdb_localized and imdb_localized != imdb_original:
                    info['localized_title'] = imdb_localized

                if imdb_localized and imdb_localized != imdb_original and not info.get('title'):
                    info['title'] = imdb_localized
                elif imdb_original and not info.get('title'):
                    info['title'] = imdb_original
                
                if imdb_year and not info['year']:
                    info['year'] = imdb_year
            
            if not info['season']:
                try:
                    season = tag.getSeason()
                    info['season'] = season if season > 0 else None
                except:
                    pass
            
            if not info['episode']:
                try:
                    episode = tag.getEpisode()
                    info['episode'] = episode if episode > 0 else None
                except:
                    pass
        except:
            pass
        
        return info
    


class SubtitleClient:
    last_stats = {}
    
    @staticmethod
    def search(search_term, category=None, language=None):
        search_term = SubtitleClient._clean_search_term(search_term)
        
        # WordPress search parameter and official site language filter,
        # confirmed by the browser HAR (category/filmes/?language=br).
        params = {'s': search_term}
        if language == 'br':
            params['language'] = 'br'
        if category in ('filmes', 'serie'):
            url = urljoin(__website__, 'category/%s/' % category) + '?' + urlencode(params)
        else:
            url = __website__ + '?' + urlencode(params)
        
        SubtitleClient.last_stats = {}
        html_content = SubtitleClient._fetch_all_pages(url)
        if not html_content:
            SubtitleClient.last_stats = {'reason': SubtitleClient.last_fetch_status, 'cards': 0, 'accepted': 0}
            return []
        
        results = SubtitleClient._parse_results(html_content, search_term)
        
        return results
    
    @staticmethod
    def _fetch_all_pages(start_url):
        pages = []
        SubtitleClient.last_fetch_status = 'NO_PAGES'
        current = _safe_url(start_url)
        visited = set()
        while current and current not in visited and len(visited) < 3:
            visited.add(current)
            r = _get(current)
            if not r:
                SubtitleClient.last_fetch_status = _LAST_HTTP.get('status', 'NO_RESPONSE')
                break
            SubtitleClient.last_fetch_status = 'HTTP_200'
            html = _body_text(r)
            pages.append(html)
            soup = BeautifulSoup(html, 'html.parser')
            next_link = soup.select_one('a.sfwppa-link-next, a.next, a[rel="next"]')
            current = _safe_url(next_link.get('href'), current) if next_link else None
        return '\n'.join(pages)

    @staticmethod
    def _parse_results(html, original_search):
        results = []
        seen = set()
        stats = {"cards": 0, "invalid_url": 0, "low_score": 0, "accepted": 0}
        soup = BeautifulSoup(html, 'html.parser')
        # Supports both the legacy spans and post/list cards.
        # Restrict to post-title anchors. Generic span/menu/category links were
        # incorrectly offered as subtitles in the real Kodi 21.3 log.
        anchors = soup.select('span[style*="font-size"] a[href], .simple-grid-posts a[title][href], article h2 a[href], article h3 a[href], .entry-title a[href], .post-title a[href], .search-results a[href], .resultado a[href]')
        if not anchors:
            anchors = [a for a in soup.select('a[href]') if _episode(a.get_text(' ', strip=True)) or _episode(a.get('title', ''))]
        for a in anchors:
            stats["cards"] += 1
            link = _safe_url(a.get('href'))
            name = (a.get('title') or a.get_text(' ', strip=True) or '').strip()
            if not link or not name or link in seen or len(name) < 4:
                stats["invalid_url"] += 1
                continue
            parsed = urlparse(link)
            parts = [part.lower() for part in parsed.path.strip('/').split('/') if part]
            # WordPress taxonomy, search, pagination and homepage are never subtitle posts.
            if not parts or parts[0] in ('category', 'tag', 'author', 'page', 'wp-content', 'wp-json', 'feed'):
                stats['invalid_url'] += 1
                continue
            if 's' in parse_qs(parsed.query):
                stats['invalid_url'] += 1
                continue
            score = SubtitleClient._calculate_similarity(original_search, name)
            if score < 0.60:
                stats['low_score'] += 1
                continue
            seen.add(link)
            results.append({'name': name, 'link': link, 'similarity': score, 'language': _language(name)})
        results.sort(key=lambda x: x['similarity'], reverse=True)
        stats['accepted'] = len(results)
        SubtitleClient.last_stats = stats
        return results

    @staticmethod
    def _calculate_similarity(search_term, result_name):
        requested_ep, found_ep = _episode(search_term), _episode(result_name)
        if requested_ep and found_ep and requested_ep != found_ep: return 0.0
        if requested_ep and not found_ep: return 0.0
        if not requested_ep and found_ep: return 0.0
        if requested_ep:
            # Episode equality alone is never proof of the same television show.
            # Require the series identity to match before comparing release names.
            # This blocks Thunder 3 S01E03 -> Thundercats Roar S01E03.
            if not _show_identity_match(search_term, result_name):
                return 0.0
        def core(value):
            value = re.split(r'(?i)\bS\d{1,2}[. _-]*E\d{1,3}\b', _strip_title_metadata(value))[0]
            value = re.sub(r'\b(?:19|20)\d{2}\b', '', value)
            return _normalize(value)
        a, b = core(search_term), core(result_name)
        if not a or not b: return 0.0
        # Results commonly append release and codec after the title.
        if b == a or (len(a) >= 9 and len(a.split()) >= 2 and b.startswith(a + ' ')): score = 0.94
        else: score = SequenceMatcher(None,a,b).ratio()
        years_a = re.findall(r'\b(?:19|20)\d{2}\b', search_term or '')
        years_b = re.findall(r'\b(?:19|20)\d{2}\b', result_name or '')
        if years_a and years_b and years_a[0] != years_b[0]: score *= 0.45
        if requested_ep and found_ep == requested_ep: score = min(1.0,score + 0.06)
        return score

    @staticmethod
    def _clean_search_term(term):
        if not term:
            return ''
        
        term = term.replace(':', ' ')
        term = term.replace('-', ' ')
        term = ' '.join(term.split())
        term = re.sub(r'\s*\(\d{4}[-–]?\d{0,4}\)\s*$', '', term)
        
        return term.strip()
    
    @staticmethod
    def download_subtitle(url):
        url = _safe_url(url)
        if not url:
            log('Download', 'INVALID_URL')
            return False
        seen = set()
        for hop in range(4):
            if url in seen:
                log('Download', 'REDIRECT_LOOP hop=%s' % hop)
                return False
            seen.add(url)
            r = _get(url, timeout=20)
            if not r:
                log('Download', 'REQUEST_FAILED hop=%s reason=%s' % (hop, _LAST_HTTP.get('status', 'UNKNOWN')))
                return False
            payload = r._legendei_body
            content_type = r.headers.get('Content-Type', '').split(';')[0].strip().lower()
            kind = 'zip' if zipfile.is_zipfile(__import__('io').BytesIO(payload)) else ('rar' if payload.startswith(b'Rar!\x1a\x07') else 'other')
            log('Download', 'RESPONSE hop=%s bytes=%s mime=%s detected=%s' % (hop, len(payload), content_type[:60], kind))
            if kind in ('zip', 'rar'):
                success = SubtitleClient._save_and_extract(payload)
                log('Download', 'ARCHIVE_%s' % ('OK' if success else 'FAILED'))
                return success
            header = payload[:256].lstrip(b'\xef\xbb\xbf \r\n\t')
            if not ('html' in content_type or header.lower().startswith((b'<!doctype html', b'<html'))):
                if re.match(br'\d{1,7}\s*\r?\n', header) or header.startswith(b'WEBVTT') or header.startswith(b'[Script Info]'):
                    extension = '.vtt' if header.startswith(b'WEBVTT') else ('.ass' if header.startswith(b'[Script Info]') else '.srt')
                    try:
                        with open(os.path.join(__temp__, 'subtitle' + extension), 'wb') as f:
                            f.write(payload)
                        log('Download', 'RAW_SUBTITLE_OK format=%s' % extension)
                        return True
                    except OSError as exc:
                        log('Download', 'WRITE_FAILED error=%s' % type(exc).__name__)
                        return False
            if 'html' not in content_type and not header.lower().startswith((b'<!doctype html', b'<html', b'<?xml')):
                log('Download', 'UNSUPPORTED_BODY bytes=%s' % len(payload))
                return False
            next_url = SubtitleClient._extract_download_link(_body_text(r), url)
            if not next_url or next_url == url:
                log('Download', 'HTML_WITHOUT_DOWNLOAD_LINK hop=%s' % hop)
                return False
            log('Download', 'FOLLOW_DOWNLOAD_LINK hop=%s' % hop)
            url = next_url
        log('Download', 'MAX_HOPS_REACHED')
        return False

    @staticmethod
    def _extract_download_link(html, base=__website__):
        soup = BeautifulSoup(html, 'html.parser')
        for a in soup.select('a.buttonmyup[href], p.post-attachment a[href], a[href*="dl_id="]'):
            url = _safe_url(a.get('href'),base)
            if url and urlparse(url).path.strip('/').split('/')[0] not in ('category', 'tag', 'page', 'author'):
                return url
        return None

    @staticmethod
    def _save_and_extract(content):
        if len(content) > MAX_DOWNLOAD:
            log('Download', 'ARCHIVE_TOO_LARGE')
            return False
        tmp = os.path.join(__temp__, 'subtitle_package.tmp')
        try:
            with open(tmp, 'wb') as f: f.write(content)
            return FileManager.extract_archive(tmp, __temp__)
        except OSError as exc:
            log('Download', 'ARCHIVE_WRITE_FAILED error=%s' % type(exc).__name__)
            return False
        finally:
            try: os.remove(tmp)
            except OSError: pass


def log(module, msg):
    try:
        xbmc.log(f"### [Legendei - {module}] - {msg}", level=xbmc.LOGDEBUG)
    except:
        pass


def add_subtitle_item(name, link, similarity, video_info=None):
    try:
        params = {
            'action': 'download',
            'sub_download': link
        }
        if video_info and video_info.get('season') and video_info.get('episode'):
            show = _candidate_titles(video_info)[0] if _candidate_titles(video_info) else ''
            params['requested_show'] = _show_identity(show)
            params['requested_episode'] = 'S%02dE%02d' % (int(video_info['season']), int(video_info['episode']))
        url = f"{plugin}?{urlencode(params)}"
        
        score = int(similarity * 5)
        rating = '5' if score >= 4 else str(score)
        
        li = xbmcgui.ListItem(label=_language(name), label2=name)
        li.setArt({"icon": rating, "thumb": 'pb'})
        
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=url,
            listitem=li,
            isFolder=False
        )
    except:
        pass


def show_subtitle_selection(subtitles, requested_show=None, requested_episode=None):
    if not subtitles:
        notify('Nenhuma legenda disponível')
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    
    if requested_show and requested_episode:
        ep = _episode(requested_episode)
        if ep:
            rejected = [name for name, _ in subtitles if not _archive_series_compatible(name, requested_show, ep)]
            subtitles = [(name, path) for name, path in subtitles if _archive_series_compatible(name, requested_show, ep)]
            log('Extract', 'SERIES_ARCHIVE_FILTER accepted=%s rejected=%s' % (len(subtitles), len(rejected)))
            if not subtitles:
                notify('Arquivo sem legenda da série solicitada', 'WARNING')
                xbmcplugin.endOfDirectory(handle, succeeded=False)
                return
    subtitles = sorted(subtitles, key=lambda x: (not x[0].lower().endswith('.srt'), _language(x[0]) == 'Unknown', x[0].lower()))
    names = [s[0] for s in subtitles]
    paths = [s[1] for s in subtitles]
    
    index = xbmcgui.Dialog().select('Selecionar legenda', names)
    
    if index >= 0:
        selected_path = paths[index]
        set_subtitle(selected_path)
    else:
        xbmcplugin.endOfDirectory(handle, succeeded=False)


def set_subtitle(subtitle_path):
    try:
        li = xbmcgui.ListItem(label2=os.path.basename(subtitle_path))
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=subtitle_path,
            listitem=li,
            isFolder=False
        )
        xbmcplugin.endOfDirectory(handle)
    except:
        pass


def notify(message, icon='INFO'):
    try:
        icon_map = {
            'INFO': xbmcgui.NOTIFICATION_INFO,
            'WARNING': xbmcgui.NOTIFICATION_WARNING,
            'ERROR': xbmcgui.NOTIFICATION_ERROR
        }
        xbmcgui.Dialog().notification(
            'Legendei',
            message,
            icon_map.get(icon, xbmcgui.NOTIFICATION_INFO),
            3000
        )
    except:
        pass


def _preferred_language(lang):
    value = _normalize(lang or '')
    return 'br' if value in ('pt', 'pt br', 'pt_br', 'brazilian', 'portuguese brazil', 'portugues brasil', 'portugues brasileiro', 'portuguese') else None


def _candidate_titles(video_info):
    """Title variants derived from the actual movie's metadata, not a fixed alias list."""
    titles, seen = [], set()
    for source in ('original_name', 'originaltitle', 'title', 'localized_title'):
        value = video_info.get(source)
        if not isinstance(value, str):
            continue
        # Strip UI language markers sometimes appended by third-party players.
        name = _strip_title_metadata(clean_search_term(value)).strip()
        key = _normalize(name)
        if key and key not in seen:
            titles.append(name)
            seen.add(key)
    return titles


def _language_rank(language):
    """Fallback order: Brazilian Portuguese, European Portuguese, Spanish, others."""
    return {'Portuguese (Brazil)': 0, 'Portuguese': 1, 'Spanish': 2,
            'Unknown': 3, 'English': 4}.get(language, 5)


def _sorted_results(results):
    return sorted(results, key=lambda r: (_language_rank(r.get('language')),
                                          -r.get('similarity', 0), r.get('name', '')))


def _search_plan(video_info):
    """Build bounded queries from playback metadata without fabricating translations."""
    titles = _candidate_titles(video_info)

    if not titles:
        return []

    season, episode = video_info.get('season'), video_info.get('episode')
    is_series = bool(season and episode)
    category = 'serie' if is_series else 'filmes'
    year = str(video_info.get('year') or '').strip()
    if not re.fullmatch(r'(?:19|20)\d{2}', year):
        year = ''

    plan = []
    used = set()
    def add(term, group):
        key = (_normalize(term), group)
        if key[0] and key not in used:
            used.add(key)
            plan.append((term, group))

    # Phase 1: category-specific searches, including year-free variants.
    for title in titles:
        if is_series:
            term = _canonical_episode_query(title, season, episode)
            add(term, category)
        else:
            if year:
                add(f'{title} {year}', category)
            add(title, category)

    # Phase 2: same titles in the whole catalog (manual search uses this).
    for title in titles:
        if is_series:
            add(_canonical_episode_query(title, season, episode), None)
        else:
            if year:
                add(f'{title} {year}', None)
            add(title, None)

    # No unsafe automatic shortening of titles: that can select another film.
    return plan[:16]


def search_subtitle(lang, manual_search=None):
    FileManager.clear_temp()
    preferred = _preferred_language(lang)
    if manual_search:
        term = clean_search_term(manual_search) if isinstance(manual_search, str) else ''
        results = SubtitleClient.search(term, language=None) if term else []
        log('Search', f'manual query={term!r} valid={len(results)} stats={SubtitleClient.last_stats}')
        for result in _sorted_results(results):
            add_subtitle_item(result['name'], result['link'], result['similarity'])
        xbmcplugin.endOfDirectory(handle)
        return

    video_info = VideoDetector.get_info()
    plan = _search_plan(video_info)
    if not plan:
        log('Search', 'automatic search unavailable: no usable playback title')
        notify('Informações do vídeo não encontradas', 'WARNING')
        xbmcplugin.endOfDirectory(handle)
        return

    results_by_link = {}
    # First query the requested Brazilian catalog. If no reliable PT-BR results,
    # repeat progressively without a language filter to allow PT-PT and Spanish.
    stages = ('br', None) if preferred == 'br' else (None,)
    attempts = 0
    max_attempts = 10
    for stage in stages:
        if attempts >= max_attempts:
            break
        found_in_category = False
        for term, category in plan:
            if attempts >= max_attempts:
                break
            if category is None and found_in_category:
                break
            try:
                results = SubtitleClient.search(term, category, language=stage)
            except Exception as exc:
                log('Search', f'query failed term={term!r} category={category or "all"} lang={stage or "any"}: {type(exc).__name__}')
                results = []
            attempts += 1
            log('Search', f'automatic query={term!r} category={category or "all"} lang={stage or "any"} valid={len(results)} stats={SubtitleClient.last_stats}')
            if category is not None and results:
                found_in_category = True
            for result in results:
                link = result.get('link')
                if link and (link not in results_by_link or result.get('similarity', 0) > results_by_link[link].get('similarity', 0)):
                    results_by_link[link] = result
        # Only end fallback when a positively identified Brazilian-language result exists.
        if any(r.get('language') == 'Portuguese (Brazil)' for r in results_by_link.values()):
            break

    if not results_by_link:
        notify('Nenhuma legenda encontrada', 'WARNING')
        log('Search', f'automatic search exhausted queries={attempts} valid=0')
        xbmcplugin.endOfDirectory(handle)
        return

    final_results = _sorted_results(results_by_link.values())
    counts = {language: sum(r.get('language') == language for r in final_results)
              for language in ('Portuguese (Brazil)', 'Portuguese', 'Spanish', 'Unknown', 'English')}
    log('Search', f'automatic result count={len(final_results)} languages={counts} requests={attempts}')
    for result in final_results[:60]:
        add_subtitle_item(result['name'], result['link'], result['similarity'], video_info)
    xbmcplugin.endOfDirectory(handle)


def download_subtitle(url, requested_show=None, requested_episode=None):
    # parse_qs already decodes parameters; decoding again corrupts '+' and '%'.
    FileManager.clear_temp()
    
    success = SubtitleClient.download_subtitle(url)
    
    if success:
        subtitles = FileManager.find_subtitles()
        
        if subtitles:
            show_subtitle_selection(subtitles, requested_show, requested_episode)
        else:
            notify('Nenhuma legenda encontrada no arquivo', 'WARNING')
            xbmcplugin.endOfDirectory(handle, succeeded=False)
    else:
        notify('Erro ao baixar legenda', 'ERROR')
        xbmcplugin.endOfDirectory(handle, succeeded=False)


if __name__ == '__main__':
    try:
        params = dict(parse_qs(sys.argv[2][1:]))
        params = {k: v[0] if v else None for k, v in params.items()}
    except:
        params = {}
    
    action = params.get('action')
    
    if action == 'search':
        search_subtitle('pt', params.get('searchstring'))
    elif action == 'download':
        download_subtitle(params.get('sub_download', ''), params.get('requested_show'), params.get('requested_episode'))
    else:
        search_subtitle('pt')