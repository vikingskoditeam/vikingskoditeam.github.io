from _re005f0d31a6b3889 import __run__
__run__(__name__, __file__, 'service')
