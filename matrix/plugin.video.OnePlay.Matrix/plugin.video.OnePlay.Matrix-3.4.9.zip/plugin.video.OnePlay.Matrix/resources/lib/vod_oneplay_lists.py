# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Fonte VOD 01–07 pelo contrato de pesquisa publicado no painel OnePlay.

Busca por título/ano na origem, sem varrer catálogos no dispositivo. Somente
streams HTTP(S) retornados pelo endpoint Stremio entram no player existente.
"""

import re
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor, as_completed
try:
    from urllib.parse import urlparse, urljoin
except ImportError:  # pragma: no cover
    from urlparse import urlparse, urljoin

try:
    import requests
except ImportError:  # pragma: no cover
    requests = None

ROOT = 'https://listas.oneplayhd.com/'
SEARCH = ROOT + 'vod_search.php'
SEARCH_TIMEOUT = (2.0, 5.5)
STREAM_TIMEOUT = (2.0, 3.5)
MAX_MATCHES = 7  # uma correspondência principal por slot, antes de variantes
MAX_STREAMS = 14  # até duas URLs úteis por slot, sem monopolizar o resultado
TOTAL_BUDGET_SECONDS = 10.0
USER_AGENT = 'OnePlay-Matrix/3.4.8'
PROBE_TIMEOUT = (1.0, 1.5)
PROBE_MAX_WORKERS = 3


def _clean_name(value):
    value = unicodedata.normalize('NFKD', str(value or ''))
    value = ''.join(c for c in value if not unicodedata.combining(c))
    # A M3U pode trazer marcadores técnicos no final do nome. Remover apenas
    # esses sufixos, preservando todas as palavras que identificam a obra.
    value = re.sub(r'(?:\s*[\(\[\{]\s*(?:dublado|legendado|dual audio|4k|uhd|fhd|1080p|720p)\s*[\)\]\}])+$',
                   ' ', value, flags=re.I)
    value = re.sub(r'\(\s*(?:19|20)\d{2}\s*\)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value.lower()).strip()
    return re.sub(r'\s+', ' ', value)


def _same_title(candidate, title):
    return bool(_clean_name(candidate) and _clean_name(candidate) == _clean_name(title))


def _same_series_alias(candidate, title):
    """Alias restrito: título original seguido de subtítulo, ano ou temporada.

    A API já precisa comprovar o video_id de temporada/episódio antes de
    devolver esse candidato; não usamos semelhança arbitrária de palavras.
    """
    original = _clean_name(title)
    candidate_norm = _clean_name(candidate)
    if not original or not candidate_norm.startswith(original + ' '):
        return False
    raw = unicodedata.normalize('NFKD', str(candidate or ''))
    raw = ''.join(c for c in raw if not unicodedata.combining(c))
    # Aceita somente fronteiras explícitas, evitando prefixos de outras obras.
    prefix = re.escape(str(title or '').strip())
    return bool(re.match(r'^{}\s*(?::\s*.+|\(\s*(?:19|20)\d{{2}}\s*\).*$|\b(?:19|20)\d{{2}}\b.*|\bS\d{{1,2}}\b.*)$'.format(prefix), raw, re.I))


def _safe_stream_path(value, kind):
    """Aceita apenas o caminho relativo Stremio esperado, sem URL externa."""
    value = str(value or '').strip()
    if not value.startswith('stream/{}/op:'.format(kind)):
        return ''
    if not re.match(r'^stream/(movie|series)/op:[ms]:[A-Za-z0-9:_-]+\.json$', value):
        return ''
    return value


class OnePlayListsProvider(object):
    def __init__(self, http=None, logger=None):
        self.http = http or requests
        self.logger = logger

    def _log(self, msg):
        if self.logger:
            try:
                self.logger(msg)
            except Exception:
                pass

    def _json(self, url, params=None, timeout=SEARCH_TIMEOUT):
        response = self.http.get(url, params=params, timeout=timeout,
                                 headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
                                 allow_redirects=False)
        try:
            if int(response.status_code) != 200:
                return None, 'http-{}'.format(response.status_code)
            if len(response.content) > 512 * 1024:
                return None, 'resposta-grande'
            obj = response.json()
            return (obj, '') if isinstance(obj, dict) else (None, 'json-invalido')
        finally:
            response.close()

    def _probe(self, url):
        """Descarta apenas recusas definitivas; não lê nem baixa o vídeo.

        Probes ambíguas (timeout, 405, 429, 5xx) permanecem disponíveis,
        pois alguns servidores não aceitam HEAD ou limitam sondagens.
        """
        response = None
        try:
            response = self.http.get(
                url, timeout=PROBE_TIMEOUT, stream=True, allow_redirects=True,
                headers={'User-Agent': USER_AGENT, 'Range': 'bytes=0-0',
                         'Accept': '*/*'},
            )
            status = int(response.status_code)
            if status in (401, 403, 404, 410):
                return False, 'http-{}'.format(status)
            if status in (200, 206):
                ctype = (response.headers.get('Content-Type') or '').lower().split(';', 1)[0].strip()
                if ctype in ('text/html', 'application/json', 'text/plain'):
                    return False, 'mime-{}'.format(ctype.replace('/', '-'))
            return True, 'ok' if status in (200, 206) else 'inconclusivo-{}'.format(status)
        except Exception as exc:
            return True, 'inconclusivo-{}'.format(exc.__class__.__name__)
        finally:
            if response is not None:
                response.close()

    def resolve(self, media_type, title, year=None, season=None, episode=None, tmdb_id=None):
        deadline = time.monotonic() + TOTAL_BUDGET_SECONDS
        kind = str(media_type or '').lower().strip()
        if kind not in ('movie', 'series') or not _clean_name(title):
            return {'streams': [], 'reason': 'título/tipo ausente', 'audit': ['sem-titulo']}
        if self.http is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}
        params = {'type': kind, 'title': str(title).strip()}
        if tmdb_id and re.match(r'^[1-9][0-9]{0,9}$', str(tmdb_id)):
            params['tmdb_id'] = str(tmdb_id)
        try:
            if year and re.match(r'^(?:19|20)\d{2}$', str(year)):
                params['year'] = str(year)
            if kind == 'series':
                if int(season) < 0 or int(episode) < 1:
                    raise ValueError('episodio-invalido')
                params.update({'season': int(season), 'episode': int(episode)})
        except (ValueError, TypeError):
            return {'streams': [], 'reason': 'temporada/episódio inválido', 'audit': ['sem-episodio']}

        try:
            result, error = self._json(SEARCH, params=params)
        except Exception as exc:
            return {'streams': [], 'reason': 'pesquisa indisponível',
                    'audit': ['pesquisa-{}'.format(exc.__class__.__name__)]}
        if error:
            return {'streams': [], 'reason': 'pesquisa indisponível', 'audit': [error]}
        matches = result.get('matches') or []
        if not isinstance(matches, list):
            return {'streams': [], 'reason': 'resposta de pesquisa inválida', 'audit': ['matches-invalidos']}

        selected, seen_paths, seen_slots = [], set(), set()
        for match in matches:
            if not isinstance(match, dict) or match.get('type') != kind:
                continue
            # Score sozinho aceita obras relacionadas; exigir nome exato evita
            # confundir filmes diferentes. O ano conhecido também é obrigatório.
            tmdb_confirmed = bool(params.get('tmdb_id') and match.get('tmdb_confirmed') is True
                                  and str(match.get('tmdb_id')) == params['tmdb_id'])
            if not (tmdb_confirmed or _same_title(match.get('title'), title) or
                    (kind == 'series' and match.get('video_id') and
                     _same_series_alias(match.get('title'), title))):
                continue
            if not tmdb_confirmed and params.get('year') and match.get('year'):
                if str(match['year']) != str(params['year']):
                    continue
            path = _safe_stream_path(match.get('stream_path'), kind)
            if not path or path in seen_paths:
                continue
            try:
                slot_number = int(match.get('slot'))
            except (TypeError, ValueError):
                continue
            if slot_number < 1 or slot_number > 7 or slot_number in seen_slots:
                continue
            seen_paths.add(path)
            seen_slots.add(slot_number)
            selected.append((path, slot_number))
            if len(selected) >= MAX_MATCHES:
                break

        streams, audits, seen_urls = [], [], set()
        fetched = {}
        remaining = deadline - time.monotonic()
        if selected and remaining >= 1.0:
            timeout = (min(STREAM_TIMEOUT[0], max(0.5, remaining)),
                       min(STREAM_TIMEOUT[1], max(0.5, remaining)))

            def fetch(index, path):
                try:
                    data, error = self._json(urljoin(ROOT, path), timeout=timeout)
                    return index, data, error
                except Exception as exc:
                    return index, None, exc.__class__.__name__

            # Até quatro consultas em paralelo, uma por slot selecionado.
            # O executor é encerrado antes de devolver o lote ao Kodi.
            with ThreadPoolExecutor(max_workers=min(4, len(selected))) as pool:
                futures = [pool.submit(fetch, i, path) for i, (path, _) in enumerate(selected)]
                for future in as_completed(futures):
                    index, data, error = future.result()
                    fetched[index] = (data, error)

        per_slot_streams = []
        for index, (path, slot) in enumerate(selected):
            data, error = fetched.get(index, (None, 'budget-esgotado'))
            if error or not isinstance(data, dict):
                audits.append('slot-{}-{}'.format(slot, error or 'json-invalido'))
                continue
            local_streams = []
            for item in (data.get('streams') or [])[:MAX_STREAMS]:
                if not isinstance(item, dict):
                    continue
                url = str(item.get('url') or '').strip()
                try:
                    parsed = urlparse(url)
                    if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password:
                        continue
                except Exception:
                    continue
                if url in seen_urls:
                    continue
                seen_urls.add(url)
                name = 'OnePlay VOD • Lista {}'.format(slot if str(slot).isdigit() else '?')
                local_streams.append({
                    'name': name, 'title': name,
                    'description': str(item.get('title') or name)[:200],
                    'url': url,
                    '__vod_provider': 'OnePlay VOD',
                    '__vod_source_family': 'OnePlay VOD',
                    '__vod_source_host': parsed.hostname,
                    '__vod_playable': True,
                    '__vod_target_type': 'url', '__vod_target_value': url,
                    '__request_rank': 75 + index,
                    '__request_label': 'oneplay-lists',
                })
                if len(local_streams) >= 2:
                    break
            if local_streams:
                per_slot_streams.append(local_streams)
        # Primeiro uma URL de cada lista; depois uma variante por lista.
        # Isso impede que duas variantes de um slot escondam outros slots.
        for round_index in range(2):
            for group in per_slot_streams:
                if len(group) > round_index:
                    streams.append(group[round_index])
                if len(streams) >= MAX_STREAMS:
                    break
            if len(streams) >= MAX_STREAMS:
                break
        # As consultas de catálogo são rápidas, mas endereços gerados pela
        # origem podem estar bloqueados. Sondar somente os poucos candidatos,
        # sem descarregar mídia e sem alongar a busca de outros provedores.
        if streams:
            checks = {}
            with ThreadPoolExecutor(max_workers=min(PROBE_MAX_WORKERS, len(streams))) as pool:
                jobs = {pool.submit(self._probe, entry['url']): i
                        for i, entry in enumerate(streams)}
                for future in as_completed(jobs):
                    try:
                        checks[jobs[future]] = future.result()
                    except Exception:
                        checks[jobs[future]] = (True, 'inconclusivo')
            filtered = []
            for index, entry in enumerate(streams):
                allowed, reason = checks.get(index, (True, 'sem-sonda'))
                if allowed:
                    filtered.append(entry)
                else:
                    audits.append('fonte-{}-{}'.format(index + 1, reason))
            streams = filtered
        self._log('OnePlay VOD {}: matches={} exatos={} fontes={} descartadas={}.'.format(
            kind, len(matches), len(selected), len(streams),
            sum(1 for entry in audits if entry.startswith('fonte-'))))
        return {'streams': streams, 'reason': '' if streams else 'OnePlay VOD sem fonte para este título',
                'audit': ['matches={}'.format(len(matches)), 'exatos={}'.format(len(selected))] + audits}


_DEFAULT = None


def get_default_provider():
    global _DEFAULT
    if _DEFAULT is None:
        def logger(msg):
            try:
                from resources.lib.common import log
                log('[VOD OnePlay Listas] ' + msg)
            except Exception:
                pass
        _DEFAULT = OnePlayListsProvider(logger=logger)
    return _DEFAULT
