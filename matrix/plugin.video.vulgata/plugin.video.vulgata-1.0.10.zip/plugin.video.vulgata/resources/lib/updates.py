__import__('sys').path.insert(0, __import__('os').path.abspath(__import__('os').path.join(__import__('os').path.dirname(__file__), '../..')))
from _r06e8ad8f462e28a7 import __run__
__run__(__name__, __file__, 'resources.lib.updates')
