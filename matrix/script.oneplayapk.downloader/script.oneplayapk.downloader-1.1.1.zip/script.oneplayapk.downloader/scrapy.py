# scrapy.py
# -*- coding: utf-8 -*-
"""Descoberta dinâmica de APKs em uma pasta pública do MediaFire.

Usa o endpoint público de pasta via POST, no mesmo formato do web-app atual.
Nenhum session_token de navegador é persistido no add-on.
"""

import json
import time
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen

MEDIAFIRE_FOLDER_KEY = "jtpajir56ydhb"
MEDIAFIRE_API = "https://www.mediafire.com/api/1.5/folder/get_content.php"
USER_AGENT = (
    "Mozilla/5.0 (Linux; Android 10; Kodi) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"
)
TIMEOUT = 20
MAX_RETRIES = 2
MAX_FOLDER_DEPTH = 8


def _api_post(folder_key, content_type, chunk=1):
    # O MediaFire aceita a consulta pública da pasta sem session_token.
    # POST aproxima o fluxo do app.mediafire.com e de clientes atuais.
    form = {
        "response_format": "json",
        "folder_key": folder_key,
        "content_type": content_type,
        "chunk": chunk,
        "chunk_size": 1000,
        "filter": "all",
        "order_by": "name",
        "order_direction": "asc",
    }
    body = urlencode(form).encode("ascii")
    headers = {
        "User-Agent": USER_AGENT,
        "Accept": "application/json",
        "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
        "Content-Type": "application/x-www-form-urlencoded",
        "Referer": "https://app.mediafire.com/",
        "Origin": "https://app.mediafire.com",
    }

    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            req = Request(MEDIAFIRE_API, data=body, headers=headers, method="POST")
            with urlopen(req, timeout=TIMEOUT) as response:
                charset = response.headers.get_content_charset() or "utf-8"
                payload = response.read().decode(charset, "replace")
            data = json.loads(payload)
            response_obj = data.get("response", {})
            if response_obj.get("result") == "Error":
                raise RuntimeError(response_obj.get("message") or "Erro retornado pelo MediaFire")
            return response_obj.get("folder_content", {})
        except (HTTPError, URLError, ValueError, RuntimeError) as exc:
            last_error = exc
            if attempt < MAX_RETRIES:
                time.sleep(0.7 * (attempt + 1))

    raise RuntimeError("Falha ao consultar a pasta do MediaFire: %s" % last_error)


def _get_all(folder_key, content_type):
    items = []
    chunk = 1
    while True:
        content = _api_post(folder_key, content_type, chunk)
        items.extend(content.get(content_type, []) or [])
        if str(content.get("more_chunks", "no")).lower() != "yes":
            break
        chunk += 1
    return items


def _normal_download_url(file_info):
    links = file_info.get("links") or {}
    normal = links.get("normal_download")
    if normal:
        return normal

    quickkey = file_info.get("quickkey") or file_info.get("quick_key")
    filename = file_info.get("filename") or "download.apk"
    if quickkey:
        return "https://www.mediafire.com/file/%s/%s/file" % (
            quickkey,
            quote(filename),
        )
    return None


def _walk_folder(folder_key, prefix="", depth=0, visited=None):
    if visited is None:
        visited = set()
    if folder_key in visited or depth > MAX_FOLDER_DEPTH:
        return []
    visited.add(folder_key)

    result = []
    for file_info in _get_all(folder_key, "files"):
        filename = (file_info.get("filename") or "").strip()
        if not filename.lower().endswith(".apk"):
            continue
        page_url = _normal_download_url(file_info)
        if not page_url:
            continue
        display = (prefix + filename) if prefix else filename
        # O endpoint folder/get_content já fornece o tamanho em bytes.
        # Mantemos o valor cru aqui e apenas formatamos na interface.
        try:
            size_bytes = int(file_info.get("size") or 0)
        except (TypeError, ValueError):
            size_bytes = 0
        result.append((display, page_url, filename, size_bytes))

    for folder in _get_all(folder_key, "folders"):
        child_key = folder.get("folderkey") or folder.get("folder_key")
        child_name = (folder.get("name") or "Pasta").strip()
        if not child_key:
            continue
        child_prefix = "%s%s / " % (prefix, child_name)
        result.extend(_walk_folder(child_key, child_prefix, depth + 1, visited))

    return result


def listar_apks():
    """Retorna [(nome_exibicao, pagina_mediafire, nome_arquivo, tamanho_bytes), ...]."""
    itens = _walk_folder(MEDIAFIRE_FOLDER_KEY)
    itens.sort(key=lambda item: item[0].lower())
    return itens


if __name__ == "__main__":
    for nome, url, arquivo, tamanho in listar_apks():
        print("%s -> %s (%s, %d bytes)" % (nome, url, arquivo, tamanho))
