# -*- coding: utf-8 -*-
from helpers import xbmc, log
import localproxy


def main():
    monitor = xbmc.Monitor()
    try:
        if localproxy.start():
            log('Servico de proxy Cloudflare iniciado.')
        else:
            log('Servico de proxy Cloudflare nao confirmou a porta local.')
    except Exception as exc:
        try:
            log('Falha ao iniciar servico de proxy: {0}'.format(str(exc)))
        except Exception:
            pass
    while not monitor.abortRequested():
        monitor.waitForAbort(1)
    try:
        localproxy.stop()
    except Exception:
        pass


if __name__ == '__main__':
    main()
