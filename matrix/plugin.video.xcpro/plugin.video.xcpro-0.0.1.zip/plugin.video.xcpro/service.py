# -*- coding: utf-8 -*-
"""Serviço persistente do XC Pro.

Mantém o proxy local e o servidor de pareamento vivos fora das rotas do plugin.
Isso evita depender de threads criadas pelo default.py, que podem morrer quando a navegação termina.
"""

import datetime
import json
import os
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon('plugin.video.xcpro')
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
LIB_PATH = os.path.join(ADDON_PATH, 'resources', 'lib')
if LIB_PATH not in sys.path:
    sys.path.append(LIB_PATH)

from proxy import UnifiedServer
from webserver import PairingWebServer


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[XC Pro Service] {}'.format(msg), level)
    except Exception:
        pass


def get_int_setting(setting_id, default_value):
    try:
        value = ADDON.getSetting(setting_id)
        value = int(value) if value else int(default_value)
        if 1 <= value <= 65535:
            return value
    except Exception:
        pass
    return int(default_value)


def get_ports():
    return get_int_setting('proxy_port', 9097), get_int_setting('webserver_port', 9099)


def get_profile_path():
    profile = ADDON.getAddonInfo('profile')
    try:
        profile = xbmcvfs.translatePath(profile)
    except Exception:
        pass
    try:
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            if not os.path.exists(profile):
                os.makedirs(profile)
        except Exception:
            pass
    return profile


PROFILE_PATH = get_profile_path()
EPG_XML_FILE = os.path.join(PROFILE_PATH, 'epg_xmltv.xml')
EPG_XML_INDEX_FILE = os.path.join(PROFILE_PATH, 'epg_xmltv_index.json')
EPG_XML_META_FILE = os.path.join(PROFILE_PATH, 'epg_xmltv_meta.json')
EPG_CACHE_FILE = os.path.join(PROFILE_PATH, 'epg_cache.json')
EPG_XML_TTL = 86400
EPG_WATCHDOG_INTERVAL = 3600
EPG_INDEX_PREVENTIVE_MARGIN = 7200
EPG_XML_INDEX_VERSION = 'xcpro_epg_xmltv_login_v4'


def normalize_host(host):
    host = (host or '').strip()
    if not host:
        return ''
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    try:
        parsed = urllib.parse.urlparse(host)
        if parsed.scheme and parsed.netloc:
            return '{}://{}'.format(parsed.scheme, parsed.netloc).rstrip('/')
    except Exception:
        pass
    return host.rstrip('/')


def get_credentials():
    host = normalize_host(ADDON.getSetting('host'))
    username = (ADDON.getSetting('username') or '').strip()
    password = (ADDON.getSetting('password') or '').strip()
    return host, username, password


def has_credentials():
    host, user, password = get_credentials()
    return bool(host and user and password)


def epg_fingerprint():
    host, user, password = get_credentials()
    return '{}|{}|{}'.format(host, user, password)


def safe_read_json(path, default=None):
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file_obj:
                return json.load(file_obj)
    except Exception:
        pass
    return {} if default is None else default


def safe_write_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as file_obj:
            json.dump(data or {}, file_obj, ensure_ascii=False)
        return True
    except Exception as exc:
        log('Falha ao salvar JSON EPG {}: {}'.format(path, exc), xbmc.LOGWARNING)
    return False


def clear_epg_cache(reason=''):
    for path in (EPG_XML_FILE, EPG_XML_INDEX_FILE, EPG_XML_META_FILE, EPG_CACHE_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except Exception as exc:
            log('Falha ao remover cache EPG {}: {}'.format(path, exc), xbmc.LOGWARNING)
    if reason:
        log('Cache EPG limpo: {}'.format(reason), xbmc.LOGINFO)


def get_browser_headers(host=None):
    origin = ''
    try:
        parsed = urllib.parse.urlparse(host or '')
        if parsed.scheme and parsed.netloc:
            origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        origin = ''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/xml,text/xml,*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'close',
    }
    if origin:
        headers['Origin'] = origin
        headers['Referer'] = origin + '/'
    return headers


def build_epg_urls():
    host, user, password = get_credentials()
    if not host or not user or not password:
        return []
    params = urllib.parse.urlencode({'username': user, 'password': password})
    return [
        ('xmltv.php', '{}/xmltv.php?{}'.format(host, params)),
        ('epg.php', '{}/epg.php?{}'.format(host, params)),
    ]


def build_epg_url():
    urls = build_epg_urls()
    return urls[0][1] if urls else ''


def epg_xml_fresh():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta.get('fingerprint') != epg_fingerprint():
        return False
    fetched_at = int(meta.get('fetched_at') or 0)
    if not fetched_at or (time.time() - fetched_at) >= EPG_XML_TTL:
        return False
    try:
        return os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128
    except Exception:
        return False


def epg_index_needs_rebuild(index=None, preventive=True):
    index = index if isinstance(index, dict) else safe_read_json(EPG_XML_INDEX_FILE, {})
    if index.get('version') != EPG_XML_INDEX_VERSION:
        return True
    if index.get('fingerprint') != epg_fingerprint():
        return True
    generated_at = int(index.get('generated_at') or 0)
    if not generated_at or (time.time() - generated_at) >= EPG_XML_TTL:
        return True

    channels = index.get('channels')
    if not isinstance(channels, dict) or not channels:
        return True

    now_ts = int(time.time())
    window_start = int(index.get('window_start') or 0)
    window_end = int(index.get('window_end') or 0)
    if window_start and now_ts < window_start:
        return True
    if window_end and now_ts > window_end:
        return True
    if preventive and window_end and now_ts >= (window_end - EPG_INDEX_PREVENTIVE_MARGIN):
        return True

    return False


def epg_index_fresh():
    return not epg_index_needs_rebuild(preventive=False)


def normalize_epg_channel_id(value):
    return str(value or '').strip().lower()


def parse_xmltv_time(value):
    value = str(value or '').strip()
    if not value:
        return 0
    try:
        main = value.split(' ', 1)[0].strip()
        tz = value.split(' ', 1)[1].strip() if ' ' in value else ''
        if len(main) >= 14 and main[:14].isdigit():
            dt = datetime.datetime.strptime(main[:14], '%Y%m%d%H%M%S')
            if tz and len(tz) >= 5 and tz[0] in '+-' and tz[1:5].isdigit():
                sign = 1 if tz[0] == '+' else -1
                offset = sign * (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60)
                return int(dt.replace(tzinfo=datetime.timezone(datetime.timedelta(seconds=offset))).timestamp())
            return int(time.mktime(dt.timetuple()))
        if 'T' in value:
            return int(datetime.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())
    except Exception:
        return 0
    return 0


def xml_child_text(element, child_name):
    try:
        child = element.find(child_name)
        if child is not None and child.text:
            return child.text.strip()
    except Exception:
        pass
    try:
        for child in list(element):
            tag = str(child.tag or '').split('}', 1)[-1]
            if tag == child_name and child.text:
                return child.text.strip()
    except Exception:
        pass
    return ''


def download_epg_xml():
    urls = build_epg_urls()
    if not urls:
        return False

    last_error = ''
    for label, url in urls:
        try:
            response = requests.get(url, timeout=60, headers=get_browser_headers(get_credentials()[0]), allow_redirects=True)
            if response.status_code != 200 or not response.content:
                last_error = 'HTTP {} em {}'.format(response.status_code, label)
                log('EPG background: {}'.format(last_error), xbmc.LOGWARNING)
                continue

            content = response.content
            sample = content[:512].lower()
            if b'<tv' not in sample and b'<xmltv' not in sample and b'<epg' not in sample:
                last_error = '{} não parece XMLTV'.format(label)
                log('EPG background rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue

            tmp_path = EPG_XML_FILE + '.tmp'
            with open(tmp_path, 'wb') as file_obj:
                file_obj.write(content)
            try:
                if os.path.exists(EPG_XML_FILE):
                    os.remove(EPG_XML_FILE)
            except Exception:
                pass
            os.rename(tmp_path, EPG_XML_FILE)

            safe_write_json(EPG_XML_META_FILE, {
                'fingerprint': epg_fingerprint(),
                'fetched_at': int(time.time()),
                'size': len(content),
                'source': label,
            })

            try:
                if os.path.exists(EPG_XML_INDEX_FILE):
                    os.remove(EPG_XML_INDEX_FILE)
            except Exception:
                pass

            log('EPG background: XMLTV baixado via {} para o login atual ({} bytes).'.format(label, len(content)))
            return True
        except Exception as exc:
            last_error = '{}: {}'.format(label, exc)
            log('EPG background: falha em {}: {}'.format(label, exc), xbmc.LOGWARNING)

    if last_error:
        log('EPG background: falha geral XMLTV: {}'.format(last_error), xbmc.LOGWARNING)
    return False


def build_epg_index():
    if not os.path.exists(EPG_XML_FILE):
        return False

    now_ts = int(time.time())
    start_day = datetime.datetime.fromtimestamp(now_ts).replace(hour=0, minute=0, second=0, microsecond=0)
    window_start = int(start_day.timestamp()) - 3600
    window_end = int((start_day + datetime.timedelta(days=2)).timestamp()) + 3600

    channels = {}
    total = 0
    try:
        for event, elem in ET.iterparse(EPG_XML_FILE, events=('end',)):
            tag = str(elem.tag or '').split('}', 1)[-1]
            if tag != 'programme':
                if tag not in ('title', 'desc'):
                    try:
                        elem.clear()
                    except Exception:
                        pass
                continue

            cid = normalize_epg_channel_id(elem.get('channel'))
            start = parse_xmltv_time(elem.get('start'))
            end = parse_xmltv_time(elem.get('stop') or elem.get('end'))
            if end <= start:
                end = start + 3600

            if cid and start > 0 and not (end < window_start or start > window_end):
                title = xml_child_text(elem, 'title')
                desc = xml_child_text(elem, 'desc')
                if title:
                    channels.setdefault(cid, []).append({
                        'start': start,
                        'end': end,
                        'title': title,
                        'desc': desc,
                    })
                    total += 1

            try:
                elem.clear()
            except Exception:
                pass

        for cid in list(channels.keys()):
            channels[cid].sort(key=lambda item: item.get('start') or 0)

        safe_write_json(EPG_XML_INDEX_FILE, {
            'version': EPG_XML_INDEX_VERSION,
            'fingerprint': epg_fingerprint(),
            'generated_at': int(time.time()),
            'window_start': window_start,
            'window_end': window_end,
            'channels': channels,
        })
        log('EPG background: índice pronto. canais={}, programas={}'.format(len(channels), total))
        return True
    except Exception as exc:
        log('EPG background: erro criando índice: {}'.format(exc), xbmc.LOGWARNING)
        return False


def ensure_epg_preloaded(reason='watchdog'):
    if not has_credentials():
        return False

    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta and meta.get('fingerprint') != epg_fingerprint():
        clear_epg_cache('login/servidor alterado')

    xml_ok = epg_xml_fresh()
    index = safe_read_json(EPG_XML_INDEX_FILE, {})
    index_needs_rebuild = epg_index_needs_rebuild(index, preventive=True)

    if xml_ok and not index_needs_rebuild:
        return True

    log('EPG watchdog: verificação acionada ({}) xml_ok={} index_rebuild={}'.format(reason, xml_ok, index_needs_rebuild), xbmc.LOGINFO)

    if not xml_ok:
        if not download_epg_xml():
            log('EPG watchdog: XMLTV indisponível; mantendo cache anterior se existir.', xbmc.LOGWARNING)
            return False

    if epg_index_needs_rebuild(preventive=True):
        return bool(build_epg_index())

    return True


class EPGBackgroundWorker:
    def __init__(self, monitor):
        self.monitor = monitor
        self.thread = None
        self.last_watchdog = 0
        self.last_fingerprint = ''

    def start(self):
        self.thread = threading.Thread(target=self.run)
        self.thread.daemon = True
        self.thread.start()

    def force_next_check(self):
        self.last_watchdog = 0

    def run(self):
        # Pequeno atraso para não brigar com boot do Kodi/proxy.
        self.monitor.waitForAbort(3)

        while not self.monitor.abortRequested():
            try:
                current_fp = epg_fingerprint()

                # Troca de login/servidor precisa ser detectada rápido,
                # mas sem baixar EPG toda hora.
                if current_fp != self.last_fingerprint:
                    if self.last_fingerprint:
                        clear_epg_cache('login/servidor alterado em background')
                    self.last_fingerprint = current_fp
                    self.force_next_check()

                now = time.time()

                # Watchdog real: checagem técnica a cada 1 hora.
                # A primeira execução no boot roda imediatamente.
                if now - self.last_watchdog >= EPG_WATCHDOG_INTERVAL:
                    self.last_watchdog = now
                    ensure_epg_preloaded('watchdog_1h')

            except Exception as exc:
                log('EPG watchdog: erro geral: {}'.format(exc), xbmc.LOGWARNING)

            # Loop leve: detecta troca de login rápido, mas só faz checagem pesada a cada 1h.
            if self.monitor.waitForAbort(30):
                break


class XCProServiceMonitor(xbmc.Monitor):
    def __init__(self):
        xbmc.Monitor.__init__(self)
        self.settings_changed = False

    def onSettingsChanged(self):
        self.settings_changed = True
        log('Configurações alteradas; verificando portas/EPG dos serviços.')


class ServiceRuntime:
    def __init__(self, monitor):
        self.monitor = monitor
        self.proxy = None
        self.proxy_thread = None
        self.webserver = None
        self.webserver_thread = None
        self.current_ports = (None, None)
        self.epg_worker = EPGBackgroundWorker(monitor)

    def start(self):
        proxy_port, webserver_port = get_ports()
        self.current_ports = (proxy_port, webserver_port)
        self.start_proxy(proxy_port)
        self.start_webserver(webserver_port)
        self.epg_worker.start()

    def start_proxy(self, port):
        try:
            self.proxy = UnifiedServer(port)
            self.proxy_thread = threading.Thread(target=self.proxy.start, args=(self.monitor,))
            self.proxy_thread.daemon = True
            self.proxy_thread.start()
            log('Proxy local iniciado na porta {}'.format(port))
        except Exception as exc:
            log('Falha ao iniciar proxy: {}'.format(exc), xbmc.LOGERROR)

    def start_webserver(self, port):
        try:
            self.webserver = PairingWebServer(port, self.monitor)
            self.webserver_thread = threading.Thread(target=self.webserver.start)
            self.webserver_thread.daemon = True
            self.webserver_thread.start()
            log('Pareamento iniciado na porta {}'.format(port))
        except Exception as exc:
            log('Falha ao iniciar pareamento: {}'.format(exc), xbmc.LOGERROR)

    def stop(self):
        try:
            if self.proxy:
                self.proxy.stop()
        except Exception:
            pass
        try:
            if self.webserver:
                self.webserver.stop()
        except Exception:
            pass
        self.proxy = None
        self.webserver = None

    def restart_if_ports_changed(self):
        new_ports = get_ports()
        if new_ports == self.current_ports:
            return
        log('Portas alteradas de {} para {}; reiniciando serviços.'.format(self.current_ports, new_ports))
        self.stop()
        # Pequena janela para liberar sockets.
        self.monitor.waitForAbort(0.5)
        self.current_ports = new_ports
        self.start_proxy(new_ports[0])
        self.start_webserver(new_ports[1])


def main():
    monitor = XCProServiceMonitor()
    runtime = ServiceRuntime(monitor)
    runtime.start()

    while not monitor.abortRequested():
        if monitor.settings_changed:
            monitor.settings_changed = False
            runtime.restart_if_ports_changed()
            try:
                runtime.epg_worker.force_next_check()
            except Exception:
                pass
        if monitor.waitForAbort(1):
            break

    log('Encerrando serviço.')
    runtime.stop()


if __name__ == '__main__':
    main()
