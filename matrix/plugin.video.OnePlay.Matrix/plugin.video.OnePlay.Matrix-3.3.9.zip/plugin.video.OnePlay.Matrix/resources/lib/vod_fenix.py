# -*- coding: utf-8 -*-
from __future__ import unicode_literals

"""Provider VOD adicional por IMDb, isolado do FrostStream.

A fonte foi integrada a partir do contrato observado no ``stream_telegram.py``
fornecido para a Matrix. Este módulo faz somente descoberta/normalização:
reprodução, Range, HLS/DASH, legendas e Stop continuam sob o pipeline VOD já
homologado da Matrix.

Contrato conservador desta primeira integração:
* consulta somente IMDb exato;
* uma única requisição, sem retry automático;
* no máximo uma fonte válida por filme/episódio, preservando o script original;
* somente URLs ``http/https`` com ``/stream/`` em hosts koyeb.app/discloud.app;
* reescrita para o relay declarado pelo script original;
* falha desta fonte nunca invalida as fontes FrostStream.
"""

import re
import time
try:
    from urllib.parse import urlparse
except ImportError:  # pragma: no cover
    from urlparse import urlparse

try:
    import requests as _requests
except Exception:  # pragma: no cover
    _requests = None

try:
    from resources.lib import cache_store as _cache_store
except Exception:  # pragma: no cover
    _cache_store = None


FENIX_API_ROOT = (
    'https://fenixflix.fenixhub.online/'
    'qualities=4k,1080p,720p,sd,cam%7Caudio=dublado,legendado%7C'
    'catalogs=populares_movie,populares_series,recentes_movie,recentes_series'
)
FENIX_RELAY_ROOT = 'https://passing-melinda-onomed1-d0cbec40.koyeb.app'
FENIX_PROVIDER_NAME = 'FenixFlix'
USER_AGENT = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/151.0.0.0 Safari/537.36'
)
REQUEST_TIMEOUT = (2.0, 4.0)
IMDB_RE = re.compile(r'^tt\d{5,}$', re.I)
ALLOWED_SOURCE_SUFFIXES = ('koyeb.app', 'discloud.app')
MAX_STREAM_PATH = 4096
MAX_STREAM_QUERY = 2048
HEALTH_NAMESPACE = 'vod_fenix_provider_health_v1'
HEALTH_KEY = 'cooldown'
NETWORK_COOLDOWN_SECONDS = 30
RATE_LIMIT_COOLDOWN_SECONDS = 60
SERVER_COOLDOWN_SECONDS = 30


class FenixVodProvider(object):
    """Resolvedor pequeno e testável, sem dependência do Kodi."""

    def __init__(self, requests_module=None, cache_api=None, logger=None, clock=None,
                 api_root=FENIX_API_ROOT, relay_root=FENIX_RELAY_ROOT):
        self.requests = requests_module or _requests
        self.cache = cache_api if cache_api is not None else _cache_store
        self.logger = logger
        self.clock = clock or time.time
        self.api_root = (api_root or FENIX_API_ROOT).rstrip('/')
        self.relay_root = (relay_root or FENIX_RELAY_ROOT).rstrip('/')

    def _log(self, message, level=1):
        if self.logger is None:
            return
        try:
            self.logger(message, level)
        except TypeError:
            try:
                self.logger(message)
            except Exception:
                pass
        except Exception:
            pass

    @staticmethod
    def _valid_imdb(imdb_id):
        return bool(IMDB_RE.match((imdb_id or '').strip()))

    @staticmethod
    def _host_allowed(host):
        host = (host or '').strip().lower().rstrip('.')
        if not host:
            return False
        for suffix in ALLOWED_SOURCE_SUFFIXES:
            if host == suffix or host.endswith('.' + suffix):
                return True
        return False

    def _cooldown_state(self):
        if self.cache is None:
            return ''
        try:
            record = self.cache.get_record(HEALTH_NAMESPACE, HEALTH_KEY)
            if record and self.cache.is_fresh(record, int(self.clock())):
                value = record.get('value') or {}
                return str(value.get('reason') or 'cooldown')
        except Exception:
            pass
        return ''

    def _remember_cooldown(self, reason, ttl):
        if self.cache is None:
            return
        try:
            self.cache.set_record(
                HEALTH_NAMESPACE, HEALTH_KEY,
                {'reason': str(reason or 'provider-indisponivel')},
                max(1, int(ttl or NETWORK_COOLDOWN_SECONDS))
            )
        except Exception:
            pass

    @staticmethod
    def _language_label(raw_stream):
        if not isinstance(raw_stream, dict):
            return ''
        text = ' '.join(str(raw_stream.get(key) or '') for key in (
            'description', 'name', 'title'
        )).lower()
        dubbed = 'dublado' in text or re.search(r'(^|[^a-z0-9])dub([^a-z0-9]|$)', text)
        subtitled = 'legendado' in text or re.search(r'(^|[^a-z0-9])leg([^a-z0-9]|$)', text)
        if dubbed and subtitled:
            return 'Dublado / Legendado'
        if dubbed:
            return 'Dublado'
        if subtitled:
            return 'Legendado'
        return ''

    @staticmethod
    def _infer_kind(raw_stream, source_url, relay_url):
        values = [source_url or '', relay_url or '']
        if isinstance(raw_stream, dict):
            values.extend(str(raw_stream.get(key) or '') for key in (
                'name', 'title', 'description', 'type'
            ))
        probe = ' '.join(values).lower()
        if '.m3u8' in probe or re.search(r'(^|[^a-z0-9])hls([^a-z0-9]|$)', probe):
            return 'hls'
        if '.mpd' in probe or 'dash' in probe:
            return 'dash'
        if any(ext in probe for ext in ('.mp4', '.mkv', '.webm', '.avi', '.mov', '.m4v', '.ts')):
            return 'progressive'
        return 'unknown'

    def _rewrite_stream_url(self, source_url):
        try:
            parsed = urlparse((source_url or '').strip())
        except Exception:
            return ''
        if (parsed.scheme or '').lower() not in ('http', 'https'):
            return ''
        if not self._host_allowed(parsed.hostname):
            return ''
        path = parsed.path or ''
        marker = '/stream/'
        pos = path.find(marker)
        if pos < 0:
            return ''
        remainder = path[pos + len(marker):]
        if not remainder or len(remainder) > MAX_STREAM_PATH:
            return ''
        query = parsed.query or ''
        if len(query) > MAX_STREAM_QUERY:
            return ''
        rewritten = self.relay_root + marker + remainder.lstrip('/')
        if query:
            rewritten += '?' + query
        return rewritten

    def _build_api_url(self, media_type, imdb_id, season=None, episode=None):
        imdb_id = (imdb_id or '').strip()
        if not self._valid_imdb(imdb_id):
            return ''
        if media_type == 'movie':
            return '{}/stream/movie/{}.json'.format(self.api_root, imdb_id)
        if media_type != 'series':
            return ''
        try:
            season_value = int(season)
            episode_value = int(episode)
        except Exception:
            return ''
        if season_value < 0 or episode_value < 1:
            return ''
        return '{}/stream/series/{}:{}:{}.json'.format(
            self.api_root, imdb_id, season_value, episode_value
        )

    def _normalize_first_stream(self, raw_streams, imdb_id):
        if not isinstance(raw_streams, list):
            return None, 'streams-invalidos'
        rejected = 0
        for raw in raw_streams:
            if not isinstance(raw, dict):
                rejected += 1
                continue
            source_url = str(raw.get('url') or '').strip()
            relay_url = self._rewrite_stream_url(source_url)
            if not relay_url:
                rejected += 1
                continue
            language = self._language_label(raw)
            raw_name = str(raw.get('name') or '').strip()
            raw_title = str(raw.get('title') or '').strip()
            raw_description = str(raw.get('description') or '').strip()
            readable = ' '.join(piece for piece in (
                raw_name, raw_title, raw_description, language
            ) if piece).strip()
            kind = self._infer_kind(raw, source_url, relay_url)
            try:
                relay_host = (urlparse(relay_url).hostname or '').lower()
            except Exception:
                relay_host = ''
            item = {
                'name': readable or FENIX_PROVIDER_NAME,
                'title': raw_title or raw_name or FENIX_PROVIDER_NAME,
                'description': readable or FENIX_PROVIDER_NAME,
                'url': relay_url,
                '__vod_kind': kind,
                '__vod_source_family': 'Relay',
                '__vod_source_host': relay_host,
                '__vod_playable': True,
                '__vod_caution': kind == 'unknown',
                '__vod_caution_reasons': ('link-opaco',) if kind == 'unknown' else (),
                '__vod_raw_title': raw_title,
                '__vod_raw_name': raw_name,
                '__vod_target_type': 'url',
                '__vod_target_value': relay_url,
                '__request_rank': 50,
                '__request_label': 'fenix-imdb',
                '__vod_provider_id': imdb_id,
                '__vod_provider_id_kind': 'imdb',
                '__vod_provider': FENIX_PROVIDER_NAME,
                '__vod_request_headers': {'User-Agent': USER_AGENT},
            }
            return item, 'ok'
        return None, 'sem-stream-compativel' if rejected else 'sem-stream'

    def resolve(self, media_type, imdb_id, season=None, episode=None):
        """Retorna estrutura neutra ``streams/reason/audit`` para o agregador."""
        api_url = self._build_api_url(media_type, imdb_id, season, episode)
        if not api_url:
            return {'streams': [], 'reason': 'IMDb/episódio inválido ou ausente', 'audit': ['sem-id']}
        if self.requests is None:
            return {'streams': [], 'reason': 'cliente HTTP indisponível', 'audit': ['sem-http']}

        cooldown = self._cooldown_state()
        if cooldown:
            self._log('VOD FenixFlix em cooldown temporário: {}.'.format(cooldown), 1)
            return {'streams': [], 'reason': 'fonte extra temporariamente em cooldown', 'audit': ['cooldown']}

        response = None
        try:
            response = self.requests.get(
                api_url,
                headers={'User-Agent': USER_AGENT, 'Accept': 'application/json'},
                timeout=REQUEST_TIMEOUT,
            )
            status = int(getattr(response, 'status_code', 0) or 0)
            if status != 200:
                if status == 429:
                    self._remember_cooldown('http-429', RATE_LIMIT_COOLDOWN_SECONDS)
                elif status >= 500 or status <= 0:
                    self._remember_cooldown('http-{}'.format(status or 'erro'), SERVER_COOLDOWN_SECONDS)
                return {
                    'streams': [],
                    'reason': 'fonte extra respondeu HTTP {}'.format(status or 'desconhecido'),
                    'audit': ['http-{}'.format(status or 'erro')],
                }
            try:
                payload = response.json()
            except Exception:
                return {'streams': [], 'reason': 'resposta JSON inválida', 'audit': ['json-invalido']}
            if not isinstance(payload, dict):
                return {'streams': [], 'reason': 'resposta fora do contrato', 'audit': ['payload-invalido']}
            item, outcome = self._normalize_first_stream(payload.get('streams'), (imdb_id or '').strip())
            if item is None:
                return {'streams': [], 'reason': 'nenhuma fonte extra compatível agora', 'audit': [outcome]}
            self._log('VOD FenixFlix resolveu {} por IMDb: 1 fonte extra.'.format(media_type), 1)
            return {'streams': [item], 'reason': '', 'audit': ['imdb=1']}
        except Exception as exc:
            self._remember_cooldown(exc.__class__.__name__, NETWORK_COOLDOWN_SECONDS)
            self._log('VOD FenixFlix indisponível nesta consulta: {}.'.format(exc.__class__.__name__), 1)
            return {
                'streams': [],
                'reason': 'fonte extra indisponível nesta consulta',
                'audit': ['erro-rede:{}'.format(exc.__class__.__name__)],
            }
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


_DEFAULT_PROVIDER = None


def get_default_provider():
    global _DEFAULT_PROVIDER
    if _DEFAULT_PROVIDER is None:
        def _kodi_log(message, level=1):
            try:
                from resources.lib.common import log, log_debug
                log('[VOD Extra] {}'.format(message), level=level)
                log_debug(message, component='FenixFlix')
            except Exception:
                pass
        _DEFAULT_PROVIDER = FenixVodProvider(logger=_kodi_log)
    return _DEFAULT_PROVIDER


def reset_default_provider_for_tests():
    global _DEFAULT_PROVIDER
    _DEFAULT_PROVIDER = None
