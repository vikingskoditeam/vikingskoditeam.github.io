# -*- coding: utf-8 -*-
import base64
import json
import socket
import threading
import time
import urllib.parse
from collections import OrderedDict, deque

import requests

try:
    import xbmc
except ImportError:
    from kodi_six import xbmc

try:
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from socketserver import ThreadingMixIn
except ImportError:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer  # type: ignore
    from SocketServer import ThreadingMixIn  # type: ignore

PORT = 8088
DEFAULT_USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36'
SERVER_NAME = 'OnePlayProxy/2.1'
_SERVER = None
_SERVER_THREAD = None

_PROXY_POLICY = {
    'hls_max_retries': 10,
    'timeout_connect': 6,
    'timeout_read': 18,
    'cooldown_base': 0.20,
    'cache_chunks': 24,
    'cache_replay_chunks': 8,
    'chunk_size': 65536,
    'playlist_cache_age': 10.0,
    'segment_cache_age': 35.0,
    'segment_cache_items': 16,
    'segment_cache_item_bytes': 2621440,
    'segment_cache_total_bytes': 25165824,
    'segment_min_cache_bytes': 131072,
    'ts_keepalive_bursts': 5,
    'ts_keepalive_packets': 24,
    'ts_keepalive_sleep': 0.08,
}

_SESSION_CACHE = {
    'good_hosts': {},
    'bad_hosts': {},
    'working_user_agent': {},
    'last_working_url': {},
    'content_type': {},
    'source_profile': {},
}
_ORIGIN_HEALTH = {}
_LOG_THROTTLE = {}
_LOG_BURSTS = {}
_PLAYLIST_CACHE = {}
_SEGMENT_CACHE = OrderedDict()
_SEGMENT_CACHE_TOTAL_BYTES = [0]
_SEGMENT_CACHE_LOCK = threading.Lock()

_NULL_TS_PACKET = b"\x47\x1f\xff\x10" + (b"\xff" * 184)


def _log(message, level=None):
    try:
        xbmc.log('[OnePlayProxy] ' + str(message), level=level or xbmc.LOGINFO)
    except Exception:
        pass


def _safe_text(value):
    try:
        return str(value)
    except Exception:
        try:
            return repr(value)
        except Exception:
            return 'erro_desconhecido'


def _throttled_log(key, interval, level, message):
    now = time.time()
    last = _LOG_THROTTLE.get(key, 0)
    if (now - last) >= interval:
        _LOG_THROTTLE[key] = now
        _log(message, level=level)


def _burst_log(key, window, level, template):
    now = time.time()
    item = _LOG_BURSTS.get(key)
    if not item or (now - item['start']) > window:
        item = {'start': now, 'count': 0}
    item['count'] += 1
    _LOG_BURSTS[key] = item
    if item['count'] == 1:
        _log(template % 1, level=level)
    elif item['count'] in (5, 15, 30) or (now - item['start']) >= window:
        _log(template % item['count'], level=level)
        item['start'] = now
        item['count'] = 0


def _policy(key):
    return _PROXY_POLICY.get(key)


def _decode_header_blob(value):
    value = (value or '').strip()
    if not value:
        return {}
    try:
        padded = value + ('=' * (-len(value) % 4))
        payload = base64.urlsafe_b64decode(padded.encode('ascii')).decode('utf-8')
        data = json.loads(payload)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _is_valid_upstream_url(url):
    try:
        parsed = urllib.parse.urlparse(url or '')
        if (parsed.scheme or '').lower() not in ('http', 'https'):
            return False
        host = (parsed.hostname or '').strip().lower()
        if not host or host in ('127.0.0.1', 'localhost', '::1'):
            return False
        if host.startswith(('169.254.', '0.')):
            return False
        return True
    except Exception:
        return False


def _host_from_url(url):
    try:
        return urllib.parse.urlparse(url).netloc.lower()
    except Exception:
        return ''


def _classify_source(url):
    try:
        parsed = urllib.parse.urlparse(url or '')
        path = (parsed.path or '').lower()
        query = (parsed.query or '').lower()
    except Exception:
        path = ''
        query = ''
    is_ts = path.endswith('.ts') or '/hls/' in path or '/hl' in path
    is_m3u8 = path.endswith('.m3u8') or 'mpegurl' in query
    tokenized = 'token=' in query or 'wmsauth' in query or 'auth=' in query
    is_xtream = '/live/' in path or '/hls/' in path or '/movie/' in path or '/series/' in path or tokenized
    if is_xtream and (is_ts or is_m3u8) and tokenized:
        return 'xtream_bad'
    if is_xtream:
        return 'xtream_good'
    if is_m3u8:
        return 'hls_generic'
    if is_ts:
        return 'ts_generic'
    return 'generic'


def _source_profile(url):
    host = _host_from_url(url)
    return _SESSION_CACHE['source_profile'].get(host) or _classify_source(url)


def _remember_source_profile(url, profile=None):
    host = _host_from_url(url)
    if host:
        _SESSION_CACHE['source_profile'][host] = profile or _classify_source(url)


def _host_stats(host):
    item = _SESSION_CACHE['good_hosts'].get(host)
    if item is None:
        item = {'success_count': 0, 'fail_count': 0, 'cooldown_until': 0, 'last_error': '', 'last_success': 0}
        _SESSION_CACHE['good_hosts'][host] = item
    return item


def _host_is_available(host):
    return not host or time.time() >= _host_stats(host).get('cooldown_until', 0)


def _host_backoff(host):
    if not host:
        return
    wait = _host_stats(host).get('cooldown_until', 0) - time.time()
    if wait > 0:
        time.sleep(min(0.8, wait))


def _mark_host_ok(host, final_url=None, user_agent=None, content_type=None):
    if not host:
        return
    item = _host_stats(host)
    item['success_count'] = item.get('success_count', 0) + 1
    item['fail_count'] = 0
    item['cooldown_until'] = 0
    item['last_error'] = ''
    item['last_success'] = time.time()
    _SESSION_CACHE['bad_hosts'].pop(host, None)
    if final_url:
        _SESSION_CACHE['last_working_url'][host] = final_url
    if user_agent:
        _SESSION_CACHE['working_user_agent'][host] = user_agent
    if content_type:
        _SESSION_CACHE['content_type'][host] = content_type


def _mark_host_fail(host, err='unknown', soft=False):
    if not host:
        return
    item = _host_stats(host)
    item['fail_count'] = item.get('fail_count', 0) + 1
    item['last_error'] = str(err)
    threshold = 5 if soft else 3
    if item['fail_count'] >= threshold:
        item['cooldown_until'] = time.time() + min(3.0, _policy('cooldown_base') * item['fail_count'])
        _SESSION_CACHE['bad_hosts'][host] = item['cooldown_until']


def _origin_key(url):
    try:
        p = urllib.parse.urlparse(url)
        return '%s://%s' % (p.scheme or 'http', p.netloc or '')
    except Exception:
        return url or 'unknown'


def _origin_state(url):
    key = _origin_key(url)
    state = _ORIGIN_HEALTH.get(key)
    now = time.time()
    if not state or (now - state.get('updated', 0)) > 180:
        state = {
            'updated': now,
            'fail_count': 0,
            '406_count': 0,
            'timeout_count': 0,
            'good_count': 0,
            'cooldown_until': 0,
            'last_error': '',
        }
        _ORIGIN_HEALTH[key] = state
    return state


def _mark_origin_ok(url):
    state = _origin_state(url)
    state['updated'] = time.time()
    state['good_count'] = state.get('good_count', 0) + 1
    state['fail_count'] = 0
    state['406_count'] = 0
    state['timeout_count'] = 0
    state['last_error'] = ''
    state['cooldown_until'] = 0


def _mark_origin_fail(url, code=None, exc_name=None):
    state = _origin_state(url)
    state['updated'] = time.time()
    state['fail_count'] = state.get('fail_count', 0) + 1
    if code == 406:
        state['406_count'] = state.get('406_count', 0) + 1
    if exc_name in ('ReadTimeout', 'ConnectionError', 'ChunkedEncodingError'):
        state['timeout_count'] = state.get('timeout_count', 0) + 1
    state['last_error'] = str(code or exc_name or 'unknown')
    if state['fail_count'] >= 6:
        state['cooldown_until'] = time.time() + min(2.0, _policy('cooldown_base') * state['fail_count'])


def _apply_origin_cooldown(url):
    state = _origin_state(url)
    now = time.time()
    cooldown_until = state.get('cooldown_until', 0)
    if cooldown_until > now:
        time.sleep(min(0.75, cooldown_until - now))


def _pick_user_agent(host, reconnects=0):
    cached = _SESSION_CACHE['working_user_agent'].get(host)
    if cached and reconnects <= 1:
        return cached
    pool = [
        DEFAULT_USER_AGENT,
        'Mozilla/5.0 (Linux; Android 10; SM-A505G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:133.0) Gecko/20100101 Firefox/133.0',
        'ExoPlayerLib/2.18.7',
    ]
    idx = reconnects % len(pool)
    return pool[idx]


def _smart_retry_delay(err_kind, attempt):
    if err_kind == '406':
        return min(0.45, 0.08 * max(1, attempt))
    if err_kind == 'timeout':
        return min(1.0, 0.20 * max(1, attempt))
    if err_kind == 'connection':
        return min(0.8, 0.16 * max(1, attempt))
    return min(0.75, 0.14 * max(1, attempt))


def _request_headers(handler, forwarded_headers=None, url='', reconnects=0, response_code=None):
    headers = {
        'User-Agent': DEFAULT_USER_AGENT,
        'Accept': '*/*',
        'Accept-Encoding': 'identity',
        'Connection': 'close',
    }
    blocked = {'host', 'connection', 'content-length', 'accept-encoding'}
    try:
        for key, value in (forwarded_headers or {}).items():
            lk = (key or '').lower()
            if lk in blocked:
                continue
            headers[key] = value
    except Exception:
        pass
    try:
        for key, value in handler.headers.items():
            lk = key.lower()
            if lk in blocked:
                continue
            headers.setdefault(key, value)
    except Exception:
        pass

    profile = _source_profile(url)
    host = _host_from_url(url)
    headers['User-Agent'] = _pick_user_agent(host, reconnects)
    if reconnects > 0:
        headers['Connection'] = 'close'
        headers['Cache-Control'] = 'no-cache'
        headers['Pragma'] = 'no-cache'
    if profile in ('xtream_bad', 'xtream_good', 'hls_generic', 'ts_generic'):
        headers['Accept'] = '*/*'
        headers['Accept-Encoding'] = 'identity'
    if response_code == 406:
        for noisy in ('Accept', 'Accept-Language', 'Origin', 'Referer', 'Sec-Fetch-Dest', 'Sec-Fetch-Mode', 'Sec-Fetch-Site'):
            headers.pop(noisy, None)
        headers['Accept'] = '*/*'
        headers['Connection'] = 'close'
    if profile == 'xtream_bad':
        headers.pop('Range', None)
        headers.pop('If-None-Match', None)
        headers.pop('If-Modified-Since', None)
    return headers


def _validate_upstream_response(response, expect_playlist=False, expect_stream=False, url=''):
    try:
        ctype = (response.headers.get('content-type') or '').lower()
    except Exception:
        ctype = ''
    if response.status_code not in (200, 206):
        return False, ctype
    if 'text/html' in ctype and not expect_playlist:
        return False, ctype
    if expect_stream and ('json' in ctype or 'xml' in ctype):
        return False, ctype
    profile = _source_profile(url)
    if expect_stream and profile == 'xtream_bad':
        if not ctype or 'application/octet-stream' in ctype or 'video/' in ctype or 'audio/' in ctype or 'text/plain' in ctype:
            return True, ctype or 'application/octet-stream'
    return True, ctype


def _looks_like_playlist(url, content_type):
    ctype = (content_type or '').lower()
    target = (url or '').lower()
    return '.m3u8' in target or 'mpegurl' in ctype or 'x-mpegurl' in ctype or 'application/vnd.apple.mpegurl' in ctype


def _is_ts_like_url(url):
    lower = (url or '').lower()
    return lower.endswith('.ts') or '/hl' in lower or '/hls/' in lower or lower.endswith('.m2ts')


def _is_segment_like(url, content_type=''):
    lower = (url or '').lower()
    ctype = (content_type or '').lower()
    return (
        _is_ts_like_url(lower)
        or lower.endswith('.m4s')
        or lower.endswith('.aac')
        or lower.endswith('.mp4')
        or 'video/' in ctype
        or 'audio/' in ctype
    ) and not _looks_like_playlist(lower, ctype)


def _null_ts_chunk(packet_count=None):
    packets = int(packet_count or _policy('ts_keepalive_packets') or 24)
    packets = max(1, min(256, packets))
    return _NULL_TS_PACKET * packets


def _playlist_cache_put(original_url, final_url, playlist_text):
    now = time.time()
    item = {'text': playlist_text, 'updated': now}
    if original_url:
        _PLAYLIST_CACHE[original_url] = item
    if final_url and final_url != original_url:
        _PLAYLIST_CACHE[final_url] = item


def _playlist_cache_get(url):
    if not url:
        return None
    item = _PLAYLIST_CACHE.get(url)
    if not item:
        return None
    if (time.time() - item.get('updated', 0)) > float(_policy('playlist_cache_age') or 10.0):
        return None
    return item.get('text')


def _segment_cache_trim_locked():
    max_items = int(_policy('segment_cache_items') or 16)
    max_total = int(_policy('segment_cache_total_bytes') or 25165824)
    while len(_SEGMENT_CACHE) > max_items or _SEGMENT_CACHE_TOTAL_BYTES[0] > max_total:
        _, victim = _SEGMENT_CACHE.popitem(last=False)
        _SEGMENT_CACHE_TOTAL_BYTES[0] = max(0, _SEGMENT_CACHE_TOTAL_BYTES[0] - int(victim.get('size', 0) or 0))


def _segment_cache_put(url, chunks, media_type):
    if not url or not chunks:
        return
    size = sum(len(chunk) for chunk in chunks)
    if size < int(_policy('segment_min_cache_bytes') or 131072):
        return
    if size > int(_policy('segment_cache_item_bytes') or 2621440):
        return
    item = {
        'chunks': [bytes(chunk) for chunk in chunks],
        'media_type': media_type or 'video/mp2t',
        'updated': time.time(),
        'size': size,
    }
    with _SEGMENT_CACHE_LOCK:
        old = _SEGMENT_CACHE.pop(url, None)
        if old:
            _SEGMENT_CACHE_TOTAL_BYTES[0] = max(0, _SEGMENT_CACHE_TOTAL_BYTES[0] - int(old.get('size', 0) or 0))
        _SEGMENT_CACHE[url] = item
        _SEGMENT_CACHE_TOTAL_BYTES[0] += size
        _segment_cache_trim_locked()


def _segment_cache_get(url):
    if not url:
        return None
    with _SEGMENT_CACHE_LOCK:
        item = _SEGMENT_CACHE.get(url)
        if not item:
            return None
        if (time.time() - item.get('updated', 0)) > float(_policy('segment_cache_age') or 35.0):
            stale = _SEGMENT_CACHE.pop(url, None)
            if stale:
                _SEGMENT_CACHE_TOTAL_BYTES[0] = max(0, _SEGMENT_CACHE_TOTAL_BYTES[0] - int(stale.get('size', 0) or 0))
            return None
        _SEGMENT_CACHE.move_to_end(url)
        return {
            'chunks': list(item.get('chunks') or []),
            'media_type': item.get('media_type') or 'video/mp2t',
            'size': int(item.get('size', 0) or 0),
        }


def _rewrite_m3u8_urls(playlist_content, base_url, host, header_blob=''):
    def replace_line(line):
        raw = (line or '').strip()
        if not raw or raw.startswith('#'):
            return line
        absolute_url = urllib.parse.urljoin(base_url + '/', raw)
        if not _is_valid_upstream_url(absolute_url):
            return line
        params = {'url': absolute_url}
        if header_blob:
            params['headers'] = header_blob
        return 'http://%s/hlsretry?%s' % (host, urllib.parse.urlencode(params))

    return '\n'.join(replace_line(line) for line in playlist_content.splitlines())


def _open_upstream(url, handler, forwarded_headers=None, expect_playlist=False, expect_stream=False):
    last_exc = None
    last_status = None
    max_retries = int(_policy('hls_max_retries') or 10)
    for attempt in range(max_retries):
        response = None
        try:
            _apply_origin_cooldown(url)
            headers = _request_headers(handler, forwarded_headers=forwarded_headers, url=url, reconnects=attempt, response_code=last_status)
            host = _host_from_url(url)
            if not _host_is_available(host):
                _host_backoff(host)
            response = requests.get(
                url,
                headers=headers,
                allow_redirects=True,
                stream=True,
                timeout=(float(_policy('timeout_connect') or 6), float(_policy('timeout_read') or 18)),
            )
            ok_response, content_type = _validate_upstream_response(response, expect_playlist=expect_playlist, expect_stream=expect_stream, url=url)
            if ok_response:
                final_url = response.url or url
                _mark_origin_ok(final_url)
                _mark_host_ok(_host_from_url(final_url), final_url=final_url, user_agent=headers.get('User-Agent'), content_type=content_type)
                _remember_source_profile(final_url)
                return response, headers, content_type
            last_status = response.status_code
            _mark_origin_fail(response.url or url, code=response.status_code)
            _mark_host_fail(_host_from_url(response.url or url), err=response.status_code, soft=(response.status_code in (403, 406, 429)))
            if response.status_code == 406:
                _burst_log('hls-406:%s' % _origin_key(url), 60, xbmc.LOGINFO, 'Origem respondeu 406; fallback discreto acionado (%sx).')
                time.sleep(_smart_retry_delay('406', attempt + 1))
            else:
                _throttled_log('hls-status:%s:%s' % (_origin_key(url), response.status_code), 20, xbmc.LOGWARNING, 'Resposta HTTP %s da origem.' % response.status_code)
                if response.status_code in (403, 429, 500, 502, 503, 504):
                    time.sleep(_smart_retry_delay('connection', attempt + 1))
                else:
                    break
        except requests.RequestException as exc:
            last_exc = exc
            _mark_origin_fail(url, exc_name=exc.__class__.__name__)
            _mark_host_fail(_host_from_url(url), err=exc.__class__.__name__, soft=True)
            _throttled_log('hls-exc:%s:%s' % (_origin_key(url), exc.__class__.__name__), 15, xbmc.LOGWARNING, 'Origem instável; retry inteligente em curso (%s).' % _safe_text(exc.__class__.__name__))
            time.sleep(_smart_retry_delay('timeout' if exc.__class__.__name__ in ('ReadTimeout', 'ChunkedEncodingError') else 'connection', attempt + 1))
        finally:
            if response is not None and response.status_code not in (200, 206):
                try:
                    response.close()
                except Exception:
                    pass
    if last_exc:
        raise last_exc
    raise RuntimeError('Falha ao abrir origem')


def _stream_response(response, url='', media_type='application/octet-stream'):
    cache = deque(maxlen=int(_policy('cache_chunks') or 24))
    byte_count = 0
    is_ts_like = _is_ts_like_url(url) or 'video/mp2t' in (media_type or '').lower()
    try:
        for chunk in response.iter_content(chunk_size=int(_policy('chunk_size') or 65536)):
            if not chunk:
                continue
            cache.append(chunk)
            byte_count += len(chunk)
            yield chunk
    except Exception as exc:
        _throttled_log('stream-tail:%s' % _origin_key(url), 10, xbmc.LOGINFO, 'Falha parcial na origem; reaproveitando cauda em cache para segurar a transição.')
        replay = list(cache)[-int(_policy('cache_replay_chunks') or 8):]
        for chunk in replay:
            yield chunk
        if is_ts_like:
            bursts = int(_policy('ts_keepalive_bursts') or 5)
            filler = _null_ts_chunk(int(_policy('ts_keepalive_packets') or 24))
            for _ in range(max(1, bursts)):
                yield filler
                time.sleep(float(_policy('ts_keepalive_sleep') or 0.08))
        _log('Falha parcial no stream: %s' % _safe_text(exc), level=xbmc.LOGDEBUG)
    finally:
        try:
            if _is_segment_like(url, media_type) and byte_count >= int(_policy('segment_min_cache_bytes') or 131072):
                _segment_cache_put(url, list(cache), media_type)
        except Exception:
            pass
        try:
            response.close()
        except Exception:
            pass


class _ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True
    allow_reuse_address = True


class _ProxyHandler(BaseHTTPRequestHandler):
    protocol_version = 'HTTP/1.1'
    server_version = SERVER_NAME
    sys_version = ''

    def log_message(self, format, *args):
        return

    def handle(self):
        try:
            BaseHTTPRequestHandler.handle(self)
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass

    def finish(self):
        try:
            BaseHTTPRequestHandler.finish(self)
        except (ConnectionResetError, BrokenPipeError, OSError):
            pass

    def do_GET(self):
        self._dispatch(head_only=False)

    def do_HEAD(self):
        self._dispatch(head_only=True)

    def _dispatch(self, head_only=False):
        parsed = urllib.parse.urlparse(self.path)
        if parsed.path == '/':
            payload = b'{"message":"OnePlay Proxy hard ativo"}'
            self.send_response(200)
            self.send_header('Content-Type', 'application/json; charset=utf-8')
            self.send_header('Content-Length', str(len(payload)))
            self.send_header('Connection', 'close')
            self.end_headers()
            if not head_only:
                self.wfile.write(payload)
            return
        if parsed.path == '/hlsretry':
            return self._handle_hlsretry(parsed, head_only=head_only)
        self.send_error(404)

    def _send_cached_playlist(self, playlist_text, base_url, header_blob, head_only=False):
        host = self.headers.get('Host', '127.0.0.1:%d' % PORT)
        rewritten = _rewrite_m3u8_urls(playlist_text, base_url, host, header_blob=header_blob).encode('utf-8')
        self.send_response(200)
        self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
        self.send_header('Content-Length', str(len(rewritten)))
        self.send_header('Connection', 'close')
        self.end_headers()
        if not head_only:
            self.wfile.write(rewritten)

    def _send_cached_segment(self, item, head_only=False):
        chunks = list(item.get('chunks') or [])
        total = sum(len(chunk) for chunk in chunks)
        self.send_response(200)
        self.send_header('Content-Type', item.get('media_type') or 'video/mp2t')
        if total > 0:
            self.send_header('Content-Length', str(total))
        self.send_header('Connection', 'close')
        self.end_headers()
        if head_only:
            return
        for chunk in chunks:
            try:
                self.wfile.write(chunk)
            except Exception:
                return

    def _send_ts_keepalive(self, head_only=False):
        filler = _null_ts_chunk(int(_policy('ts_keepalive_packets') or 24))
        payload = filler * max(1, int(_policy('ts_keepalive_bursts') or 5))
        self.send_response(200)
        self.send_header('Content-Type', 'video/mp2t')
        self.send_header('Content-Length', str(len(payload)))
        self.send_header('Connection', 'close')
        self.end_headers()
        if not head_only:
            try:
                self.wfile.write(payload)
            except Exception:
                return

    def _handle_hlsretry(self, parsed, head_only=False):
        params = urllib.parse.parse_qs(parsed.query)
        url = urllib.parse.unquote(params.get('url', [''])[0] or '')
        header_blob = (params.get('headers', [''])[0] or '').strip()
        if not _is_valid_upstream_url(url):
            self.send_error(400, 'Invalid upstream URL')
            return

        forwarded_headers = _decode_header_blob(header_blob)
        response = None
        try:
            response, _, content_type = _open_upstream(
                url,
                self,
                forwarded_headers=forwarded_headers,
                expect_playlist=True,
                expect_stream=True,
            )
            final_url = response.url or url
            if _looks_like_playlist(final_url, content_type):
                base_url = final_url.rsplit('/', 1)[0]
                playlist = response.content.decode('utf-8', errors='ignore')
                _playlist_cache_put(url, final_url, playlist)
                try:
                    response.close()
                except Exception:
                    pass
                self._send_cached_playlist(playlist, base_url, header_blob, head_only=head_only)
                return

            media_type = content_type or response.headers.get('content-type') or 'application/octet-stream'
            self.send_response(206 if response.status_code == 206 else 200)
            self.send_header('Content-Type', media_type)
            accept_ranges = response.headers.get('accept-ranges')
            if accept_ranges:
                self.send_header('Accept-Ranges', accept_ranges)
            content_range = response.headers.get('content-range')
            if content_range:
                self.send_header('Content-Range', content_range)
            content_length = response.headers.get('content-length')
            if content_length:
                self.send_header('Content-Length', content_length)
            self.send_header('Connection', 'close')
            self.end_headers()
            if head_only:
                try:
                    response.close()
                except Exception:
                    pass
                return

            for chunk in _stream_response(response, url=final_url, media_type=media_type):
                try:
                    self.wfile.write(chunk)
                except Exception:
                    return
        except Exception as exc:
            playlist_text = _playlist_cache_get(url)
            if playlist_text:
                try:
                    _throttled_log('playlist-cache:%s' % _origin_key(url), 15, xbmc.LOGINFO, 'Origem oscilou; servindo playlist recente em cache para ganhar fôlego.')
                    self._send_cached_playlist(playlist_text, url.rsplit('/', 1)[0], header_blob, head_only=head_only)
                    return
                except Exception:
                    pass

            segment_item = _segment_cache_get(url)
            if segment_item:
                try:
                    _throttled_log('segment-cache:%s' % _origin_key(url), 10, xbmc.LOGINFO, 'Origem falhou no segmento; reaproveitando segmento recente em cache.')
                    self._send_cached_segment(segment_item, head_only=head_only)
                    return
                except Exception:
                    pass

            if _is_ts_like_url(url):
                try:
                    _throttled_log('segment-keepalive:%s' % _origin_key(url), 10, xbmc.LOGINFO, 'Origem falhou no TS; enviando filler curto para tentar segurar até a próxima recuperação.')
                    self._send_ts_keepalive(head_only=head_only)
                    return
                except Exception:
                    pass

            _log('Falha no hlsretry: %s' % _safe_text(exc), level=xbmc.LOGERROR)
            try:
                self.send_error(502, 'Falha ao conectar na origem')
            except Exception:
                pass
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass


def is_proxy_running():
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.35)
    try:
        return s.connect_ex(('127.0.0.1', PORT)) == 0
    finally:
        try:
            s.close()
        except Exception:
            pass


def _server_run():
    global _SERVER
    try:
        _SERVER = _ThreadedHTTPServer(('127.0.0.1', PORT), _ProxyHandler)
        _SERVER.serve_forever(poll_interval=0.2)
    except Exception as exc:
        _log('Falha ao iniciar proxy: %s' % _safe_text(exc), level=xbmc.LOGERROR)


def start_proxy():
    global _SERVER_THREAD
    if is_proxy_running():
        return True
    if _SERVER_THREAD and _SERVER_THREAD.is_alive():
        return True
    _SERVER_THREAD = threading.Thread(target=_server_run, name='OnePlayProxyServer', daemon=True)
    _SERVER_THREAD.start()
    for _ in range(30):
        if is_proxy_running():
            _log('Proxy hard ativo na porta %d' % PORT)
            return True
        time.sleep(0.2)
    _log('Proxy não respondeu na porta %d' % PORT, level=xbmc.LOGERROR)
    return False


def stop_proxy():
    global _SERVER, _SERVER_THREAD
    try:
        if _SERVER is not None:
            _SERVER.shutdown()
            _SERVER.server_close()
    except Exception:
        pass
    finally:
        _SERVER = None
        _SERVER_THREAD = None
    return True


def kodiproxy():
    return start_proxy()
