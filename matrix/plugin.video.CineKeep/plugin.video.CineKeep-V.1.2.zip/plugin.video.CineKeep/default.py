# -*- coding: utf-8 -*-
import os
import sys
import xbmcvfs
import xbmcaddon

# Obter o caminho da pasta do addon
addon = xbmcaddon.Addon()
addon_path = xbmcvfs.translatePath(addon.getAddonInfo('path'))

# Caminho para a pasta __pycache__ e o ficheiro compilado
cache_dir = os.path.join(addon_path, '__pycache__')

# Procurar automaticamente pelo ficheiro .pyc compilado lá dentro
if os.path.exists(cache_dir):
    for f in os.listdir(cache_dir):
        if f.endswith('.pyc'):
            pyc_path = os.path.join(cache_dir, f)
            if pyc_path not in sys.path:
                sys.path.insert(0, cache_dir)
            
            # Importar e executar o código compilado de forma dinâmica
            import importlib.util
            spec = importlib.util.spec_from_file_location("default", pyc_path)
            mod = importlib.util.module_from_spec(spec)
            sys.modules["default"] = mod
            spec.loader.exec_module(mod)
            break