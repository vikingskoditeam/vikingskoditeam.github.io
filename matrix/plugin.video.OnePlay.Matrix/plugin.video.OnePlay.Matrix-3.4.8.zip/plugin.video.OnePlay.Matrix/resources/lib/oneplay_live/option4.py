# -*- coding: utf-8 -*-
"""Catálogo/resolvedor isolado da Opção 4 (BugouMods).

Contrato público auditado em 11/10/2026:
    https://embed.bugoumods.com/
      -> categorias publicadas em ``ld('live_streams', <id>, <nome>)``
      -> ``index.php?ajax=1&type=live_streams&cat=<id>&_t=<ms>``
      -> ``player.php?type=live_streams&id=<stream_id>&ext=<ext>&...``
      -> HLS dinâmico publicado pelo próprio player.

A integração não fixa host/caminho HLS final, token ou URL de segmento. O
``player.php`` continua sendo a ponte dinâmica e a camada ``player.py`` só
aceita a mídia depois do preflight HLS já homologado. O proxy LiveSeq da V3H
permanece inalterado e continua responsável pelas URLs efêmeras dos segmentos.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
import html
import json
import os
import re
import time
from urllib.parse import urlencode, urljoin, urlparse
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcvfs

from .proxy import cloudflare_urlopen
from .source_contract import BROWSER_UA, is_safe_public_url, media_headers, page_headers
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
ROOT_URL = 'https://embed.bugoumods.com/'
AJAX_URL = urljoin(ROOT_URL, 'index.php')
PLAYER_URL = urljoin(ROOT_URL, 'player.php')
MAX_ROOT_BYTES = 2 * 1024 * 1024
MAX_CATEGORY_BYTES = 2 * 1024 * 1024
MAX_CACHE_BYTES = 8 * 1024 * 1024
CACHE_TTL = 24 * 60 * 60
CATEGORY_WORKERS = 4
CATEGORY_TIMEOUT = 8
_CACHE_FILE = os.path.join(PROFILE, 'oneplay_live_option4_catalog.json')
_MEMO = None
_MEMO_DEADLINE = 0.0

# Classificação exclusivamente estrutural de categoria. Nome de canal não é
# usado para isso, portanto "Adult Swim" continua normal.
_ADULT_CATEGORY_MARKERS = (
    'xxx', 'adulto', 'adultos', 'adult', 'onlyfans', '+18', '18+', 'porno', 'pornô',
)

_CATEGORY_RE = re.compile(
    r"\bld\(\s*(['\"])live_streams\1\s*,\s*(['\"])(\d+)\2\s*,\s*(['\"])(.*?)\4\s*\)",
    re.I | re.S,
)


def _log(message, warning=False):
    xbmc.log('[ONEPLAY LIVE] OPCAO4 %s' % message,
             xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _clean_text(value, limit=240):
    value = html.unescape(str(value or ''))
    value = re.sub(r'<[^>]+>', ' ', value)
    value = ' '.join(value.split()).strip()
    return value[:limit]


def _safe_url(value, base=ROOT_URL):
    value = html.unescape(str(value or '').strip())
    if not value:
        return ''
    try:
        value = urljoin(base, value)
    except Exception:
        return ''
    return value if is_safe_public_url(value) else ''


def _is_adult_category(value):
    text = _clean_text(value, 120).casefold()
    return bool(text and any(marker in text for marker in _ADULT_CATEGORY_MARKERS))


def _public_category_label(value):
    value = _clean_text(value, 120)
    if not value:
        return ''
    # O site usa ícones decorativos nos cards. Eles não fazem parte do nome
    # funcional da categoria exibido pelo add-on.
    value = re.sub(r'^[\s▶️⚽⭐🔴🟢🟡]+', '', value).strip()
    value = value.replace('👑', '').strip()
    value = ' '.join(value.split())
    return value[:100]


def _normalize_category(value):
    raw = _clean_text(value, 120) or 'Geral'
    if _is_adult_category(raw):
        return 'adulto'
    return _public_category_label(raw) or 'Geral'


def _headers_json():
    h = page_headers(page_url=AJAX_URL, parent_url=ROOT_URL)
    h['User-Agent'] = BROWSER_UA
    h['Accept'] = 'application/json,text/plain;q=0.9,*/*;q=0.8'
    h['Referer'] = ROOT_URL
    h['Sec-Fetch-Dest'] = 'empty'
    h['Sec-Fetch-Mode'] = 'cors'
    h['Sec-Fetch-Site'] = 'same-origin'
    h['Cache-Control'] = 'no-cache'
    h['Pragma'] = 'no-cache'
    return h


def _headers_page(url):
    h = page_headers(page_url=url, parent_url=ROOT_URL)
    h['User-Agent'] = BROWSER_UA
    h['Referer'] = ROOT_URL
    return h


def _read_response(request, limit, timeout):
    with cloudflare_urlopen(request, timeout=timeout, allow_native_fallback=True) as response:
        data = response.read(limit + 1)
        if len(data) > limit:
            raise ValueError('payload excedeu limite')
        return data, getattr(response, 'headers', {})


def _fetch_root_categories():
    request = Request(ROOT_URL, headers=_headers_page(ROOT_URL), method='GET')
    data, _headers = _read_response(request, MAX_ROOT_BYTES, 10)
    text = data.decode('utf-8', 'ignore')
    out = []
    seen = set()
    for match in _CATEGORY_RE.finditer(text):
        category_id = str(match.group(3) or '').strip()
        raw_label = _clean_text(match.group(5), 160)
        if not category_id or not raw_label or category_id in seen:
            continue
        seen.add(category_id)
        out.append({
            'id': category_id,
            'raw_label': raw_label,
            'label': _normalize_category(raw_label),
        })
    if not out:
        raise ValueError('nenhuma categoria live_streams reconhecida na home')
    if len(out) > 300:
        raise ValueError('quantidade de categorias excedeu limite: %d' % len(out))
    _log('home contrato novo categorias=%d' % len(out))
    return out


def _category_url(category_id):
    return '%s?%s' % (AJAX_URL, urlencode({
        'ajax': '1',
        'type': 'live_streams',
        'cat': str(category_id),
        '_t': str(int(time.time() * 1000)),
    }))


def _player_url(row):
    if not isinstance(row, dict):
        return ''
    stream_id = str(row.get('_option4_stream_id') or row.get('stream_id') or row.get('id') or '').strip()
    if not stream_id.isdigit():
        return ''
    ext = _clean_text(row.get('_option4_ext') or row.get('container_extension') or 'ts', 16) or 'ts'
    name = _clean_text(row.get('name'), 180) or 'Canal'
    image = _safe_url(row.get('image') or row.get('stream_icon') or '')
    query = {
        'type': 'live_streams',
        'id': stream_id,
        'ext': ext,
        'name': name,
    }
    if image:
        query['img'] = image
    return '%s?%s' % (PLAYER_URL, urlencode(query))


def _normalize_category_rows(rows, category):
    if not isinstance(rows, list):
        raise ValueError('categoria não retornou lista JSON')
    category_id = str(category.get('id') or '').strip()
    category_label = _normalize_category(category.get('raw_label') or category.get('label') or 'Geral')
    out = []
    for raw in rows:
        if not isinstance(raw, dict):
            continue
        stream_id = str(raw.get('stream_id') or raw.get('id') or '').strip()
        name = _clean_text(raw.get('name') or raw.get('title') or '', 180)
        if not stream_id.isdigit() or not name:
            continue
        image = _safe_url(raw.get('stream_icon') or raw.get('image') or raw.get('logo') or '')
        ext = _clean_text(raw.get('container_extension') or 'ts', 16) or 'ts'
        epg_id = _clean_text(raw.get('epg_channel_id') or stream_id, 160) or stream_id
        item = {
            'id': stream_id,
            'epg_id': epg_id,
            'name': name,
            'categories': [category_label],
            'category': category_label,
            'description': '',
            'image': image,
            'preview': '',
            'api_url': '',
            'source_page': '',
            'stream_url': '',
            'headers': {},
            '_option4_stream_id': stream_id,
            '_option4_ext': ext,
            '_option4_category_ids': [category_id] if category_id else [],
            '_option4_url_kind': 'page',
            '_oneplay_source': 'option4',
        }
        page = _player_url(item)
        if not page:
            continue
        item['api_url'] = page
        item['source_page'] = page
        out.append(item)
    return out


def _fetch_category(category):
    category_id = str(category.get('id') or '').strip()
    url = _category_url(category_id)
    request = Request(url, headers=_headers_json(), method='GET')
    data, _headers = _read_response(request, MAX_CATEGORY_BYTES, CATEGORY_TIMEOUT)
    try:
        obj = json.loads(data.decode('utf-8', 'ignore').lstrip('\ufeff'))
    except Exception as exc:
        raise ValueError('JSON inválido categoria %s: %s' % (category_id, exc))
    rows = _normalize_category_rows(obj, category)
    return rows


def _merge_channels(channels):
    out = []
    by_id = {}
    for row in channels or []:
        if not isinstance(row, dict):
            continue
        cid = str(row.get('id') or '').strip()
        if not cid:
            continue
        existing = by_id.get(cid)
        if existing is None:
            copy = dict(row)
            copy['categories'] = list(row.get('categories') or [row.get('category') or 'Geral'])
            copy['_option4_category_ids'] = list(row.get('_option4_category_ids') or [])
            by_id[cid] = copy
            out.append(copy)
            continue
        for category in row.get('categories') or [row.get('category') or 'Geral']:
            if category and category not in existing['categories']:
                existing['categories'].append(category)
        for category_id in row.get('_option4_category_ids') or []:
            if category_id and category_id not in existing['_option4_category_ids']:
                existing['_option4_category_ids'].append(category_id)
        # Atualiza metadados voláteis pela resposta mais recente.
        if row.get('image'):
            existing['image'] = row.get('image')
        if row.get('epg_id'):
            existing['epg_id'] = row.get('epg_id')
        if row.get('_option4_ext'):
            existing['_option4_ext'] = row.get('_option4_ext')
        page = _player_url(existing)
        if page:
            existing['api_url'] = page
            existing['source_page'] = page
    if len(out) > 6000:
        raise ValueError('quantidade de canais excedeu limite: %d' % len(out))
    return out


def _normalize_cached_channel(raw):
    if not isinstance(raw, dict):
        return None
    stream_id = str(raw.get('_option4_stream_id') or raw.get('id') or '').strip()
    name = _clean_text(raw.get('name'), 180)
    if not stream_id.isdigit() or not name:
        return None
    categories = []
    for value in raw.get('categories') or [raw.get('category') or 'Geral']:
        category = _normalize_category(value)
        if category and category not in categories:
            categories.append(category)
    item = {
        'id': stream_id,
        'epg_id': _clean_text(raw.get('epg_id') or stream_id, 160) or stream_id,
        'name': name,
        'categories': categories or ['Geral'],
        'category': (categories or ['Geral'])[0],
        'description': _clean_text(raw.get('description') or '', 500),
        'image': _safe_url(raw.get('image') or ''),
        'preview': '',
        'api_url': '',
        'source_page': '',
        'stream_url': '',
        'headers': {},
        '_option4_stream_id': stream_id,
        '_option4_ext': _clean_text(raw.get('_option4_ext') or 'ts', 16) or 'ts',
        '_option4_category_ids': [str(x) for x in (raw.get('_option4_category_ids') or []) if str(x).strip()],
        '_option4_url_kind': 'page',
        '_oneplay_source': 'option4',
    }
    page = _player_url(item)
    if not page:
        return None
    item['api_url'] = page
    item['source_page'] = page
    return item


def _read_cache(fresh_only=False):
    try:
        if fresh_only and time.time() - os.path.getmtime(_CACHE_FILE) > CACHE_TTL:
            return None
        with open(_CACHE_FILE, 'rb') as fh:
            raw = fh.read(MAX_CACHE_BYTES + 1)
        if len(raw) > MAX_CACHE_BYTES:
            return None
        obj = json.loads(raw.decode('utf-8'))
        channels_raw = obj.get('channels') if isinstance(obj, dict) else None
        if not isinstance(channels_raw, list):
            return None
        channels = []
        for raw_channel in channels_raw:
            channel = _normalize_cached_channel(raw_channel)
            if channel is not None:
                channels.append(channel)
        if not channels:
            return None
        categories = obj.get('categories') if isinstance(obj.get('categories'), list) else []
        return {
            'channels': _merge_channels(channels),
            'categories': categories,
            'fetched_at': int(obj.get('fetched_at') or 0),
        }
    except Exception:
        return None


def _write_cache(payload):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_CACHE_FILE, payload, MAX_CACHE_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _stale_by_category_id(payload):
    mapping = {}
    for channel in (payload or {}).get('channels') or []:
        for category_id in channel.get('_option4_category_ids') or []:
            mapping.setdefault(str(category_id), []).append(channel)
    return mapping


def _clone_for_category(channel, category):
    clone = dict(channel)
    label = _normalize_category(category.get('raw_label') or category.get('label') or 'Geral')
    category_id = str(category.get('id') or '').strip()
    clone['categories'] = [label]
    clone['category'] = label
    clone['_option4_category_ids'] = [category_id] if category_id else []
    return clone


def _fetch_live():
    categories = _fetch_root_categories()
    stale = _read_cache(False)
    stale_map = _stale_by_category_id(stale)
    collected = []
    fresh_categories = 0
    stale_categories = 0
    failed_categories = []

    with ThreadPoolExecutor(max_workers=CATEGORY_WORKERS, thread_name_prefix='OnePlayOp4') as executor:
        jobs = {executor.submit(_fetch_category, category): category for category in categories}
        for future in as_completed(jobs):
            category = jobs[future]
            category_id = str(category.get('id') or '')
            try:
                rows = list(future.result() or [])
                collected.extend(rows)
                fresh_categories += 1
            except Exception as exc:
                fallback = stale_map.get(category_id) or []
                if fallback:
                    collected.extend(_clone_for_category(ch, category) for ch in fallback)
                    stale_categories += 1
                else:
                    failed_categories.append(category_id)
                _log('categoria %s indisponível tipo=%s; stale=%d' % (
                    category_id, exc.__class__.__name__, len(fallback)), True)

    channels = _merge_channels(collected)
    if not channels:
        raise ValueError('catálogo novo sem canais reconhecíveis')
    payload = {
        'channels': channels,
        'categories': categories,
        'fetched_at': int(time.time()),
    }
    _log('catálogo novo canais=%d categorias=%d fresh=%d stale=%d falhas=%d' % (
        len(channels), len(categories), fresh_categories, stale_categories, len(failed_categories)))
    return payload


def _payload(force=False):
    global _MEMO, _MEMO_DEADLINE
    now = time.monotonic()
    if not force and _MEMO is not None and now < _MEMO_DEADLINE:
        return _MEMO
    if not force:
        fresh = _read_cache(True)
        if fresh is not None:
            _MEMO = fresh
            _MEMO_DEADLINE = now + CACHE_TTL
            return fresh
    try:
        live = _fetch_live()
        _write_cache(live)
        _MEMO = live
        _MEMO_DEADLINE = now + CACHE_TTL
        return live
    except Exception as exc:
        _log('catálogo online indisponível: %s' % exc, True)
    stale = _read_cache(False)
    if stale is not None:
        _MEMO = stale
        _MEMO_DEADLINE = now + min(CACHE_TTL, 60)
        _log('usando cache anterior canais=%d' % len(stale.get('channels') or []), True)
        return stale
    _MEMO = {'channels': [], 'categories': []}
    _MEMO_DEADLINE = now + 20
    return _MEMO


def source_for(channel):
    """Entrega o player público atual ao resolvedor homologado.

    A URL HLS não é construída aqui. ``player.py`` extrai da página somente o
    manifesto publicado e o valida antes de entregar ao proxy.
    """
    if not isinstance(channel, dict):
        return None
    url = _player_url(channel)
    if not url:
        url = _safe_url(channel.get('source_page') or channel.get('api_url'))
    if not url:
        return None
    page_h = _headers_page(url)
    resource_h = media_headers(page_url=url)
    return {
        'name': 'opcao4-player-page',
        'url': url,
        'playlist_headers': dict(page_h),
        'resource_headers': dict(resource_h),
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'max_html_depth': 2,
        'preserve_navigation_referer': True,
        'source_kind': 'derived-page',
    }


def _refresh_category_for_channel(channel):
    category_ids = list(channel.get('_option4_category_ids') or []) if isinstance(channel, dict) else []
    if not category_ids:
        return []
    payload = _payload(False)
    category_meta = {str(c.get('id')): c for c in (payload.get('categories') or []) if isinstance(c, dict)}
    rows = []
    for category_id in category_ids[:3]:
        meta = category_meta.get(str(category_id)) or {
            'id': str(category_id),
            'raw_label': (channel.get('category') or 'Geral'),
            'label': (channel.get('category') or 'Geral'),
        }
        try:
            rows.extend(_fetch_category(meta))
        except Exception as exc:
            _log('refresh categoria %s falhou tipo=%s' % (category_id, exc.__class__.__name__), True)
    return _merge_channels(rows)


class Catalog(object):
    def __init__(self):
        self._payload = _payload(False) or {}
        self._channels = list(self._payload.get('channels') or [])

    def channels(self):
        return list(self._channels)

    def categories(self):
        present = []
        for channel in self._channels:
            for name in channel.get('categories') or [channel.get('category') or 'Geral']:
                if name and name not in present:
                    present.append(str(name))
        normal = sorted([x for x in present if x != 'adulto'], key=lambda x: x.casefold())
        return normal + (['adulto'] if 'adulto' in present else [])

    def category_description(self, category):
        if str(category or '') == 'adulto':
            return 'Conteúdo adulto disponível na Opção 4.'
        return 'Canais disponíveis na Opção 4.'

    def by_category(self, category):
        return [c for c in self._channels if category in (c.get('categories') or [c.get('category')])]

    def get(self, channel_id):
        wanted = str(channel_id or '').strip().lower()
        for channel in self._channels:
            if str(channel.get('id') or '').strip().lower() == wanted:
                return channel
        return None

    def refresh_get(self, channel_id):
        global _MEMO, _MEMO_DEADLINE
        wanted = str(channel_id or '').strip().lower()
        current = self.get(channel_id)
        if current is not None:
            fresh_rows = _refresh_category_for_channel(current)
            for channel in fresh_rows:
                if str(channel.get('id') or '').strip().lower() == wanted:
                    # Atualiza apenas o(s) canal(is) da categoria no cache em memória;
                    # evita refazer as 77 categorias durante recovery de playback.
                    existing = [c for c in self._channels if str(c.get('id') or '').strip().lower() != wanted]
                    existing.append(channel)
                    merged = _merge_channels(existing)
                    payload = dict(self._payload)
                    payload['channels'] = merged
                    payload['fetched_at'] = int(time.time())
                    _write_cache(payload)
                    _MEMO = payload
                    _MEMO_DEADLINE = time.monotonic() + CACHE_TTL
                    self._payload = payload
                    self._channels = merged
                    _log('refresh por categoria atualizado id=%s' % channel_id)
                    return channel
        # Fallback conservador: só se não houver metadado suficiente para um
        # refresh pontual. Mantém o contrato dinâmico sem loop infinito.
        try:
            live = _fetch_live()
            _write_cache(live)
            _MEMO = live
            _MEMO_DEADLINE = time.monotonic() + CACHE_TTL
            self._payload = live
            self._channels = list(live.get('channels') or [])
            return self.get(channel_id)
        except Exception as exc:
            _log('refresh live falhou id=%s: %s' % (channel_id, exc), True)
        return None
