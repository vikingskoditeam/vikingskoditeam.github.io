# -*- coding: utf-8 -*-
from urllib.parse import parse_qsl, urlencode
import sys
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import os
import hashlib
import hmac
from .catalog import Catalog
from .player import play_channel
from .artwork import artwork_for
from .epg import EpgGuide
from .events import EventsGuide, event_display_text, event_art_url
from .presentation import public_text as _public_text

ADDON = xbmcaddon.Addon()
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
_ROOT = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))
ADDON_FANART = os.path.join(_ROOT, 'fanart.jpg')
ADDON_ICON = os.path.join(_ROOT, 'icon.png')

# A proteção adulta do OnePlay Live usa exclusivamente a classificação
# estrutural do catálogo (category/categories ou IDs explicitamente adultos).
# NUNCA classifica por substring do nome do canal; portanto nomes legítimos
# como "Adult Swim" não são considerados conteúdo adulto por causa do título.
_ADULT_CATEGORY = 'adulto'
_ADULT_CHANNEL_IDS = frozenset(('playboy', 'sexyhot'))
_ADULT_ENABLED_CB = None
_ADULT_PROMPT_CB = None
_ADULT_GUARD_KEY_FILE = os.path.join(
    xbmcvfs.translatePath(ADDON.getAddonInfo('profile')),
    'oneplay_live_adult_guard.key'
)


def _normalized_category(value):
    try:
        return str(value or '').strip().casefold()
    except Exception:
        return str(value or '').strip().lower()


def _is_adult_category(value):
    return _normalized_category(value) == _ADULT_CATEGORY


def _is_adult_channel(ch):
    if not isinstance(ch, dict):
        return False
    channel_id = str(ch.get('id') or '').strip().lower()
    if channel_id in _ADULT_CHANNEL_IDS:
        return True
    values = list(ch.get('categories') or [])
    category = ch.get('category')
    if category:
        values.append(category)
    return any(_is_adult_category(value) for value in values)


def _adult_protection_enabled():
    if callable(_ADULT_ENABLED_CB):
        try:
            return bool(_ADULT_ENABLED_CB())
        except Exception:
            return False
    try:
        return ADDON.getSetting('tv_adult_protect').strip().lower() in ('true', '1', 'yes', 'sim', 'on')
    except Exception:
        return False


def _adult_guard_key():
    """Retorna uma chave local para assinar apenas URLs já liberadas por PIN.

    Não contém nem deriva o PIN e não representa uma sessão de autorização.
    Serve somente para impedir que um parâmetro simples na URL seja forjado.
    """
    try:
        parent = os.path.dirname(_ADULT_GUARD_KEY_FILE)
        if parent and not os.path.isdir(parent):
            os.makedirs(parent)
        if os.path.isfile(_ADULT_GUARD_KEY_FILE):
            with open(_ADULT_GUARD_KEY_FILE, 'rb') as fh:
                key = fh.read(64)
            if len(key) >= 32:
                return key[:32]
        key = os.urandom(32)
        tmp = _ADULT_GUARD_KEY_FILE + '.tmp'
        with open(tmp, 'wb') as fh:
            fh.write(key)
        try:
            os.replace(tmp, _ADULT_GUARD_KEY_FILE)
        except Exception:
            if os.path.exists(_ADULT_GUARD_KEY_FILE):
                try:
                    os.remove(_ADULT_GUARD_KEY_FILE)
                except Exception:
                    pass
            os.rename(tmp, _ADULT_GUARD_KEY_FILE)
        return key
    except Exception:
        return b''


def _adult_play_guard(channel_id):
    key = _adult_guard_key()
    if not key:
        return ''
    message = ('oneplay-live-adult-play|' + str(channel_id or '').strip().lower()).encode('utf-8')
    return hmac.new(key, message, hashlib.sha256).hexdigest()


def _valid_adult_play_guard(channel_id, token):
    expected = _adult_play_guard(channel_id)
    supplied = str(token or '').strip().lower()
    if not expected or len(supplied) != len(expected):
        return False
    try:
        return hmac.compare_digest(expected, supplied)
    except Exception:
        return expected == supplied


def _container_is_current_adult_category(name):
    """True somente quando o Kodi já está exibindo a própria pasta adulta.

    Isso diferencia um refresh interno (inclusive o retorno do STOP) de uma
    nova entrada vinda da raiz/outra pasta. Não grava PIN, timestamp, sessão
    ou autorização persistente.
    """
    if not _is_adult_category(name):
        return False
    try:
        current = xbmc.getInfoLabel('Container.FolderPath') or ''
        if '?' not in current:
            return False
        query = current.split('?', 1)[1]
        current_params = dict(parse_qsl(query, keep_blank_values=True))
        return (
            current_params.get('action') == 'oneplay_live_category' and
            _is_adult_category(current_params.get('category', ''))
        )
    except Exception:
        return False


def _authorize_adult():
    """Pede o PIN em toda nova entrada protegida; não há cache/sessão/TTL."""
    if not _adult_protection_enabled():
        xbmcgui.Dialog().notification(
            'OnePlay', 'Categorias adultas desativadas nesta configuração.',
            xbmcgui.NOTIFICATION_INFO, 3500
        )
        return False
    if not callable(_ADULT_PROMPT_CB):
        return False
    try:
        return bool(_ADULT_PROMPT_CB())
    except Exception:
        return False

def _non_adult_channels(items):
    return [ch for ch in (items or []) if not _is_adult_channel(ch)]


def params():
    query = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else ''
    return dict(parse_qsl(query))


def plugin_url(**kwargs):
    mode = str(kwargs.pop('mode', '') or '').strip()
    payload = {'action': ('oneplay_live_' + mode) if mode else 'oneplay_live_root'}
    payload.update(kwargs)
    return BASE_URL + '?' + urlencode(payload)



def _set_plot(li, title, plot, genre='', mediatype=''):
    title = _public_text(title)
    plot = _public_text(plot, multiline=True)
    genre = _public_text(genre)
    try:
        tag = li.getVideoInfoTag()
        tag.setTitle(title)
        tag.setPlot(plot or '')
        if genre:
            tag.setGenres([genre])
        if mediatype:
            try: tag.setMediaType(mediatype)
            except Exception: pass
    except Exception:
        try:
            li.setInfo('video', {'title': title, 'plot': plot or '', 'genre': genre or ''})
        except Exception:
            pass


def add_folder(label, mode, description='', **kwargs):
    label = _public_text(label)
    li = xbmcgui.ListItem(label=label)
    li.setProperty('IsPlayable', 'false')
    _set_plot(li, label, description)
    if ADDON_ICON or ADDON_FANART:
        li.setArt({'icon': ADDON_ICON, 'thumb': ADDON_ICON, 'fanart': ADDON_FANART})
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(mode=mode, **kwargs), li, True)


def add_channel(ch, epg_info=None, adult_guarded=False):
    name = _public_text(ch.get('name', '')) or str(ch.get('id') or 'Canal')
    info = epg_info or {}
    description = info.get('plot') or 'Programação não disponível no EPG.'
    category = ch.get('category', '')
    li = xbmcgui.ListItem(label=name)
    # Reprodução direta: a rota inicia xbmc.Player sem pedir ao Kodi uma segunda
    # resolução do item. Isso preserva o container anterior ao voltar do Stop.
    li.setProperty('IsPlayable', 'false')
    _set_plot(li, name, description, category, 'video')
    try:
        li.setLabel2(_public_text(info.get('current_title') or info.get('next_title') or ''))
    except Exception:
        pass

    artinfo = artwork_for(ch)
    remote = artinfo.get('remote', '')
    preview = artinfo.get('preview', '')
    fallback = artinfo.get('fallback', '') or ADDON_ICON
    if remote:
        # A imagem `image` da API é a capa real em qualquer view do Kodi.
        art = {
            'icon': remote,
            'thumb': remote,
            'poster': remote,
            'clearlogo': remote,
            'landscape': preview or remote,
            'fanart': preview or ADDON_FANART,
        }
    else:
        art = {'fanart': ADDON_FANART}
        if fallback:
            art.update({'icon': fallback, 'thumb': fallback, 'poster': fallback, 'landscape': fallback})
    li.setArt(art)
    try:
        if art.get('fanart'): li.setProperty('fanart_image', art.get('fanart'))
        li.setProperty('channel_id', str(ch.get('id') or ''))
    except Exception:
        pass

    play_kwargs = {'mode': 'play', 'channel_id': ch['id'], 'channel_name': name}
    if adult_guarded:
        token = _adult_play_guard(ch.get('id'))
        if token:
            play_kwargs['adult_guard'] = token
    xbmcplugin.addDirectoryItem(HANDLE, plugin_url(**play_kwargs), li, False)


def root():
    cat = Catalog()
    add_folder(
        'Todos os canais', 'category',
        description='Lista completa de canais disponíveis no catálogo, sem conteúdo adulto.',
        category='__all__'
    )
    for category in cat.categories():
        if _is_adult_category(category):
            if _adult_protection_enabled():
                add_folder(
                    '[COLOR red]Conteúdos Adulto[/COLOR]', 'category',
                    description='Abrir canais adultos mediante o PIN configurado em TV ao vivo.',
                    category=category
                )
            continue
        add_folder(category, 'category', description=cat.category_description(category), category=category)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)


def list_category(name):
    cat = Catalog()
    if name == '__all__':
        # A grade geral nunca mistura conteúdo adulto. O acesso adulto fica
        # exclusivamente na pasta protegida por PIN.
        items = _non_adult_channels(cat.channels())
    elif _is_adult_category(name):
        # O Kodi recarrega automaticamente o diretório corrente ao voltar do
        # player. Se já estamos na própria pasta Adulto, isso NÃO é uma nova
        # entrada e não deve pedir PIN de novo. Vindo da raiz/outra pasta, o
        # Container.FolderPath é diferente e o PIN é obrigatório novamente.
        if not _container_is_current_adult_category(name):
            if not _authorize_adult():
                xbmcplugin.endOfDirectory(HANDLE, succeeded=False, updateListing=False, cacheToDisc=False)
                return
        items = [ch for ch in cat.by_category(name) if _is_adult_channel(ch)]
    else:
        items = _non_adult_channels(cat.by_category(name))
    # Uma única leitura do EPG por abertura real de grade; EpgGuide usa cache de 2 min.
    guide = EpgGuide(allow_network=True)
    adult_guarded = _is_adult_category(name)
    for ch in items:
        add_channel(ch, guide.info(ch.get('id')), adult_guarded=adult_guarded)
    xbmcplugin.setContent(HANDLE, 'videos')
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Categorias comuns podem usar cache de listagem. A pasta adulta não é
    # gravada em cache pelo Kodi: ao sair dela e entrar novamente, a rota é
    # executada de novo e o PIN é obrigatório outra vez.
    xbmcplugin.endOfDirectory(
        HANDLE, succeeded=True, updateListing=False,
        cacheToDisc=(not adult_guarded)
    )



def _event_art(item):
    art_url=event_art_url(item.get('image'))
    home=event_art_url(item.get('home_image'))
    away=event_art_url(item.get('away_image'))
    primary=art_url or home or away or ADDON_ICON
    fan=away or home or art_url or ADDON_FANART
    return {k:v for k,v in {'icon':primary,'thumb':primary,'poster':primary,'clearlogo':primary,
                             'fanart':fan,'landscape':fan}.items() if v}


def _known_channels():
    # Eventos e atalhos públicos também não recebem canais adultos.
    cat=Catalog(); return cat,{c.get('id'):c for c in _non_adult_channels(cat.channels()) if c.get('id')}


def add_event_day(group):
    count=int(group.get('count') or 0); live=int(group.get('live') or 0)
    label=event_display_text(group.get('label')) or 'Eventos'
    desc='%d evento%s' % (count,'' if count==1 else 's')
    if live: desc+=' • %d ao vivo'%live
    add_folder(label,'events_day',description=desc,day=str(group.get('key') or ''))



def add_event(item, known):
    status=event_display_text(item.get('status'))
    title=event_display_text(item.get('title')) or 'Evento'
    league=event_display_text(item.get('league'))
    plot=event_display_text(item.get('plot'), multiline=True)
    label=_public_text((('%s • '%status) if status else '')+title)
    li=xbmcgui.ListItem(label=label); li.setProperty('IsPlayable','false')
    _set_plot(li,title,plot,league or 'Evento','video')
    try: li.setLabel2(_public_text(league))
    except Exception: pass
    art=_event_art(item); li.setArt(art)
    try:
        if art.get('fanart'): li.setProperty('fanart_image',art.get('fanart'))
        li.setProperty('event_key',str(item.get('event_key') or ''))
    except Exception: pass
    matches=item.get('matched_channels') or []
    if len(matches)==1:
        cid=matches[0]; ch=known.get(cid) or {}
        url=plugin_url(mode='play',channel_id=cid,channel_name=_public_text(ch.get('name')) or cid); is_folder=False
    elif len(matches)>1:
        url=plugin_url(mode='event_sources',event_key=str(item.get('event_key') or '')); is_folder=True
    else:
        url=plugin_url(mode='event_unavailable',event_name=title); is_folder=False
    xbmcplugin.addDirectoryItem(HANDLE,url,li,is_folder)


def list_events():
    cat,known=_known_channels(); guide=EventsGuide(allow_network=True)
    groups=guide.days(known)
    if not groups:
        xbmc.log('[ONEPLAY LIVE] EVENTOS janela atual vazia; antecedência=20min',xbmc.LOGINFO)
        xbmcgui.Dialog().notification('OnePlay Live','Não há eventos disponíveis no momento.',xbmcgui.NOTIFICATION_INFO,4000)
        xbmcplugin.endOfDirectory(HANDLE,succeeded=False,updateListing=False,cacheToDisc=False)
        return
    if len(groups)==1:
        # Com a janela temporal, normalmente existe só o dia atual; abre direto a grade.
        list_events_day(groups[0].get('key') or '',guide=guide,known=known)
        return
    for group in groups: add_event_day(group)
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.addSortMethod(HANDLE,xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE,succeeded=True,updateListing=False,cacheToDisc=False)


def list_events_day(day,guide=None,known=None):
    if guide is None or known is None:
        cat,known=_known_channels(); guide=EventsGuide(allow_network=True)
    for item in guide.events_for_day(day,known): add_event(item,known)
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.addSortMethod(HANDLE,xbmcplugin.SORT_METHOD_NONE)
    xbmcplugin.endOfDirectory(HANDLE,succeeded=True,updateListing=False,cacheToDisc=False)



def list_event_sources(event_key):
    cat,known=_known_channels(); guide=EventsGuide(allow_network=True); item=guide.event_by_key(event_key,known)
    if not item:
        xbmcgui.Dialog().notification('OnePlay Live','Evento não está disponível no momento.',xbmcgui.NOTIFICATION_INFO,4000)
        xbmcplugin.endOfDirectory(HANDLE,succeeded=False,updateListing=False,cacheToDisc=False); return
    event_title=_public_text(item.get('title')) or 'Evento'
    status=event_display_text(item.get('status'))
    league=event_display_text(item.get('league'))
    for cid in item.get('matched_channels') or []:
        ch=known.get(cid) or {}; name=_public_text(ch.get('name')) or cid
        info={'plot':'%s\n%s\nTransmissão de: %s'%(status,league,event_title)}
        add_channel(ch,info)
    xbmcplugin.setContent(HANDLE,'videos'); xbmcplugin.addSortMethod(HANDLE,xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE,succeeded=True,updateListing=False,cacheToDisc=False)


def dispatch(action, p=None, adult_enabled=None, adult_prompt=None):
    global _ADULT_ENABLED_CB, _ADULT_PROMPT_CB
    _ADULT_ENABLED_CB = adult_enabled
    _ADULT_PROMPT_CB = adult_prompt

    p = dict(p or {})
    action = str(action or 'oneplay_live_root')
    if action == 'oneplay_live_category':
        list_category(p.get('category', '__all__'))
    elif action == 'oneplay_live_events':
        list_events()
    elif action == 'oneplay_live_events_day':
        list_events_day(p.get('day',''))
    elif action == 'oneplay_live_event_sources':
        list_event_sources(p.get('event_key',''))
    elif action == 'oneplay_live_event_unavailable':
        xbmcgui.Dialog().notification('OnePlay Live','Evento sem canal associado no catálogo atual.',xbmcgui.NOTIFICATION_INFO,4000)
    elif action == 'oneplay_live_play':
        channel_id = p.get('channel_id', '')
        channel = Catalog().get(channel_id)
        is_adult = (
            (channel is not None and _is_adult_channel(channel)) or
            str(channel_id or '').strip().lower() in _ADULT_CHANNEL_IDS
        )
        if is_adult:
            # A pasta adulta já exigiu PIN. Os itens gerados por ela carregam
            # uma prova local assinada para evitar uma segunda solicitação no
            # clique do canal. Não há cache/sessão de PIN: entrar novamente na
            # pasta sempre chama _authorize_adult() de novo.
            if not _valid_adult_play_guard(channel_id, p.get('adult_guard', '')):
                # Acesso direto/favorito/URL sem prova válida continua fail-closed.
                if not _authorize_adult():
                    return
        play_channel(HANDLE, channel_id)
    else:
        root()


def run():
    p = params()
    dispatch(p.get('action') or 'oneplay_live_root', p)


if __name__ == '__main__':
    run()
