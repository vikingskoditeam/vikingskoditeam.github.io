# service.py
# -*- coding: utf-8 -*-
"""Limpeza automática dos APKs na inicialização do Kodi no Android."""

import xbmc

from cleanup import cleanup_previous_sessions, current_kodi_session_id


def _is_android():
    return bool(xbmc.getCondVisibility('system.platform.android'))


def _log(message, level=None):
    try:
        xbmc.log(
            '[ONEPLAY APK Downloader][SERVICE] %s' % message,
            level if level is not None else xbmc.LOGINFO,
        )
    except Exception:
        pass


def run():
    if not _is_android():
        _log('Plataforma não Android; limpeza automática inativa.')
        return

    session_id = current_kodi_session_id()
    try:
        cleanup_previous_sessions(session_id)
    except Exception as exc:
        _log('Falha na limpeza de inicialização: %s' % exc, xbmc.LOGWARNING)


if __name__ == '__main__':
    run()
