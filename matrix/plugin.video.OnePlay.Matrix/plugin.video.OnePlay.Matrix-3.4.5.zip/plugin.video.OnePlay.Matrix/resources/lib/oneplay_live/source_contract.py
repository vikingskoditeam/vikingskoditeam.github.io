# -*- coding: utf-8 -*-
"""Contrato HTTP adaptativo do OnePlay Live.

Únicos endpoints fixos do contrato:
- canais: ``https://embedtv.lat/api/channels``
- eventos: ``https://embedtv.lat/api/events``
- EPG: ``https://embedtv.lat/api/epg_all``

Todo o restante é descoberto em tempo de execução por cadeia de confiança:
API oficial -> URL pública do canal -> página/iframe publicado -> mídia publicada
-> validação real de HLS e do primeiro segmento.

Não há fallback fixo de subdomínio, CDN, caminho de manifesto ou extensão.
O resolvedor não executa JavaScript nem tenta contornar autenticação/desafios.
"""
import ipaddress
from urllib.parse import urlparse

CHANNELS_API = 'https://embedtv.lat/api/channels'
EVENTS_API = 'https://embedtv.lat/api/events'
EPG_API = 'https://embedtv.lat/api/epg_all'

BROWSER_UA = (
    'Mozilla/5.0 (Linux; Android 10; K) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/152.0.0.0 Mobile Safari/537.36'
)

COMMON_HEADERS = {
    'Accept': '*/*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,it;q=0.6',
    'Priority': 'u=1, i',
    'Sec-CH-UA': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
    'Sec-CH-UA-Mobile': '?1',
    'Sec-CH-UA-Platform': '"Android"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'User-Agent': BROWSER_UA,
}

PAGE_ACCEPT = (
    'text/html,application/xhtml+xml,application/xml;q=0.9,'
    'image/avif,image/webp,image/apng,*/*;q=0.8,'
    'application/signed-exchange;v=b3;q=0.7'
)


def _merge(base, extra=None):
    out = dict(base)
    if isinstance(extra, dict):
        for key, value in extra.items():
            if key and value is not None:
                out[str(key)] = str(value)
    return out


def _public_http_url(url):
    try:
        parsed = urlparse(str(url or '').strip())
        scheme = (parsed.scheme or '').lower()
        host = (parsed.hostname or '').lower()
    except Exception:
        return False
    if scheme not in ('http', 'https') or not host:
        return False
    if parsed.username or parsed.password:
        return False
    if host == 'localhost' or host.endswith(('.localhost', '.local', '.lan', '.internal')):
        return False
    try:
        return bool(ipaddress.ip_address(host).is_global)
    except ValueError:
        return True


def is_safe_public_url(url):
    """Aceita somente HTTP(S) público para URLs descendentes das APIs fixas."""
    return _public_http_url(url)


def _origin(url):
    if not _public_http_url(url):
        return ''
    parsed = urlparse(str(url).strip())
    host = (parsed.hostname or '').lower()
    netloc = host
    try:
        if parsed.port:
            netloc = '%s:%d' % (host, parsed.port)
    except Exception:
        pass
    return '%s://%s' % ((parsed.scheme or 'https').lower(), netloc)


API_ORIGIN = _origin(CHANNELS_API)


def _fetch_site(target_url, parent_url=None):
    """Classifica same-origin/same-site/cross-site sem fixar host de player."""
    try:
        target = urlparse(str(target_url or ''))
        parent = urlparse(str(parent_url or ''))
        th = (target.hostname or '').lower()
        ph = (parent.hostname or '').lower()
        if not th or not ph:
            return 'cross-site'
        if th == ph:
            return 'same-origin'
        if th.endswith('.' + ph) or ph.endswith('.' + th):
            return 'same-site'
    except Exception:
        pass
    return 'cross-site'


def api_headers(extra=None):
    h = _merge(COMMON_HEADERS, extra)
    if API_ORIGIN:
        h['Referer'] = API_ORIGIN + '/'
    h['Sec-Fetch-Site'] = 'same-origin'
    return h


def page_headers(extra=None, page_url=None, parent_url=None):
    """Headers de navegação/iframe para a página dinâmica publicada pela API."""
    h = _merge(COMMON_HEADERS, extra)
    h['Accept'] = PAGE_ACCEPT
    h['DNT'] = '1'
    h['Priority'] = 'u=0, i'
    h['Sec-Fetch-Dest'] = 'iframe'
    h['Sec-Fetch-Mode'] = 'navigate'
    h['Sec-Fetch-Site'] = _fetch_site(page_url, parent_url or (API_ORIGIN + '/'))
    h['Sec-Fetch-User'] = '?1'
    h['Upgrade-Insecure-Requests'] = '1'
    # A página é tratada como documento, não como recurso CORS de mídia.
    h.pop('Origin', None)
    h.pop('Referer', None)
    h.pop('Range', None)
    return h


def media_headers(extra=None, page_url=None):
    """Deriva Origin/Referer exclusivamente da página que publicou a mídia."""
    h = _merge(COMMON_HEADERS, extra)
    origin = _origin(page_url)
    if origin:
        h['Referer'] = origin + '/'
        h['Origin'] = origin
    else:
        h.pop('Referer', None)
        h.pop('Origin', None)
    h['Sec-Fetch-Site'] = 'cross-site'
    h['Sec-Fetch-Dest'] = 'empty'
    h['Sec-Fetch-Mode'] = 'cors'
    return h


def api_source(channel_url, extra_headers=None):
    """Cria a fonte exclusivamente a partir da URL publicada por /api/channels."""
    url = str(channel_url or '').strip()
    if not _public_http_url(url):
        return None
    page_h = page_headers(extra_headers, page_url=url, parent_url=API_ORIGIN + '/')
    media_h = media_headers(extra_headers, page_url=url)
    return {
        'name': 'embedtv-api-url',
        'url': url,
        'playlist_headers': dict(page_h),
        'resource_headers': dict(media_h),
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'source_kind': 'api-url',
    }
