# -*- coding: utf-8 -*-
from helpers import *
import threading
import socket
import requests
import re
try:
    requests.packages.urllib3.disable_warnings()
except Exception:
    pass
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
try:
    from urllib.parse import urljoin
except Exception:
    from urlparse import urljoin

HOST = '127.0.0.1'
PORT = 9098
URL_PROXY = 'http://{}:{}/?url='.format(HOST, PORT)

WINDOW = xbmcgui.Window(10000)
PROPERTY_NAME = 'meufutebol.proxy.running'

_proxy_instance = None

DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def is_port_in_use(port, host='127.0.0.1'):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex((host, port)) == 0


def _split_kodi_url(raw):
    if '|' in raw:
        url, options = raw.split('|', 1)
    else:
        url, options = raw, ''
    parsed_options = parse_qs(options, keep_blank_values=True)
    return url, parsed_options


def _opt(options, key, default=''):
    value = options.get(key, [default])
    return value[0] if value else default


def _build_proxy_url(url, options):
    params = {}
    user_agent = _opt(options, 'User-Agent', DEFAULT_UA)
    referer = _opt(options, 'Referer', '')
    origin = _opt(options, 'Origin', '')
    upstream_proxy = _opt(options, 'Proxy', '')
    if user_agent:
        params['User-Agent'] = user_agent
    if referer:
        params['Referer'] = referer
    if origin:
        params['Origin'] = origin
    if upstream_proxy:
        params['Proxy'] = upstream_proxy
    kodi_url = url + ('|' + urlencode(params) if params else '')
    return URL_PROXY + quote_plus(kodi_url)


def _rewrite_attr_uris(line, base_url, options):
    def repl(match):
        quote_char = match.group(1)
        uri = match.group(2)
        absolute = urljoin(base_url, uri)
        return 'URI={}{}{}'.format(quote_char, _build_proxy_url(absolute, options), quote_char)
    return re.sub(r'URI=(["\'])(.*?)\1', repl, line)


def _rewrite_playlist(content, base_url, options):
    lines = []
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            lines.append(line)
            continue
        if stripped.startswith('#'):
            if 'URI=' in stripped:
                lines.append(_rewrite_attr_uris(line, base_url, options))
            else:
                lines.append(line)
            continue
        absolute = urljoin(base_url, stripped)
        lines.append(_build_proxy_url(absolute, options))
    return '\n'.join(lines) + '\n'


class M3UProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        target_url = query.get('url', [None])[0]
        target_url = unquote_plus(target_url) if target_url else None

        if not target_url:
            self.send_error(400)
            return

        try:
            url, options = _split_kodi_url(target_url)
            upstream_proxy = _opt(options, 'Proxy', '')
            headers = {
                'User-Agent': _opt(options, 'User-Agent', DEFAULT_UA),
                'Referer': _opt(options, 'Referer', ''),
                'Origin': _opt(options, 'Origin', '')
            }
            headers = {k: v for k, v in headers.items() if v}

            proxies = {'http': upstream_proxy, 'https': upstream_proxy} if upstream_proxy else None
            r = requests.get(url, headers=headers, proxies=proxies, timeout=(8, 25), verify=False, allow_redirects=True)
            r.raise_for_status()

            content_type = r.headers.get('Content-Type', '')
            final_url = r.url or url
            base_url = final_url.rsplit('/', 1)[0] + '/'
            is_playlist = '.m3u8' in final_url.lower() or 'mpegurl' in content_type.lower() or r.content[:16].lstrip().startswith(b'#EXTM3U')

            if is_playlist:
                text = r.text
                text = text.replace('\\/', '/')
                body = _rewrite_playlist(text, base_url, options).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                self.end_headers()
                self.wfile.write(body)
            else:
                self.send_response(200)
                self.send_header('Content-Type', content_type or 'application/octet-stream')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                self.end_headers()
                for chunk in r.iter_content(chunk_size=64 * 1024):
                    if chunk:
                        self.wfile.write(chunk)

        except Exception as e:
            xbmc.log('[MEU FUTEBOL PROXY ERROR] ' + str(e), xbmc.LOGERROR)
            self.send_error(500)


class ProxyServer(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.server = None
        self.monitor = xbmc.Monitor()

    def run(self):
        try:
            ThreadedHTTPServer.allow_reuse_address = True
            self.server = ThreadedHTTPServer((HOST, PORT), M3UProxyHandler)
            xbmc.log('[MEU FUTEBOL PROXY] Rodando em http://{}:{}'.format(HOST, PORT), xbmc.LOGINFO)
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            while not self.monitor.abortRequested():
                self.monitor.waitForAbort(1)
            self.stop()
        except OSError:
            xbmc.log('[MEU FUTEBOL PROXY] Porta ocupada.', xbmc.LOGINFO)

    def stop(self):
        if self.server:
            xbmc.log('[MEU FUTEBOL PROXY] Encerrando...', xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()
            self.server = None


def start():
    global _proxy_instance
    if WINDOW.getProperty(PROPERTY_NAME) == 'true':
        if is_port_in_use(PORT, HOST):
            xbmc.log('[MEU FUTEBOL PROXY] Ja marcado como ativo.', xbmc.LOGINFO)
            return True
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Marcacao antiga sem porta ativa; reiniciando.', xbmc.LOGINFO)
    if is_port_in_use(PORT, HOST):
        WINDOW.setProperty(PROPERTY_NAME, 'true')
        xbmc.log('[MEU FUTEBOL PROXY] Porta ja estava ativa.', xbmc.LOGINFO)
        return True
    try:
        _proxy_instance = ProxyServer()
        _proxy_instance.start()
        # Em algumas plataformas, especialmente Android/Xbox, a thread pode demorar ou falhar ao abrir socket.
        for _ in range(15):
            xbmc.sleep(100)
            if is_port_in_use(PORT, HOST):
                WINDOW.setProperty(PROPERTY_NAME, 'true')
                xbmc.log('[MEU FUTEBOL PROXY] Iniciado com sucesso.', xbmc.LOGINFO)
                return True
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Nao confirmou abertura da porta.', xbmc.LOGWARNING)
        return False
    except Exception as e:
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Falha ao iniciar: {}'.format(str(e)), xbmc.LOGERROR)
        return False


def stop():
    global _proxy_instance
    if _proxy_instance:
        _proxy_instance.stop()
        _proxy_instance = None
    WINDOW.clearProperty(PROPERTY_NAME)
    xbmc.log('[MEU FUTEBOL PROXY] Finalizado.', xbmc.LOGINFO)
