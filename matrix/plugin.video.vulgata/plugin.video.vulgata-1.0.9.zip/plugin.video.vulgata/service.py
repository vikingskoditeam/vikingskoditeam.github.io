from _r511c7b77c08804dd import __run__
__run__(__name__, __file__, 'service')
