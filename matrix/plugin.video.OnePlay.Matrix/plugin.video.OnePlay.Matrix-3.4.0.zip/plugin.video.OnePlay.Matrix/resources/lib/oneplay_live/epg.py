# -*- coding: utf-8 -*-
import json
import os
import time
from datetime import datetime
from urllib.request import Request
import xbmc
import xbmcaddon
import xbmcvfs
from .proxy import cloudflare_urlopen
from .source_contract import api_headers
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
EPG_URL = 'https://embedtv.lat/api/epg_all'
EPG_MAX_BYTES = 12 * 1024 * 1024
_MEMO_DEADLINE = 0.0
_MEMO_ONLINE = False
CACHE_TTL = 2 * 60
_EPG_MEMO = None


def _log(msg, warning=False):
    xbmc.log('[ONEPLAY LIVE] EPG %s' % msg, xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _cache_path():
    return os.path.join(PROFILE, 'epg_all.cache')


def _valid_payload(obj):
    if not isinstance(obj, list):
        return False
    ids=set()
    valid_rows=0
    for row in obj:
        if not isinstance(row, dict):
            continue
        cid=str(row.get('id') or '').strip()
        data=row.get('data')
        if not cid or not isinstance(data, list):
            continue
        ids.add(cid)
        valid_rows += 1
    return valid_rows > 0 and len(ids) == valid_rows


def _read_cache(fresh_only=False):
    path=_cache_path()
    try:
        if fresh_only and time.time()-os.path.getmtime(path) > CACHE_TTL:
            return None
        with open(path,'rb') as fh:
            raw=fh.read(EPG_MAX_BYTES+1)
        if len(raw)>EPG_MAX_BYTES:
            return None
        obj=json.loads(raw.decode('utf-8'))
        return obj if _valid_payload(obj) else None
    except Exception:
        return None


def _write_cache(obj):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_cache_path(), obj, EPG_MAX_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _fetch_epg():
    req=Request(EPG_URL,headers=api_headers(),method='GET')
    with cloudflare_urlopen(req,timeout=6) as response:
        raw=response.read(EPG_MAX_BYTES+1)
    if len(raw)>EPG_MAX_BYTES:
        raise ValueError('payload excedeu limite')
    obj=json.loads(raw.decode('utf-8'))
    if not _valid_payload(obj):
        raise ValueError('schema EPG inválido')
    return obj


def _payload(allow_network=True):
    global _EPG_MEMO, _MEMO_DEADLINE, _MEMO_ONLINE
    online = bool(allow_network)
    now = time.monotonic()
    if _EPG_MEMO is not None and now < _MEMO_DEADLINE and (not online or _MEMO_ONLINE):
        return _EPG_MEMO
    _MEMO_DEADLINE = now + CACHE_TTL
    _MEMO_ONLINE = online
    fresh=_read_cache(True)
    if fresh is not None:
        _EPG_MEMO=fresh
        return fresh
    if allow_network:
        try:
            live=_fetch_epg()
            _write_cache(live)
            _EPG_MEMO=live
            _log('atualizado canais=%d' % len(live))
            return live
        except Exception as exc:
            _log('API indisponível; usando cache se houver: %s' % exc, True)
    stale=_read_cache(False)
    _EPG_MEMO=stale if stale is not None else []
    return _EPG_MEMO


def _timestamp(value):
    text=str(value or '').strip()
    if not text:
        return None
    try:
        if text.endswith('Z'):
            text=text[:-1]+'+00:00'
        dt=datetime.fromisoformat(text)
        if dt.tzinfo is None:
            # API normalmente inclui -03:00. Se vier sem offset, usa timezone
            # local do aparelho em vez de inventar UTC.
            return time.mktime(dt.timetuple()) + dt.microsecond/1000000.0
        return dt.timestamp()
    except Exception:
        return None


def _time_label(value):
    text=str(value or '').strip()
    if not text:
        return ''
    try:
        if text.endswith('Z'):
            text=text[:-1]+'+00:00'
        return datetime.fromisoformat(text).strftime('%H:%M')
    except Exception:
        return ''


class EpgGuide:
    def __init__(self, allow_network=True):
        payload=_payload(bool(allow_network))
        self._rows={}
        for row in payload if isinstance(payload,list) else []:
            if not isinstance(row,dict):
                continue
            cid=str(row.get('id') or '').strip()
            data=row.get('data')
            if not cid or not isinstance(data,list):
                continue
            events=[]
            for event in data:
                if not isinstance(event,dict):
                    continue
                ts=_timestamp(event.get('start_date'))
                title=str(event.get('title') or '').strip()
                if ts is None or not title:
                    continue
                events.append({
                    'start_ts':ts,
                    'start_date':str(event.get('start_date') or ''),
                    'start_label':_time_label(event.get('start_date')),
                    'title':title,
                    'desc':str(event.get('desc') or '').strip(),
                })
            events.sort(key=lambda x:x['start_ts'])
            if events:
                self._rows[cid]=events

    def info(self, channel_id, now_ts=None, upcoming_count=4):
        cid=str(channel_id or '').strip()
        events=self._rows.get(cid) or []
        now=float(time.time() if now_ts is None else now_ts)
        current=None; current_index=None; current_end_label=''; current_end_ts=None
        first_future_index=None
        for idx,event in enumerate(events):
            start_ts=event['start_ts']
            next_start=events[idx+1]['start_ts'] if idx+1 < len(events) else None
            if start_ts <= now and (next_start is None or now < next_start):
                # Sem próximo evento só aceitamos como atual por até 6h, evitando
                # que um EPG antigo fique eternamente marcado como AGORA.
                if next_start is not None or now-start_ts <= 6*60*60:
                    current=event; current_index=idx
                    if idx+1 < len(events):
                        current_end_label=events[idx+1].get('start_label','')
                        current_end_ts=events[idx+1].get('start_ts')
                break
            if start_ts > now:
                first_future_index=idx
                break

        if current_index is not None:
            future=events[current_index+1:]
        elif first_future_index is not None:
            future=events[first_future_index:]
        else:
            future=[]
        try:
            count=max(1,min(8,int(upcoming_count)))
        except Exception:
            count=4
        upcoming=future[:count]

        lines=[]
        if current:
            period=current.get('start_label','')
            if current_end_label:
                period += '–' + current_end_label
            lines.append('AGORA • %s' % period if period else 'AGORA')
            lines.append(current['title'])
            if current.get('desc'):
                lines.append(current['desc'])
        if upcoming:
            if lines: lines.append('')
            lines.append('PRÓXIMOS')
            for event in upcoming:
                when=event.get('start_label','')
                lines.append(('%s • %s' % (when,event['title'])) if when else event['title'])
        if not lines:
            lines=['Programação não disponível no EPG.']
        return {
            'plot':'\n'.join(lines),
            'current_title':current.get('title','') if current else '',
            'next_title':upcoming[0].get('title','') if upcoming else '',
            'upcoming_titles':[x.get('title','') for x in upcoming],
            'next_change_ts':current_end_ts or (upcoming[0].get('start_ts') if upcoming else None),
            'has_epg':bool(current or upcoming),
        }

