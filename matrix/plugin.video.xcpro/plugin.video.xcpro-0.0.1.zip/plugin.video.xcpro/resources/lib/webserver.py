# -*- coding: utf-8 -*-
import os
import sys
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, HTTPServer
import urllib.parse
import xbmc
import xbmcaddon
import socket
import html
import requests
import xbmcgui

ADDON = xbmcaddon.Addon('plugin.video.xcpro')


def normalize_host(host):
    host = (host or '').strip()
    if not host:
        return ''
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    try:
        parsed = urllib.parse.urlparse(host)
        if parsed.scheme and parsed.netloc:
            return '{}://{}'.format(parsed.scheme, parsed.netloc).rstrip('/')
    except Exception:
        pass
    return host.rstrip('/')


def safe_html(value):
    return html.escape(value or '', quote=True)


def extract_query_value_from_raw(raw_url, names):
    """Extrai parâmetros mesmo quando senha vem com # sem encode no get.php."""
    raw_url = raw_url or ''
    for name in names:
        match = re.search(r'(?:\?|&)' + re.escape(name) + r'=([^&\s]+)', raw_url, re.IGNORECASE)
        if match:
            return urllib.parse.unquote_plus(match.group(1)).strip()
    return ''


def parse_login_url(raw_url):
    """Aceita get.php/player_api.php com http, sem http e com caracteres comuns em usuário/senha."""
    raw_url = (raw_url or '').strip()
    if not raw_url:
        return '', '', ''
    parse_raw = raw_url
    if not parse_raw.startswith(('http://', 'https://')):
        parse_raw = 'http://' + parse_raw
    try:
        parsed = urllib.parse.urlparse(parse_raw)
        host = normalize_host('{}://{}'.format(parsed.scheme, parsed.netloc))
        query_parts = urllib.parse.parse_qs(parsed.query)
        user = (query_parts.get('username', [''])[0] or query_parts.get('user', [''])[0]).strip()
        pw = (query_parts.get('password', [''])[0] or query_parts.get('pass', [''])[0]).strip()

        # Fallback bruto: preserva senha com # sem encode, caso comum em links colados crus.
        user_raw = extract_query_value_from_raw(parse_raw, ('username', 'user'))
        pw_raw = extract_query_value_from_raw(parse_raw, ('password', 'pass'))
        if user_raw:
            user = user_raw
        if pw_raw:
            pw = pw_raw
        return host, user, pw
    except Exception:
        return '', '', ''


def get_browser_headers(host=None):
    origin = ''
    try:
        parsed = urllib.parse.urlparse(host or '')
        if parsed.scheme and parsed.netloc:
            origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        origin = ''
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/json,text/plain,*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'close',
    }
    if origin:
        headers['Origin'] = origin
        headers['Referer'] = origin + '/'
    return headers


def validate_credentials(host, user, pw):
    """Validação não-bloqueante.

    Alguns servidores Xtream/WAF bloqueiam player_api.php quando chamado pelo Python
    e respondem 403 mesmo com credenciais corretas. Nesse caso, salvar é mais correto
    do que travar o pareamento. A validação vira diagnóstico, não porteiro chato.
    """
    host = normalize_host(host)
    user = (user or '').strip()
    pw = (pw or '').strip()
    if not host or not user or not pw:
        return False, 'Preencha servidor, usuário e senha.'

    params = urllib.parse.urlencode({'username': user, 'password': pw})
    url = '{}/player_api.php?{}'.format(host, params)
    try:
        response = requests.get(url, timeout=10, headers=get_browser_headers(host), allow_redirects=True)
    except Exception as exc:
        # Não bloqueia o salvamento: o aparelho pode conseguir acessar depois via player/proxy.
        return True, 'Salvo. Não foi possível validar agora: {}'.format(exc)

    if response.status_code == 200:
        try:
            data = response.json()
        except Exception:
            # Alguns painéis retornam HTML/anti-bot, mas os dados podem estar corretos.
            return True, 'Salvo. Servidor respondeu, mas não retornou JSON Xtream na validação.'

        if isinstance(data, dict):
            user_info = data.get('user_info') if isinstance(data.get('user_info'), dict) else {}
            auth = str(user_info.get('auth', '')).strip().lower()
            status = str(user_info.get('status', '')).strip().lower()
            if auth in ('1', 'true', 'yes') or status == 'active':
                return True, 'Validado'
            if user_info:
                # Aqui é o único caso realmente suspeito, mas ainda preservamos o fluxo antigo.
                return True, 'Salvo. Servidor respondeu status: {}'.format(user_info.get('status') or 'desconhecido')
        return True, 'Salvo. Resposta Xtream sem confirmação explícita.'

    # 403/401/406/451 são comuns em WAF, Cloudflare ou painel bloqueando User-Agent/rota.
    return True, 'Salvo. Validação remota retornou HTTP {}.'.format(response.status_code)

class PairingWebHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        # Desestruturar rota
        parsed_path = urllib.parse.urlparse(self.path)
        path = parsed_path.path
        query = urllib.parse.parse_qs(parsed_path.query)

        if path == "/save_login":
            self.handle_save_login(query)
        else:
            self.show_config_page()

    def do_POST(self):
        try:
            content_length = int(self.headers.get('Content-Length', 0))
        except Exception:
            content_length = 0
        # Evita payload grande/indevido no servidor local de pareamento.
        content_length = max(0, min(content_length, 65536))
        post_data = self.rfile.read(content_length).decode('utf-8', errors='ignore')
        params = urllib.parse.parse_qs(post_data)

        self.handle_save_login(params)

    def log_message(self, format, *args):
        # Suprimir logs do servidor HTTP para não poluir o log do Kodi
        pass

    def show_config_page(self):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.end_headers()

        # HTML Premium, simples, mobile-friendly em português para facilitar no celular
        html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurador XC Pro Addon</title>
    <style>
        body {
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
            background-color: #0f172a;
            color: #f8fafc;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            box-sizing: border-box;
        }
        .container {
            width: 100%;
            max-width: 450px;
            background-color: #1e293b;
            padding: 30px;
            border-radius: 16px;
            box-shadow: 0 10px 25px -5px rgba(0,0,0,0.3);
            border: 1px solid #334155;
        }
        h2 {
            margin-top: 0;
            color: #38bdf8;
            font-weight: 700;
            text-align: center;
            margin-bottom: 5px;
        }
        .subtitle {
            text-align: center;
            color: #94a3b8;
            font-size: 14px;
            margin-bottom: 25px;
        }
        .tab-btn-wrapper {
            display: flex;
            background-color: #0f172a;
            padding: 4px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .tab-btn {
            flex: 1;
            padding: 10px;
            background: none;
            border: none;
            color: #94a3b8;
            font-weight: 600;
            cursor: pointer;
            border-radius: 6px;
            font-size: 14px;
        }
        .tab-btn.active {
            background-color: #38bdf8;
            color: #0f172a;
        }
        .form-group {
            margin-bottom: 18px;
            display: flex;
            flex-direction: column;
        }
        label {
            font-size: 13px;
            font-weight: 600;
            color: #cbd5e1;
            margin-bottom: 6px;
        }
        input {
            background-color: #0f172a;
            border: 1px solid #334155;
            color: white;
            padding: 12px;
            border-radius: 8px;
            font-size: 15px;
            outline: none;
            transition: border-color 0.2s;
        }
        input:focus {
            border-color: #38bdf8;
        }
        .btn-submit {
            background-color: #38bdf8;
            color: #0f172a;
            border: none;
            font-size: 16px;
            font-weight: 700;
            padding: 14px;
            border-radius: 8px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
            transition: background-color 0.2s;
        }
        .btn-submit:hover {
            background-color: #0ea5e9;
        }
        .hidden {
            display: none !important;
        }
        .footer {
            margin-top: 25px;
            font-size: 11px;
            text-align: center;
            color: #64748b;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>XC PRO - PAINEL</h2>
        <div class="subtitle">Insira os dados do Xtream Codes de forma simples</div>
        
        <div class="tab-btn-wrapper">
            <button class="tab-btn active" id="btn-get" onclick="switchTab('get')">Link API Get.php</button>
            <button class="tab-btn" id="btn-manual" onclick="switchTab('manual')">Dados Manuais</button>
        </div>

        <!-- Formulário Link Get.php -->
        <form id="form-get" action="/save_login" method="POST">
            <div class="form-group">
                <label for="get_url">Link de Download Completo (get.php)</label>
                <input type="text" id="get_url" name="get_url" placeholder="http://servidor.co/get.php?username=...&password=..." required>
            </div>
            <button type="submit" class="btn-submit">Sincronizar no Kodi</button>
        </form>

        <!-- Formulário Manual -->
        <form id="form-manual" action="/save_login" method="POST" class="hidden">
            <div class="form-group">
                <label for="host">URL do Servidor Xtream Codes</label>
                <input type="text" id="host" name="host" placeholder="servidor.xyz:8080 ou http://servidor.xyz:8080">
            </div>
            <div class="form-group">
                <label for="username">Usuário (Username)</label>
                <input type="text" id="username" name="username" placeholder="Seu usuário da lista">
            </div>
            <div class="form-group">
                <label for="password">Senha (Password)</label>
                <input type="password" id="password" name="password" placeholder="Sua senha da lista">
            </div>
            <button type="submit" class="btn-submit">Salvar Credenciais</button>
        </form>

        <div class="footer">XC Pro Addon para Kodi v19/v20/v21. Conexão local pela rede do aparelho.</div>
    </div>

    <script>
        function switchTab(type) {
            const formGet = document.getElementById('form-get');
            const formManual = document.getElementById('form-manual');
            const btnGet = document.getElementById('btn-get');
            const btnManual = document.getElementById('btn-manual');

            if (type === 'get') {
                formGet.classList.remove('hidden');
                formManual.classList.add('hidden');
                btnGet.classList.add('active');
                btnManual.classList.remove('active');
                
                document.getElementById('get_url').required = true;
                document.getElementById('host').required = false;
                document.getElementById('username').required = false;
                document.getElementById('password').required = false;
            } else {
                formGet.classList.add('hidden');
                formManual.classList.remove('hidden');
                btnGet.classList.remove('active');
                btnManual.classList.add('active');
                
                document.getElementById('get_url').required = false;
                document.getElementById('host').required = true;
                document.getElementById('username').required = true;
                document.getElementById('password').required = true;
            }
        }
    </script>
</body>
</html>
"""
        self.wfile.write(html.encode('utf-8'))

    def handle_save_login(self, params):
        host = ""
        user = ""
        pw = ""
        error_msg = "Verifique o link ou preencha servidor, usuário e senha."

        if 'get_url' in params and params.get('get_url', [''])[0].strip():
            # Extrair do link completo get.php / player_api.php.
            host, user, pw = parse_login_url(params.get('get_url', [''])[0])
        else:
            # Entrada manual pelo navegador do celular.
            host_raw = (params.get('host', [''])[0] or '').strip()
            user = (params.get('username', [''])[0] or '').strip()
            pw = (params.get('password', [''])[0] or '').strip()

            # Se o usuário colar o get.php/player_api.php no campo servidor manual,
            # usa apenas o domínio como host e aproveita usuário/senha do link quando faltarem.
            if 'get.php' in host_raw.lower() or 'player_api.php' in host_raw.lower():
                host, user_from_url, pw_from_url = parse_login_url(host_raw)
                user = user or user_from_url
                pw = pw or pw_from_url
            else:
                host = normalize_host(host_raw)

        success, validation_msg = validate_credentials(host, user, pw)
        if not success:
            error_msg = validation_msg

        if success:
            # Salva diretamente nas configurações do Addon no Kodi.
            ADDON.setSetting('host', host)
            ADDON.setSetting('username', user)
            ADDON.setSetting('password', pw)

            # Fecha a janela do QR na TV e força recarregamento para entrar no menu principal.
            try:
                xbmcgui.Window(10000).setProperty('xcpro_pairing_saved', '1')
            except Exception:
                pass
            xbmc.executebuiltin('Dialog.Close(all,true)')
            xbmc.executebuiltin('Notification(XC Pro, Configuração salva!, 5000)')
            xbmc.executebuiltin('Container.Refresh')

            # Mostra página de sucesso no celular.
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()

            success_html = """<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sincronizado! - XC Pro</title>
    <style>
        body { font-family: -apple-system, sans-serif; background-color: #0f172a; color: white; text-align: center; padding: 40px 20px; }
        .success-card { background-color: #1e293b; padding: 30px; border-radius: 16px; border: 1px solid #38bdf8; max-width: 400px; margin: 50px auto 0; }
        h1 { color: #4ade80; margin-top: 0; }
        p { color: #94a3b8; line-height: 1.6; }
        .details { font-size: 13px; text-align: left; background-color: #0f172a; padding: 15px; border-radius: 8px; margin-top: 20px; border: 1px solid #334155; }
        .detail-line { margin: 6px 0; color: #cbd5e1; word-break: break-word; }
    </style>
</head>
<body>
    <div class="success-card">
        <h1>Conectado com Sucesso!</h1>
        <p>As configurações foram enviadas para a sua TV / Kodi.</p>
        <div class="details">
            <div class="detail-line"><b>Servidor:</b> """ + safe_html(host) + """</div>
            <div class="detail-line"><b>Usuário:</b> """ + safe_html(user) + """</div>
            <div class="detail-line"><b>Status:</b> """ + safe_html(validation_msg) + """</div>
        </div>
        <p style="font-size: 12px; margin-top: 25px;">Pode fechar esta aba no seu celular.</p>
    </div>
</body>
</html>"""
            self.wfile.write(success_html.encode('utf-8'))
        else:
            self.send_response(400)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()
            fail_html = """<!DOCTYPE html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
body { font-family:-apple-system,sans-serif;background:#0f172a;color:white;text-align:center;padding:30px; }
.card { background:#1e293b;border:1px solid #ef4444;border-radius:16px;padding:25px;max-width:430px;margin:40px auto 0; }
p { color:#cbd5e1; line-height:1.5; }
a { color:#38bdf8; font-weight:700; }
</style></head>
<body><div class="card">
<h2>Erro de conexão</h2>
<p>""" + safe_html(error_msg) + """</p>
<p>Confira servidor, usuário e senha. Se estiver usando link get.php, cole o link completo novamente.</p>
<p><a href="/">Tentar novamente</a></p>
</div></body></html>"""
            self.wfile.write(fail_html.encode('utf-8'))

class ManageableHTTPServer(HTTPServer):
    """HTTP Server que pode ser parado via flag"""
    def __init__(self, server_address, RequestHandlerClass, monitor=None):
        HTTPServer.__init__(self, server_address, RequestHandlerClass)
        self.monitor = monitor
        self.running = True
        try:
            self.socket.settimeout(1.0)
        except Exception:
            pass
    
    def serve_forever(self, poll_interval=0.5):
        """Serve requests until asked to stop or Kodi aborts"""
        self.running = True
        while self.running:
            # Verificar abortRequested do Kodi
            if self.monitor and self.monitor.abortRequested():
                xbmc.log("[XC Pro WebServer] abortRequested detectado, parando...", xbmc.LOGINFO)
                break
            
            # Processar requisições com timeout
            self.handle_request()
            time.sleep(poll_interval)
    
    def handle_request(self):
        """Handle one request, with timeout"""
        try:
            self.timeout = 1
            request, client_address = self.get_request()
        except socket.timeout:
            return
        except Exception:
            return
        
        if request is None:
            return
        
        try:
            self.process_request(request, client_address)
        except Exception:
            self.handle_error(request, client_address)
            self.close_request(request)
    
    def stop(self):
        """Para o servidor"""
        self.running = False
        try:
            self.server_close()
        except:
            pass


class PairingWebServer:
    """Servidor de pareamento controlável pelo service.py."""

    def __init__(self, port=9099, monitor=None):
        self.port = int(port)
        self.monitor = monitor
        self.server = None

    def start(self):
        try:
            self.server = ManageableHTTPServer(('0.0.0.0', self.port), PairingWebHandler, self.monitor)
            xbmc.log(f"[XC Pro WebServer] Servidor de pareamento iniciado na porta {self.port}", xbmc.LOGINFO)
            self.server.serve_forever()
        except Exception as e:
            xbmc.log(f"[XC Pro WebServer] Erro: {e}", xbmc.LOGERROR)
        finally:
            self.stop()

    def stop(self):
        if self.server:
            try:
                self.server.stop()
            except Exception:
                pass
            self.server = None


def start_pairing_webserver(port=9099, monitor=None):
    """Compatibilidade: inicia o webserver de pareamento em modo bloqueante."""
    PairingWebServer(port, monitor).start()
