# default.py
# -*- coding: utf-8 -*-
import os
import ntpath
import sys

import xbmc
import xbmcgui
import xbmcaddon
import xbmcvfs

from scrapy import listar_apks
from cleanup import register_download
from diagnostics import debug_log, format_device_info, log_device_info_if_debug

addon = xbmcaddon.Addon()
addonname = addon.getAddonInfo('name')
icon = addon.getAddonInfo('icon')

FOLDER_DOWNLOADS = '/storage/emulated/0/Download'


# Compatibilidade pós-download Android. O caminho homologado com DocumentsUI
# permanece prioritário. Em ROMs sem DocumentsUI, detecta gerenciadores
# instalados e usa o mesmo padrão content:// do Kodi Android Installer.
_ANDROID_PRIMARY_HANDLER = 'com.android.documentsui'
_ANDROID_FILE_MANAGER_FALLBACKS = (
    'com.google.android.apps.nbu.files',       # Files by Google
    'com.sec.android.app.myfiles',            # Samsung My Files
    'com.mi.android.globalFileexplorer',      # Xiaomi / Mi File Manager
    'com.android.fileexplorer',               # MIUI / variantes AOSP
    'com.alphainventor.filemanager',          # File Manager Plus
    'com.softwinner.TvdFileManager',          # TV Box / Allwinner
    'com.droidlogic.FileBrower',              # TV Box / Amlogic (variante OEM)
    'com.droidlogic.FileBrowser',             # TV Box / Amlogic
    'com.lonelycatgames.Xplore',              # X-plore
    'nextapp.fx',                             # FX File Explorer
    'com.ghisler.android.TotalCommander',     # Total Commander
    'pl.solidexplorer2',                      # Solid Explorer
    'com.mobisystems.fileman',                # File Commander
    'com.amaze.filemanager',                  # Amaze
    'com.asus.filemanager',                   # ASUS File Manager
    'com.mixplorer',                          # MiXplorer
    'com.mixplorer.silver',                   # MiXplorer Silver
)
_ANDROID_APK_MIME = 'application/vnd.android.package-archive'
_FILE_MANAGER_PACKAGE_MARKERS = (
    'filemanager', 'file.manager', 'file_manager',
    'fileexplorer', 'file.explorer', 'file_explorer',
    'filebrowser', 'file.browser', 'file_browser',
    'tvdfilemanager',
)


def _installed_android_apps():
    """Retorna pacotes Android visíveis ao Kodi ou None se a consulta falhar."""
    try:
        _dirs, apps = xbmcvfs.listdir('androidapp://sources/apps/')
        return [str(app) for app in (apps or []) if app]
    except Exception as exc:
        debug_log('Não foi possível consultar apps Android instalados: %s' % exc)
        return None


def _find_installed_file_manager(installed):
    """Localiza gerenciador conhecido ou OEM sem depender de marca específica."""
    if not installed:
        return None

    by_lower = {package.lower(): package for package in installed}

    # Primeiro, pacotes conhecidos e testáveis por correspondência exata.
    for package_name in _ANDROID_FILE_MANAGER_FALLBACKS:
        actual = by_lower.get(package_name.lower())
        if actual:
            return actual

    # Depois, variantes OEM cujo package name deixa claro que é file manager.
    for package_name in installed:
        lowered = package_name.lower()
        if any(marker in lowered for marker in _FILE_MANAGER_PACKAGE_MARKERS):
            return package_name

    return None


def _open_handler_with_content_uri(package_name, dest):
    """Mesmo padrão usado pelo Kodi Android Installer para custom manager."""
    safe_dest = dest.replace('"', '%22')
    xbmc.executebuiltin(
        'StartAndroidActivity(%s,,,"content://%s")' % (package_name, safe_dest)
    )


def _open_downloaded_apk(dest):
    """Abre o APK preservando o caminho homologado e ampliando ROMs OEM.

    1) DocumentsUI continua prioritário quando presente;
    2) sem ele, usa gerenciador conhecido ou detectado pelo package name;
    3) se a enumeração falhar, mantém o caminho homologado com DocumentsUI;
    4) sem gerenciador detectável, mantém o fallback implícito ACTION_VIEW.
    """
    installed = _installed_android_apps()

    if installed is None:
        debug_log('Pós-download Android: enumeração indisponível; usando DocumentsUI')
        _open_handler_with_content_uri(_ANDROID_PRIMARY_HANDLER, dest)
        return

    installed_lower = {package.lower(): package for package in installed}
    primary = installed_lower.get(_ANDROID_PRIMARY_HANDLER.lower())
    if primary:
        debug_log('Pós-download Android: handler=%s' % primary)
        _open_handler_with_content_uri(primary, dest)
        return

    package_name = _find_installed_file_manager(installed)
    if package_name:
        debug_log('Pós-download Android: fallback handler=%s' % package_name)
        _open_handler_with_content_uri(package_name, dest)
        return

    # Último recurso: intent implícito. Algumas ROMs de TV Box não resolvem
    # este caminho, por isso ele só é usado quando nenhum gerenciador é detectado.
    safe_dest = dest.replace('"', '%22')
    debug_log('Pós-download Android: fallback implícito ACTION_VIEW')
    xbmc.executebuiltin(
        'StartAndroidActivity(,android.intent.action.VIEW,%s,"content://%s")' % (
            _ANDROID_APK_MIME, safe_dest
        )
    )


def L(string_id, fallback=''):
    try:
        value = addon.getLocalizedString(int(string_id))
        return value or fallback
    except Exception:
        return fallback


def platform():
    if xbmc.getCondVisibility('system.platform.android'):
        return 'android'
    elif xbmc.getCondVisibility('system.platform.linux') or xbmc.getCondVisibility('system.platform.linux.Raspberrypi'):
        return 'linux'
    elif xbmc.getCondVisibility('system.platform.windows'):
        return 'windows'
    elif xbmc.getCondVisibility('system.platform.osx'):
        return 'osx'
    elif xbmc.getCondVisibility('system.platform.atv2'):
        return 'atv2'
    elif xbmc.getCondVisibility('system.platform.ios') or xbmc.getCondVisibility('system.platform.darwin'):
        return 'ios'
    return None


def infoDialog(message, heading=addonname, iconimage=None, time=3000, sound=False):
    if iconimage is None:
        iconimage = icon
    elif iconimage == 'INFO':
        iconimage = xbmcgui.NOTIFICATION_INFO
    elif iconimage == 'WARNING':
        iconimage = xbmcgui.NOTIFICATION_WARNING
    elif iconimage == 'ERROR':
        iconimage = xbmcgui.NOTIFICATION_ERROR

    xbmcgui.Dialog().notification(heading, message, iconimage, time, sound=sound)


def download_apk(url, filename, dest):
    try:
        import downloader
        dp = xbmcgui.DialogProgress()
        dp.create(L(30002, 'Baixando %s...') % filename, L(30003, 'Por favor, aguarde...'))
        try:
            downloader.download(url, filename, dest, dp=dp)
        finally:
            dp.close()
        # A confirmação de sucesso é exibida em uma janela grande somente
        # após o arquivo ser registrado para limpeza futura.
        return True
    except Exception as exc:
        xbmc.log('[ONEPLAY APK Downloader] Erro: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            addonname,
            '[COLOR red]%s[/COLOR]\n\n%s' % (L(30005, 'Não foi possível baixar o APK.'), str(exc))
        )
        return False


def select_apk(namelist):
    return xbmcgui.Dialog().select(L(30006, 'SELECIONE UM APK ABAIXO'), namelist)



def format_file_size(size_bytes):
    """Formata bytes vindos do MediaFire sem realizar requisição adicional."""
    try:
        size = float(size_bytes or 0)
    except (TypeError, ValueError):
        return ''

    if size <= 0:
        return ''

    units = ('B', 'KB', 'MB', 'GB', 'TB')
    unit_index = 0
    while size >= 1024.0 and unit_index < len(units) - 1:
        size /= 1024.0
        unit_index += 1

    if unit_index == 0:
        value = '%d' % int(size)
    elif size >= 100:
        value = '%.0f' % size
    elif size >= 10:
        value = '%.1f' % size
    else:
        value = '%.2f' % size

    return '%s %s' % (value, units[unit_index])

def build_item():
    try:
        itens = listar_apks()
    except Exception as exc:
        xbmc.log('[ONEPLAY APK Downloader] Falha na listagem MediaFire: %s' % exc, xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            addonname,
            '[COLOR red]%s[/COLOR]\n\n%s' % (L(30007, 'Não foi possível carregar a pasta do MediaFire.'), str(exc))
        )
        return None

    if not itens:
        xbmcgui.Dialog().ok(
            addonname,
            L(30008, 'Nenhum arquivo [COLOR yellow].apk[/COLOR] foi encontrado na pasta do MediaFire.')
        )
        return None

    debug_log('Catálogo carregado: %d APK(s).' % len(itens))

    names = []
    for item in itens:
        display_name = item[0]
        size_bytes = item[3] if len(item) > 3 else 0
        size_text = format_file_size(size_bytes)
        if size_text:
            names.append('%s  [COLOR gray](%s)[/COLOR]' % (display_name, size_text))
        else:
            names.append(display_name)

    escolha = select_apk(names)
    if escolha >= 0:
        item = itens[escolha]
        display_name, page_url, filename = item[:3]
        size_bytes = item[3] if len(item) > 3 else 0
        debug_log('APK selecionado: %s | tamanho=%s | página=%s' % (
            filename, format_file_size(size_bytes) or 'desconhecido', page_url
        ))
        return {
            'display_name': display_name,
            'url': page_url,
            'filename': filename,
            'size_bytes': size_bytes,
        }
    return None


def _confirm_redownload(dest, filename):
    if not os.path.isfile(dest):
        return True

    message = L(
        30012,
        'O arquivo %s já existe na pasta Download. Deseja baixar novamente?'
    ) % filename

    return xbmcgui.Dialog().yesno(
        L(30011, 'Arquivo já existe'),
        message,
        nolabel=L(30013, 'Cancelar'),
        yeslabel=L(30014, 'Baixar novamente'),
    )


def show_device_info():
    xbmcgui.Dialog().ok(L(30001, 'Informações do dispositivo'), format_device_info())


def baixar_apk():
    if platform() != 'android':
        xbmcgui.Dialog().ok(addonname, L(30009, 'Este dispositivo não é Android!'))
        return

    # Somente diagnóstico. Não altera catálogo, resolver, download ou limpeza.
    log_device_info_if_debug()

    item = build_item()
    if not item:
        return

    filename = os.path.basename(item['filename']) or ntpath.basename(item['filename'])
    if not filename.lower().endswith('.apk'):
        xbmcgui.Dialog().ok(addonname, L(30010, 'O item selecionado não é um APK válido.'))
        return

    if not xbmcvfs.exists(FOLDER_DOWNLOADS):
        xbmcvfs.mkdirs(FOLDER_DOWNLOADS)

    dest = os.path.join(FOLDER_DOWNLOADS, filename)
    debug_log('Destino Android: %s | existente=%s' % (dest, os.path.isfile(dest)))

    # Evolução 1.0.12: não apaga silenciosamente um APK existente.
    # O usuário decide se deseja baixar novamente; cancelar mantém o arquivo.
    if not _confirm_redownload(dest, filename):
        return

    if os.path.isfile(dest):
        try:
            os.remove(dest)
        except Exception as exc:
            xbmc.log('[ONEPLAY APK Downloader] Falha ao substituir APK existente: %s' % exc, xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(addonname, L(30021, 'Não foi possível substituir o APK existente.'))
            return

    if not download_apk(item['url'], filename, dest):
        return

    if os.path.isfile(dest):
        # O arquivo permanece disponível durante toda esta sessão do Kodi.
        # Ele será removido somente na próxima inicialização, após um
        # fechamento real do Kodi, pelo serviço de limpeza automática.
        register_download(dest)
        debug_log('Download concluído e registrado para limpeza futura: %s' % dest)
        try:
            actual_size = os.path.getsize(dest)
        except Exception:
            actual_size = item.get('size_bytes', 0)

        size_text = format_file_size(actual_size) or L(30028, 'Desconhecido')
        success_text = (
            '[COLOR yellow]%s[/COLOR]\n'
            '[COLOR white]%s:[/COLOR] [COLOR lime]%s[/COLOR]\n'
            '[COLOR white]%s:[/COLOR] [COLOR cyan]%s[/COLOR]\n'
            '[COLOR gray]%s[/COLOR]'
        ) % (
            L(30022, 'Download concluído!'),
            L(30023, 'APK'), filename,
            L(30024, 'Tamanho'), size_text,
            L(30029, 'Instalação manual • limpeza automática no próximo início do Kodi.'),
        )
        xbmcgui.Dialog().ok(addonname, success_text)

        # Evolução conservadora 1.1.2: mantém DocumentsUI como caminho
        # prioritário e amplia compatibilidade apenas quando ele não existe.
        try:
            _open_downloaded_apk(dest)
        except Exception as exc:
            xbmc.log(
                '[ONEPLAY APK Downloader] Falha ao abrir APK no gerenciador Android: %s' % exc,
                xbmc.LOGWARNING
            )


def main():
    action = sys.argv[1].lower() if len(sys.argv) > 1 else ''
    if action == 'deviceinfo':
        show_device_info()
        return
    baixar_apk()


if __name__ == '__main__':
    main()
