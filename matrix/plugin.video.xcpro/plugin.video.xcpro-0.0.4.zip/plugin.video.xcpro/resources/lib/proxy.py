# -*- coding: utf-8 -*-
"""Proxy local do XC Pro.

Motor híbrido conservador:
- mantém a API pública do XC Pro (UnifiedServer e rotas locais já usadas pelo addon);
- corrige abertura lenta de VOD com fallback HEAD -> GET Range 0-0;
- separa HLS Live/VOD por parâmetro kind=live|vod e arte por kind=art;
- aplica Range seguro para VOD direto, episódios e segmentos;
- entrega TS/M3U8 com retries curtos, sem mudar menus/login/EPG/favoritos do XC Pro.
"""

import gzip
import http.client
import re
import socket
import socketserver
import ssl
import time
import zlib
from collections import deque
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, unquote, urljoin, urlparse, urlsplit
from urllib.request import Request, urlopen

import dnsresolver
from xcpro_core import redact_url

dnsresolver.install()

try:
    import xbmc
except Exception:  # ambiente de teste fora do Kodi
    xbmc = None


def log(msg, level=None):
    try:
        clean = redact_url(str(msg))
        if xbmc:
            if level is None:
                level = xbmc.LOGINFO
            xbmc.log('[XC Pro Proxy] {}'.format(clean), level)
        else:
            print('[XC Pro Proxy] {}'.format(clean))
    except Exception:
        pass


# ==================== CONFIGURAÇÃO CONSERVADORA ====================
PROXY_PORT = 9097
BUFFER_SIZE = 64 * 1024
LIVE_BUFFER_SIZE = 16 * 1024
VOD_TIMEOUT = 18
ART_TIMEOUT = 4
# Timeout curto exclusivo para o pré-check HEAD do Kodi.
# Muitos Xtream travam/ignoram HEAD e até probes curtos podem segurar o Stat do Kodi.
# Em VOD, HEAD local deve ser imediato; a validação real fica no GET.
LIVE_TIMEOUT = 12
PLAYLIST_TIMEOUT = 10
TS_TIMEOUT = 10
RETRY_DELAY = 0.30
VOD_MAX_RETRIES = 2
VOD_SEGMENT_MAX_RETRIES = 3
LIVE_PLAYLIST_MAX_RETRIES = 5
LIVE_SEGMENT_MAX_RETRIES = 2
LIVE_SEGMENT_404_RETRIES = 1
TS_RECONNECT_DELAY = 0.45
TS_NULL_PACKET = b'\x47\x1f\xff\x10' + (b'\xff' * 184)
MAX_ATOMIC_SEGMENT_BYTES = 64 * 1024 * 1024
CACHE_DURATION_SECONDS = 5
CACHE_MAX_CHUNKS = 160
MAX_CHANNEL_CACHES = 4
MAX_VOD_CACHES = 4

CHROME_UA = (
    'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/130.0.0.0 Safari/537.36'
)

BLOCKED_UPSTREAM_HEADERS = {
    'host', 'connection', 'content-length', 'transfer-encoding',
    'accept-encoding', 'proxy-connection', 'keep-alive'
}
ALLOWED_EXTRA_HEADERS = {'cookie', 'authorization', 'referer', 'origin', 'accept-language', 'user-agent', 'accept'}
RETRYABLE_CODES = {403, 405, 406, 408, 409, 429, 451, 500, 502, 503, 504, 520, 521, 522, 523, 524}


def _warn_level():
    return getattr(xbmc, 'LOGWARNING', None) if xbmc else None


def get_origin(url):
    try:
        parsed = urlparse(url or '')
        if parsed.scheme and parsed.netloc:
            return '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        pass
    return ''


def _header_get(headers, name, default=''):
    try:
        return headers.get(name) or headers.get(name.lower()) or headers.get(name.title()) or default
    except Exception:
        return default


def _positive_int(value):
    try:
        number = int(str(value or '').strip())
        return number if number >= 0 else None
    except Exception:
        return None


def _parse_requested_range(value):
    try:
        match = re.match(r'^\s*bytes=(\d+)-(\d*)\s*$', str(value or ''), re.I)
        if not match:
            return None, None
        start = int(match.group(1))
        end = int(match.group(2)) if match.group(2) else None
        return start, end
    except Exception:
        return None, None


def _parse_content_range(value):
    try:
        match = re.match(r'^\s*bytes\s+(\d+)-(\d+)/(\d+|\*)\s*$', str(value or ''), re.I)
        if not match:
            return None, None, None
        start = int(match.group(1))
        end = int(match.group(2))
        total = None if match.group(3) == '*' else int(match.group(3))
        if start > end:
            return None, None, None
        return start, end, total
    except Exception:
        return None, None, None


def _status(response):
    try:
        return int(response.getcode() or 0)
    except Exception:
        return int(getattr(response, 'code', 0) or 0)


def _response_headers(response):
    try:
        return response.headers or {}
    except Exception:
        return {}


def _response_url(response, fallback):
    try:
        return response.geturl() or fallback
    except Exception:
        return fallback


def _is_valid_upstream_url(url):
    try:
        parsed = urlparse(url or '')
        return parsed.scheme in ('http', 'https') and bool(parsed.netloc)
    except Exception:
        return False


def _is_probably_vod(url):
    lower = (url or '').lower()
    if any(ext in lower for ext in ('.mp4', '.mkv', '.webm', '.f4v', '.mov', '.avi', '.m4v')):
        return True
    if '/movie/' in lower or '/series/' in lower or '/play/' in lower:
        return True
    return False


def _is_probably_playlist(url):
    lower = (url or '').lower()
    return '.m3u8' in lower or 'output=m3u8' in lower or 'type=m3u8' in lower


def _is_probably_ts(url):
    lower = (url or '').lower()
    return lower.endswith('.ts') or '.ts?' in lower or '/ts/' in lower or '/live/' in lower


def _guess_content_type(url, upstream_value=''):
    raw = (upstream_value or '').split(';', 1)[0].strip().lower()
    if raw and raw not in ('application/json', 'text/html', 'text/plain', 'application/xml', 'text/xml', 'binary/octet-stream'):
        return upstream_value
    try:
        path = (urlparse(url or '').path or '').lower()
    except Exception:
        path = (url or '').lower()
    if path.endswith('.m3u8'):
        return 'application/vnd.apple.mpegurl'
    if path.endswith('.mkv'):
        return 'video/x-matroska'
    if path.endswith('.avi'):
        return 'video/x-msvideo'
    if path.endswith('.mov'):
        return 'video/quicktime'
    if path.endswith('.webm'):
        return 'video/webm'
    if path.endswith('.ts'):
        return 'video/mp2t'
    if path.endswith('.m4v'):
        return 'video/x-m4v'
    return 'video/mp4'


def _safe_header_value(value):
    try:
        text = str(value or '').replace('\r', '').replace('\n', '').strip()
        return text[:4096]
    except Exception:
        return ''


class CircularBuffer:
    def __init__(self, max_seconds=5, max_chunks=160):
        self.buffer = deque()
        self.timestamps = deque()
        self.max_seconds = max_seconds
        self.max_chunks = max_chunks
        self.last_access = time.time()

    def touch(self):
        self.last_access = time.time()

    def add_chunk(self, chunk):
        if not chunk:
            return
        self.last_access = time.time()
        self.buffer.append(chunk)
        self.timestamps.append(time.time())
        cutoff = time.time() - self.max_seconds
        while self.timestamps and (len(self.buffer) > self.max_chunks or self.timestamps[0] < cutoff):
            self.timestamps.popleft()
            self.buffer.popleft()

    def recent_chunks(self, count=16):
        self.touch()
        if not self.buffer:
            return []
        return list(self.buffer)[-count:]


class ByteRangeCache:
    def __init__(self, max_chunks=160):
        self.chunks = {}
        self.max_chunks = max_chunks
        self.content_length = None
        self.last_access = time.time()

    def touch(self):
        self.last_access = time.time()

    def add_chunk(self, start_byte, data):
        if not data:
            return
        self.last_access = time.time()
        if start_byte not in self.chunks:
            self.chunks[start_byte] = data
            while len(self.chunks) > self.max_chunks:
                oldest = min(self.chunks.keys())
                self.chunks.pop(oldest, None)

    def get_range(self, start, end_exclusive):
        self.touch()
        keys = sorted(self.chunks.keys())
        if not keys:
            return None
        result = bytearray()
        pos = start
        while pos < end_exclusive:
            found = False
            for chunk_start in keys:
                chunk = self.chunks[chunk_start]
                chunk_end = chunk_start + len(chunk)
                if chunk_start <= pos < chunk_end:
                    offset = pos - chunk_start
                    take = min(end_exclusive - pos, chunk_end - pos)
                    result.extend(chunk[offset:offset + take])
                    pos += take
                    found = True
                    break
            if not found:
                return None
        return bytes(result)


class UnifiedProxy:
    def __init__(self):
        self.channel_caches = {}
        self.vod_caches = {}
        self.strict_ssl_context = ssl.create_default_context()
        self.legacy_ssl_context = ssl.create_default_context()
        self.legacy_ssl_context.check_hostname = False
        self.legacy_ssl_context.verify_mode = ssl.CERT_NONE

    @staticmethod
    def _certificate_error(exc):
        reason = getattr(exc, 'reason', exc)
        return isinstance(reason, ssl.SSLCertVerificationError) or 'CERTIFICATE_VERIFY_FAILED' in str(reason)

    def _open_request(self, request, timeout):
        dnsresolver.register_url(request.full_url)
        if not request.full_url.lower().startswith('https://'):
            return urlopen(request, timeout=timeout)
        try:
            return urlopen(request, timeout=timeout, context=self.strict_ssl_context)
        except URLError as exc:
            if self._certificate_error(exc):
                log('Certificado TLS inválido; usando compatibilidade nesta conexão.', _warn_level())
                return urlopen(request, timeout=timeout, context=self.legacy_ssl_context)
            raise

    @staticmethod
    def _prune_cache_map(mapping, limit):
        while len(mapping) >= limit:
            oldest_key = min(mapping, key=lambda key: getattr(mapping[key], 'last_access', 0))
            mapping.pop(oldest_key, None)

    def get_channel_cache(self, url):
        key = self._cache_key(url)
        if key not in self.channel_caches:
            self._prune_cache_map(self.channel_caches, MAX_CHANNEL_CACHES)
            self.channel_caches[key] = CircularBuffer(CACHE_DURATION_SECONDS, CACHE_MAX_CHUNKS)
        cache = self.channel_caches[key]
        cache.touch()
        return cache

    def get_vod_cache(self, url):
        key = self._cache_key(url)
        if key not in self.vod_caches:
            self._prune_cache_map(self.vod_caches, MAX_VOD_CACHES)
            self.vod_caches[key] = ByteRangeCache(CACHE_MAX_CHUNKS)
        cache = self.vod_caches[key]
        cache.touch()
        return cache

    @staticmethod
    def _cache_key(url):
        return re.sub(r'([?&](?:_=|timestamp=|t=|seq=)\d+)', '', url or '')

    @staticmethod
    def get_local_ip():
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(('1.1.1.1', 80))
            return s.getsockname()[0]
        except Exception:
            return '127.0.0.1'
        finally:
            s.close()

    def extract_url_from_path(self, path):
        url, _params = self.extract_params_from_path(path)
        return url

    def extract_params_from_path(self, path):
        try:
            raw = path or ''
            parsed = urlsplit(raw)
            params = parse_qs(parsed.query, keep_blank_values=True)
            url = (params.get('url') or [''])[0]
            if url:
                return unquote(url).split('|', 1)[0].strip(), params
            if raw.startswith('/http://') or raw.startswith('/https://'):
                return unquote(raw[1:]).split('|', 1)[0].strip(), params
            if raw.startswith('http://') or raw.startswith('https://'):
                return unquote(raw).split('|', 1)[0].strip(), params
        except Exception:
            pass
        return None, {}

    @staticmethod
    def _write_plain_response(wfile, code, message, body=''):
        try:
            body_bytes = (body or message or '').encode('utf-8', 'replace')
            reason = http.client.responses.get(code, message or 'Error')
            wfile.write('HTTP/1.1 {} {}\r\n'.format(code, reason).encode())
            wfile.write(b'Content-Type: text/plain; charset=utf-8\r\n')
            wfile.write('Content-Length: {}\r\n'.format(len(body_bytes)).encode())
            wfile.write(b'Access-Control-Allow-Origin: *\r\n')
            wfile.write(b'Connection: close\r\n')
            wfile.write(b'\r\n')
            if body_bytes:
                wfile.write(body_bytes)
        except Exception:
            pass

    def _build_upstream_headers(self, url, client_headers=None, range_header=None, profile='direct', stream=False):
        client_headers = client_headers or {}
        origin = get_origin(url)
        headers = {
            'User-Agent': CHROME_UA,
            'Accept': '*/*' if stream else 'video/mp4,video/*;q=0.9,*/*;q=0.8',
            'Accept-Language': 'pt-BR,pt;q=0.9',
            'Accept-Encoding': 'identity',
            'Connection': 'close',
        }
        if origin and profile in ('direct', 'origin'):
            headers['Origin'] = origin
            headers['Referer'] = origin + '/'

        for key, value in client_headers.items():
            lk = str(key or '').lower()
            if lk in BLOCKED_UPSTREAM_HEADERS or lk == 'range':
                continue
            if lk in ALLOWED_EXTRA_HEADERS:
                canonical = '-'.join(part.capitalize() for part in lk.split('-'))
                clean_value = _safe_header_value(value)
                if clean_value:
                    headers[canonical] = clean_value

        if profile == 'minimal':
            headers.pop('Origin', None)
            headers.pop('Referer', None)
            headers.pop('Accept-Language', None)
            headers['Accept'] = '*/*'
            headers['User-Agent'] = CHROME_UA
        elif profile == 'origin' and origin:
            headers['Origin'] = origin
            headers['Referer'] = origin + '/'

        if range_header:
            headers['Range'] = _safe_header_value(range_header)
        return headers

    def _open_upstream(self, method, url, client_headers=None, range_header=None, timeout=VOD_TIMEOUT, stream=False, profiles=('direct', 'origin', 'minimal')):
        last = None
        for profile in profiles:
            req_headers = self._build_upstream_headers(url, client_headers=client_headers, range_header=range_header, profile=profile, stream=stream)
            try:
                req = Request(url, headers=req_headers, method=method)
            except TypeError:  # Python antigo do Kodi não costuma precisar, mas deixa compatível
                req = Request(url, headers=req_headers)
                try:
                    req.get_method = lambda m=method: m
                except Exception:
                    pass
            try:
                response = self._open_request(req, timeout=timeout)
                code = _status(response)
                if 200 <= code < 300:
                    return response
                last = response
                if code not in RETRYABLE_CODES:
                    break
                try:
                    response.close()
                except Exception:
                    pass
                last = None
                time.sleep(0.12)
            except HTTPError as exc:
                code = getattr(exc, 'code', 0) or 0
                last = exc
                if code not in RETRYABLE_CODES:
                    break
                try:
                    exc.close()
                except Exception:
                    pass
                last = None
                time.sleep(0.12)
            except Exception as exc:
                last = None
                log('Falha upstream {} {} perfil {}: {}'.format(method, url, profile, exc), _warn_level())
                time.sleep(0.12)
        return last

    def _send_simple_error(self, wfile, status_code, message):
        body = str(message or 'Erro').encode('utf-8', 'ignore')
        try:
            wfile.write('HTTP/1.1 {} Error\r\n'.format(int(status_code)).encode())
            wfile.write(b'Content-Type: text/plain; charset=utf-8\r\n')
            wfile.write('Content-Length: {}\r\n'.format(len(body)).encode())
            wfile.write(b'Connection: close\r\n')
            wfile.write(b'\r\n')
            if body:
                wfile.write(body)
        except Exception:
            pass

    def _send_upstream_headers(self, wfile, status_code, reason, headers, content_type=None, content_length=None, content_range=None, connection='close'):
        wfile.write('HTTP/1.1 {} {}\r\n'.format(status_code, reason).encode())
        if content_type:
            wfile.write('Content-Type: {}\r\n'.format(content_type).encode())
        if content_length is not None:
            wfile.write('Content-Length: {}\r\n'.format(content_length).encode())
        if content_range:
            wfile.write('Content-Range: {}\r\n'.format(content_range).encode())
        accept_ranges = _header_get(headers, 'Accept-Ranges', 'bytes') or 'bytes'
        wfile.write('Accept-Ranges: {}\r\n'.format(accept_ranges).encode())
        wfile.write(b'Access-Control-Allow-Origin: *\r\n')
        wfile.write('Connection: {}\r\n'.format(connection).encode())
        wfile.write(b'\r\n')

    def handle_asset_stream(self, url, method, req_headers, wfile):
        """Proxy curto para capas/fanart.

        Não deve herdar a lógica Live/VOD: imagem ruim não pode travar navegação.
        HEAD responde por MIME provável; GET tenta baixar com timeout curto.
        """
        lower = url.lower().split('?', 1)[0]
        if lower.endswith('.png'):
            content_type = 'image/png'
        elif lower.endswith('.webp'):
            content_type = 'image/webp'
        elif lower.endswith('.gif'):
            content_type = 'image/gif'
        elif lower.endswith(('.jpg', '.jpeg')):
            content_type = 'image/jpeg'
        else:
            content_type = _guess_content_type(url)

        if method == 'HEAD':
            self._send_upstream_headers(
                wfile,
                200,
                'OK',
                {},
                content_type=content_type,
                content_length=None,
                connection='close',
            )
            return

        try:
            upstream = self._open_upstream('GET', url, client_headers=req_headers, timeout=ART_TIMEOUT, stream=True, profiles=('direct', 'origin'))
            if not upstream:
                self._send_simple_error(wfile, 502, 'Imagem indisponível')
                return
            headers = dict(upstream.headers or {})
            ctype = _header_get(headers, 'Content-Type', content_type) or content_type
            clen = _header_get(headers, 'Content-Length')
            try:
                clen_int = int(clen) if clen not in (None, '') else None
            except Exception:
                clen_int = None
            self._send_upstream_headers(
                wfile,
                getattr(upstream, 'status', None) or upstream.getcode() or 200,
                'OK',
                headers,
                content_type=ctype,
                content_length=clen_int,
                connection='close',
            )
            while True:
                chunk = upstream.read(LIVE_BUFFER_SIZE)
                if not chunk:
                    break
                wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            return
        except Exception as exc:
            log('Falha proxy arte {}: {}'.format(url, exc), _warn_level())
            try:
                self._send_simple_error(wfile, 502, 'Imagem indisponível')
            except Exception:
                pass

    def handle_vod_head_probe(self, url, req_headers, wfile):
        """Responde ao HEAD do Kodi de forma imediata para VOD.

        Em alguns hosts, até o probe GET Range bytes=0-0 pode ficar preso até o
        timeout do Stat do Kodi. Por isso, HEAD de VOD não toca mais no upstream:
        devolve headers otimistas e deixa a validação definitiva para o GET real.
        """
        try:
            self._send_upstream_headers(
                wfile,
                200,
                'OK',
                {},
                content_type=_guess_content_type(url),
                content_length=None,
                connection='close',
            )
        except (BrokenPipeError, ConnectionResetError, OSError) as exc:
            # Cliente Kodi pode cancelar o Stat e abrir o GET real em seguida.
            log('HEAD VOD imediato cancelado pelo cliente: {}'.format(exc), _warn_level())

    def handle_vod_stream(self, url, method, req_headers, wfile):
        if method == 'HEAD':
            return self.handle_vod_head_probe(url, req_headers, wfile)

        cache = self.get_vod_cache(url)
        requested_range = req_headers.get('range') or req_headers.get('Range') or ''
        requested_start, requested_end = _parse_requested_range(requested_range)

        if requested_start is not None and requested_end is not None:
            cached = cache.get_range(requested_start, requested_end + 1)
            if cached:
                total = cache.content_length or '*'
                self._send_upstream_headers(
                    wfile, 206, 'Partial Content', {},
                    content_type='video/mp4',
                    content_length=len(cached),
                    content_range='bytes {}-{}/{}'.format(requested_start, requested_start + len(cached) - 1, total),
                )
                if method != 'HEAD':
                    wfile.write(cached)
                return

        upstream = self._open_upstream(
            'HEAD' if method == 'HEAD' else 'GET',
            url,
            client_headers=req_headers,
            range_header=requested_range or None,
            timeout=VOD_TIMEOUT,
            stream=True,
        )

        # Gargalo real do Kodi/Xtream: muitos servidores recusam HEAD.
        # Resolve sem atrasar a abertura: GET bytes=0-0 só para capturar headers.
        if method == 'HEAD' and (upstream is None or _status(upstream) >= 400):
            try:
                if upstream is not None:
                    upstream.close()
            except Exception:
                pass
            upstream = self._open_upstream('GET', url, client_headers=req_headers, range_header=requested_range or 'bytes=0-0', timeout=VOD_TIMEOUT, stream=True)

        # Se o Range do Kodi falhou, tenta um Range aberto antes de desistir.
        if (upstream is None or _status(upstream) >= 400) and requested_range:
            try:
                if upstream is not None:
                    upstream.close()
            except Exception:
                pass
            upstream = self._open_upstream('GET', url, client_headers=req_headers, range_header='bytes={}-'.format(requested_start or 0), timeout=VOD_TIMEOUT, stream=True)

        if upstream is None:
            self._write_plain_response(wfile, 502, 'Bad Gateway', 'Upstream VOD sem resposta.')
            return

        try:
            status = _status(upstream)
            if status < 200 or status >= 300:
                self._write_plain_response(wfile, 502, 'Bad Gateway', 'Origem VOD respondeu HTTP {}.'.format(status))
                return

            headers = _response_headers(upstream)
            final_url = _response_url(upstream, url)
            content_type = _guess_content_type(final_url, _header_get(headers, 'Content-Type', ''))
            content_length = _positive_int(_header_get(headers, 'Content-Length', ''))
            content_range = _header_get(headers, 'Content-Range', '')
            range_start, range_end, _range_total = _parse_content_range(content_range)

            # Range solicitado e origem ignorou: não devolve bytes duplicados como se fosse seek válido.
            if requested_start is not None and status == 200:
                self._write_plain_response(wfile, 502, 'Bad Gateway', 'Origem VOD ignorou Range solicitado.')
                return

            expected_body = content_length
            stream_start = range_start if range_start is not None else (requested_start if requested_start is not None else 0)
            stream_end = range_end if range_end is not None else None
            if expected_body is not None and stream_end is None:
                stream_end = stream_start + expected_body - 1
            if requested_end is not None and stream_end is not None:
                stream_end = min(stream_end, requested_end)
                expected_body = max(0, stream_end - stream_start + 1)

            if content_length is not None:
                cache.content_length = _range_total or (content_length if status == 200 else cache.content_length)

            reason = 'Partial Content' if status == 206 else 'OK'
            self._send_upstream_headers(
                wfile,
                status,
                reason,
                headers,
                content_type=content_type,
                content_length=expected_body if expected_body is not None else content_length,
                content_range=content_range,
            )

            if method == 'HEAD':
                return

            delivered = 0
            retries = 0
            active_url = final_url
            active = upstream
            upstream = None
            try:
                while True:
                    failure = None
                    try:
                        chunk = active.read(BUFFER_SIZE)
                        if chunk:
                            if expected_body is not None:
                                remaining = expected_body - delivered
                                if remaining <= 0:
                                    return
                                if len(chunk) > remaining:
                                    chunk = chunk[:remaining]
                            cache.add_chunk(stream_start + delivered, chunk)
                            wfile.write(chunk)
                            delivered += len(chunk)
                            if expected_body is not None and delivered >= expected_body:
                                return
                            continue
                        if expected_body is None or delivered >= expected_body:
                            return
                        failure = IOError('upstream_eof_antes_do_content_length')
                    except (BrokenPipeError, ConnectionResetError, OSError):
                        return
                    except Exception as exc:
                        failure = exc

                    if failure is None or expected_body is None:
                        return
                    if retries >= VOD_MAX_RETRIES:
                        log('VOD interrompido; limite de retomada atingido em {}.'.format(active_url), _warn_level())
                        return

                    retries += 1
                    resume_at = stream_start + delivered
                    resume_range = 'bytes={}-{}'.format(resume_at, stream_end) if stream_end is not None else 'bytes={}-'.format(resume_at)
                    try:
                        active.close()
                    except Exception:
                        pass
                    time.sleep((0.30, 0.80, 1.50)[min(retries - 1, 2)])
                    resumed = self._open_upstream('GET', active_url, client_headers=req_headers, range_header=resume_range, timeout=VOD_TIMEOUT, stream=True)
                    if resumed is None:
                        continue
                    resumed_status = _status(resumed)
                    resumed_range = _header_get(_response_headers(resumed), 'Content-Range', '')
                    resumed_start, resumed_end, _ = _parse_content_range(resumed_range)
                    needed = expected_body - delivered if expected_body is not None else None
                    range_ok = resumed_status == 206 and resumed_start == resume_at and (needed is None or resumed_end is None or resumed_end >= resume_at + needed - 1)
                    if not range_ok:
                        try:
                            resumed.close()
                        except Exception:
                            pass
                        log('Retomada VOD recusada: origem não confirmou Range exato.', _warn_level())
                        return
                    active = resumed
                    active_url = _response_url(resumed, active_url)
            finally:
                try:
                    active.close()
                except Exception:
                    pass
        finally:
            try:
                upstream.close()
            except Exception:
                pass

    def _read_response_body(self, response, max_bytes=None):
        chunks = []
        total = 0
        while True:
            chunk = response.read(BUFFER_SIZE)
            if not chunk:
                break
            total += len(chunk)
            if max_bytes and total > max_bytes:
                raise ValueError('resposta maior que o limite seguro')
            chunks.append(chunk)
        return b''.join(chunks)

    def _decode_body_if_needed(self, body, encoding):
        try:
            enc = (encoding or '').lower()
            if enc == 'gzip':
                return gzip.decompress(body)
            if enc == 'deflate':
                return zlib.decompress(body)
        except Exception:
            pass
        return body

    def _proxify_hls_uri(self, raw_url, base_url, proxy_host, kind='live'):
        raw_url = (raw_url or '').strip()
        if not raw_url or raw_url.startswith('#'):
            return raw_url
        low = raw_url.lower()
        if low.startswith(('data:', 'skd:', 'urn:', 'about:', 'javascript:')):
            return raw_url
        try:
            absolute = urljoin(base_url + '/', raw_url)
            parsed_absolute = urlparse(absolute)
            if (parsed_absolute.hostname or '').lower() in ('127.0.0.1', 'localhost', '::1') and parsed_absolute.path in ('/hlsretry', '/tsdownloader'):
                return absolute
            if not _is_valid_upstream_url(absolute):
                return raw_url
            endpoint = 'hlsretry'
            return 'http://{}/{}?url={}&kind={}'.format(proxy_host, endpoint, quote(absolute, safe=''), 'vod' if kind == 'vod' else 'live')
        except Exception:
            return raw_url

    def rewrite_m3u8_urls(self, playlist_content, base_url, proxy_host, kind='live'):
        def replace_uri(match):
            return '{}{}{}{}'.format(
                match.group('prefix'), match.group('quote'),
                self._proxify_hls_uri(match.group('value'), base_url, proxy_host, kind=kind),
                match.group('quote'),
            )

        uri_attribute = re.compile(r'(?P<prefix>\bURI=)(?P<quote>["\'])(?P<value>.*?)(?P=quote)')
        lines = []
        for raw_line in (playlist_content or '').splitlines():
            line = raw_line.strip()
            if not line:
                lines.append(raw_line)
            elif line.startswith('#'):
                lines.append(uri_attribute.sub(replace_uri, raw_line))
            else:
                leading = raw_line[:len(raw_line) - len(raw_line.lstrip())]
                trailing = raw_line[len(raw_line.rstrip()):]
                lines.append(leading + self._proxify_hls_uri(line, base_url, proxy_host, kind=kind) + trailing)
        suffix = '\n' if (playlist_content or '').endswith(('\n', '\r')) else ''
        return '\n'.join(lines) + suffix

    def _send_playlist(self, url, req_headers, wfile, kind='live', method='GET'):
        max_retries = LIVE_PLAYLIST_MAX_RETRIES if kind != 'vod' else max(2, VOD_SEGMENT_MAX_RETRIES)
        last_status = 0
        for attempt in range(max_retries):
            response = self._open_upstream('GET', url, client_headers=req_headers, timeout=PLAYLIST_TIMEOUT, stream=False, profiles=('direct', 'origin', 'minimal'))
            if response is None:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            try:
                last_status = _status(response)
                if 200 <= last_status < 300:
                    raw = self._read_response_body(response, max_bytes=16 * 1024 * 1024)
                    raw = self._decode_body_if_needed(raw, _header_get(_response_headers(response), 'Content-Encoding', ''))
                    text = raw.decode('utf-8', 'ignore')
                    final_url = _response_url(response, url)
                    proxy_host = '127.0.0.1:{}'.format(PROXY_PORT)
                    base_url = final_url.rsplit('/', 1)[0]
                    rewritten = self.rewrite_m3u8_urls(text, base_url, proxy_host, kind=kind)
                    data = rewritten.encode('utf-8')
                    self._send_upstream_headers(
                        wfile,
                        200,
                        'OK',
                        {},
                        content_type='application/vnd.apple.mpegurl',
                        content_length=len(data),
                    )
                    if method != 'HEAD':
                        wfile.write(data)
                    return True
                if last_status not in RETRYABLE_CODES:
                    break
            finally:
                try:
                    response.close()
                except Exception:
                    pass
            time.sleep(RETRY_DELAY * (attempt + 1))
        self._write_plain_response(wfile, 504, 'Gateway Timeout', 'Playlist HLS sem resposta válida. Último status: {}'.format(last_status or 'timeout'))
        return False

    def _handle_vod_hls_segment(self, url, req_headers, wfile, method='GET'):
        requested_range = req_headers.get('range') or ''
        for attempt in range(VOD_SEGMENT_MAX_RETRIES):
            response = self._open_upstream('GET', url, client_headers=req_headers, range_header=requested_range or None, timeout=VOD_TIMEOUT, stream=True)
            if response is None:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            try:
                status = _status(response)
                if 200 <= status < 300:
                    headers = _response_headers(response)
                    content_type = _guess_content_type(_response_url(response, url), _header_get(headers, 'Content-Type', 'video/mp2t'))
                    body = b'' if method == 'HEAD' else self._read_response_body(response, max_bytes=MAX_ATOMIC_SEGMENT_BYTES)
                    length = _positive_int(_header_get(headers, 'Content-Length', ''))
                    if method != 'HEAD':
                        length = len(body)
                    reason = 'Partial Content' if status == 206 else 'OK'
                    self._send_upstream_headers(
                        wfile,
                        status,
                        reason,
                        headers,
                        content_type=content_type,
                        content_length=length,
                        content_range=_header_get(headers, 'Content-Range', ''),
                    )
                    if method != 'HEAD':
                        wfile.write(body)
                    return
                if status not in RETRYABLE_CODES:
                    self._write_plain_response(wfile, 502, 'Bad Gateway', 'Segmento VOD HLS respondeu HTTP {}.'.format(status))
                    return
            except ValueError:
                # Segmento grande demais para spool: transmite direto sem segurar tudo em memória.
                try:
                    response.close()
                except Exception:
                    pass
                self._handle_live_hls_segment(url, req_headers, wfile, method=method, max_retries=1)
                return
            finally:
                try:
                    response.close()
                except Exception:
                    pass
            time.sleep(RETRY_DELAY * (attempt + 1))
        self._write_plain_response(wfile, 504, 'Gateway Timeout', 'Segmento VOD HLS sem resposta.')

    def _handle_live_hls_segment(self, url, req_headers, wfile, method='GET', max_retries=None):
        max_retries = LIVE_SEGMENT_MAX_RETRIES if max_retries is None else max_retries
        requested_range = req_headers.get('range') or ''
        attempts = max_retries + 1
        failures_404 = 0
        for attempt in range(attempts):
            response = self._open_upstream('GET', url, client_headers=req_headers, range_header=requested_range or None, timeout=LIVE_TIMEOUT, stream=True, profiles=('direct', 'origin', 'minimal'))
            if response is None:
                time.sleep(RETRY_DELAY * (attempt + 1))
                continue
            try:
                status = _status(response)
                if status == 404 and failures_404 < LIVE_SEGMENT_404_RETRIES:
                    failures_404 += 1
                    time.sleep((0.30, 0.70, 1.20)[min(failures_404 - 1, 2)])
                    continue
                if status < 200 or status >= 300:
                    if status not in RETRYABLE_CODES:
                        self._write_plain_response(wfile, 502, 'Bad Gateway', 'Segmento Live HLS respondeu HTTP {}.'.format(status))
                        return
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue

                headers = _response_headers(response)
                content_type = _guess_content_type(_response_url(response, url), _header_get(headers, 'Content-Type', 'video/mp2t'))
                content_length = _positive_int(_header_get(headers, 'Content-Length', ''))
                self._send_upstream_headers(
                    wfile,
                    status,
                    'Partial Content' if status == 206 else 'OK',
                    headers,
                    content_type=content_type,
                    content_length=content_length,
                    content_range=_header_get(headers, 'Content-Range', ''),
                )
                if method == 'HEAD':
                    return
                while True:
                    chunk = response.read(LIVE_BUFFER_SIZE)
                    if not chunk:
                        break
                    wfile.write(chunk)
                return
            except (BrokenPipeError, ConnectionResetError, OSError):
                return
            except Exception as exc:
                log('Falha segmento Live HLS: {}'.format(exc), _warn_level())
            finally:
                try:
                    response.close()
                except Exception:
                    pass
            time.sleep(RETRY_DELAY * (attempt + 1))
        self._write_plain_response(wfile, 504, 'Gateway Timeout', 'Segmento Live HLS sem resposta.')

    def handle_hlsretry(self, url, headers, wfile, method='GET', kind='live'):
        kind = 'vod' if str(kind or '').lower() == 'vod' else 'live'
        if _is_probably_playlist(url):
            return self._send_playlist(url, headers, wfile, kind=kind, method=method)

        # Quando o endpoint recebe um segmento, escolhe comportamento por tipo.
        if kind == 'vod':
            return self._handle_vod_hls_segment(url, headers, wfile, method=method)
        return self._handle_live_hls_segment(url, headers, wfile, method=method)

    def handle_channel_stream(self, url, headers, wfile, method='GET', kind='live'):
        if _is_probably_playlist(url):
            return self.handle_hlsretry(url, headers, wfile, method=method, kind=kind)
        if _is_probably_vod(url) and kind == 'vod':
            return self.handle_vod_stream(url, method, headers, wfile)
        if _is_probably_ts(url):
            return self.handle_tsdownloader(url, headers, wfile, method=method)

        # Fallback genérico: stream simples com cache curto para microfalhas.
        cache = self.get_channel_cache(url)
        response = self._open_upstream('GET' if method != 'HEAD' else 'HEAD', url, client_headers=headers, timeout=LIVE_TIMEOUT, stream=True)
        if response is None or _status(response) >= 400:
            recovery = cache.recent_chunks(12)
            if recovery and method != 'HEAD':
                self._send_upstream_headers(wfile, 200, 'OK', {}, content_type='video/mp2t', connection='close')
                for chunk in recovery:
                    try:
                        wfile.write(chunk)
                    except Exception:
                        break
                return
            self._write_plain_response(wfile, 504, 'Gateway Timeout', 'Upstream sem resposta e sem cache de recuperação.')
            return
        try:
            status = _status(response)
            headers_up = _response_headers(response)
            content_type = _guess_content_type(_response_url(response, url), _header_get(headers_up, 'Content-Type', 'video/mp2t'))
            self._send_upstream_headers(
                wfile,
                status,
                'OK',
                headers_up,
                content_type=content_type,
                content_length=_positive_int(_header_get(headers_up, 'Content-Length', '')),
                content_range=_header_get(headers_up, 'Content-Range', ''),
            )
            if method == 'HEAD':
                return
            while True:
                chunk = response.read(LIVE_BUFFER_SIZE)
                if not chunk:
                    break
                cache.add_chunk(chunk)
                wfile.write(chunk)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
        finally:
            try:
                response.close()
            except Exception:
                pass

    def handle_tsdownloader(self, url, headers, wfile, method='GET'):
        if method == 'HEAD':
            self._send_upstream_headers(wfile, 200, 'OK', {}, content_type='video/mp2t')
            return

        wfile.write(b'HTTP/1.1 200 OK\r\n')
        wfile.write(b'Content-Type: video/mp2t\r\n')
        wfile.write(b'Access-Control-Allow-Origin: *\r\n')
        wfile.write(b'Cache-Control: no-cache\r\n')
        wfile.write(b'Connection: close\r\n\r\n')

        reconnects = 0
        last_good = 0.0
        while True:
            response = None
            try:
                response = self._open_upstream('GET', url, client_headers=headers, timeout=TS_TIMEOUT, stream=True, profiles=('direct', 'origin', 'minimal'))
                if response is None or _status(response) >= 400:
                    if last_good and time.time() - last_good <= 5.5:
                        wfile.write(TS_NULL_PACKET * 24)
                    reconnects += 1
                    time.sleep(min(2.5, TS_RECONNECT_DELAY * reconnects))
                    continue
                reconnects = 0
                while True:
                    chunk = response.read(LIVE_BUFFER_SIZE)
                    if not chunk:
                        break
                    last_good = time.time()
                    wfile.write(chunk)
            except (BrokenPipeError, ConnectionResetError, OSError):
                return
            except Exception as exc:
                reconnects += 1
                log('TS instável; reconectando: {}'.format(exc), _warn_level())
                if last_good and time.time() - last_good <= 5.5:
                    try:
                        wfile.write(TS_NULL_PACKET * 18)
                    except Exception:
                        return
                time.sleep(min(2.5, TS_RECONNECT_DELAY * reconnects))
            finally:
                try:
                    if response is not None:
                        response.close()
                except Exception:
                    pass


class ProxyHandler(socketserver.StreamRequestHandler):
    proxy = UnifiedProxy()

    def send_response(self, code, message=None):
        if message is None:
            message = http.client.responses.get(code, 'OK')
        self._resp_statusline = 'HTTP/1.1 {} {}\r\n'.format(code, message)
        self._resp_headers = []

    def send_header(self, key, value):
        self._resp_headers.append((key, value))

    def end_headers(self):
        try:
            has_conn = any(k.lower() == 'connection' for k, _ in self._resp_headers)
            if not has_conn:
                self._resp_headers.append(('Connection', 'close'))
            data = self._resp_statusline
            for k, v in self._resp_headers:
                data += '{}: {}\r\n'.format(k, v)
            data += '\r\n'
            self.wfile.write(data.encode('utf-8', 'replace'))
        except Exception:
            pass

    def send_error(self, code, message=''):
        body = ('{} {}'.format(code, message)).encode('utf-8', 'replace')
        self.send_response(code)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Access-Control-Allow-Origin', '*')
        self.end_headers()
        try:
            if self.command != 'HEAD':
                self.wfile.write(body)
        except Exception:
            pass

    def handle(self):
        try:
            raw = self.rfile.readline(65537)
            if not raw:
                return
            if raw.startswith(b'\x16\x03') or raw.startswith(b'PRI * HTTP/2.0'):
                self.send_error(400, 'Bad Request')
                return
            line = raw.decode('iso-8859-1', 'replace').rstrip('\r\n')
            parts = line.split(' ')
            if len(parts) < 2:
                self.send_error(400, 'Bad Request')
                return
            self.command = parts[0].upper()
            if len(parts) >= 3 and parts[-1].startswith('HTTP/'):
                self.request_version = parts[-1]
                target = ' '.join(parts[1:-1])
            else:
                self.request_version = 'HTTP/1.1'
                target = ' '.join(parts[1:])
            if target.startswith(('http://', 'https://')):
                try:
                    u = urlsplit(target)
                    target = (u.path or '/') + (('?' + u.query) if u.query else '')
                except Exception:
                    pass
            self.path = target
            headers = {}
            while True:
                h = self.rfile.readline(65537)
                if not h or h in (b'\r\n', b'\n'):
                    break
                hs = h.decode('iso-8859-1', 'replace')
                if ':' in hs:
                    k, v = hs.split(':', 1)
                    headers[k.strip().lower()] = v.strip()
            self.headers = headers
            if self.command == 'OPTIONS':
                self.do_OPTIONS()
            elif self.command == 'HEAD':
                self.do_HEAD()
            else:
                self.do_GET()
        except Exception as exc:
            log('RAW socket handler erro: {}'.format(exc), _warn_level())
            try:
                self.send_error(500, 'Internal Server Error')
            except Exception:
                pass

    def do_GET(self):
        self.process_request()

    def do_HEAD(self):
        self.process_request()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Range, Origin, Content-Type, Accept')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def process_request(self):
        try:
            url, params = self.proxy.extract_params_from_path(self.path)
            parsed_local = urlsplit(self.path)
            local_path = parsed_local.path or '/'

            if not url:
                html = ('<html><body><h2>XC Pro Proxy Active</h2>'
                        '<p>Proxy funcionando na porta {}</p></body></html>').format(PROXY_PORT).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html)))
                self.end_headers()
                if self.command != 'HEAD':
                    self.wfile.write(html)
                return

            if not _is_valid_upstream_url(url):
                self.send_error(400, 'URL upstream inválida')
                return

            kind = (params.get('kind') or [''])[0].strip().lower()
            kind = kind if kind in ('live', 'vod', 'art') else 'live'
            headers = dict(self.headers or {})

            log('Requisição {} {} kind={}'.format(self.command, local_path, kind))

            if kind == 'art':
                self.proxy.handle_asset_stream(url, self.command, headers, self.wfile)
                return

            if local_path == '/tsdownloader':
                self.proxy.handle_tsdownloader(url, headers, self.wfile, method=self.command)
                return

            if local_path == '/hlsretry':
                self.proxy.handle_hlsretry(url, headers, self.wfile, method=self.command, kind=kind)
                return

            # Rota histórica do XC Pro: /?url=...
            if kind == 'vod':
                if _is_probably_playlist(url):
                    self.proxy.handle_hlsretry(url, headers, self.wfile, method=self.command, kind='vod')
                else:
                    self.proxy.handle_vod_stream(url, self.command, headers, self.wfile)
                return

            if _is_probably_playlist(url):
                self.proxy.handle_hlsretry(url, headers, self.wfile, method=self.command, kind='live')
                return

            if _is_probably_vod(url):
                self.proxy.handle_vod_stream(url, self.command, headers, self.wfile)
                return

            self.proxy.handle_channel_stream(url, headers, self.wfile, method=self.command, kind='live')
        except Exception as exc:
            log('Erro handle_request: {}'.format(exc), _warn_level())
            try:
                self.send_error(500, str(exc))
            except Exception:
                pass


class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True


class UnifiedServer:
    def __init__(self, port=9090):
        global PROXY_PORT
        self.port = int(port)
        PROXY_PORT = self.port
        self.server = None
        self.running = False
        self.monitor = None

    def start(self, monitor=None):
        self.monitor = monitor
        self.running = True
        try:
            self.server = ThreadedTCPServer(('127.0.0.1', self.port), ProxyHandler)
            self.server.timeout = 1
            log('=== PROXY XC PRO INICIADO em 127.0.0.1:{} ==='.format(self.port))
            while self.running:
                if self.monitor and self.monitor.abortRequested():
                    log('abortRequested detectado, parando proxy...')
                    break
                try:
                    self.server.handle_request()
                except OSError as exc:
                    log('Socket error: {}'.format(exc), _warn_level())
                except Exception as exc:
                    log('Erro processando request: {}'.format(exc), _warn_level())
        except Exception as exc:
            log('Erro no servidor: {}'.format(exc), _warn_level())
        finally:
            self.stop()

    def stop(self):
        self.running = False
        try:
            if self.server:
                self.server.server_close()
        except Exception:
            pass
        log('Proxy XC Pro finalizado.')
