# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# Inicialização local e rápida da Home do OnePlay Matrix.
# A Home não consulta catálogo, M3U, EPG, proxy, DNS nem player.

import os
import sys
from urllib.parse import parse_qsl, urlencode

try:
    from kodi_six import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
except ImportError:
    import xbmc
    import xbmcplugin
    import xbmcgui
    import xbmcaddon
    import xbmcvfs

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
TRANSLATE = xbmcvfs.translatePath
HOME_DIR = TRANSLATE(ADDON.getAddonInfo('path'))
ADDON_ICON = os.path.join(HOME_DIR, 'icon.png')
ADDON_FANART = os.path.join(HOME_DIR, 'fanart.jpg')
IBO_ADDON_URL = 'plugin://plugin.video.ibo.oneplay/?origin=oneplay_matrix'
IBO_RETURN_HINT_PROPERTY = 'OnePlayMatrix.IBOReturnFast'

WELCOME_LABEL = '[COLOR aquamarine]:::[/COLOR]BEM-VINDOS AO ONEPLAY[COLOR aquamarine]:::[/COLOR]'
ONEPLAY_DESC = '''
Para trabalhar em equipe precisamos ter empatia, transparência, solidariedade e muita lealdade, esses ingredientes são necessários para o sucesso em grupo.

[B][COLOR aquamarine]Repositório Oficial ONEPLAY[/COLOR][/B]
[COLOR blue]https://oneplayhd.github.io[/COLOR]

[B][COLOR aquamarine]Grupo Oficial FACEBOOK[/COLOR][/B]
[COLOR blue]https://tinyurl.com/oneplay2019[/COLOR]

[B][COLOR aquamarine]Grupo Oficial TELEGRAM[/COLOR][/B]
[COLOR blue]http://t.me/oneplay2019[/COLOR]
    '''



def _maintenance_debug(message):
    if not _setting_bool('mododebug', False):
        return
    try:
        from resources.lib.common import log_debug
        log_debug(message, addon=ADDON, component='Home')
    except Exception:
        pass


def _maintenance_exception(context, exc):
    try:
        from resources.lib.common import log_exception
        log_exception('Home', context, exc, addon=ADDON)
    except Exception:
        try:
            xbmc.log('[OnePlay][Home] {}: {}'.format(context, exc.__class__.__name__), level=xbmc.LOGERROR)
        except Exception:
            pass

def _setting_text(key, default=''):
    try:
        value = ADDON.getSetting(key)
        return value if value not in (None, '') else default
    except Exception:
        return default


def _setting_bool(key, default=False):
    try:
        return str(_setting_text(key, 'true' if default else 'false')).lower() == 'true'
    except Exception:
        return default


def _build_url(query):
    return '{}?{}'.format(BASE_URL, urlencode(query or {}))


def _open_ibo_replacing_matrix():
    """Abre o ONEPLAY IBO sem manter o diretório Matrix como pai visual.

    O VIP não é mais entregue ao Kodi como uma pasta externa filha da Home do
    Matrix. ReplaceWindow substitui a janela Videos atual sem adicioná-la ao
    histórico, impedindo que plugin.video.OnePlay.Matrix permaneça renderizado
    por baixo das janelas customizadas do IBO no Android.
    """
    command = 'ReplaceWindow(Videos,{})'.format(IBO_ADDON_URL)
    _maintenance_debug('evento=ibo_replace_launch | destino={}'.format(IBO_ADDON_URL))
    try:
        xbmc.executebuiltin(command, True)
    except TypeError:
        xbmc.executebuiltin(command)



def _consume_ibo_return_hint():
    """Consome o marcador de retorno rápido deixado pelo ONEPLAY IBO.

    O marcador vive apenas em Window(Home) e não persiste em disco. Ele serve
    exclusivamente para distinguir uma abertura normal da raiz Matrix de um
    retorno imediato vindo do IBO por ReplaceWindow.
    """
    try:
        window = xbmcgui.Window(10000)
        raw = str(window.getProperty(IBO_RETURN_HINT_PROPERTY) or '').strip()
        if not raw:
            return False
        window.clearProperty(IBO_RETURN_HINT_PROPERTY)
        return True
    except Exception:
        return False


def _suppress_return_busy_once():
    """Fecha somente o Busy nativo já ativo no retorno IBO -> Matrix.

    O log real mostra que DialogBusy é aberto antes de o interpretador Python
    do Matrix terminar de inicializar. Portanto basta fechá-lo no começo do
    fast-path; não há thread, polling ou efeito fora desta volta.
    """
    for dialog_name in ('busydialog', 'busydialognocancel'):
        try:
            xbmc.executebuiltin('Dialog.Close({})'.format(dialog_name))
        except Exception:
            pass


def _home_return_fast():
    """Reconstrói a Home Matrix pelo menor caminho possível após sair do IBO.

    A Home é 100% local. Nesta rota de retorno os ListItems são enviados em
    lote e não há import de routes.py, DNS, TMDB, proxy ou rede. O conteúdo e os
    URLs são os mesmos de ``home()``.
    """
    _suppress_return_busy_once()
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    items = [
        ('Pesquisar', 'Buscar filmes e séries pelo nome do conteúdo.', TRANSLATE(os.path.join(image_dir, 'pesquisar.png')), {'action': 'search'}),
        ('TV ao vivo', 'Entrar nas listas e categorias de canais ao vivo.', TRANSLATE(os.path.join(image_dir, 'tv.png')), {'action': 'tv'}),
        ('Filmes', 'Explorar filmes em alta, top avaliados e lançamentos.', TRANSLATE(os.path.join(image_dir, 'filmes.png')), {'action': 'menu_movies'}),
        ('Séries', 'Explorar séries em alta, top avaliadas e lançamentos.', TRANSLATE(os.path.join(image_dir, 'series.png')), {'action': 'menu_series'}),
        ('Configurações', 'Abrir as configurações do addon OnePlay.', TRANSLATE(os.path.join(image_dir, 'configuracoes.png')), {'action': 'open_settings'}),
    ]
    if _setting_bool('mostrarboasvindas', True):
        items.insert(0, (WELCOME_LABEL, ONEPLAY_DESC, ADDON_ICON, {'action': 'donate'}))
    if _setting_bool('exibirvip', True):
        items.insert(1, ('VIP', _vip_description(), TRANSLATE(os.path.join(image_dir, 'vip.png')), {'action': ''}))

    batch = []
    for label, description, icon, query in items:
        url = _build_url({'action': 'open_ibo'}) if label == 'VIP' else _build_url(query)
        list_item = xbmcgui.ListItem(label)
        try:
            list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        except Exception:
            pass
        is_folder = label not in ('Configurações', WELCOME_LABEL, 'VIP')
        if is_folder:
            _set_folder_info(list_item, title=label, plot=description)
        else:
            _set_video_info(list_item, title=label, plot=description)
        try:
            list_item.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        batch.append((url, list_item, is_folder))

    try:
        xbmcplugin.addDirectoryItems(ADDON_HANDLE, batch, len(batch))
    except Exception:
        for url, list_item, is_folder in batch:
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)
    try:
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
    _maintenance_debug('evento=ibo_return_fast | itens={}'.format(len(batch)))

def _set_folder_info(item, title='', plot=''):
    """Metadados neutros para diretórios Kodi.

    Não define ``VideoInfoTag.mediaType``. Mantém apenas a propriedade leve
    ``mediatype=video``, exatamente como o roteador tradicional de TV. O
    ``isFolder=True`` passado a addDirectoryItem permanece como a semântica
    autoritativa, permitindo que a skin desenhe o indicador de pasta de forma
    consistente com TV/Pluto sem perder título, sinopse ou arte.
    """
    try:
        tag = item.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        try:
            if title and hasattr(tag, 'setTitle'):
                tag.setTitle(str(title))
            if plot and hasattr(tag, 'setPlot'):
                tag.setPlot(str(plot))
        except Exception:
            pass
    else:
        try:
            info = {'title': title, 'plot': plot}
            item.setInfo('video', info)
        except Exception:
            pass
    try:
        item.setProperty('mediatype', 'video')
    except Exception:
        pass


def _set_video_info(item, title='', plot='', mediatype='video'):
    # API atual, com fallback seguro para builds Kodi mais antigas.
    try:
        tag = item.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        try:
            if title and hasattr(tag, 'setTitle'):
                tag.setTitle(str(title))
            if plot and hasattr(tag, 'setPlot'):
                tag.setPlot(str(plot))
            if mediatype and hasattr(tag, 'setMediaType'):
                tag.setMediaType(str(mediatype))
        except Exception:
            pass
    else:
        try:
            item.setInfo('video', {'title': title, 'plot': plot, 'mediatype': mediatype or 'video'})
        except Exception:
            pass
    try:
        item.setProperty('mediatype', str(mediatype or 'video'))
    except Exception:
        pass


def _skin_signature():
    skin_id = ''
    skin_theme = ''
    try:
        skin_id = xbmc.getSkinDir() or ''
    except Exception:
        pass
    try:
        skin_theme = xbmc.getInfoLabel('Skin.CurrentTheme') or ''
    except Exception:
        pass
    return '{}|{}'.format(skin_id, skin_theme).strip('|') or 'default'


def _apply_default_list_view(flag_key):
    """Aplica a lista padrão uma vez por skin durante a sessão atual.

    A marcação fica em uma propriedade global do Kodi, não no settings.xml do
    addon. Assim, abrir Filmes/Séries pela primeira vez não dispara
    onSettingsChanged() no service.py nem acorda a sincronização de DNS/EPG.
    O cache de diretório continua sob responsabilidade do Kodi via
    endOfDirectory(..., cacheToDisc=True).
    """
    signature = _skin_signature()
    property_name = 'OnePlayMatrix.ViewState.{}'.format(flag_key)
    window = None
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(property_name) == signature:
            return
    except Exception:
        window = None

    try:
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        return

    # Mantido apenas na primeira entrada de cada área/skin da sessão. Nas
    # voltas pelo histórico, o Kodi usa a lista cacheada sem nova espera.
    try:
        xbmc.sleep(40)
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        pass

    if window is not None:
        try:
            window.setProperty(property_name, signature)
        except Exception:
            pass


def _end_local_directory(content, view_flag):
    """Fecha diretórios inteiramente locais com cache de navegação do Kodi."""
    try:
        xbmcplugin.setContent(ADDON_HANDLE, content)
    except Exception:
        pass
    try:
        # Filmes/Séries e Home não dependem de resposta remota. Persistir
        # a lista permite ao Kodi reutilizar o histórico sem revalidar nada.
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        except Exception:
            pass
    except Exception:
        pass
    _apply_default_list_view(view_flag)


def _vip_description():
    return '''[B][COLOR aquamarine]ONEPLAY IBO[/COLOR] [COLOR white]Acesso integrado[/COLOR][/B]

No primeiro acesso, o [COLOR aquamarine]ONEPLAY IBO[/COLOR] identifica o [COLOR aquamarine]ID do dispositivo[/COLOR] e verifica se já existe um acesso vinculado.

Com o [COLOR aquamarine]Teste Automático[/COLOR] disponível, a ativação pode ser concluída automaticamente, sem preencher credenciais.'''


def home():
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    items = [
        ('Pesquisar', 'Buscar filmes e séries pelo nome do conteúdo.', TRANSLATE(os.path.join(image_dir, 'pesquisar.png')), {'action': 'search'}),
        ('TV ao vivo', 'Entrar nas listas e categorias de canais ao vivo.', TRANSLATE(os.path.join(image_dir, 'tv.png')), {'action': 'tv'}),
        ('Filmes', 'Explorar filmes em alta, top avaliados e lançamentos.', TRANSLATE(os.path.join(image_dir, 'filmes.png')), {'action': 'menu_movies'}),
        ('Séries', 'Explorar séries em alta, top avaliadas e lançamentos.', TRANSLATE(os.path.join(image_dir, 'series.png')), {'action': 'menu_series'}),
        ('Configurações', 'Abrir as configurações do addon OnePlay.', TRANSLATE(os.path.join(image_dir, 'configuracoes.png')), {'action': 'open_settings'}),
    ]

    if _setting_bool('mostrarboasvindas', True):
        items.insert(0, (WELCOME_LABEL, ONEPLAY_DESC, ADDON_ICON, {'action': 'donate'}))
    if _setting_bool('exibirvip', True):
        items.insert(1, ('VIP', _vip_description(), TRANSLATE(os.path.join(image_dir, 'vip.png')), {'action': ''}))

    for label, description, icon, query in items:
        url = _build_url({'action': 'open_ibo'}) if label == 'VIP' else _build_url(query)
        list_item = xbmcgui.ListItem(label)
        try:
            list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        except Exception:
            pass
        is_folder = label not in ('Configurações', WELCOME_LABEL, 'VIP')
        if is_folder:
            _set_folder_info(list_item, title=label, plot=description)
        else:
            _set_video_info(list_item, title=label, plot=description)
        try:
            list_item.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    _end_local_directory('movies', 'default_view_home_list_applied')


def _add_local_folder(label, description, icon_name, query):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, icon_name))
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
    except Exception:
        pass
    _set_folder_info(item, title=label, plot=description)
    try:
        item.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url(query),
        listitem=item,
        isFolder=True
    )


def _add_local_settings_item(plot):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, 'configuracoes.png'))
    label = 'Configurações'
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        item.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    _set_video_info(item, title=label, plot=plot)
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url({'action': 'open_settings'}),
        listitem=item,
        isFolder=False
    )


def menu_movies_fast():
    """Menu local de Filmes; não importa routes.py, DNS ou catálogo."""
    items = (
        ('Filmes - Em Alta', 'Ver os filmes em tendência na semana.', {'action': 'list', 'type': 'movie', 'category': 'trending'}),
        ('Filmes - Top Avaliados', 'Ver os filmes mais bem avaliados.', {'action': 'list', 'type': 'movie', 'category': 'top'}),
        ('Filmes - Em Cartaz', 'Ver os filmes atualmente em cartaz conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'now_playing'}),
        ('Filmes - Próximos Lançamentos', 'Ver os próximos lançamentos de filmes conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'upcoming'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'filmes.png', query)
    if _setting_bool('pluto_exibir_filmes', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Filmes - Pluto TV',
            'Abrir os filmes sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_movies'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de filmes.')
    _end_local_directory('movies', 'default_view_movies_list_applied')


def menu_series_fast():
    """Menu local de Séries; não importa routes.py, DNS ou catálogo."""
    items = (
        ('Séries - Em Alta', 'Ver as séries em tendência na semana.', {'action': 'list', 'type': 'series', 'category': 'trending'}),
        ('Séries - Top Avaliadas', 'Ver as séries mais bem avaliadas.', {'action': 'list', 'type': 'series', 'category': 'top'}),
        ('Séries - No Ar', 'Ver séries com episódios em exibição nos próximos dias.', {'action': 'list', 'type': 'series', 'category': 'on_the_air'}),
        ('Séries - Estreias Recentes', 'Ver séries com estreia inicial recente.', {'action': 'list', 'type': 'series', 'category': 'recent_premieres'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'series.png', query)
    if _setting_bool('pluto_exibir_series', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Séries - Pluto TV',
            'Abrir as séries sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_series'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de séries.')
    _end_local_directory('tvshows', 'default_view_series_list_applied')


def _render_pluto_snapshot(action, params):
    """Fast-path de retorno após Stop para diretórios Pluto já montados.

    O Kodi limpa o cache visual do plugin ao encerrar o player. Este caminho
    restaura a pasta a partir do snapshot da sessão sem importar o roteador
    completo, requests ou a API Pluto. Em cache miss, o fluxo normal assume.
    """
    if action not in ('pluto_vod_category', 'pluto_vod_episodes', 'channels_pluto_category'):
        return False
    try:
        from resources.lib import pluto_nav_cache
        snapshot = pluto_nav_cache.load(action, params)
    except Exception:
        return False
    if not snapshot:
        return False

    items = snapshot.get('items') or []
    if not items:
        return False
    for row in items:
        try:
            label = str(row.get('label', '') or 'Pluto')
            item = xbmcgui.ListItem(label)
            art = row.get('art') or {}
            if art:
                item.setArt(art)
            is_folder = bool(row.get('is_folder'))
            if is_folder:
                _set_folder_info(
                    item,
                    title=label,
                    plot=str(row.get('plot', '') or '')
                )
                item.setProperty('IsPlayable', 'false')
            else:
                _set_video_info(
                    item,
                    title=label,
                    plot=str(row.get('plot', '') or ''),
                    mediatype=str(row.get('mediatype', '') or 'video')
                )
                if row.get('is_playable'):
                    item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle=ADDON_HANDLE,
                url=str(row.get('url', '') or ''),
                listitem=item,
                isFolder=is_folder
            )
        except Exception:
            return False

    try:
        xbmcplugin.setContent(ADDON_HANDLE, str(snapshot.get('content', '') or 'videos'))
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
    _maintenance_debug('evento=pluto_snapshot_hit | acao={} | itens={}'.format(action, len(items)))
    return True



def _resolve_tv_proxy_fast(params):
    """Resolve o Live já preparado sem carregar routes.py/requests/EPG novamente.

    ``play_url`` continua apontando para /hlsretry ou /tsdownloader do mesmo
    Proxy Nativo. MIME + ContentLookup=False evitam a sondagem prévia da URL
    loopback, mas não mudam demux, buffer, retry, headers ou transporte.
    """
    play_url = str(params.get('play_url') or '')
    if not play_url:
        try:
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        except Exception:
            pass
        return

    name = str(params.get('name') or 'Canal')
    plot = str(params.get('plot') or 'Abrir o canal para reprodução.')
    icon = str(params.get('icon') or '')
    stream_kind = str(params.get('stream_kind') or 'hls').strip().lower()

    item = xbmcgui.ListItem(name)
    try:
        item.setPath(play_url)
    except Exception:
        pass
    _set_video_info(item, title=name, plot=plot, mediatype='video')
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        item.setProperty('IsPlayable', 'true')
        if stream_kind == 'hls':
            item.setMimeType('application/x-mpegURL')
            item.setContentLookup(False)
        elif stream_kind == 'ts':
            item.setMimeType('video/mp2t')
            item.setContentLookup(False)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=item)

def _dispatch_to_routes(paramstring):
    # Importação tardia: apenas ações fora da Home precisam da implementação
    # completa (M3U, EPG, TMDB, Pluto, proxy, DNS e HTTP).
    from resources.lib import routes
    routes.router(paramstring)


def _main_impl():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    params = dict(parse_qsl(paramstring, keep_blank_values=True))
    action = params.get('action')

    # Playback Live já preparado: resolve localmente antes de carregar o
    # roteador completo. O Proxy Nativo continua responsável pelo transporte.
    if action == 'play_proxy_resolved':
        _resolve_tv_proxy_fast(params)
        return

    # Integração IBO: troca a janela Videos em vez de abrir o IBO como pasta
    # filha do Matrix. Isso remove o Matrix da camada visual subjacente.
    if action == 'open_ibo':
        _open_ibo_replacing_matrix()
        return

    # Home, Filmes e Séries são diretórios puramente locais. Eles não devem
    # carregar o roteador, DNS, proxy, TMDB, Pluto ou requests.
    if action == 'menu_movies':
        menu_movies_fast()
        return
    if action == 'menu_series':
        menu_series_fast()
        return

    # Retorno de player Pluto (VOD e Live): restaura a lista já montada sem carregar a
    # pilha completa de rotas/HTTP. O primeiro acesso sempre passa pelo router.
    if _render_pluto_snapshot(action, params):
        return

    if action is None:
        if _consume_ibo_return_hint():
            _home_return_fast()
            return
        start_page = _setting_text('paginainicial', '0')
        if start_page == '0':
            home()
            return
        if start_page == '2':
            menu_movies_fast()
            return
        if start_page == '3':
            menu_series_fast()
            return

    _dispatch_to_routes(paramstring)


def main():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    try:
        params = dict(parse_qsl(paramstring, keep_blank_values=True))
        action = params.get('action') or 'home'
    except Exception:
        action = 'home'
    _maintenance_debug('evento=inicio | acao={}'.format(action))
    try:
        result = _main_impl()
        _maintenance_debug('evento=fim | acao={}'.format(action))
        return result
    except Exception as exc:
        _maintenance_exception('Falha não tratada na entrada local (ação={})'.format(action), exc)
        try:
            xbmcgui.Dialog().notification('OnePlay', 'Ocorreu um erro ao abrir esta área. Consulte o log de manutenção.', xbmcgui.NOTIFICATION_ERROR, 3500)
        except Exception:
            pass


if __name__ == '__main__':
    main()
