# -*- coding: utf-8 -*-
from __future__ import unicode_literals

import hashlib
import json
import time

try:
    from kodi_six import xbmcgui
except ImportError:
    import xbmcgui

_WINDOW_ID = 10000
_PREFIX = 'OnePlayMatrix.PlutoNav.v1.'
_MANIFEST = _PREFIX + 'manifest'
_TTL_SECONDS = 1800
_LIVE_TTL_SECONDS = 90
_ACTION_TTL_SECONDS = {
    'channels_pluto_category': _LIVE_TTL_SECONDS,
}
_MAX_SNAPSHOTS = 12
_MAX_PAYLOAD_BYTES = 384 * 1024


def _window():
    return xbmcgui.Window(_WINDOW_ID)


def _canonical_params(action, params):
    params = dict(params or {})
    params.pop('action', None)
    params.pop('resume', None)
    normalized = []
    for key in sorted(params):
        value = params.get(key, '')
        normalized.append((str(key), str(value if value is not None else '')))
    return [str(action or ''), normalized]


def snapshot_property(action, params):
    raw = json.dumps(_canonical_params(action, params), separators=(',', ':'), ensure_ascii=True)
    digest = hashlib.md5(raw.encode('utf-8')).hexdigest()
    return _PREFIX + digest


def _read_manifest(win):
    try:
        raw = win.getProperty(_MANIFEST)
        data = json.loads(raw) if raw else []
        return data if isinstance(data, list) else []
    except Exception:
        return []


def _write_manifest(win, manifest):
    try:
        win.setProperty(_MANIFEST, json.dumps(manifest, separators=(',', ':')))
    except Exception:
        pass


def _ttl_for_action(action):
    return int(_ACTION_TTL_SECONDS.get(str(action or ''), _TTL_SECONDS))


def _prune(win, keep_key=''):
    now = int(time.time())
    manifest = _read_manifest(win)
    live = []
    for entry in manifest:
        if not isinstance(entry, dict):
            continue
        key = str(entry.get('key', '') or '')
        ts = int(entry.get('ts', 0) or 0)
        ttl = int(entry.get('ttl', _TTL_SECONDS) or _TTL_SECONDS)
        if not key:
            continue
        if now - ts > ttl:
            try:
                win.clearProperty(key)
            except Exception:
                pass
            continue
        live.append({'key': key, 'ts': ts, 'ttl': ttl})

    # Mais recentes primeiro; mantém o snapshot recém-gravado quando houver.
    live.sort(key=lambda row: row.get('ts', 0), reverse=True)
    if keep_key:
        live.sort(key=lambda row: row.get('key') != keep_key)
    for entry in live[_MAX_SNAPSHOTS:]:
        try:
            win.clearProperty(entry.get('key', ''))
        except Exception:
            pass
    _write_manifest(win, live[:_MAX_SNAPSHOTS])


def save(action, params, content, items):
    """Guarda somente a representação pública da lista de navegação atual.

    URLs resolvidas/JWT do player nunca entram aqui. O snapshot existe só na
    Window global da sessão Kodi e serve para reconstruir rapidamente a pasta
    quando o VideoPlayer invalida o cache visual do plugin após Stop.
    """
    ttl = _ttl_for_action(action)
    payload = {
        'ts': int(time.time()),
        'ttl': ttl,
        'content': str(content or 'videos'),
        'items': list(items or []),
    }
    try:
        raw = json.dumps(payload, separators=(',', ':'), ensure_ascii=True)
    except Exception:
        return False
    if len(raw.encode('utf-8')) > _MAX_PAYLOAD_BYTES:
        return False

    key = snapshot_property(action, params)
    try:
        win = _window()
        win.setProperty(key, raw)
        manifest = [row for row in _read_manifest(win) if isinstance(row, dict) and row.get('key') != key]
        manifest.insert(0, {'key': key, 'ts': payload['ts'], 'ttl': ttl})
        _write_manifest(win, manifest)
        _prune(win, keep_key=key)
        return True
    except Exception:
        return False


def load(action, params):
    key = snapshot_property(action, params)
    try:
        win = _window()
        raw = win.getProperty(key)
        if not raw:
            return None
        payload = json.loads(raw)
        if not isinstance(payload, dict):
            return None
        ts = int(payload.get('ts', 0) or 0)
        ttl = int(payload.get('ttl', _ttl_for_action(action)) or _ttl_for_action(action))
        if int(time.time()) - ts > ttl:
            win.clearProperty(key)
            _prune(win)
            return None
        items = payload.get('items')
        if not isinstance(items, list):
            return None
        return payload
    except Exception:
        return None
