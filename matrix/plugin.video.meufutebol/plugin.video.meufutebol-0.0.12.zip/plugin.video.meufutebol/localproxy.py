# -*- coding: utf-8 -*-
from helpers import *
import threading
import socket
import struct
import time
import os
import requests
import re
from contextlib import contextmanager
try:
    requests.packages.urllib3.disable_warnings()
except Exception:
    pass
from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
try:
    from urllib.parse import urljoin
except Exception:
    from urlparse import urljoin

HOST = '127.0.0.1'
PORT = 9098
URL_PROXY = 'http://{}:{}/?url='.format(HOST, PORT)

WINDOW = xbmcgui.Window(10000)
PROPERTY_NAME = 'meufutebol.proxy.running'

_proxy_instance = None

DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:147.0) Gecko/20100101 Firefox/147.0'


class CloudflareDNSResolver(object):
    """Resolvedor DNS privado ao addon, usando os recursivos 1.1.1.1/1.0.0.1.

    Ele só substitui getaddrinfo enquanto uma requisição HTTP deste addon está em
    andamento. Isso evita mudar a configuração DNS do dispositivo ou deixar uma
    alteração permanente no Kodi. Respostas ficam em cache curto e, se Cloudflare
    não responder, o DNS nativo permanece como fallback seguro.
    """

    SERVERS = ('1.1.1.1', '1.0.0.1')
    CACHE_TTL_MIN = 60
    CACHE_TTL_MAX = 1800
    UDP_TIMEOUT = 2.0
    TCP_TIMEOUT = 3.5
    DOH_TIMEOUT = (3, 6)

    def __init__(self):
        self._native_getaddrinfo = socket.getaddrinfo
        self._cache = {}
        self._cache_lock = threading.RLock()
        self._patch_lock = threading.RLock()
        self._patch_depth = 0
        self._resolving = threading.local()
        self._logged_active = False

    @staticmethod
    def _host_text(host):
        if isinstance(host, bytes):
            try:
                return host.decode('idna')
            except Exception:
                return host.decode('utf-8', 'ignore')
        return str(host or '')

    @staticmethod
    def _is_ip_literal(host):
        try:
            socket.inet_pton(socket.AF_INET, host)
            return True
        except Exception:
            pass
        try:
            socket.inet_pton(socket.AF_INET6, host)
            return True
        except Exception:
            return False

    def _skip_name(self, packet, offset):
        seen = 0
        length = len(packet)
        while offset < length:
            if seen > 128:
                raise ValueError('Loop de nome DNS')
            seen += 1
            size = packet[offset]
            if size == 0:
                return offset + 1
            if size & 0xC0 == 0xC0:
                if offset + 1 >= length:
                    raise ValueError('Ponteiro DNS truncado')
                return offset + 2
            if size & 0xC0:
                raise ValueError('Label DNS invalido')
            offset += 1 + size
        raise ValueError('Nome DNS truncado')

    def _build_query(self, host):
        labels = []
        for label in host.rstrip('.').split('.'):
            raw = label.encode('idna')
            if not raw or len(raw) > 63:
                raise ValueError('Hostname DNS invalido')
            labels.append(bytes([len(raw)]) + raw)
        question = b''.join(labels) + b'\x00' + struct.pack('!HH', 1, 1)
        query_id = struct.unpack('!H', os.urandom(2))[0]
        return query_id, struct.pack('!HHHHHH', query_id, 0x0100, 1, 0, 0, 0) + question

    def _parse_response(self, packet, query_id):
        if not packet or len(packet) < 12:
            return [], self.CACHE_TTL_MIN
        response_id, flags, qdcount, ancount, _, _ = struct.unpack('!HHHHHH', packet[:12])
        if response_id != query_id or (flags & 0x8000) == 0 or (flags & 0x000F):
            return [], self.CACHE_TTL_MIN
        offset = 12
        for _ in range(qdcount):
            offset = self._skip_name(packet, offset)
            offset += 4
            if offset > len(packet):
                return [], self.CACHE_TTL_MIN

        addresses = []
        ttl_values = []
        for _ in range(ancount):
            offset = self._skip_name(packet, offset)
            if offset + 10 > len(packet):
                break
            rtype, rclass, ttl, rdlength = struct.unpack('!HHIH', packet[offset:offset + 10])
            offset += 10
            rdata_end = offset + rdlength
            if rdata_end > len(packet):
                break
            if rtype == 1 and rclass == 1 and rdlength == 4:
                addresses.append(socket.inet_ntoa(packet[offset:rdata_end]))
                ttl_values.append(ttl)
            offset = rdata_end

        ttl = min(ttl_values) if ttl_values else self.CACHE_TTL_MIN
        ttl = max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
        return addresses, ttl

    def _query_udp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            sock.settimeout(self.UDP_TIMEOUT)
            sock.sendto(packet, (server, 53))
            response, _ = sock.recvfrom(8192)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    def _query_tcp(self, server, packet, query_id):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            sock.settimeout(self.TCP_TIMEOUT)
            sock.connect((server, 53))
            payload = struct.pack('!H', len(packet)) + packet
            sock.sendall(payload)
            header = self._recv_exact(sock, 2)
            if not header:
                return [], self.CACHE_TTL_MIN
            size = struct.unpack('!H', header)[0]
            response = self._recv_exact(sock, size)
            return self._parse_response(response, query_id)
        finally:
            try:
                sock.close()
            except Exception:
                pass

    @staticmethod
    def _recv_exact(sock, amount):
        data = b''
        while len(data) < amount:
            block = sock.recv(amount - len(data))
            if not block:
                return b''
            data += block
        return data

    def _query_doh(self, host):
        """Fallback HTTPS oficial da Cloudflare quando a rede bloqueia DNS UDP/TCP."""
        try:
            response = requests.get(
                'https://cloudflare-dns.com/dns-query',
                params={'name': host, 'type': 'A'},
                headers={'Accept': 'application/dns-json', 'User-Agent': DEFAULT_UA},
                timeout=self.DOH_TIMEOUT,
                allow_redirects=False
            )
            response.raise_for_status()
            payload = response.json()
            ips = []
            ttls = []
            for answer in payload.get('Answer') or []:
                if answer.get('type') == 1 and answer.get('data'):
                    ip = str(answer.get('data'))
                    if self._is_ip_literal(ip):
                        ips.append(ip)
                        ttls.append(answer.get('TTL') or self.CACHE_TTL_MIN)
            ttl = min(ttls) if ttls else self.CACHE_TTL_MIN
            return ips, max(self.CACHE_TTL_MIN, min(int(ttl), self.CACHE_TTL_MAX))
        except Exception as exc:
            try:
                xbmc.log('[MEU FUTEBOL DNS] Fallback DoH indisponivel: {}'.format(str(exc)), xbmc.LOGDEBUG)
            except Exception:
                pass
            return [], self.CACHE_TTL_MIN

    def resolve(self, host):
        host = self._host_text(host).strip().rstrip('.').lower()
        if not host or self._is_ip_literal(host) or host in ('localhost', 'localhost.localdomain') or host.endswith('.local'):
            return []
        now = time.time()
        with self._cache_lock:
            cached = self._cache.get(host)
            if cached and cached[0] > now:
                return list(cached[1])

        if getattr(self._resolving, 'active', False):
            return []

        self._resolving.active = True
        try:
            query_id, packet = self._build_query(host)
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_udp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            for server in self.SERVERS:
                try:
                    addresses, ttl = self._query_tcp(server, packet, query_id)
                    if addresses:
                        self._save_cache(host, addresses, ttl)
                        return addresses
                except Exception:
                    pass
            addresses, ttl = self._query_doh(host)
            if addresses:
                self._save_cache(host, addresses, ttl)
                return addresses
        finally:
            self._resolving.active = False
        return []

    def _save_cache(self, host, addresses, ttl):
        with self._cache_lock:
            self._cache[host] = (time.time() + ttl, tuple(addresses))

    def _patched_getaddrinfo(self, host, port, family=0, type=0, proto=0, flags=0):
        # Não recursar quando o próprio fallback DoH precisa alcançar cloudflare-dns.com.
        if getattr(self._resolving, 'active', False):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        host_text = self._host_text(host)
        if not host_text or self._is_ip_literal(host_text) or host_text in ('localhost', 'localhost.localdomain') or host_text.endswith('.local'):
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        # Não fabrica IPv6: caso o chamador exija AF_INET6, preserva o resolver nativo.
        if family == socket.AF_INET6:
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        addresses = self.resolve(host_text)
        if not addresses:
            return self._native_getaddrinfo(host, port, family, type, proto, flags)
        results = []
        for ip in addresses:
            try:
                results.extend(self._native_getaddrinfo(ip, port, family, type, proto, flags))
            except Exception:
                pass
        return results or self._native_getaddrinfo(host, port, family, type, proto, flags)

    @contextmanager
    def scoped(self):
        with self._patch_lock:
            if self._patch_depth == 0:
                socket.getaddrinfo = self._patched_getaddrinfo
            self._patch_depth += 1
        try:
            yield
        finally:
            with self._patch_lock:
                self._patch_depth -= 1
                if self._patch_depth <= 0:
                    self._patch_depth = 0
                    socket.getaddrinfo = self._native_getaddrinfo

    def mark_active(self):
        if self._logged_active:
            return
        self._logged_active = True
        try:
            xbmc.log('[MEU FUTEBOL DNS] Cloudflare 1.1.1.1 habilitado para o fluxo deste addon.', xbmc.LOGINFO)
        except Exception:
            pass


_cloudflare_dns = CloudflareDNSResolver()


def install_cloudflare_dns():
    """Marca o resolvedor como ativo; não troca o DNS do sistema nem grava configurações."""
    _cloudflare_dns.mark_active()
    return True


def cloudflare_get(url, **kwargs):
    """GET do requests com resolução Cloudflare limitada a esta requisição."""
    install_cloudflare_dns()
    with _cloudflare_dns.scoped():
        return requests.get(url, **kwargs)


class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    daemon_threads = True


def is_port_in_use(port, host='127.0.0.1'):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(1)
        return s.connect_ex((host, port)) == 0


def _split_kodi_url(raw):
    if '|' in raw:
        url, options = raw.split('|', 1)
    else:
        url, options = raw, ''
    parsed_options = parse_qs(options, keep_blank_values=True)
    return url, parsed_options


def _opt(options, key, default=''):
    value = options.get(key, [default])
    return value[0] if value else default


def _build_proxy_url(url, options):
    params = {}
    user_agent = _opt(options, 'User-Agent', DEFAULT_UA)
    referer = _opt(options, 'Referer', '')
    origin = _opt(options, 'Origin', '')
    upstream_proxy = _opt(options, 'Proxy', '')
    if user_agent:
        params['User-Agent'] = user_agent
    if referer:
        params['Referer'] = referer
    if origin:
        params['Origin'] = origin
    if upstream_proxy:
        params['Proxy'] = upstream_proxy
    kodi_url = url + ('|' + urlencode(params) if params else '')
    return URL_PROXY + quote_plus(kodi_url)


def _rewrite_attr_uris(line, base_url, options):
    def repl(match):
        quote_char = match.group(1)
        uri = match.group(2)
        absolute = urljoin(base_url, uri)
        return 'URI={}{}{}'.format(quote_char, _build_proxy_url(absolute, options), quote_char)
    return re.sub(r'URI=(["\'])(.*?)\1', repl, line)


def _rewrite_playlist(content, base_url, options):
    lines = []
    for line in content.splitlines():
        stripped = line.strip()
        if not stripped:
            lines.append(line)
            continue
        if stripped.startswith('#'):
            if 'URI=' in stripped:
                lines.append(_rewrite_attr_uris(line, base_url, options))
            else:
                lines.append(line)
            continue
        absolute = urljoin(base_url, stripped)
        lines.append(_build_proxy_url(absolute, options))
    return '\n'.join(lines) + '\n'


class M3UProxyHandler(BaseHTTPRequestHandler):
    def log_message(self, format, *args):
        return

    def do_GET(self):
        query = parse_qs(urlparse(self.path).query)
        target_url = query.get('url', [None])[0]
        target_url = unquote_plus(target_url) if target_url else None

        if not target_url:
            self.send_error(400)
            return

        try:
            url, options = _split_kodi_url(target_url)
            upstream_proxy = _opt(options, 'Proxy', '')
            headers = {
                'User-Agent': _opt(options, 'User-Agent', DEFAULT_UA),
                'Referer': _opt(options, 'Referer', ''),
                'Origin': _opt(options, 'Origin', '')
            }
            # Repassa Range quando o player pedir, sem criar uma resolução DNS fora do proxy.
            client_range = self.headers.get('Range', '')
            if client_range:
                headers['Range'] = client_range
            headers = {k: v for k, v in headers.items() if v}

            proxies = {'http': upstream_proxy, 'https': upstream_proxy} if upstream_proxy else None
            r = cloudflare_get(url, headers=headers, proxies=proxies, timeout=(8, 25), verify=False, allow_redirects=True)
            r.raise_for_status()

            content_type = r.headers.get('Content-Type', '')
            final_url = r.url or url
            base_url = final_url.rsplit('/', 1)[0] + '/'
            body_source = r.content
            is_playlist = (
                '.m3u8' in final_url.lower() or
                'mpegurl' in content_type.lower() or
                body_source[:16].lstrip().startswith(b'#EXTM3U')
            )

            if is_playlist:
                text = body_source.decode(r.encoding or 'utf-8', 'replace')
                text = text.replace('\\/', '/')
                body = _rewrite_playlist(text, base_url, options).encode('utf-8')
                self.send_response(200)
                self.send_header('Content-Type', 'application/vnd.apple.mpegurl')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                self.send_header('Content-Length', str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            else:
                status = r.status_code if r.status_code in (200, 206) else 200
                self.send_response(status)
                self.send_header('Content-Type', content_type or 'application/octet-stream')
                self.send_header('Cache-Control', 'no-store')
                self.send_header('Connection', 'close')
                self.send_header('Content-Length', str(len(body_source)))
                for header in ('Content-Range', 'Accept-Ranges'):
                    value = r.headers.get(header)
                    if value:
                        self.send_header(header, value)
                self.end_headers()
                self.wfile.write(body_source)

        except Exception as e:
            xbmc.log('[MEU FUTEBOL PROXY ERROR] ' + str(e), xbmc.LOGERROR)
            self.send_error(500)


class ProxyServer(threading.Thread):
    def __init__(self):
        super().__init__(daemon=True)
        self.server = None
        self.monitor = xbmc.Monitor()

    def run(self):
        try:
            ThreadedHTTPServer.allow_reuse_address = True
            self.server = ThreadedHTTPServer((HOST, PORT), M3UProxyHandler)
            xbmc.log('[MEU FUTEBOL PROXY] Rodando em http://{}:{}'.format(HOST, PORT), xbmc.LOGINFO)
            threading.Thread(target=self.server.serve_forever, daemon=True).start()
            while not self.monitor.abortRequested():
                self.monitor.waitForAbort(1)
            self.stop()
        except OSError:
            xbmc.log('[MEU FUTEBOL PROXY] Porta ocupada.', xbmc.LOGINFO)

    def stop(self):
        if self.server:
            xbmc.log('[MEU FUTEBOL PROXY] Encerrando...', xbmc.LOGINFO)
            self.server.shutdown()
            self.server.server_close()
            self.server = None


def start():
    global _proxy_instance
    install_cloudflare_dns()
    if WINDOW.getProperty(PROPERTY_NAME) == 'true':
        if is_port_in_use(PORT, HOST):
            xbmc.log('[MEU FUTEBOL PROXY] Ja marcado como ativo.', xbmc.LOGINFO)
            return True
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Marcacao antiga sem porta ativa; reiniciando.', xbmc.LOGINFO)
    if is_port_in_use(PORT, HOST):
        WINDOW.setProperty(PROPERTY_NAME, 'true')
        xbmc.log('[MEU FUTEBOL PROXY] Porta ja estava ativa.', xbmc.LOGINFO)
        return True
    try:
        _proxy_instance = ProxyServer()
        _proxy_instance.start()
        # Em algumas plataformas, especialmente Android/Xbox, a thread pode demorar ou falhar ao abrir socket.
        for _ in range(15):
            xbmc.sleep(100)
            if is_port_in_use(PORT, HOST):
                WINDOW.setProperty(PROPERTY_NAME, 'true')
                xbmc.log('[MEU FUTEBOL PROXY] Iniciado com sucesso.', xbmc.LOGINFO)
                return True
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Nao confirmou abertura da porta.', xbmc.LOGWARNING)
        return False
    except Exception as e:
        WINDOW.clearProperty(PROPERTY_NAME)
        xbmc.log('[MEU FUTEBOL PROXY] Falha ao iniciar: {}'.format(str(e)), xbmc.LOGERROR)
        return False


def stop():
    global _proxy_instance
    if _proxy_instance:
        _proxy_instance.stop()
        _proxy_instance = None
    WINDOW.clearProperty(PROPERTY_NAME)
    xbmc.log('[MEU FUTEBOL PROXY] Finalizado.', xbmc.LOGINFO)
