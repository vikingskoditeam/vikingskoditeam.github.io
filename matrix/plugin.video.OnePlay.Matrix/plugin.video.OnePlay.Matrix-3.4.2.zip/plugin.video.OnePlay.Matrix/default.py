# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# Inicialização local e rápida da Home do OnePlay Matrix.
# A Home não consulta catálogo, M3U, EPG, proxy, DNS nem player.

import os
import sys
import hashlib
from urllib.parse import parse_qsl, urlencode

try:
    from kodi_six import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
except ImportError:
    import xbmc
    import xbmcplugin
    import xbmcgui
    import xbmcaddon
    import xbmcvfs

# Migração mínima antes de o Kodi carregar as configurações do addon: remove
# apenas resíduos aposentados do perfil. Falha aqui é sempre fail-open.
try:
    from resources.lib.profile_cleanup import cleanup_retired_runtime_residue
    cleanup_retired_runtime_residue(clean_bytecode=False)
except Exception:
    pass

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
TRANSLATE = xbmcvfs.translatePath
HOME_DIR = TRANSLATE(ADDON.getAddonInfo('path'))
ADDON_ICON = os.path.join(HOME_DIR, 'icon.png')
ADDON_FANART = os.path.join(HOME_DIR, 'fanart.jpg')
IBO_ADDON_ID = 'plugin.video.ibo.oneplay'
IBO_ADDON_URL = 'plugin://plugin.video.ibo.oneplay/?origin=oneplay_matrix'
ONEPLAY_REPO_ID = 'One.repo'
ONEPLAY_REPO_BUNDLED_ZIP = os.path.join(HOME_DIR, 'resources', 'installers', 'One.repo.zip')
ONEPLAY_REPO_BUNDLED_SHA256 = 'e48b77bcfe5bc6219a6890d9490f207fe25476d99d31af1eeafe0d8c6b97b453'
IBO_RETURN_HINT_PROPERTY = 'OnePlayMatrix.IBOReturnFast'

WELCOME_LABEL = '[COLOR aquamarine]:::[/COLOR]BEM-VINDOS AO ONEPLAY[COLOR aquamarine]:::[/COLOR]'
ONEPLAY_DESC = '''
Para trabalhar em equipe precisamos ter empatia, transparência, solidariedade e muita lealdade, esses ingredientes são necessários para o sucesso em grupo.

[B][COLOR aquamarine]Repositório Oficial ONEPLAY[/COLOR][/B]
[COLOR blue]https://oneplayhd.github.io[/COLOR]

[B][COLOR aquamarine]Grupos Oficiais:[/COLOR][/B]
Entre em BEM-VINDOS AO ONEPLAY para ver o QR Code.
    '''



def _maintenance_debug(message):
    if not _setting_bool('mododebug', False):
        return
    try:
        from resources.lib.common import log_debug
        log_debug(message, addon=ADDON, component='Home')
    except Exception:
        pass


def _maintenance_exception(context, exc):
    try:
        from resources.lib.common import log_exception
        log_exception('Home', context, exc, addon=ADDON)
    except Exception:
        try:
            xbmc.log('[OnePlay][Home] {}: {}'.format(context, exc.__class__.__name__), level=xbmc.LOGERROR)
        except Exception:
            pass

def _setting_text(key, default=''):
    try:
        value = ADDON.getSetting(key)
        return value if value not in (None, '') else default
    except Exception:
        return default


def _setting_bool(key, default=False):
    try:
        return str(_setting_text(key, 'true' if default else 'false')).lower() == 'true'
    except Exception:
        return default


def _build_url(query):
    return '{}?{}'.format(BASE_URL, urlencode(query or {}))


def _jsonrpc(method, params=None):
    """Executa JSON-RPC local sem gerar exceção para estados normais de ausência."""
    import json
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': str(method or ''),
        'params': params or {},
    }
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload, ensure_ascii=False))
        data = json.loads(raw or '{}')
        if isinstance(data, dict) and not data.get('error'):
            return data.get('result')
    except Exception as exc:
        _maintenance_exception('jsonrpc_{}'.format(str(method or '').replace('.', '_')), exc)
    return None


def _addon_available(addon_id):
    """True somente quando o addon está instalado e habilitado.

    Não instancia xbmcaddon.Addon(addon_id) para testar ausência esperada, pois
    o Kodi registra isso como ERROR e o polling antigo poluía o log.
    """
    try:
        checker = getattr(xbmc, 'getCondVisibility', None)
        return bool(checker and checker('System.HasAddon({})'.format(addon_id)))
    except Exception:
        return False


def _addons_jsonrpc(installed):
    result = _jsonrpc('Addons.GetAddons', {
        'installed': installed,
        'enabled': 'all',
        'properties': ['name', 'version'],
    })
    if not isinstance(result, dict):
        return []
    addons = result.get('addons') or []
    return addons if isinstance(addons, list) else []


def _addon_installed_any_state(addon_id):
    target = str(addon_id or '')
    for item in _addons_jsonrpc(True):
        if isinstance(item, dict) and str(item.get('addonid') or '') == target:
            return True
    return False


def _catalog_has_addon(addon_id):
    """True quando algum repositório já publicou o addon, mesmo não instalado."""
    target = str(addon_id or '')
    for item in _addons_jsonrpc(False):
        if isinstance(item, dict) and str(item.get('addonid') or '') == target:
            return True
    return False


def _set_addon_enabled_jsonrpc(addon_id, enabled=True):
    result = _jsonrpc('Addons.SetAddonEnabled', {
        'addonid': str(addon_id or ''),
        'enabled': bool(enabled),
    })
    return result is not None


def _ibo_available():
    return _addon_available(IBO_ADDON_ID)


def _wait_until(predicate, total_ms=3500, step_ms=200):
    elapsed = 0
    total_ms = max(0, int(total_ms))
    step_ms = max(50, int(step_ms))
    while elapsed <= total_ms:
        try:
            if predicate():
                return True
        except Exception:
            pass
        if elapsed >= total_ms:
            break
        try:
            xbmc.sleep(step_ms)
        except Exception:
            break
        elapsed += step_ms
    try:
        return bool(predicate())
    except Exception:
        return False


def _wait_addon_available(addon_id, total_ms=3500, step_ms=250):
    return _wait_until(lambda: _addon_available(addon_id), total_ms, step_ms)


def _exec_builtin(command, wait=False):
    try:
        xbmc.executebuiltin(command, bool(wait))
    except TypeError:
        xbmc.executebuiltin(command)


def _version_key(value):
    import re
    numbers = [int(x) for x in re.findall(r'\d+', str(value or ''))[:4]]
    while len(numbers) < 4:
        numbers.append(0)
    return tuple(numbers)


def _manifest_info(path):
    try:
        import xml.etree.ElementTree as ET
        tree = ET.parse(path)
        node = tree.getroot()
        return str(node.attrib.get('id') or ''), str(node.attrib.get('version') or '')
    except Exception:
        return '', ''


def _file_sha256(path, chunk_size=256 * 1024):
    """Calcula a identidade do pacote local sem carregá-lo inteiro na RAM."""
    digest = hashlib.sha256()
    with open(path, 'rb') as handle:
        while True:
            chunk = handle.read(chunk_size)
            if not chunk:
                break
            digest.update(chunk)
    return digest.hexdigest()


def _ibo_lock_path():
    profile = TRANSLATE(ADDON.getAddonInfo('profile'))
    try:
        xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            os.makedirs(profile, exist_ok=True)
        except Exception:
            pass
    return os.path.join(profile, 'ibo_install_flow.lock')


def _acquire_ibo_flow_lock(stale_seconds=120):
    """Lock inter-invocador para impedir vários open_ibo concorrentes."""
    import time
    import uuid
    path = _ibo_lock_path()
    owner = '{}-{}'.format(int(time.time() * 1000), uuid.uuid4().hex)
    for attempt in range(2):
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            try:
                os.write(fd, owner.encode('utf-8'))
            finally:
                os.close(fd)
            _maintenance_debug('evento=ibo_flow_lock_acquired')
            return path, owner
        except FileExistsError:
            try:
                age = max(0.0, time.time() - os.path.getmtime(path))
            except Exception:
                age = 0.0
            if age > float(stale_seconds) and attempt == 0:
                try:
                    os.remove(path)
                    _maintenance_debug('evento=ibo_flow_lock_stale_removed | idade={:.1f}s'.format(age))
                    continue
                except Exception:
                    pass
            _maintenance_debug('evento=ibo_flow_duplicate_blocked')
            return None, None
        except Exception as exc:
            _maintenance_exception('ibo_flow_lock_acquire', exc)
            return None, None
    return None, None


def _release_ibo_flow_lock(path, owner):
    if not path or not owner:
        return
    try:
        current = ''
        with open(path, 'rb') as fh:
            current = fh.read(256).decode('utf-8', 'ignore')
        if current == owner:
            os.remove(path)
            _maintenance_debug('evento=ibo_flow_lock_released')
    except FileNotFoundError:
        pass
    except Exception as exc:
        _maintenance_exception('ibo_flow_lock_release', exc)


def _focus_native_confirm_yes(timeout_ms=5000):
    """Foca o botão afirmativo do próximo DialogConfirm nativo do Kodi.

    É chamado somente imediatamente após EnableAddon/InstallAddon iniciados
    por este fluxo. Não confirma automaticamente: o usuário ainda pode mover
    para Não/Cancelar. Em Estuary/Kodi 21 o controle afirmativo é o id 11.
    """
    getter = getattr(xbmcgui, 'getCurrentWindowDialogId', None)
    if getter is None:
        return False
    elapsed = 0
    step = 50
    while elapsed <= max(0, int(timeout_ms)):
        try:
            dialog_id = int(getter() or 0)
        except Exception:
            dialog_id = 0
        if dialog_id == 10100:
            try:
                window = xbmcgui.Window(10100)
                for _ in range(4):
                    window.setFocusId(11)
                    try:
                        if int(window.getFocusId()) == 11:
                            _maintenance_debug('evento=ibo_native_confirm_focus_yes')
                            return True
                    except Exception:
                        return True
                    xbmc.sleep(40)
            except Exception as exc:
                _maintenance_exception('ibo_native_confirm_focus', exc)
                return False
        try:
            xbmc.sleep(step)
        except Exception:
            break
        elapsed += step
    return False


def _start_builtin_with_yes_focus(command, focus_timeout_ms=5000):
    """Inicia built-in assíncrono e posiciona foco afirmativo no seu modal."""
    try:
        _exec_builtin(command, wait=False)
    except Exception as exc:
        _maintenance_exception('ibo_builtin_start', exc)
        return False
    _focus_native_confirm_yes(focus_timeout_ms)
    return True


def _install_bundled_oneplay_repo():
    """Copia com segurança o One.repo empacotado após confirmação do usuário.

    Esta função deliberadamente NÃO habilita nem atualiza o repositório. A
    máquina de estados do VIP faz isso somente depois que o Kodi registrar o
    addon, evitando o segundo DialogConfirm que o log real revelou.
    """
    import shutil
    import stat
    import tempfile
    import zipfile
    import xml.etree.ElementTree as ET

    repo_zip = TRANSLATE(ONEPLAY_REPO_BUNDLED_ZIP)
    if not repo_zip or not os.path.isfile(repo_zip):
        _maintenance_debug('evento=ibo_repo_bundle_missing')
        return False, 'Arquivo local do Repositório Oficial ONEPLAY não encontrado.'

    try:
        actual_sha256 = _file_sha256(repo_zip)
    except Exception as exc:
        _maintenance_exception('ibo_repo_bundle_hash_read', exc)
        return False, 'Não foi possível validar o pacote local do Repositório Oficial ONEPLAY.'
    if actual_sha256.lower() != ONEPLAY_REPO_BUNDLED_SHA256.lower():
        _maintenance_debug('evento=ibo_repo_bundle_hash_mismatch')
        return False, 'A integridade do pacote local do Repositório Oficial ONEPLAY não confere.'

    addons_root = TRANSLATE('special://home/addons')
    if not addons_root:
        return False, 'Diretório de addons do Kodi não pôde ser localizado.'
    try:
        os.makedirs(addons_root, exist_ok=True)
    except Exception as exc:
        _maintenance_exception('ibo_repo_mkdir_addons', exc)
        return False, 'Não foi possível preparar o diretório de addons.'

    try:
        with zipfile.ZipFile(repo_zip, 'r') as archive:
            infos = archive.infolist()
            total_uncompressed = sum(max(0, int(i.file_size)) for i in infos)
            if total_uncompressed > 20 * 1024 * 1024:
                return False, 'Pacote local do repositório excede o limite de segurança.'
            manifest_info = next((i for i in infos if i.filename.replace('\\', '/') == 'One.repo/addon.xml'), None)
            if manifest_info is None:
                return False, 'Pacote local do repositório não possui addon.xml esperado.'
            manifest = ET.fromstring(archive.read(manifest_info))
            bundled_id = str(manifest.attrib.get('id') or '')
            bundled_version = str(manifest.attrib.get('version') or '')
            if bundled_id != ONEPLAY_REPO_ID:
                return False, 'Identidade do pacote local do repositório não confere.'

            target_dir = os.path.join(addons_root, ONEPLAY_REPO_ID)
            existing_id, existing_version = _manifest_info(os.path.join(target_dir, 'addon.xml'))
            if existing_id == ONEPLAY_REPO_ID and _version_key(existing_version) >= _version_key(bundled_version):
                _maintenance_debug('evento=ibo_repo_preserve | versao={}'.format(existing_version or '?'))
                _exec_builtin('UpdateLocalAddons', wait=True)
                return True, 'Repositório Oficial ONEPLAY já está instalado.'

            stage_root = tempfile.mkdtemp(prefix='oneplay_repo_', dir=addons_root)
            stage_repo = os.path.join(stage_root, ONEPLAY_REPO_ID)
            try:
                for info in infos:
                    name = info.filename.replace('\\', '/')
                    parts = [p for p in name.split('/') if p not in ('', '.')]
                    if not parts:
                        continue
                    if parts[0] != ONEPLAY_REPO_ID or '..' in parts:
                        raise ValueError('entrada fora do diretório permitido')
                    mode = (int(info.external_attr) >> 16) & 0o170000
                    if mode == stat.S_IFLNK:
                        raise ValueError('symlink não permitido')
                    destination = os.path.abspath(os.path.join(stage_root, *parts))
                    if os.path.commonpath([os.path.abspath(stage_root), destination]) != os.path.abspath(stage_root):
                        raise ValueError('path traversal')
                    if info.is_dir() or name.endswith('/'):
                        os.makedirs(destination, exist_ok=True)
                        continue
                    os.makedirs(os.path.dirname(destination), exist_ok=True)
                    with archive.open(info, 'r') as src, open(destination, 'wb') as dst:
                        shutil.copyfileobj(src, dst, length=256 * 1024)

                check_id, check_version = _manifest_info(os.path.join(stage_repo, 'addon.xml'))
                if check_id != ONEPLAY_REPO_ID or check_version != bundled_version:
                    raise ValueError('manifesto extraído não confere')

                backup_dir = None
                if os.path.isdir(target_dir):
                    backup_dir = target_dir + '.matrix_backup'
                    if os.path.exists(backup_dir):
                        shutil.rmtree(backup_dir, ignore_errors=True)
                    os.replace(target_dir, backup_dir)
                try:
                    os.replace(stage_repo, target_dir)
                except Exception:
                    if backup_dir and os.path.isdir(backup_dir) and not os.path.exists(target_dir):
                        os.replace(backup_dir, target_dir)
                    raise
                if backup_dir and os.path.isdir(backup_dir):
                    shutil.rmtree(backup_dir, ignore_errors=True)
            finally:
                shutil.rmtree(stage_root, ignore_errors=True)
    except Exception as exc:
        _maintenance_exception('ibo_repo_local_install', exc)
        return False, 'Não foi possível instalar o Repositório Oficial ONEPLAY.'

    try:
        _exec_builtin('UpdateLocalAddons', wait=True)
    except Exception as exc:
        _maintenance_exception('ibo_repo_refresh_local', exc)

    _maintenance_debug('evento=ibo_repo_local_installed | id={} | versao={}'.format(ONEPLAY_REPO_ID, bundled_version))
    return True, 'Repositório Oficial ONEPLAY instalado.'


def _ask_install_official_repo():
    message = ('O ONEPLAY IBO não está disponível nos repositórios configurados.\n\n'
               'Deseja instalar o Repositório Oficial ONEPLAY para obtê-lo?')
    dialog = xbmcgui.Dialog()
    try:
        return bool(dialog.yesno('ONEPLAY VIP', message, nolabel='Não', yeslabel='Instalar', defaultbutton=xbmcgui.DLG_YESNO_YES_BTN))
    except TypeError:
        try:
            return bool(dialog.yesno('ONEPLAY VIP', message, '', '', 'Não', 'Instalar'))
        except Exception:
            return False
    except Exception:
        return False


def _ensure_oneplay_repo_enabled():
    """Garante One.repo registrado e habilitado, evitando falso negativo após instalação.

    O registro/habilitação de um addon pode ser confirmado pelo Kodi alguns instantes
    depois do retorno do comando que iniciou a operação. Por isso reconciliamos o
    estado final antes de informar falha ao usuário.
    """
    if not _addon_installed_any_state(ONEPLAY_REPO_ID):
        _exec_builtin('UpdateLocalAddons', wait=True)
        if not _wait_until(lambda: _addon_installed_any_state(ONEPLAY_REPO_ID), 3500, 150):
            return False

    if _addon_available(ONEPLAY_REPO_ID):
        return True

    if _set_addon_enabled_jsonrpc(ONEPLAY_REPO_ID, True):
        if _wait_addon_available(ONEPLAY_REPO_ID, 5000, 150):
            _maintenance_debug('evento=ibo_repo_enabled_jsonrpc')
            return True
        _maintenance_debug('evento=ibo_repo_enable_ack_pending_visibility')

    # Reconcilia a base local antes do fallback. Em hardware mais lento o comando
    # pode ter sido aceito e o System.HasAddon ainda não refletir o novo estado.
    try:
        _exec_builtin('UpdateLocalAddons', wait=True)
    except Exception as exc:
        _maintenance_exception('ibo_repo_reconcile_local', exc)
    if _wait_addon_available(ONEPLAY_REPO_ID, 2500, 150):
        _maintenance_debug('evento=ibo_repo_enabled_after_reconcile')
        return True

    # Fallback para instalações em que ManageAddon via JSON-RPC esteja negado.
    _maintenance_debug('evento=ibo_repo_enable_builtin_fallback')
    if _start_builtin_with_yes_focus('EnableAddon({})'.format(ONEPLAY_REPO_ID), 4000):
        if _wait_addon_available(ONEPLAY_REPO_ID, 8000, 200):
            _maintenance_debug('evento=ibo_repo_enabled_builtin')
            return True

    # Última leitura do estado real antes de produzir qualquer mensagem de falha.
    try:
        _exec_builtin('UpdateLocalAddons', wait=True)
    except Exception as exc:
        _maintenance_exception('ibo_repo_final_refresh', exc)
    return _wait_addon_available(ONEPLAY_REPO_ID, 2500, 150)


def _wait_catalog_for_ibo(total_ms=30000):
    """Aguarda a publicação do IBO no catálogo local após refresh do repo.

    Em hardware real o Kodi pode terminar o download/parse do repositório antes de
    expor o novo addon via Addons.GetAddons(installed=False). O log de 09/09/2026
    mostrou esse atraso ultrapassando a janela anterior de 12 s. Mantemos um
    único refresh e apenas ampliamos a espera bounded para não exigir segundo
    clique no VIP.
    """
    return _wait_until(lambda: _catalog_has_addon(IBO_ADDON_ID) or _ibo_available(), total_ms, 250)


def _current_dialog_id():
    getter = getattr(xbmcgui, 'getCurrentWindowDialogId', None)
    if getter is None:
        return 0
    try:
        return int(getter() or 0)
    except Exception:
        return 0


def _wait_dialog_close(dialog_id, total_ms=15000, step_ms=100):
    elapsed = 0
    target = int(dialog_id or 0)
    while elapsed <= max(0, int(total_ms)):
        if _current_dialog_id() != target:
            return True
        if elapsed >= int(total_ms):
            break
        xbmc.sleep(max(50, int(step_ms)))
        elapsed += max(50, int(step_ms))
    return _current_dialog_id() != target


def _wait_ibo_install_outcome(total_ms=20000, step_ms=200):
    """Distingue instalação, falha nativa e simples cancelamento/timeout.

    O DialogOK do Kodi usa a janela 12002. Ele só é tratado como falha aqui
    depois que InstallAddon foi iniciado por este fluxo; assim um 'Não' no
    diálogo de instalação não dispara retentativa automática.
    """
    elapsed = 0
    total_ms = max(0, int(total_ms))
    step_ms = max(50, int(step_ms))
    while elapsed <= total_ms:
        if _addon_installed_any_state(IBO_ADDON_ID):
            if not _ibo_available():
                _set_addon_enabled_jsonrpc(IBO_ADDON_ID, True)
                _wait_addon_available(IBO_ADDON_ID, 3000, 150)
            return 'installed' if _ibo_available() else 'installed-disabled'
        if _current_dialog_id() == 12002:
            return 'native-failure-dialog'
        if elapsed >= total_ms:
            break
        xbmc.sleep(step_ms)
        elapsed += step_ms
    return 'timeout-or-cancel'


def _install_ibo_from_catalog(allow_transient_retry=True):
    if _ibo_available():
        return True
    if not _catalog_has_addon(IBO_ADDON_ID):
        return False

    max_attempts = 2 if allow_transient_retry else 1
    for attempt in range(1, max_attempts + 1):
        _maintenance_debug('evento=ibo_native_install_start | tentativa={}'.format(attempt))
        if not _start_builtin_with_yes_focus('InstallAddon({})'.format(IBO_ADDON_ID), 5000):
            return False

        outcome = _wait_ibo_install_outcome(total_ms=20000, step_ms=200)
        _maintenance_debug('evento=ibo_native_install_outcome | tentativa={} | resultado={}'.format(attempt, outcome))
        if outcome == 'installed':
            return True
        if outcome == 'installed-disabled':
            return _ibo_available()

        # Retenta somente quando o próprio Kodi exibiu seu DialogOK de falha.
        # Se o usuário escolheu Não, normalmente não existe esse DialogOK:
        # nesse caso outcome=timeout-or-cancel e respeitamos a decisão.
        if outcome != 'native-failure-dialog' or attempt >= max_attempts:
            return False

        _maintenance_debug('evento=ibo_native_install_transient_failure | tentativa={}'.format(attempt))
        if not _wait_dialog_close(12002, total_ms=15000, step_ms=100):
            return False
        xbmc.sleep(2500)
        if _ibo_available():
            return True
        if not _catalog_has_addon(IBO_ADDON_ID):
            return False

    return False


def _request_ibo_install_with_repo_fallback():
    """Fluxo VIP em duas etapas quando o Repositório Oficial ainda não existe.

    Contrato deliberado:
    1) primeira entrada sem One.repo: instala/habilita o repositório, dispara a
       atualização do catálogo e encerra com orientação explícita;
    2) entrada seguinte: com o repositório já presente, aguarda o catálogo se
       necessário e então usa InstallAddon para instalar o ONEPLAY IBO.

    Não tenta encadear repo recém-instalado + InstallAddon na mesma invocação.
    O Kodi não expõe ao Python o evento interno que confirma que todos os jobs
    do RepositoryUpdater terminaram/estabilizaram para o AddonInstaller.
    """
    _maintenance_debug('evento=ibo_install_flow_start | addon={}'.format(IBO_ADDON_ID))

    if _ibo_available():
        return True

    # Se o catálogo já conhece o IBO, a instalação pode seguir diretamente.
    if _catalog_has_addon(IBO_ADDON_ID):
        return _install_ibo_from_catalog(allow_transient_retry=False)

    repo_installed = _addon_installed_any_state(ONEPLAY_REPO_ID)
    if not repo_installed:
        if not _ask_install_official_repo():
            _maintenance_debug('evento=ibo_repo_install_declined')
            return False

        ok, message = _install_bundled_oneplay_repo()
        if not ok:
            try:
                xbmcgui.Dialog().ok('ONEPLAY VIP', message)
            except Exception:
                pass
            return False

        if not _wait_until(lambda: _addon_installed_any_state(ONEPLAY_REPO_ID), 3500, 150):
            try:
                xbmcgui.Dialog().ok(
                    'ONEPLAY VIP',
                    'O Repositório Oficial ONEPLAY foi copiado, mas o Kodi ainda não conseguiu registrá-lo.'
                )
            except Exception:
                pass
            return False

        if not _ensure_oneplay_repo_enabled():
            try:
                xbmcgui.Dialog().ok(
                    'ONEPLAY VIP',
                    'O Repositório Oficial ONEPLAY está instalado. O Kodi ainda não confirmou a habilitação.\n\nAguarde alguns instantes e entre novamente no VIP.'
                )
            except Exception:
                pass
            return False

        # O refresh é propositalmente assíncrono. Não tentamos instalar o IBO
        # nesta mesma invocação: isso foi instável nos testes reais e o Kodi
        # não oferece um await público para o RepositoryUpdater.
        _maintenance_debug('evento=ibo_repo_catalog_refresh_start | etapa=primeira_entrada')
        try:
            _exec_builtin('UpdateAddonRepos', wait=False)
        except Exception as exc:
            _maintenance_exception('ibo_repo_catalog_refresh', exc)

        # Pequena janela apenas para permitir que o job comece; NÃO é usada
        # como heurística para iniciar InstallAddon na mesma entrada.
        try:
            xbmc.sleep(700)
        except Exception:
            pass

        try:
            xbmcgui.Dialog().ok(
                'ONEPLAY VIP',
                'Repositório Oficial ONEPLAY instalado e habilitado com sucesso.\n\n'
                'Entre novamente no VIP para instalar o ONEPLAY IBO.'
            )
        except Exception:
            pass
        _maintenance_debug('evento=ibo_repo_first_stage_complete | proxima_acao=entrar_vip_novamente')
        return False

    # Segunda entrada: repo já existe. Garante que esteja habilitado e deixa o
    # próprio catálogo do Kodi ficar pronto antes de chamar InstallAddon.
    if not _ensure_oneplay_repo_enabled():
        try:
            xbmcgui.Dialog().ok(
                'ONEPLAY VIP',
                'O Repositório Oficial ONEPLAY está instalado. O Kodi ainda não confirmou a habilitação.\n\nAguarde alguns instantes e entre novamente no VIP.'
            )
        except Exception:
            pass
        return False

    if not _catalog_has_addon(IBO_ADDON_ID):
        _maintenance_debug('evento=ibo_repo_catalog_refresh_start | etapa=segunda_entrada')
        try:
            _exec_builtin('UpdateAddonRepos', wait=False)
        except Exception as exc:
            _maintenance_exception('ibo_repo_catalog_refresh', exc)
        if not _wait_catalog_for_ibo(30000):
            try:
                xbmcgui.Dialog().ok(
                    'ONEPLAY VIP',
                    'O Repositório Oficial ONEPLAY está instalado, mas o ONEPLAY IBO ainda não apareceu no catálogo.\n\n'
                    'Aguarde alguns instantes e entre novamente no VIP.'
                )
            except Exception:
                pass
            return False

    return _install_ibo_from_catalog(allow_transient_retry=False)


def _open_ibo_replacing_matrix():
    """Abre IBO; se ausente, executa uma única instalação serializada."""
    if _ibo_available():
        command = 'ReplaceWindow(Videos,{})'.format(IBO_ADDON_URL)
        _maintenance_debug('evento=ibo_replace_launch | destino={}'.format(IBO_ADDON_URL))
        try:
            _exec_builtin(command, wait=True)
            return True
        except Exception as exc:
            _maintenance_exception('ibo_replace_launch', exc)
            return False

    lock_path, lock_owner = _acquire_ibo_flow_lock()
    if not lock_path:
        # Um Enter repetido durante a instalação não cria outro modal/worker.
        return False
    try:
        if not _request_ibo_install_with_repo_fallback():
            return False
        if not _ibo_available():
            return False
        command = 'ReplaceWindow(Videos,{})'.format(IBO_ADDON_URL)
        _maintenance_debug('evento=ibo_replace_launch | destino={}'.format(IBO_ADDON_URL))
        try:
            _exec_builtin(command, wait=True)
        except Exception as exc:
            _maintenance_exception('ibo_replace_launch', exc)
            return False
        return True
    finally:
        _release_ibo_flow_lock(lock_path, lock_owner)


def _prepare_oneplay_live_startup(params):
    """Replica a trava/feedback imediato do OnePlay Live V4 no Matrix.

    Executa antes de importar o roteador completo. A trava é exclusiva do Live
    e não interfere nos locks de VOD, M3U ou demais players do Matrix.
    """
    import json
    import time
    import uuid
    import builtins

    channel_id = str((params or {}).get('channel_id') or '').strip()
    channel_name = str((params or {}).get('channel_name') or '').strip()
    profile = TRANSLATE(ADDON.getAddonInfo('profile'))
    try:
        xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            if profile and not os.path.isdir(profile):
                os.makedirs(profile)
        except Exception:
            pass
    lock_path = os.path.join(profile, 'oneplay_live_startup.lock')
    now = time.time()
    stale_seconds = 180.0

    if os.path.exists(lock_path):
        try:
            age = max(0.0, now - os.path.getmtime(lock_path))
        except Exception:
            age = 0.0
        if age > stale_seconds:
            try:
                os.remove(lock_path)
                xbmc.log('[ONEPLAY LIVE] lock startup órfão removido age=%.1fs' % age, xbmc.LOGWARNING)
            except Exception:
                pass

    token = uuid.uuid4().hex
    payload = {
        'token': token, 'channel_id': channel_id, 'name': channel_name,
        'created': now, 'updated': now,
    }
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
    except FileExistsError:
        active_name = ''
        try:
            with open(lock_path, 'r', encoding='utf-8') as fh:
                active = json.load(fh)
            active_name = str(active.get('name') or active.get('channel_id') or '').strip()
        except Exception:
            pass
        msg = ('Aguarde. %s ainda está sendo preparado.' % active_name) if active_name else 'Aguarde. Outra transmissão ainda está sendo preparada.'
        try:
            xbmcgui.Dialog().notification('OnePlay Live', msg, xbmcgui.NOTIFICATION_INFO, 4000, sound=False)
        except TypeError:
            xbmcgui.Dialog().notification('OnePlay Live', msg, xbmcgui.NOTIFICATION_INFO, 4000)
        except Exception:
            pass
        xbmc.log('[ONEPLAY LIVE] abertura bloqueada por startup ativo solicitado=%s ativo=%s' % (channel_id, active_name or '?'), xbmc.LOGWARNING)
        raise SystemExit(0)
    else:
        try:
            os.write(fd, json.dumps(payload, ensure_ascii=False, separators=(',', ':')).encode('utf-8'))
        finally:
            os.close(fd)

    builtins._oneplay_live_startup_lock = (lock_path, token)
    try:
        dlg = xbmcgui.DialogProgressBG()
        dlg.create('AGUARDE...', 'Preparando transmissão...')
        builtins._oneplay_live_early_wait = (dlg, time.monotonic())
    except Exception:
        pass
    xbmc.log('[ONEPLAY LIVE] lock startup adquirido id=%s; AGUARDE bootstrap imediato' % channel_id, xbmc.LOGDEBUG)


def _release_oneplay_live_startup_on_entry_failure():
    """Libera somente lock pertencente a este invocador em falha pré-player."""
    try:
        import builtins
        import json
        state = getattr(builtins, '_oneplay_live_startup_lock', None)
        if not isinstance(state, tuple) or len(state) < 2:
            return
        path, token = state[0], state[1]
        current = {}
        if path and os.path.exists(path):
            try:
                with open(path, 'r', encoding='utf-8') as fh:
                    current = json.load(fh)
            except Exception:
                current = {}
            if str(current.get('token') or '') == str(token):
                try:
                    os.remove(path)
                except Exception:
                    pass
        try:
            dlg_state = getattr(builtins, '_oneplay_live_early_wait', None)
            dlg = dlg_state[0] if isinstance(dlg_state, tuple) else dlg_state
            if dlg is not None:
                dlg.close()
        except Exception:
            pass
        for attr in ('_oneplay_live_startup_lock', '_oneplay_live_early_wait'):
            try:
                if hasattr(builtins, attr):
                    delattr(builtins, attr)
            except Exception:
                pass
    except Exception:
        pass


def _consume_ibo_return_hint():
    """Consome o marcador de retorno rápido deixado pelo ONEPLAY IBO.

    O marcador vive apenas em Window(Home) e não persiste em disco. Ele serve
    exclusivamente para distinguir uma abertura normal da raiz Matrix de um
    retorno imediato vindo do IBO por ReplaceWindow.
    """
    try:
        window = xbmcgui.Window(10000)
        raw = str(window.getProperty(IBO_RETURN_HINT_PROPERTY) or '').strip()
        if not raw:
            return False
        window.clearProperty(IBO_RETURN_HINT_PROPERTY)
        return True
    except Exception:
        return False


def _suppress_return_busy_once():
    """Fecha somente o Busy nativo já ativo no retorno IBO -> Matrix.

    O log real mostra que DialogBusy é aberto antes de o interpretador Python
    do Matrix terminar de inicializar. Portanto basta fechá-lo no começo do
    fast-path; não há thread, polling ou efeito fora desta volta.
    """
    for dialog_name in ('busydialog', 'busydialognocancel'):
        try:
            xbmc.executebuiltin('Dialog.Close({})'.format(dialog_name))
        except Exception:
            pass


def _home_return_fast():
    """Reconstrói a Home Matrix pelo menor caminho possível após sair do IBO.

    A Home é 100% local. Nesta rota de retorno os ListItems são enviados em
    lote e não há import de routes.py, DNS, TMDB, proxy ou rede. O conteúdo e os
    URLs são os mesmos de ``home()``.
    """
    _suppress_return_busy_once()
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    items = [
        ('TV ao vivo', 'Entrar nas listas e categorias de canais ao vivo.', TRANSLATE(os.path.join(image_dir, 'tv.png')), {'action': 'tv'}),
        ('Filmes', 'Explorar filmes em alta, top avaliados e lançamentos.', TRANSLATE(os.path.join(image_dir, 'filmes.png')), {'action': 'menu_movies'}),
        ('Séries', 'Explorar séries em alta, top avaliadas e lançamentos.', TRANSLATE(os.path.join(image_dir, 'series.png')), {'action': 'menu_series'}),
        ('Configurações', 'Abrir as configurações do addon OnePlay.', TRANSLATE(os.path.join(image_dir, 'configuracoes.png')), {'action': 'open_settings'}),
    ]
    if _setting_bool('mostrarboasvindas', True):
        items.insert(0, (WELCOME_LABEL, ONEPLAY_DESC, ADDON_ICON, {'action': 'donate'}))
    if _setting_bool('exibirvip', True):
        items.insert(1, ('VIP', _vip_description(), TRANSLATE(os.path.join(image_dir, 'vip.png')), {'action': ''}))

    batch = []
    for label, description, icon, query in items:
        url = _build_url({'action': 'open_ibo'}) if label == 'VIP' else _build_url(query)
        list_item = xbmcgui.ListItem(label)
        try:
            list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        except Exception:
            pass
        is_folder = label not in ('Configurações', WELCOME_LABEL, 'VIP')
        if is_folder:
            _set_folder_info(list_item, title=label, plot=description)
        else:
            _set_video_info(list_item, title=label, plot=description)
        try:
            list_item.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        batch.append((url, list_item, is_folder))

    try:
        xbmcplugin.addDirectoryItems(ADDON_HANDLE, batch, len(batch))
    except Exception:
        for url, list_item, is_folder in batch:
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)
    try:
        xbmcplugin.setContent(ADDON_HANDLE, 'movies')
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
    _maintenance_debug('evento=ibo_return_fast | itens={}'.format(len(batch)))

def _set_folder_info(item, title='', plot=''):
    """Metadados neutros para diretórios Kodi.

    Não define ``VideoInfoTag.mediaType``. Mantém apenas a propriedade leve
    ``mediatype=video``, exatamente como o roteador tradicional de TV. O
    ``isFolder=True`` passado a addDirectoryItem permanece como a semântica
    autoritativa, permitindo que a skin desenhe o indicador de pasta de forma
    consistente com TV/Pluto sem perder título, sinopse ou arte.
    """
    try:
        tag = item.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        try:
            if title and hasattr(tag, 'setTitle'):
                tag.setTitle(str(title))
            if plot and hasattr(tag, 'setPlot'):
                tag.setPlot(str(plot))
        except Exception:
            pass
    else:
        try:
            info = {'title': title, 'plot': plot}
            item.setInfo('video', info)
        except Exception:
            pass
    try:
        item.setProperty('mediatype', 'video')
    except Exception:
        pass


def _set_video_info(item, title='', plot='', mediatype='video'):
    # API atual, com fallback seguro para builds Kodi mais antigas.
    try:
        tag = item.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        try:
            if title and hasattr(tag, 'setTitle'):
                tag.setTitle(str(title))
            if plot and hasattr(tag, 'setPlot'):
                tag.setPlot(str(plot))
            if mediatype and hasattr(tag, 'setMediaType'):
                tag.setMediaType(str(mediatype))
        except Exception:
            pass
    else:
        try:
            item.setInfo('video', {'title': title, 'plot': plot, 'mediatype': mediatype or 'video'})
        except Exception:
            pass
    try:
        item.setProperty('mediatype', str(mediatype or 'video'))
    except Exception:
        pass


def _skin_signature():
    skin_id = ''
    skin_theme = ''
    try:
        skin_id = xbmc.getSkinDir() or ''
    except Exception:
        pass
    try:
        skin_theme = xbmc.getInfoLabel('Skin.CurrentTheme') or ''
    except Exception:
        pass
    return '{}|{}'.format(skin_id, skin_theme).strip('|') or 'default'


def _apply_default_list_view(flag_key):
    """Aplica a lista padrão uma vez por skin durante a sessão atual.

    A marcação fica em uma propriedade global do Kodi, não no settings.xml do
    addon. Assim, abrir Filmes/Séries pela primeira vez não dispara
    onSettingsChanged() no service.py nem acorda a sincronização de DNS/EPG.
    O cache de diretório continua sob responsabilidade do Kodi via
    endOfDirectory(..., cacheToDisc=True).
    """
    signature = _skin_signature()
    property_name = 'OnePlayMatrix.ViewState.{}'.format(flag_key)
    window = None
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(property_name) == signature:
            return
    except Exception:
        window = None

    try:
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        return

    # Mantido apenas na primeira entrada de cada área/skin da sessão. Nas
    # voltas pelo histórico, o Kodi usa a lista cacheada sem nova espera.
    try:
        xbmc.sleep(40)
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        pass

    if window is not None:
        try:
            window.setProperty(property_name, signature)
        except Exception:
            pass


def _end_local_directory(content, view_flag):
    """Fecha diretórios inteiramente locais com cache de navegação do Kodi."""
    try:
        xbmcplugin.setContent(ADDON_HANDLE, content)
    except Exception:
        pass
    try:
        # Filmes/Séries e Home não dependem de resposta remota. Persistir
        # a lista permite ao Kodi reutilizar o histórico sem revalidar nada.
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        except Exception:
            pass
    except Exception:
        pass
    _apply_default_list_view(view_flag)


def _vip_description():
    return '''[B][COLOR aquamarine]ONEPLAY VIP[/COLOR][/B]

Acesso integrado ao [COLOR aquamarine]ONEPLAY IBO[/COLOR].
No primeiro acesso, siga as instruções exibidas na tela. Depois, o VIP abre o ONEPLAY IBO diretamente.'''


def home():
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    items = [
        ('TV ao vivo', 'Entrar nas listas e categorias de canais ao vivo.', TRANSLATE(os.path.join(image_dir, 'tv.png')), {'action': 'tv'}),
        ('Filmes', 'Explorar filmes em alta, top avaliados e lançamentos.', TRANSLATE(os.path.join(image_dir, 'filmes.png')), {'action': 'menu_movies'}),
        ('Séries', 'Explorar séries em alta, top avaliadas e lançamentos.', TRANSLATE(os.path.join(image_dir, 'series.png')), {'action': 'menu_series'}),
        ('Configurações', 'Abrir as configurações do addon OnePlay.', TRANSLATE(os.path.join(image_dir, 'configuracoes.png')), {'action': 'open_settings'}),
    ]

    if _setting_bool('mostrarboasvindas', True):
        items.insert(0, (WELCOME_LABEL, ONEPLAY_DESC, ADDON_ICON, {'action': 'donate'}))
    if _setting_bool('exibirvip', True):
        items.insert(1, ('VIP', _vip_description(), TRANSLATE(os.path.join(image_dir, 'vip.png')), {'action': ''}))

    for label, description, icon, query in items:
        url = _build_url({'action': 'open_ibo'}) if label == 'VIP' else _build_url(query)
        list_item = xbmcgui.ListItem(label)
        try:
            list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        except Exception:
            pass
        is_folder = label not in ('Configurações', WELCOME_LABEL, 'VIP')
        if is_folder:
            _set_folder_info(list_item, title=label, plot=description)
        else:
            _set_video_info(list_item, title=label, plot=description)
        try:
            list_item.setProperty('IsPlayable', 'false')
        except Exception:
            pass
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    _end_local_directory('movies', 'default_view_home_list_applied')


def _add_local_folder(label, description, icon_name, query):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, icon_name))
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
    except Exception:
        pass
    _set_folder_info(item, title=label, plot=description)
    try:
        item.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url(query),
        listitem=item,
        isFolder=True
    )


def _add_local_settings_item(plot):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, 'configuracoes.png'))
    label = 'Configurações'
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        item.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    _set_video_info(item, title=label, plot=plot)
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url({'action': 'open_settings'}),
        listitem=item,
        isFolder=False
    )


def menu_movies_fast():
    """Menu local de Filmes; não importa routes.py, DNS ou catálogo."""
    _add_local_folder(
        'Pesquisar Filmes',
        'Pesquisar somente filmes no catálogo TMDB.',
        'pesquisar.png',
        {'action': 'search', 'type': 'movie'}
    )
    items = (
        ('Filmes - Em Alta', 'Ver os filmes em tendência na semana.', {'action': 'list', 'type': 'movie', 'category': 'trending'}),
        ('Filmes - Top Avaliados', 'Ver os filmes mais bem avaliados.', {'action': 'list', 'type': 'movie', 'category': 'top'}),
        ('Filmes - Em Cartaz', 'Ver os filmes atualmente em cartaz conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'now_playing'}),
        ('Filmes - Próximos Lançamentos', 'Ver os próximos lançamentos de filmes conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'upcoming'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'filmes.png', query)
    if _setting_bool('pluto_exibir_filmes', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Filmes - Pluto TV',
            'Abrir os filmes sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_movies'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de filmes.')
    _end_local_directory('movies', 'default_view_movies_list_applied')


def menu_series_fast():
    """Menu local de Séries; não importa routes.py, DNS ou catálogo."""
    _add_local_folder(
        'Pesquisar Séries',
        'Pesquisar somente séries no catálogo TMDB.',
        'pesquisar.png',
        {'action': 'search', 'type': 'series'}
    )
    items = (
        ('Séries - Em Alta', 'Ver as séries em tendência na semana.', {'action': 'list', 'type': 'series', 'category': 'trending'}),
        ('Séries - Top Avaliadas', 'Ver as séries mais bem avaliadas.', {'action': 'list', 'type': 'series', 'category': 'top'}),
        ('Séries - No Ar', 'Ver séries com episódios em exibição nos próximos dias.', {'action': 'list', 'type': 'series', 'category': 'on_the_air'}),
        ('Séries - Estreias Recentes', 'Ver séries com estreia inicial recente.', {'action': 'list', 'type': 'series', 'category': 'recent_premieres'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'series.png', query)
    if _setting_bool('pluto_exibir_series', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Séries - Pluto TV',
            'Abrir as séries sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_series'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de séries.')
    _end_local_directory('tvshows', 'default_view_series_list_applied')


def _render_pluto_snapshot(action, params):
    """Fast-path de retorno após Stop para diretórios Pluto já montados.

    O Kodi limpa o cache visual do plugin ao encerrar o player. Este caminho
    restaura a pasta a partir do snapshot da sessão sem importar o roteador
    completo, requests ou a API Pluto. Em cache miss, o fluxo normal assume.
    """
    if action not in ('pluto_vod_category', 'pluto_vod_episodes', 'channels_pluto_category'):
        return False
    try:
        from resources.lib import pluto_nav_cache
        snapshot = pluto_nav_cache.load(action, params)
    except Exception:
        return False
    if not snapshot:
        return False

    items = snapshot.get('items') or []
    if not items:
        return False
    for row in items:
        try:
            label = str(row.get('label', '') or 'Pluto')
            item = xbmcgui.ListItem(label)
            art = row.get('art') or {}
            if art:
                item.setArt(art)
            is_folder = bool(row.get('is_folder'))
            if is_folder:
                _set_folder_info(
                    item,
                    title=label,
                    plot=str(row.get('plot', '') or '')
                )
                item.setProperty('IsPlayable', 'false')
            else:
                _set_video_info(
                    item,
                    title=label,
                    plot=str(row.get('plot', '') or ''),
                    mediatype=str(row.get('mediatype', '') or 'video')
                )
                if row.get('is_playable'):
                    item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(
                handle=ADDON_HANDLE,
                url=str(row.get('url', '') or ''),
                listitem=item,
                isFolder=is_folder
            )
        except Exception:
            return False

    try:
        xbmcplugin.setContent(ADDON_HANDLE, str(snapshot.get('content', '') or 'videos'))
    except Exception:
        pass
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
    _maintenance_debug('evento=pluto_snapshot_hit | acao={} | itens={}'.format(action, len(items)))
    return True



def _resolve_tv_proxy_fast(params):
    """Resolve o Live já preparado sem carregar routes.py/requests/EPG novamente.

    ``play_url`` continua apontando para /hlsretry ou /tsdownloader do mesmo
    Proxy Nativo. MIME + ContentLookup=False evitam a sondagem prévia da URL
    loopback, mas não mudam demux, buffer, retry, headers ou transporte.
    """
    play_url = str(params.get('play_url') or '')
    if not play_url:
        try:
            xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=False, listitem=xbmcgui.ListItem())
        except Exception:
            pass
        return

    name = str(params.get('name') or 'Canal')
    plot = str(params.get('plot') or '')
    if plot == 'Abrir o canal para reprodução.':
        plot = ''
    icon = str(params.get('icon') or '')
    stream_kind = str(params.get('stream_kind') or 'hls').strip().lower()

    item = xbmcgui.ListItem(name)
    try:
        item.setPath(play_url)
    except Exception:
        pass
    _set_video_info(item, title=name, plot=plot, mediatype='video')
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        item.setProperty('IsPlayable', 'true')
        if stream_kind == 'hls':
            item.setMimeType('application/x-mpegURL')
            item.setContentLookup(False)
        elif stream_kind == 'ts':
            item.setMimeType('video/mp2t')
            item.setContentLookup(False)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(handle=ADDON_HANDLE, succeeded=True, listitem=item)

def _dispatch_to_routes(paramstring):
    # Importação tardia: apenas ações fora da Home precisam da implementação
    # completa (M3U, EPG, TMDB, Pluto, proxy, DNS e HTTP).
    from resources.lib import routes
    routes.router(paramstring)


def _main_impl():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    params = dict(parse_qsl(paramstring, keep_blank_values=True))
    action = params.get('action')

    # OnePlay Live integrado: preserva a trava transacional e o feedback
    # imediato da V4 antes de carregar o roteador completo.
    if action == 'oneplay_live_play':
        _prepare_oneplay_live_startup(params)

    # Playback Live já preparado: resolve localmente antes de carregar o
    # roteador completo. O Proxy Nativo continua responsável pelo transporte.
    if action == 'play_proxy_resolved':
        _resolve_tv_proxy_fast(params)
        return

    # Integração IBO: troca a janela Videos em vez de abrir o IBO como pasta
    # filha do Matrix. Isso remove o Matrix da camada visual subjacente.
    if action == 'open_ibo':
        _open_ibo_replacing_matrix()
        return

    # Home, Filmes e Séries são diretórios puramente locais. Eles não devem
    # carregar o roteador, DNS, proxy, TMDB, Pluto ou requests.
    if action == 'menu_movies':
        menu_movies_fast()
        return
    if action == 'menu_series':
        menu_series_fast()
        return

    # Retorno de player Pluto (VOD e Live): restaura a lista já montada sem carregar a
    # pilha completa de rotas/HTTP. O primeiro acesso sempre passa pelo router.
    if _render_pluto_snapshot(action, params):
        return

    if action is None:
        if _consume_ibo_return_hint():
            _home_return_fast()
            return
        start_page = _setting_text('paginainicial', '0')
        if start_page == '0':
            home()
            return
        if start_page == '2':
            menu_movies_fast()
            return
        if start_page == '3':
            menu_series_fast()
            return

    _dispatch_to_routes(paramstring)


def main():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    try:
        params = dict(parse_qsl(paramstring, keep_blank_values=True))
        action = params.get('action') or 'home'
    except Exception:
        action = 'home'
    _maintenance_debug('evento=inicio | acao={}'.format(action))
    try:
        result = _main_impl()
        _maintenance_debug('evento=fim | acao={}'.format(action))
        return result
    except Exception as exc:
        if action == 'oneplay_live_play':
            _release_oneplay_live_startup_on_entry_failure()
        _maintenance_exception('Falha não tratada na entrada local (ação={})'.format(action), exc)
        try:
            xbmcgui.Dialog().notification('OnePlay', 'Ocorreu um erro ao abrir esta área. Consulte o log de manutenção.', xbmcgui.NOTIFICATION_ERROR, 3500)
        except Exception:
            pass


if __name__ == '__main__':
    main()
