# -*- coding: utf-8 -*-
"""Catálogo/resolvedor isolado da Opção 1 do OnePlay Live.

O único ponto fixo desta integração é a página pública de catálogo. Os canais
são extraídos do bloco JSON publicado em ``const CHANNELS`` e cada reprodução
parte do ``href`` publicado naquele catálogo. Redirects, página de player, CDN
e manifesto HLS continuam dinâmicos e são validados pelo motor homologado.

Não executa JavaScript e nunca usa o CDN capturado em HAR como URL fixa.
"""
import json
import os
import re
import time
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcvfs

from .proxy import cloudflare_urlopen
from .source_contract import (
    BROWSER_UA, is_safe_public_url, media_headers, page_headers,
)
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CATALOG_URL = 'https://embedcanais.online/'
MAX_HTML_BYTES = 768 * 1024
MAX_CACHE_BYTES = 512 * 1024
CACHE_TTL = 5 * 60
_CACHE_FILE = os.path.join(PROFILE, 'oneplay_live_option1_catalog.json')
_MEMO = None
_MEMO_DEADLINE = 0.0

_CATEGORY_ORDER = (
    'Esportes', 'Filmes e Séries', 'Variedades', 'Canais Abertos',
    'Infantil', 'Notícias', 'Religiosos',
)
_CATEGORY_DESCS = {
    'Esportes': 'Canais e transmissões esportivas disponíveis na Opção 1.',
    'Filmes e Séries': 'Canais de filmes, séries e entretenimento da Opção 1.',
    'Variedades': 'Canais de variedades e entretenimento geral da Opção 1.',
    'Canais Abertos': 'Emissoras abertas disponíveis na Opção 1.',
    'Infantil': 'Programação infantil e familiar da Opção 1.',
    'Notícias': 'Canais de notícias e informação da Opção 1.',
    'Religiosos': 'Canais religiosos disponíveis na Opção 1.',
}

# Equivalencias editoriais comprovadas entre os IDs publicados pela Opção 1
# e os IDs usados pelo EPG homologado da Opção 2. IDs iguais não precisam
# aparecer aqui: são consultados diretamente. Não há casamento fuzzy; canais
# sem correspondência real permanecem sem EPG.
_EPG_ID_ALIASES = {
    'aee': 'ae',
    'amazonprimevideo': 'primevideo',
    'amazonprimevideo02': 'primevideo2',
    'amazonprimevideo03': 'primevideo3',
    'amazonprimevideo04': 'primevideo4',
    'canaloff': 'off',
    'cazetv': 'caze1',
    'cazetv2': 'caze2',
    'cazetv3': 'caze3',
    'discoverytheater': 'discoverytheather',
    'disneyplus': 'disneyplus1',
    'disneyplus02': 'disneyplus2',
    'disneyplus03': 'disneyplus3',
    'globoplaynovelas': 'globonovelas',
    'max': 'max1',
    'max02': 'max2',
    'max03': 'max3',
    'paieterno': 'tvpaieterno',
    'paramountplus02': 'paramountplus2',
    'premiereclubes': 'premiere',
    'sportynet1': 'sportynetplus1',
    'sportynet2': 'sportynetplus2',
    'sportynet3': 'sportynetplus3',
    'tcaction': 'telecineaction',
    'tccult': 'telecinecult',
    'tcfun': 'telecinefun',
    'tcpipoca': 'telecinepipoca',
    'tcpremium': 'telecinepremium',
    'tctouch': 'telecinetouch',
    'tnt1': 'tnt',
    'tvaparecida': 'aparecida',
    'tvcultura': 'cultura',
    'warner': 'warnerchannel',
}


def epg_id_for(channel_id):
    """Retorna somente ID exato ou alias auditado; nunca usa fuzzy."""
    cid = str(channel_id or '').strip().lower()
    return _EPG_ID_ALIASES.get(cid, cid)


def _log(message, warning=False):
    xbmc.log('[ONEPLAY LIVE] OPCAO1 %s' % message,
             xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _extract_json_array(text):
    """Extrai somente o array JSON atribuído a CHANNELS, sem executar JS."""
    if not isinstance(text, str) or not text:
        raise ValueError('HTML vazio')
    match = re.search(r'\b(?:const|let|var)\s+CHANNELS\s*=\s*', text, re.I)
    if not match:
        raise ValueError('bloco CHANNELS ausente')
    start = text.find('[', match.end())
    if start < 0:
        raise ValueError('array CHANNELS ausente')

    depth = 0
    quote = ''
    escaped = False
    for pos in range(start, min(len(text), start + MAX_HTML_BYTES)):
        char = text[pos]
        if quote:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = ''
            continue
        if char in ('"', "'"):
            quote = char
        elif char == '[':
            depth += 1
        elif char == ']':
            depth -= 1
            if depth == 0:
                raw = text[start:pos + 1]
                data = json.loads(raw)
                if not isinstance(data, list):
                    raise ValueError('CHANNELS não é lista')
                return data
    raise ValueError('array CHANNELS incompleto')


def _normalize(rows):
    out = []
    by_slug = {}
    for raw in rows if isinstance(rows, list) else []:
        if not isinstance(raw, dict):
            continue
        slug = str(raw.get('slug') or raw.get('id') or '').strip().lower()
        name = str(raw.get('name') or '').strip()
        category = str(raw.get('category') or 'Outros').strip() or 'Outros'
        raw_categories = raw.get('categories') if isinstance(raw.get('categories'), list) else [category]
        categories = []
        for value in raw_categories:
            value = str(value or '').strip()[:80]
            if value and value not in categories:
                categories.append(value)
        if not categories:
            categories = [category[:80]]
        category = categories[0]
        href = str(raw.get('href') or raw.get('api_url') or raw.get('source_page') or '').strip()
        image = str(raw.get('image') or '').strip()
        if not slug or not re.fullmatch(r'[a-z0-9_-]{1,96}', slug):
            continue
        if not name or not is_safe_public_url(href):
            continue
        if image and not is_safe_public_url(image):
            image = ''
        existing = by_slug.get(slug)
        if existing is not None:
            # O catálogo capturado publica TNT duas vezes em categorias distintas.
            # Mantemos um único canal reproduzível, mas preservamos ambas as pastas.
            for value in categories:
                if value not in existing['categories']:
                    existing['categories'].append(value)
            continue
        item = {
            'id': slug,
            'epg_id': epg_id_for(slug),
            'name': name[:160],
            'categories': list(categories),
            'category': category,
            'description': '',
            'image': image,
            'preview': '',
            'api_url': href,
            'source_page': href,
            'stream_url': '',
            'headers': {},
            '_oneplay_source': 'option1',
        }
        by_slug[slug] = item
        out.append(item)
    if len(out) < 20 or len(out) > 1000:
        raise ValueError('quantidade de canais fora do esperado: %d' % len(out))
    return out


def _fetch_live():
    headers = page_headers(page_url=CATALOG_URL, parent_url=CATALOG_URL)
    headers['User-Agent'] = BROWSER_UA
    headers['Sec-Fetch-Dest'] = 'document'
    headers['Sec-Fetch-Site'] = 'none'
    request = Request(CATALOG_URL, headers=headers, method='GET')
    with cloudflare_urlopen(request, timeout=10, allow_native_fallback=True) as response:
        data = response.read(MAX_HTML_BYTES + 1)
        if len(data) > MAX_HTML_BYTES:
            raise ValueError('HTML excedeu limite')
        text = data.decode('utf-8', 'ignore')
    channels = _normalize(_extract_json_array(text))
    return {'channels': channels, 'fetched_at': int(time.time())}


def _read_cache(fresh_only=False):
    try:
        if fresh_only and time.time() - os.path.getmtime(_CACHE_FILE) > CACHE_TTL:
            return None
        with open(_CACHE_FILE, 'rb') as fh:
            raw = fh.read(MAX_CACHE_BYTES + 1)
        if len(raw) > MAX_CACHE_BYTES:
            return None
        obj = json.loads(raw.decode('utf-8'))
        channels = obj.get('channels') if isinstance(obj, dict) else None
        if not isinstance(channels, list):
            return None
        # Revalida o cache com o mesmo contrato de segurança.
        normalized = _normalize(channels)
        return {'channels': normalized, 'fetched_at': int(obj.get('fetched_at') or 0)}
    except Exception:
        return None


def _write_cache(payload):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_CACHE_FILE, payload, MAX_CACHE_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _payload(force=False):
    global _MEMO, _MEMO_DEADLINE
    now = time.monotonic()
    if not force and _MEMO is not None and now < _MEMO_DEADLINE:
        return _MEMO
    if not force:
        fresh = _read_cache(True)
        if fresh is not None:
            _MEMO = fresh
            _MEMO_DEADLINE = now + CACHE_TTL
            return fresh
    try:
        live = _fetch_live()
        _write_cache(live)
        _MEMO = live
        _MEMO_DEADLINE = now + CACHE_TTL
        _log('catálogo atualizado canais=%d' % len(live.get('channels') or []))
        return live
    except Exception as exc:
        _log('catálogo online indisponível: %s' % exc, True)
    stale = _read_cache(False)
    if stale is not None:
        _MEMO = stale
        _MEMO_DEADLINE = now + min(CACHE_TTL, 60)
        _log('usando cache anterior canais=%d' % len(stale.get('channels') or []), True)
        return stale
    _MEMO = {'channels': []}
    _MEMO_DEADLINE = now + 20
    return _MEMO


def source_for(channel):
    """Converte o href publicado em fonte dinâmica para o resolvedor existente."""
    if not isinstance(channel, dict):
        return None
    url = str(channel.get('api_url') or channel.get('source_page') or '').strip()
    if not is_safe_public_url(url):
        return None
    page_h = page_headers(page_url=url, parent_url=CATALOG_URL)
    # O HAR real mostra o iframe sendo navegado com Referer da página de catálogo.
    page_h['Referer'] = CATALOG_URL
    resource_h = media_headers(page_url=url)
    return {
        'name': 'opcao1-page',
        'url': url,
        'playlist_headers': page_h,
        'resource_headers': resource_h,
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'source_kind': 'derived-page',
    }


class Catalog:
    def __init__(self):
        self._channels = list((_payload(False) or {}).get('channels') or [])

    def channels(self):
        return list(self._channels)

    def categories(self):
        present = set()
        for channel in self._channels:
            for name in channel.get('categories') or [channel.get('category') or 'Outros']:
                if name:
                    present.add(str(name))
        ordered = [name for name in _CATEGORY_ORDER if name in present]
        return ordered + sorted(present - set(ordered))

    def category_description(self, category):
        return _CATEGORY_DESCS.get(category, 'Canais disponíveis na Opção 1.')

    def by_category(self, category):
        return [c for c in self._channels if category in (c.get('categories') or [c.get('category')])]

    def get(self, channel_id):
        wanted = str(channel_id or '').strip().lower()
        for channel in self._channels:
            if str(channel.get('id') or '').strip().lower() == wanted:
                return channel
        return None

    def refresh_get(self, channel_id):
        global _MEMO, _MEMO_DEADLINE
        try:
            live = _fetch_live()
            _write_cache(live)
            _MEMO = live
            _MEMO_DEADLINE = time.monotonic() + CACHE_TTL
            _log('catálogo forçado atualizado canais=%d' % len(live.get('channels') or []))
            wanted = str(channel_id or '').strip().lower()
            for channel in live.get('channels') or []:
                if str(channel.get('id') or '').strip().lower() == wanted:
                    return channel
        except Exception as exc:
            _log('refresh live falhou id=%s: %s' % (channel_id, exc), True)
        return None
