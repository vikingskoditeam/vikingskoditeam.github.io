# -*- coding: utf-8 -*-
from urllib.error import HTTPError
from urllib.parse import urljoin, urlparse
from urllib.request import Request
import re
import html
import os
import json
import threading
import ipaddress
import socket
import time
import uuid
import xbmcvfs
import xbmc
import xbmcaddon
import xbmcgui
from .catalog import Catalog
from .artwork import artwork_for
from .presentation import public_text as _public_text
from .proxy import HlsProxy, cloudflare_urlopen
from .source_contract import api_source, media_headers, page_headers, is_safe_public_url

ALLOWED_SCHEMES = {'http', 'https'}
PROBE_TIMEOUT = 8
MEDIA_PROBE_TIMEOUT = 7
MAX_MANIFEST_BYTES = 256 * 1024
MEDIA_PROBE_BYTES = 4096
MAX_PLAYLIST_DEPTH = 3
STARTUP_TIMEOUT = 20
PLAYBACK_POLL = 0.25
END_GRACE = 1.5
# Android pode retirar isPlaying() antes de entregar onPlayBackStopped ao Python.
# Esta janela adicional evita classificar um STOP real como live_lost.
LIVE_LOST_CONFIRM_GRACE = 2.0
LIVE_RECOVERY_MAX = 2
LIVE_RECOVERY_BACKOFF = (2.0, 4.0)
URI_ATTR_RE = re.compile(r'URI=("|\')([^"\']+)(\1)')


def _log(message, level=xbmc.LOGINFO):
    xbmc.log('[ONEPLAY LIVE] %s' % message, level)


def _prepare_dialog_state():
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_early_wait',None)
        if isinstance(state,tuple):
            return state
        if state is not None:
            return (state,0.0)
    except Exception:
        pass
    return (None,0.0)


def _startup_lock_state():
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_startup_lock',None)
        if isinstance(state,tuple) and len(state)>=2:
            return state[0],state[1]
    except Exception:
        pass
    return None,None


def _play_session_register(channel_id):
    """Registra a invocação manual mais recente do OnePlay Live.

    O arquivo é compartilhado entre invocadores Python do Kodi. Assim, uma
    nova seleção de canal invalida recuperações antigas que ainda estejam em
    backoff/refresh/resolução, sem interferir em STOP ou startup normal.
    """
    try:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if profile and not os.path.isdir(profile):
            try:
                os.makedirs(profile, exist_ok=True)
            except Exception:
                pass
        path = os.path.join(profile, 'oneplay_live_session.json')
        _lock_path, startup_token = _startup_lock_state()
        token = str(startup_token or uuid.uuid4().hex)
        payload = {
            'token': token,
            'channel_id': str(channel_id or ''),
            'created': time.time(),
        }
        tmp = path + '.tmp-' + token[:12]
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'))
        os.replace(tmp, path)
        _log('sessao ativa registrada id=%s token=%s' % (channel_id, token[:8]), xbmc.LOGDEBUG)
        return (path, token, str(channel_id or ''))
    except Exception as exc:
        _log('registro de sessao ativa indisponivel: %s' % exc, xbmc.LOGWARNING)
        return None


def _play_session_is_current(session_state):
    if not session_state:
        return True
    try:
        path, token = session_state[0], session_state[1]
        if not path or not os.path.exists(path):
            return False
        with open(path, 'r', encoding='utf-8') as fh:
            current = json.load(fh)
        return str(current.get('token') or '') == str(token)
    except Exception:
        # Falha transitória de leitura não deve derrubar uma sessão válida.
        return True


def _play_session_cancelled(session_state, channel_id, stage=''):
    if _play_session_is_current(session_state):
        return False
    _log('sessao substituida por nova selecao id=%s etapa=%s; recovery antigo cancelado' % (
        channel_id, stage or 'verificacao'), xbmc.LOGWARNING)
    return True


def _play_session_clear(session_state):
    if not session_state:
        return
    try:
        path, token = session_state[0], session_state[1]
        if not path or not os.path.exists(path):
            return
        current = {}
        try:
            with open(path, 'r', encoding='utf-8') as fh:
                current = json.load(fh)
        except Exception:
            current = {}
        if str(current.get('token') or '') == str(token):
            os.remove(path)
            _log('sessao ativa liberada token=%s' % str(token)[:8], xbmc.LOGDEBUG)
    except Exception as exc:
        _log('falha ao liberar sessao ativa: %s' % exc, xbmc.LOGDEBUG)


def _startup_lock_update_name(channel_name):
    path,token=_startup_lock_state()
    if not path or not token:
        return
    try:
        current={}
        if os.path.exists(path):
            with open(path,'r',encoding='utf-8') as fh:
                current=json.load(fh)
        if str(current.get('token') or '') != str(token):
            return
        current['name']=_public_text(channel_name or current.get('name') or current.get('channel_id') or 'Canal') or 'Canal'
        current['updated']=time.time()
        tmp=path+'.tmp-'+str(token)[:12]
        with open(tmp,'w',encoding='utf-8') as fh:
            json.dump(current,fh,ensure_ascii=False,separators=(',',':'))
        os.replace(tmp,path)
    except Exception as exc:
        try: _log('lock startup não pôde atualizar nome: %s' % exc, xbmc.LOGDEBUG)
        except Exception: pass


def _startup_lock_release(reason=''):
    path,token=_startup_lock_state()
    if not path or not token:
        return
    removed=False
    try:
        current={}
        if os.path.exists(path):
            try:
                with open(path,'r',encoding='utf-8') as fh:
                    current=json.load(fh)
            except Exception:
                current={}
            if str(current.get('token') or '') == str(token):
                try:
                    os.remove(path); removed=True
                except FileNotFoundError:
                    removed=True
        else:
            removed=True
    except Exception as exc:
        try: _log('lock startup falha ao liberar: %s' % exc, xbmc.LOGWARNING)
        except Exception: pass
    try:
        import builtins
        state=getattr(builtins,'_oneplay_live_startup_lock',None)
        if isinstance(state,tuple) and len(state)>=2 and str(state[1])==str(token):
            delattr(builtins,'_oneplay_live_startup_lock')
    except Exception:
        pass
    if removed:
        try: _log('lock startup liberado motivo=%s' % (reason or 'concluido'), xbmc.LOGDEBUG)
        except Exception: pass


def _prepare_dialog_update(channel_name='', ready=False):
    dlg,_started=_prepare_dialog_state()
    if dlg is None:
        return
    name=_public_text(channel_name)
    if not name:
        return
    message=('Transmissão pronta: %s' if ready else 'Preparando transmissão: %s') % name
    try:
        dlg.update(0,'AGUARDE...',message)
        _log('AGUARDE atualizado: %s' % message, xbmc.LOGDEBUG)
    except Exception:
        pass


def _prepare_dialog_close(reason=''):
    dlg,_started=_prepare_dialog_state()
    if dlg is not None:
        try:
            dlg.close()
        except Exception:
            pass
    try:
        import builtins
        if hasattr(builtins,'_oneplay_live_early_wait'):
            delattr(builtins,'_oneplay_live_early_wait')
    except Exception:
        pass
    _startup_lock_release(reason)
    try:
        _log('AGUARDE encerrado motivo=%s' % (reason or 'concluido'), xbmc.LOGDEBUG)
    except Exception:
        pass


def _clean_headers(headers):
    if not isinstance(headers, dict):
        return {}
    return {str(k): str(v) for k, v in headers.items() if k and v is not None}


def _candidate_sources(ch):
    """Raiz de playback isolada por catálogo, sem misturar provedores."""
    if str(ch.get('_oneplay_source') or '') == 'option1':
        try:
            from .option1 import source_for
            source = source_for(ch)
            return [source] if source else []
        except Exception as exc:
            _log('OPCAO1 contrato inválido id=%s tipo=%s msg=%s' % (
                ch.get('id'), exc.__class__.__name__, exc), xbmc.LOGWARNING)
            return []
    if str(ch.get('_oneplay_source') or '') == 'option3':
        try:
            from .option3 import sources_for
            return list(sources_for(ch) or [])
        except Exception as exc:
            _log('OPCAO3 contrato inválido id=%s tipo=%s msg=%s' % (
                ch.get('id'), exc.__class__.__name__, exc), xbmc.LOGWARNING)
            return []
    # Opção 2: contrato homologado anterior, inalterado.
    api=api_source(ch.get('api_url'), ch.get('headers') or {})
    return [api] if api else []

def _is_ts(data):
    if not data:
        return False
    limit = min(188, len(data))
    for offset in range(limit):
        if data[offset] != 0x47:
            continue
        if offset + 188 < len(data) and data[offset + 188] == 0x47:
            return True
    return False


def _is_media_bytes(data, content_type=''):
    if not data:
        return False
    ct = (content_type or '').split(';', 1)[0].strip().lower()
    # Assinatura real prevalece sobre Content-Type: alguns upstreams respondem
    # com MIME de vídeo mesmo quando entregam placeholder PNG/JPEG/GIF.
    image_signatures = (b'\x89PNG\r\n\x1a\n', b'\xff\xd8\xff', b'GIF87a', b'GIF89a')
    # Rejeita imagem tanto no inicio quanto encapsulada nos primeiros bytes.
    # Alguns falsos HLS usam segmento .ts/MIME video mas carregam PNG como
    # stream elementar; o log real da 0.0.10 mostrou exatamente esse caso.
    if any(data.startswith(sig) or sig in data[:MEDIA_PROBE_BYTES] for sig in image_signatures):
        return False
    sample = data[:256].lstrip().lower()
    if sample.startswith((b'<!doctype html', b'<html', b'<?xml', b'{"', b'[{')):
        return False
    if _is_ts(data):
        return True
    if len(data) >= 8 and (data[4:8] == b'ftyp' or b'moof' in data[:96] or b'styp' in data[:32]):
        return True
    if data[:3] == b'ID3':
        return True
    if len(data) >= 2 and data[0] == 0xFF and (data[1] & 0xF0) == 0xF0:
        return True
    if ct.startswith('image/') or ct in ('video/png',):
        return False
    if ct.startswith('video/') or ct.startswith('audio/'):
        return True
    return False


def _first_uri(text):
    for raw in text.splitlines():
        line = raw.strip()
        if not line or line.startswith('#'):
            continue
        return line
    return ''


def _fetch_probe(url, headers, limit, timeout, allow_native_dns_fallback=True):
    request_headers = dict(headers or {})
    if limit and not any(str(k).lower() == 'range' for k in request_headers):
        request_headers['Range'] = 'bytes=0-%d' % (limit - 1)
    request = Request(url, headers=request_headers, method='GET')
    response = cloudflare_urlopen(request, timeout=timeout, allow_native_fallback=allow_native_dns_fallback)
    data = response.read(limit + 1 if limit else -1)
    return response, data


def _validate_hls_media(playlist_url, text, resource_headers, depth=0):
    """Valida a primeira mídia e identifica live sem iniciar o player."""
    if depth >= MAX_PLAYLIST_DEPTH:
        return False, None
    target = _first_uri(text)
    if not target:
        return False, None
    target_url = urljoin(playlist_url, target)
    try:
        response, data = _fetch_probe(target_url, resource_headers, MEDIA_PROBE_BYTES, MEDIA_PROBE_TIMEOUT, allow_native_dns_fallback=True)
        final_url = getattr(response, 'url', target_url) or target_url
        ctype = response.headers.get('Content-Type', '') if getattr(response, 'headers', None) else ''
        sample = data[:MEDIA_PROBE_BYTES]
        sample_text = sample.decode('utf-8', 'ignore')
        if '#EXTM3U' in sample_text:
            nested_live = '#EXT-X-ENDLIST' not in sample_text
            ok, leaf_live = _validate_hls_media(final_url, sample_text, resource_headers, depth + 1)
            if ok:
                return True, bool(nested_live if leaf_live is None else leaf_live)
            return False, None
        ok = _is_media_bytes(sample, ctype)
        if not ok:
            sig = sample[:12].hex()
            _log('preflight rejeitou mídia host=%s tipo=%s assinatura=%s' % (
                urlparse(final_url).netloc, (ctype or '?').split(';', 1)[0], sig), xbmc.LOGWARNING)
            return False, None
        return True, None
    except HTTPError as exc:
        _log('preflight HTTP status=%s host=%s' % (
            getattr(exc, 'code', '?'), urlparse(target_url).netloc), xbmc.LOGWARNING)
        return False, None
    except Exception as exc:
        _log('preflight erro host=%s tipo=%s msg=%s' % (
            urlparse(target_url).netloc, exc.__class__.__name__, exc), xbmc.LOGWARNING)
        return False, None


def _normalized_html(text):
    if not text:
        return ''
    cleaned = html.unescape(text)
    return (cleaned.replace('\\/', '/')
                   .replace('\\u002F', '/').replace('\\u002f', '/')
                   .replace('\\u003A', ':').replace('\\u003a', ':')
                   .replace('\\x2F', '/').replace('\\x2f', '/')
                   .replace('\\x3A', ':').replace('\\x3a', ':'))


_NON_HLS_EXTENSIONS = (
    '.mp4', '.m4v', '.webm', '.mp3', '.aac', '.jpg', '.jpeg', '.png', '.gif',
    '.webp', '.svg', '.ico', '.css', '.js', '.xml', '.woff', '.woff2', '.ttf',
    '.otf', '.json', '.html', '.htm', '.php',
)


def _normalize_candidate_url(base_url, value):
    target = html.unescape(str(value or '').strip()).replace('\\/', '/')
    if not target:
        return ''
    # Uma URL HTTP nunca pode conter espaço ou caractere de controle literal.
    # O player remoto usa várias propriedades JavaScript (``url: '/+ i ...'``)
    # que parecem fortes semanticamente, mas são apenas trechos de código.
    # Rejeitar isso antes do urlopen elimina probes impossíveis sem reduzir o
    # contrato dinâmico: URLs reais com espaço chegam percent-encoded.
    if re.search(r'[\x00-\x20\x7f]', target):
        return ''
    if target.startswith('//'):
        target = 'https:' + target
    else:
        target = urljoin(base_url, target)
    target = target.rstrip(');,]')
    if re.search(r'[\x00-\x20\x7f]', target):
        return ''
    try:
        parsed = urlparse(target)
    except Exception:
        return ''
    if (parsed.scheme or '').lower() not in ALLOWED_SCHEMES or not parsed.hostname:
        return ''
    host = (parsed.hostname or '').lower()
    # Nunca permita que HTML remoto transforme o Kodi em cliente de endereços
    # locais. Nomes públicos continuam livres para rotação de CDN.
    if host == 'localhost' or host.endswith('.local'):
        return ''
    try:
        if not ipaddress.ip_address(host).is_global:
            return ''
    except ValueError:
        pass
    return target


def _candidate_is_plausible(target, strong=False):
    try:
        parsed = urlparse(target)
    except Exception:
        return False
    host = (parsed.hostname or '').lower()
    path = (parsed.path or '').lower()
    if any(path.endswith(ext) for ext in _NON_HLS_EXTENSIONS):
        return False
    # Contratos conhecidos: HLS convencional e manifests textuais disfarçados.
    if path.endswith(('.m3u8', '.m3u', '.txt')):
        return True
    if 'm3u8' in (parsed.query or '').lower():
        return True
    # Uma URL explicitamente atribuída a source/src/stream pode mudar de
    # extensão ou ficar extensionless. Ela ainda será aceita somente depois de
    # o probe confirmar #EXTM3U e validar a primeira mídia.
    if strong:
        return True
    # URLs genéricas sem pista forte precisam ao menos parecer um caminho de
    # manifesto. O domínio continua totalmente dinâmico e a aceitação final
    # depende do probe real (#EXTM3U + primeira mídia válida).
    return any(token in path for token in ('/manifest', '/playlist', '/live/', '/hls/'))


def _extract_inline_hls_candidates(base_url, text):
    """Descobre manifestos publicados pela página sem executar JavaScript.

    O resolvedor usa contexto semântico (src/source/stream/file) antes de uma
    varredura genérica e valida cada candidato pela assinatura ``#EXTM3U``.
    Assim acompanha rotação de CDN, ``.txt``/extensionless e subdomínios do
    player sem amarrar o add-on a um caminho específico.
    """
    cleaned = _normalized_html(text)
    ranked = []
    order = 0

    def add(value, rank, strong=False):
        nonlocal order
        target = _normalize_candidate_url(base_url, value)
        if not target or not _candidate_is_plausible(target, strong=strong):
            return
        ranked.append((rank, order, target))
        order += 1

    # 1) Atribuições diretas usadas por players/variáveis de stream. Esta regra
    # prioriza a URL explicitamente atribuída pelo player antes de URLs
    # genéricas presentes no mesmo JavaScript.
    variable_re = re.compile(
        r'\b(?:var|let|const)\s+(?:src|source|file|stream|streamurl|stream_url|playlist|playlisturl|playlist_url|hls|hlsurl|hls_url|manifest|manifesturl|manifest_url|playback|playbackurl|playback_url|url)\s*=\s*(["\'])([^"\']+)\1',
        re.I)
    for m in variable_re.finditer(cleaned):
        add(m.group(2), 0, strong=True)

    property_re = re.compile(
        r'\b(?:source|src|file|stream|streamurl|stream_url|playlist|playlisturl|playlist_url|hls|hlsurl|hls_url|manifest|manifesturl|manifest_url|playback|playbackurl|playback_url|url)\s*:\s*(["\'])([^"\']+)\1',
        re.I)
    for m in property_re.finditer(cleaned):
        add(m.group(2), 1, strong=True)

    tag_re = re.compile(
        r'<(?:source|video)[^>]+(?:src|data-src)\s*=\s*(["\'])([^"\']+)\1',
        re.I)
    for m in tag_re.finditer(cleaned):
        add(m.group(2), 1, strong=True)

    call_re = re.compile(
        r'\b(?:startPlayer|loadSource|setSource|setSrc|setUrl|loadStream|playStream)\s*\(\s*(["\'])([^"\']+)\1',
        re.I)
    for m in call_re.finditer(cleaned):
        add(m.group(2), 2, strong=True)

    # 2) Contratos conhecidos encontrados fora de uma atribuição explícita.
    for m in re.finditer(r'https?://[^\s"\'<>]+', cleaned, re.I):
        target = m.group(0)
        try:
            parsed = urlparse(target)
            host = (parsed.hostname or '').lower()
            path = (parsed.path or '').lower()
        except Exception:
            continue
        if path.endswith('.txt'):
            rank = 3
        elif path.endswith(('.m3u8', '.m3u')):
            rank = 4
        elif any(token in path for token in ('/manifest', '/playlist', '/live/', '/hls/')):
            rank = 5
        else:
            continue
        add(target, rank, strong=False)

    # URLs protocol-relative e relativas explícitas continuam suportadas.
    for m in re.finditer(r'(?<!:)//[^\s"\'<>]+', cleaned, re.I):
        add('https:' + m.group(0), 8, strong=False)
    for m in re.finditer(r'(["\'])(/[^"\']+)(\1)', cleaned, re.I):
        add(m.group(2), 9, strong=False)

    unique = []
    seen = set()
    for rank, idx, target in sorted(ranked, key=lambda x: (x[0], x[1])):
        if target in seen:
            continue
        seen.add(target)
        unique.append(target)
        if len(unique) >= 12:
            break
    return unique


def _extract_inline_hls(base_url, text):
    # Compatibilidade com testes/chamadores anteriores: devolve o melhor.
    items=_extract_inline_hls_candidates(base_url,text)
    return items[0] if items else ''


def _extract_nested_pages(base_url, text):
    """Descobre iframes públicos explicitamente publicados pela página confiável."""
    cleaned=_normalized_html(text)
    out=[]; seen=set()
    for m in re.finditer(r'<iframe[^>]+src\s*=\s*(["\'])([^"\']+)(\1)', cleaned, re.I):
        target=urljoin(base_url,m.group(2).strip())
        if target in seen or not is_safe_public_url(target):
            continue
        if target==base_url:
            continue
        seen.add(target); out.append(target)
        if len(out)>=4: break
    return out


def _dynamic_probe_state(source):
    state = source.get('_dynamic_probe_state') if isinstance(source, dict) else None
    return state if isinstance(state, dict) else None


def _dynamic_root_id(source):
    return str((source or {}).get('_dynamic_root_id') or (source or {}).get('name') or '')


def _dynamic_endpoint_key(url):
    """Identidade estável só para consenso da tentativa atual.

    Query/token não participa da chave: antes de encurtar o contrato exigimos
    duas leituras independentes, permitindo que um token fresco se recupere.
    Nada desta informação é persistido entre canais/sessões.
    """
    try:
        parsed = urlparse(str(url or ''))
        scheme = (parsed.scheme or '').lower()
        host = (parsed.hostname or '').lower()
        if scheme not in ALLOWED_SCHEMES or not host:
            return ''
        port = parsed.port
        authority = host if port is None else '%s:%d' % (host, port)
        path = parsed.path or '/'
        return '%s://%s%s' % (scheme, authority, path)
    except Exception:
        return ''


def _dynamic_record_media_outcome(source, url, outcome):
    state = _dynamic_probe_state(source)
    if state is None:
        return
    root = _dynamic_root_id(source)
    key = _dynamic_endpoint_key(url)
    if not root or not key:
        return
    outcomes = state.setdefault('media_outcomes', {})
    outcomes[(root, key)] = str(outcome or '')


def _dynamic_page_short_circuit(source, page_url):
    state = _dynamic_probe_state(source)
    if state is None:
        return False
    key = _dynamic_endpoint_key(page_url)
    row = (state.get('terminal_pages') or {}).get(key)
    if not row:
        return False
    _log('resolver consenso dinâmico host=%s confirmacoes=%s motivo=%s; evitando leitura repetida' % (
        urlparse(page_url).netloc, row.get('confirmations', '?'), row.get('reason', 'indisponivel')),
        xbmc.LOGWARNING)
    return True


def _dynamic_update_page_consensus(source, page_url, targets):
    """Encurta apenas repetição comprovada dentro do MESMO clique/recovery.

    O primeiro espelho sempre é testado por completo. O segundo também, mesmo
    que publique o mesmo host/caminho com token novo. Só após duas origens
    independentes produzirem a mesma assinatura de endpoints e apenas 404 ou
    timeout (com pelo menos um 404) a página intermediária passa a ser tratada
    como repetição sem diversidade. 403/5xx/preflight/outros nunca ativam o
    atalho, porque podem depender de referer, token ou instabilidade transitória.
    """
    state = _dynamic_probe_state(source)
    if state is None:
        return
    try:
        threshold = max(2, min(4, int(source.get('dynamic_failure_consensus') or 2)))
    except Exception:
        threshold = 2
    root = _dynamic_root_id(source)
    page_key = _dynamic_endpoint_key(page_url)
    if not root or not page_key:
        return
    outcomes = state.get('media_outcomes') or {}
    signature = []
    for target in targets or []:
        media_key = _dynamic_endpoint_key(target)
        if not media_key:
            continue
        outcome = outcomes.get((root, media_key))
        if outcome:
            signature.append((media_key, outcome))
    if not signature:
        return
    signature = tuple(sorted(signature))
    statuses = [row[1] for row in signature]
    # Só o perfil observado nos logs de origem realmente offline: endpoint(s)
    # de mídia em 404 e, opcionalmente, um endpoint lento em timeout.
    if not all(status in ('http404', 'timeout') for status in statuses):
        return
    if 'http404' not in statuses:
        return
    observations = state.setdefault('page_observations', {}).setdefault(page_key, {})
    observations[root] = signature
    equivalent = [rid for rid, sig in observations.items() if sig == signature]
    if len(equivalent) < threshold:
        return
    reason = '404-confirmado' if all(status == 'http404' for status in statuses) else 'indisponibilidade-repetida'
    state.setdefault('terminal_pages', {})[page_key] = {
        'confirmations': len(equivalent),
        'reason': reason,
    }
    _log('resolver consenso dinâmico confirmado host=%s origens=%d motivo=%s' % (
        urlparse(page_url).netloc, len(equivalent), reason), xbmc.LOGWARNING)


def _probe_inline_hls(source, base_url, text, resolve_depth=0, visited=None):
    if not source.get('allow_html_resolve'):
        return None
    visited=set(visited or ())
    visited.add(base_url)
    targets=_extract_inline_hls_candidates(base_url,text)
    if targets:
        _log('resolver HTML host=%s candidatos_midia=%d' % (urlparse(base_url).netloc,len(targets)))
    for idx,target in enumerate(targets,1):
        nested=dict(source)
        nested['name']=str(source.get('name') or 'embedtv')+'-resolved-%d'%idx
        nested['url']=target
        nested['allow_html_resolve']=False
        nested['allow_native_dns_fallback']=True
        # Playlist e segmentos herdam dinamicamente o contexto exato da
        # página que publicou a mídia, independentemente do domínio/CDN.
        h=media_headers(source.get('resource_headers') or {}, page_url=base_url)
        nested['playlist_headers']=dict(h)
        nested['resource_headers']=dict(h)
        _log('resolver tentando mídia %d/%d host=%s' % (idx,len(targets),urlparse(target).netloc))
        selected=_probe_hls(nested,resolve_depth=resolve_depth,visited=visited)
        if selected:
            _log('resolver mídia válida host=%s -> %s' % (urlparse(base_url).netloc,urlparse(target).netloc))
            return selected
        _log('resolver descartou candidato host=%s' % urlparse(target).netloc,xbmc.LOGWARNING)

    _dynamic_update_page_consensus(source, base_url, targets)

    # A página de entrada pode publicar outro iframe. O padrão homologado
    # continua em um nível; adaptadores isolados podem pedir no máximo dois,
    # sempre por URL pública explícita e com validação HLS antes de reproduzir.
    try:
        max_depth = max(0, min(2, int(source.get('max_html_depth', 1))))
    except Exception:
        max_depth = 1
    if resolve_depth < max_depth:
        pages=_extract_nested_pages(base_url,text)
        for page in pages:
            if page in visited: continue
            if _dynamic_page_short_circuit(source, page):
                continue
            nested=dict(source)
            nested['name']=str(source.get('name') or 'embedtv')+'-iframe'
            nested['url']=page
            nested['allow_html_resolve']=True
            nested['allow_native_dns_fallback']=True
            nested['source_kind']='derived-page'
            nested['playlist_headers']=page_headers(source.get('playlist_headers') or {}, page_url=page, parent_url=base_url)
            # Alguns contratos publicam /canal -> /__play -> player. O
            # Referer de cada navegação é necessário, mas só é ativado quando
            # o adaptador da fonte o declara; Opções 1 e 2 ficam inalteradas.
            if source.get('preserve_navigation_referer'):
                nested['playlist_headers']['Referer'] = base_url
            nested['resource_headers']=media_headers(source.get('resource_headers') or {}, page_url=page)
            _log('resolver seguindo iframe publicado host=%s -> %s' % (urlparse(base_url).netloc,urlparse(page).netloc))
            selected=_probe_hls(nested,resolve_depth=resolve_depth+1,visited=visited)
            if selected: return selected

    _log('resolver sem HLS válido host=%s' % urlparse(base_url).netloc,xbmc.LOGWARNING)
    return None


def _read_probe_payload(response, source):
    """Leitura limitada; HTML opcionalmente acompanha streaming progressivo.

    Alguns players publicam o manifesto em script inline, mas demoram para
    encerrar o documento. Para a Opção 3 guardamos chunks já recebidos e,
    somente em timeout de leitura, aceitamos HTML parcial. Isso não aprova
    mídia por si só: qualquer URL extraída ainda passa pelo preflight HLS e
    pelo primeiro segmento antes de chegar ao player.
    """
    progressive = bool(source.get('allow_html_resolve') and
                       source.get('progressive_html_read'))
    if not progressive:
        return response.read(MAX_MANIFEST_BYTES + 1), False

    chunks = []
    total = 0
    timed_out = False
    chunk_size = 32 * 1024
    try:
        while total <= MAX_MANIFEST_BYTES:
            remaining = (MAX_MANIFEST_BYTES + 1) - total
            if remaining <= 0:
                break
            block = response.read(min(chunk_size, remaining))
            if not block:
                break
            chunks.append(block)
            total += len(block)
    except (TimeoutError, socket.timeout):
        if not chunks or not source.get('allow_partial_html_on_timeout'):
            raise
        timed_out = True
    return b''.join(chunks), timed_out


def _probe_hls(source, resolve_depth=0, visited=None):
    url=source['url']
    headers=_clean_headers(source.get('playlist_headers') or {})
    if source.get('source_kind') in ('api-url', 'derived-page'):
        _log('probe página fonte=%s modo=%s/%s host=%s' % (
            source.get('name'), headers.get('Sec-Fetch-Dest', '?'),
            headers.get('Sec-Fetch-Mode', '?'), urlparse(url).netloc), xbmc.LOGDEBUG)
    request=Request(url,headers=headers,method='GET')
    # O timeout padrão homologado continua intacto. Adaptadores isolados podem
    # ampliar somente a leitura de DOCUMENTOS HTML que sabidamente concluem
    # mais devagar; mídia já resolvida nunca herda essa ampliação.
    probe_timeout = PROBE_TIMEOUT
    if source.get('allow_html_resolve'):
        try:
            probe_timeout = max(
                PROBE_TIMEOUT,
                min(18, float(source.get('html_probe_timeout') or PROBE_TIMEOUT))
            )
        except Exception:
            probe_timeout = PROBE_TIMEOUT
    try:
        with cloudflare_urlopen(request,timeout=probe_timeout,
                allow_native_fallback=bool(source.get('allow_native_dns_fallback'))) as response:
            data, partial_timeout = _read_probe_payload(response, source)
            if partial_timeout:
                _log('probe HTML parcial após timeout fonte=%s host=%s bytes=%d; validando conteúdo recebido' % (
                    source.get('name'), urlparse(url).netloc, len(data)), xbmc.LOGDEBUG)
            if len(data)>MAX_MANIFEST_BYTES:
                _log('probe manifest excedeu limite fonte=%s host=%s' % (
                    source.get('name'),urlparse(url).netloc),xbmc.LOGWARNING)
                return None
            text=data.decode('utf-8','ignore')
            final_url=getattr(response,'url',url) or url
            ok='#EXTM3U' in text
            _log('probe fonte=%s status=%s host=%s final_host=%s hls=%s' % (
                source.get('name'),getattr(response,'status',200),
                urlparse(url).netloc,urlparse(final_url).netloc,ok))
            if not ok:
                selected = _probe_inline_hls(source,final_url,text,resolve_depth=resolve_depth,visited=visited)
                if selected:
                    return selected
                if not source.get('allow_html_resolve'):
                    _dynamic_record_media_outcome(source, final_url, 'not_hls')
                return None

            media_ok,nested_live=_validate_hls_media(
                final_url,text,_clean_headers(source.get('resource_headers') or {}),0)
            if not media_ok:
                _dynamic_record_media_outcome(source, final_url, 'preflight')
                _log('fonte rejeitada no preflight fonte=%s host=%s' % (
                    source.get('name'),urlparse(final_url).netloc),xbmc.LOGWARNING)
                return None
            selected=dict(source)
            selected['resolved_url']=final_url
            selected['seed_playlist']=data
            root_live='#EXT-X-ENDLIST' not in text
            selected['is_live']=root_live if nested_live is None else bool(nested_live)
            _dynamic_record_media_outcome(source, final_url, 'valid')
            _log('preflight mídia válida fonte=%s live=%s' % (
                source.get('name'),'sim' if selected['is_live'] else 'nao'))
            return selected
    except HTTPError as exc:
        final_url=getattr(exc,'url',url) or url
        code=getattr(exc,'code','?')
        _dynamic_record_media_outcome(source, final_url, 'http%s' % code)
        _log('probe HTTP fonte=%s status=%s host=%s final_host=%s' % (
            source.get('name'),code,urlparse(url).netloc,
            urlparse(final_url).netloc),xbmc.LOGWARNING)
        return None
    except Exception as exc:
        outcome = 'timeout' if isinstance(exc, (TimeoutError, socket.timeout)) or exc.__class__.__name__.lower() == 'timeout' else 'error'
        _dynamic_record_media_outcome(source, url, outcome)
        _log('probe erro fonte=%s host=%s tipo=%s msg=%s' % (
            source.get('name'),urlparse(url).netloc,exc.__class__.__name__,exc),xbmc.LOGWARNING)
        return None

def _validated_sources(ch):
    """Gera fontes aprovadas no probe, uma por vez, preservando a ordem.

    A validação é lazy de propósito: se a primeira fonte inicia A/V, a segunda
    nem é consultada. Se a primeira morrer antes de OnAVStarted, o chamador pode
    avançar para a próxima sem confundir isso com reconnect após Stop.
    """
    candidates = _candidate_sources(ch)
    _log('contrato id=%s candidatos=%d' % (ch.get('id'), len(candidates)))
    dynamic_state = {} if any(source.get('dynamic_failure_consensus') for source in candidates if isinstance(source, dict)) else None
    for index, source in enumerate(candidates, 1):
        if dynamic_state is not None and source.get('dynamic_failure_consensus'):
            source = dict(source)
            source['_dynamic_probe_state'] = dynamic_state
            source['_dynamic_root_id'] = str(source.get('name') or 'fonte-%d' % index)
        url = source.get('url') or ''
        parsed = urlparse(url)
        if parsed.scheme.lower() not in ALLOWED_SCHEMES:
            _log('fonte ignorada esquema invalido id=%s fonte=%s' % (
                ch.get('id'), source.get('name')), xbmc.LOGWARNING)
            continue
        _log('testando id=%s fonte=%d/%d nome=%s host=%s referer=%s' % (
            ch.get('id'), index, len(candidates), source.get('name'), parsed.netloc,
            'sim' if any(k.lower() == 'referer' for k in (source.get('playlist_headers') or {})) else 'nao'))
        selected = _probe_hls(source)
        if selected:
            selected['_candidate_index'] = index
            selected['_candidate_total'] = len(candidates)
            yield selected


def _notify_source_unavailable(channel_name=None):
    msg = 'Fonte indisponível no momento. Tente novamente mais tarde.'
    display_name=_public_text(channel_name)
    if display_name:
        msg = '%s: fonte indisponível no momento.' % display_name
    try:
        xbmcgui.Dialog().notification('OnePlay Live', msg, xbmcgui.NOTIFICATION_ERROR, 5000)
    except Exception:
        pass


class _PlaybackSession(xbmc.Player):
    """Vigia uma sessão; live não pausa e STOP do usuário nunca reconecta."""
    def __init__(self, live=False):
        xbmc.Player.__init__(self)
        self.live = bool(live)
        self.started = threading.Event()
        self.stopped = threading.Event()
        self.ended = threading.Event()
        self.failed = threading.Event()
        self.paused = threading.Event()
        self._resume_guard = threading.Lock()

    def onAVStarted(self):
        self.started.set()
        _prepare_dialog_close('av_started')
        _log('OnAVStarted')

    def onPlayBackStarted(self):
        _log('OnPlayBackStarted')

    def onPlayBackPaused(self):
        if self.live:
            _log('OnPlayBackPaused em live; retomada imediata sem timeshift', xbmc.LOGWARNING)
            if self._resume_guard.acquire(False):
                try:
                    # pause() é toggle no xbmc.Player; aqui desfaz imediatamente
                    # uma pausa aplicada ao live, sem criar buffer/timeshift.
                    self.pause()
                except Exception as exc:
                    _log('falha ao retomar live apos pause: %s' % exc, xbmc.LOGWARNING)
                finally:
                    self._resume_guard.release()
            return
        self.paused.set()
        _log('OnPlayBackPaused; proxy preservado')

    def onPlayBackResumed(self):
        self.paused.clear()
        _log('OnPlayBackResumed')

    def onPlayBackStopped(self):
        self.stopped.set()
        _log('OnPlayBackStopped; sem reconnect')

    def onPlayBackEnded(self):
        self.ended.set()
        _log('OnPlayBackEnded; fim involuntario elegivel a recuperacao se live')

    def onPlayBackError(self):
        self.failed.set()
        _log('OnPlayBackError; elegivel a recuperacao se live', xbmc.LOGWARNING)


def _enable_ffmpegdirect(li, is_live=False):
    try:
        xbmcaddon.Addon('inputstream.ffmpegdirect')
        li.setProperty('inputstream', 'inputstream.ffmpegdirect')
        li.setProperty('inputstream.ffmpegdirect.manifest_type', 'hls')
        li.setProperty('inputstream.ffmpegdirect.open_mode', 'ffmpeg')
        if is_live:
            li.setProperty('inputstream.ffmpegdirect.is_realtime_stream', 'true')
            # Não definir stream_mode=timeshift: live permanece linear, sem
            # buffer local de rewind/pause e sem consumo extra de armazenamento.
        _log('inputstream.ffmpegdirect HLS live=%s timeshift=nao' % ('sim' if is_live else 'nao'))
    except Exception:
        _log('inputstream.ffmpegdirect indisponivel; usando player nativo', xbmc.LOGWARNING)


def _confirm_live_loss(player, monitor):
    """Confirma perda real do live antes de habilitar recovery.

    Em Android/Kodi o estado isPlaying() pode cair antes de o callback
    onPlayBackStopped() chegar ao objeto Python. Durante esta janela STOP
    tem prioridade absoluta; Ended/Error continuam recuperáveis.
    """
    deadline = time.time() + LIVE_LOST_CONFIRM_GRACE
    _log('live deixou de tocar sem callback; aguardando confirmacao por %.1fs' %
         LIVE_LOST_CONFIRM_GRACE, xbmc.LOGDEBUG)
    while time.time() < deadline and not monitor.abortRequested():
        if player.stopped.is_set():
            _log('STOP confirmado durante janela de live_lost; recovery cancelado')
            return 'stopped'
        if player.failed.is_set():
            return 'live_error'
        if player.ended.is_set():
            return 'live_ended'
        try:
            if player.isPlaying():
                _log('live voltou a tocar durante janela de confirmacao; mantendo sessao', xbmc.LOGDEBUG)
                return 'resumed'
        except Exception:
            pass
        remaining = max(0.0, deadline - time.time())
        monitor.waitForAbort(min(PLAYBACK_POLL, remaining))
    if monitor.abortRequested():
        return 'abort'
    if player.stopped.is_set():
        return 'stopped'
    if player.failed.is_set():
        return 'live_error'
    if player.ended.is_set():
        return 'live_ended'
    return 'live_lost'


def _observer_stopped(player):
    try:
        return bool(player is not None and player.stopped.is_set())
    except Exception:
        return False


def _wait_recovery_backoff(monitor, delay, stop_observer=None):
    """Espera o backoff, mas um STOP tardio cancela recovery imediatamente."""
    deadline = time.time() + max(0.0, float(delay or 0.0))
    while time.time() < deadline:
        if _observer_stopped(stop_observer):
            _log('STOP tardio confirmado durante backoff; recovery cancelado')
            return 'stopped'
        remaining = max(0.0, deadline - time.time())
        if monitor.waitForAbort(min(0.10, remaining)):
            return 'abort'
    if _observer_stopped(stop_observer):
        _log('STOP tardio confirmado ao fim do backoff; recovery cancelado')
        return 'stopped'
    return 'continue'


def _play_direct(local_url, li, channel_name, is_live=False):
    """Executa uma tentativa e preserva a causa real do encerramento.

    completed: reprodução não-live terminou normalmente.
    live_ended: live entrou em A/V e Kodi encerrou por EOF/fim da mídia.
    live_error: live entrou em A/V e Kodi reportou erro de playback.
    live_lost: live entrou em A/V, deixou de tocar sem callback terminal.
    startup_failed: terminou/errou/timeout antes de A/V; pode testar backup.
    stopped: usuário emitiu Stop; é sempre terminal e nunca reconecta.
    abort: Kodi está encerrando.
    """
    monitor = xbmc.Monitor()
    player = _PlaybackSession(live=is_live)
    _log('iniciando xbmc.Player.play direto; rota nao usa setResolvedUrl')
    player.play(item=local_url, listitem=li)

    deadline = time.time() + STARTUP_TIMEOUT
    while time.time() < deadline and not monitor.abortRequested():
        if player.started.is_set():
            break
        try:
            if player.isPlayingVideo():
                player.started.set()
                break
        except Exception:
            pass
        if player.stopped.is_set():
            _prepare_dialog_close('stop_pre_av')
            _log('Stop recebido antes de A/V; sem fallback/reconnect')
            return 'stopped', player
        if player.failed.is_set() or player.ended.is_set():
            break
        monitor.waitForAbort(PLAYBACK_POLL)

    if monitor.abortRequested():
        _prepare_dialog_close('abort')
        return 'abort', player

    if player.started.is_set():
        _prepare_dialog_close('av_started_checkpoint')

    if not player.started.is_set():
        reason = 'ended' if player.ended.is_set() else ('error' if player.failed.is_set() else 'timeout')
        _log('player nao entrou em A/V motivo=%s; fonte elegivel a fallback de startup' % reason, xbmc.LOGWARNING)
        try:
            if player.isPlaying():
                player.stop()
        except Exception:
            pass
        return 'startup_failed', player

    _log('reproducao iniciada; live=%s proxy mantido' % ('sim' if is_live else 'nao'))
    not_playing_since = 0.0
    terminal = 'completed'
    while not monitor.abortRequested():
        if player.stopped.is_set():
            terminal = 'stopped'
            break
        if player.failed.is_set():
            terminal = 'live_error' if is_live else 'completed'
            break
        if player.ended.is_set():
            terminal = 'live_ended' if is_live else 'completed'
            break
        try:
            active = bool(player.isPlaying())
        except Exception:
            active = False
        if (not is_live) and player.paused.is_set():
            not_playing_since = 0.0
        elif active:
            not_playing_since = 0.0
        else:
            if not not_playing_since:
                not_playing_since = time.time()
            elif time.time() - not_playing_since >= END_GRACE:
                if is_live:
                    confirmed = _confirm_live_loss(player, monitor)
                    if confirmed == 'resumed':
                        not_playing_since = 0.0
                        continue
                    terminal = confirmed
                else:
                    terminal = 'completed'
                break
        monitor.waitForAbort(PLAYBACK_POLL)

    if monitor.abortRequested():
        _log('sessao encerrada por abort; liberando proxy da tentativa')
        return 'abort', player
    if terminal == 'stopped':
        _log('sessao encerrada por Stop do usuario; liberando proxy sem reconnect')
        return terminal, player
    if terminal in ('live_ended', 'live_error', 'live_lost'):
        _log('sessao live encerrou involuntariamente motivo=%s; liberando proxy para recuperacao controlada' % terminal, xbmc.LOGWARNING)
        return terminal, player
    _log('sessao encerrada; liberando proxy sem reconnect')
    return terminal, player


def _apply_channel_art(li, ch):
    try:
        artinfo=artwork_for(ch)
        remote=artinfo.get('remote',''); preview=artinfo.get('preview',''); fallback=artinfo.get('fallback','')
        addon=xbmcaddon.Addon(); addon_icon=addon.getAddonInfo('icon'); addon_fanart=addon.getAddonInfo('fanart')
        primary=remote or fallback or addon_icon
        fanart=preview or remote or addon_fanart
        art={}
        if primary:
            art.update({'icon':primary,'thumb':primary,'poster':primary,'clearlogo':primary})
        if fanart:
            art.update({'fanart':fanart,'landscape':fanart})
        if art: li.setArt(art)
        if fanart: li.setProperty('fanart_image',fanart)
    except Exception as exc:
        _log('artwork do player indisponível: %s'%exc, xbmc.LOGDEBUG)


def _run_source_attempt(ch, selected, channel_id, attempted, format_recovery=False, live_recovery=False):
    upstream = selected.get('resolved_url') or selected['url']
    display_name=_public_text(ch.get('name')) or str(channel_id)
    display_category=_public_text(ch.get('category'))
    display_plot=_public_text(ch.get('_epg_plot'),multiline=True)
    is_live = bool(selected.get('is_live'))
    is_globorj = str(ch.get('id') or '').lower() == 'globorj'
    proxy = HlsProxy(
        root_url=upstream,
        root_headers=selected.get('playlist_headers') or {},
        nested_headers=selected.get('resource_headers') or {},
        log=lambda msg: _log('PROXY %s' % msg),
        # Na recuperação pedimos playlist fresca para evitar reutilizar
        # segmentos que podem ter expirado durante a primeira tentativa.
        seed_playlist=None if (format_recovery or live_recovery) else selected.get('seed_playlist'),
        mask_png_ts_segments=is_globorj,
        format_recovery=bool(format_recovery and not is_globorj),
        segment_recovery=True,
    ).start()
    result = 'startup_failed'
    stop_observer = None
    had_format_suspect = False
    try:
        local_url = proxy.url(upstream)
        li = xbmcgui.ListItem(label=display_name, path=local_url)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('application/vnd.apple.mpegurl')
        li.setContentLookup(False)
        _apply_channel_art(li,ch)
        _enable_ffmpegdirect(li, is_live=is_live)
        try:
            tag = li.getVideoInfoTag()
            tag.setTitle(display_name)
            try: tag.setMediaType('video')
            except Exception: pass
            tag.setPlot(display_plot)
            if display_category:
                tag.setGenres([display_category])
        except Exception:
            pass

        _log('play id=%s fonte=%s upstream=%s proxy_port=%d live=%s tentativa=%d/%d recuperacao_formato=%s' % (
            channel_id, selected.get('name'), urlparse(upstream).netloc, proxy.port,
            'sim' if is_live else 'nao', selected.get('_candidate_index', attempted),
            selected.get('_candidate_total', attempted), 'sim' if format_recovery else 'nao'))
        if live_recovery:
            _log('tentativa de recuperacao live usando playlist fresca id=%s fonte=%s' % (
                channel_id, selected.get('name')), xbmc.LOGWARNING)
        _prepare_dialog_update(display_name, ready=True)
        result, stop_observer = _play_direct(local_url, li, display_name, is_live=is_live)
        had_format_suspect = proxy.has_format_suspects()
    finally:
        # Captura antes do stop para decidir se uma segunda tentativa do MESMO
        # source deve esconder extensão enganosa. Nunca é usado após A/V.
        try:
            had_format_suspect = had_format_suspect or proxy.has_format_suspects()
        except Exception:
            pass
        proxy.stop()
    return result, had_format_suspect, stop_observer


def _try_channel_contract(ch, channel_id, attempted_start=0, live_recovery=False, cancel_observer=None, session_state=None):
    attempted=attempted_start
    is_globorj=str(ch.get('id') or '').lower()=='globorj'
    any_selected=False
    if _play_session_cancelled(session_state, channel_id, 'antes_contrato'):
        return 'terminal',attempted,'superseded',cancel_observer
    for selected in _validated_sources(ch):
        # _validated_sources pode gastar alguns segundos em rede. Revalida o
        # dono da sessão depois de cada candidato para não iniciar playback de
        # uma recuperação antiga caso o usuário já tenha escolhido outro canal.
        if _play_session_cancelled(session_state, channel_id, 'apos_validacao_fonte'):
            return 'terminal',attempted,'superseded',cancel_observer
        if _observer_stopped(cancel_observer):
            _log('STOP tardio confirmado durante resolucao do recovery; nova reproducao cancelada')
            return 'terminal',attempted,'stopped',cancel_observer
        any_selected=True
        if live_recovery and not bool(selected.get('is_live')):
            _log('recuperacao live rejeitou manifesto encerrado/nao-live id=%s fonte=%s' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            continue
        attempted+=1
        result,had_format_suspect,stop_observer=_run_source_attempt(
            ch,selected,channel_id,attempted,format_recovery=False,live_recovery=live_recovery)
        if result in ('live_ended','live_error','live_lost'):
            return 'recoverable',attempted,result,stop_observer
        if result=='startup_failed' and had_format_suspect and not is_globorj:
            _log('startup falhou id=%s fonte=%s com extensao suspeita; tentando recuperacao de formato na mesma origem' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            result,_,stop_observer=_run_source_attempt(
                ch,selected,channel_id,attempted,format_recovery=True,live_recovery=live_recovery)
            if result in ('live_ended','live_error','live_lost'):
                return 'recoverable',attempted,result,stop_observer
            if result=='startup_failed':
                _log('recuperacao de formato nao iniciou A/V id=%s fonte=%s; avancando no contrato' % (
                    channel_id,selected.get('name')),xbmc.LOGWARNING)
                continue
            return 'terminal',attempted,result,stop_observer
        if result=='startup_failed':
            _log('startup falhou id=%s fonte=%s; tentando proxima origem NOVA do contrato' % (
                channel_id,selected.get('name')),xbmc.LOGWARNING)
            continue
        return 'terminal',attempted,result,stop_observer
    if _play_session_cancelled(session_state, channel_id, 'fim_contrato'):
        return 'terminal',attempted,'superseded',cancel_observer
    if _observer_stopped(cancel_observer):
        _log('STOP tardio confirmado ao fim da resolucao do recovery; recovery encerrado')
        return 'terminal',attempted,'stopped',cancel_observer
    return ('failed' if any_selected else 'unvalidated'),attempted,None,None


def _recover_live_channel(catalog, ch, channel_id, attempted, reason, stop_observer=None, session_state=None):
    """Recupera somente término involuntário de live já iniciado.

    Nunca é chamado para OnPlayBackStopped. Cada rodada relê o catálogo da
    opção ativa, reexecuta o contrato dinâmico e obriga playlist fresca no
    proxy. O limite evita loops quando a origem realmente está fora do ar.
    """
    monitor=xbmc.Monitor()
    current=ch
    for recovery_no in range(1,LIVE_RECOVERY_MAX+1):
        if _play_session_cancelled(session_state, channel_id, 'inicio_recovery'):
            return 'terminal',attempted
        delay=LIVE_RECOVERY_BACKOFF[min(recovery_no-1,len(LIVE_RECOVERY_BACKOFF)-1)]
        _log('queda involuntaria live id=%s motivo=%s; recuperacao=%d/%d em %.1fs' % (
            channel_id,reason,recovery_no,LIVE_RECOVERY_MAX,delay),xbmc.LOGWARNING)
        wait_state=_wait_recovery_backoff(monitor,delay,stop_observer)
        if wait_state=='abort':
            return 'abort',attempted
        if wait_state=='stopped':
            return 'terminal',attempted
        if _play_session_cancelled(session_state, channel_id, 'apos_backoff'):
            return 'terminal',attempted

        fresh=catalog.refresh_get(channel_id)
        if _play_session_cancelled(session_state, channel_id, 'apos_refresh'):
            return 'terminal',attempted
        if _observer_stopped(stop_observer):
            _log('STOP tardio confirmado apos refresh do catalogo; recovery cancelado')
            return 'terminal',attempted
        if not fresh:
            _log('recuperacao live id=%s tentativa=%d/%d sem catalogo fresco' % (
                channel_id,recovery_no,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
            continue
        fresh=dict(fresh)
        # O refresh do catálogo renova o contrato de rede; metadados já obtidos
        # localmente (EPG) continuam válidos para o ListItem recuperado.
        if (current or {}).get('_epg_plot'):
            fresh['_epg_plot']=(current or {}).get('_epg_plot')

        old_host=urlparse(str((current or {}).get('api_url') or '')).netloc
        new_host=urlparse(str(fresh.get('api_url') or '')).netloc
        _log('recuperacao live id=%s tentativa=%d/%d contrato_fresco host_antigo=%s host_novo=%s' % (
            channel_id,recovery_no,LIVE_RECOVERY_MAX,old_host or '-',new_host or '-'),xbmc.LOGWARNING)
        current=fresh

        state,attempted,new_reason,new_observer=_try_channel_contract(
            fresh,channel_id,attempted,live_recovery=True,cancel_observer=stop_observer,
            session_state=session_state)
        if state=='terminal':
            # Stop do usuário ou nova sessão que permaneceu até término terminal.
            return 'terminal',attempted
        if state=='recoverable':
            reason=new_reason or reason
            stop_observer=new_observer
            continue
        _log('recuperacao live id=%s tentativa=%d/%d sem fonte HLS valida; aguardando proxima rodada' % (
            channel_id,recovery_no,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)

    _log('recuperacao live esgotada id=%s tentativas=%d; encerrando sem loop' % (
        channel_id,LIVE_RECOVERY_MAX),xbmc.LOGWARNING)
    _notify_source_unavailable((current or ch or {}).get('name','Canal'))
    return 'failed',attempted


def _play_channel_impl(handle, channel_id, catalog=None, session_state=None):
    catalog = catalog or Catalog()
    ch=catalog.get(channel_id)
    if ch:
        _prepare_dialog_update(ch.get('name',channel_id), ready=False)
        _startup_lock_update_name(ch.get('name',channel_id))
        epg_id = str(ch.get('epg_id') or '').strip()
        if not epg_id and str(ch.get('_oneplay_source') or '') != 'option1':
            epg_id = str(channel_id or '').strip()
        if epg_id:
            try:
                from .epg import EpgGuide
                # Playback nunca abre uma segunda consulta de rede: apenas
                # reaproveita o cache carregado ao montar a grade.
                epg_info=EpgGuide(allow_network=False).info(epg_id)
                ch=dict(ch)
                ch['_epg_plot']=_public_text(epg_info.get('plot'),multiline=True)
            except Exception:
                pass
    if not ch:
        xbmcgui.Dialog().notification('OnePlay Live','Canal não encontrado.',xbmcgui.NOTIFICATION_ERROR,4000)
        return

    attempted=0
    state,attempted,reason,stop_observer=_try_channel_contract(ch,channel_id,attempted,session_state=session_state)
    if state=='terminal':
        return
    if state=='recoverable':
        _recover_live_channel(catalog,ch,channel_id,attempted,reason,stop_observer,session_state=session_state)
        return

    # Se o catálogo rotacionou URL ou conjunto oficial de domínios enquanto o
    # menu estava em cache, atualiza uma vez e repete somente contrato novo.
    old_url=str(ch.get('api_url') or '')
    old_contract=str(ch.get('_contract_signature') or old_url)
    fresh=catalog.refresh_get(channel_id)
    new_url=str((fresh or {}).get('api_url') or '')
    new_contract=str((fresh or {}).get('_contract_signature') or new_url)
    if fresh and new_url and new_contract!=old_contract:
        _log('contrato rotacionado id=%s host_antigo=%s host_novo=%s; nova tentativa de startup' % (
            channel_id,urlparse(old_url).netloc,urlparse(new_url).netloc),xbmc.LOGWARNING)
        state,attempted,reason,stop_observer=_try_channel_contract(fresh,channel_id,attempted,session_state=session_state)
        if state=='terminal':
            return
        if state=='recoverable':
            _recover_live_channel(catalog,fresh,channel_id,attempted,reason,stop_observer,session_state=session_state)
            return
    elif fresh:
        _log('refresh API manteve mesma URL id=%s; não repetindo fonte idêntica' % channel_id)

    _log('todas as fontes NOVAS falharam id=%s fontes_validadas=%d' % (channel_id,attempted),xbmc.LOGWARNING)
    _notify_source_unavailable(ch.get('name','Canal'))


def play_channel(handle, channel_id, catalog=None):
    session_state = _play_session_register(channel_id)
    try:
        return _play_channel_impl(handle, channel_id, catalog=catalog, session_state=session_state)
    finally:
        _play_session_clear(session_state)
        _prepare_dialog_close('play_channel_exit')
