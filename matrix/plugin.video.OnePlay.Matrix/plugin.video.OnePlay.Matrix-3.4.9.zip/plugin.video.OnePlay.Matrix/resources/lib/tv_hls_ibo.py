# -*- coding: utf-8 -*-
"""TV HLS V2: preflight do IBO adaptado a playlist M3U do Matrix.

Somente URLs Xtream das listas: zero mudança na autenticação do IBO.
Nunca persiste URLs, credenciais, cabeçalhos ou resposta de rede.
"""
from __future__ import unicode_literals
import re
import socket
from urllib.parse import urlsplit, urlunsplit
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

XTREAM_USER_AGENT = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                     'AppleWebKit/537.36 (KHTML, like Gecko) '
                     'Chrome/123.0.0.0 Safari/537.36')
IBO_HEADERS = {'User-Agent': XTREAM_USER_AGENT, 'Accept': '*/*',
               'Accept-Encoding': 'identity', 'Connection': 'close'}


def _candidate_urls(raw):
    """Conserva query assinada; não inventa endpoints para URLs arbitrárias."""
    parsed = urlsplit(raw)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc or '|' in raw:
        return [raw]
    path = parsed.path
    parts = path.strip('/').split('/')
    out = [raw]
    if (len(parts) == 3 and re.fullmatch(r'[0-9]+\.m3u8', parts[2], re.I)
            and all(parts[:2])):
        out.append(urlunsplit((parsed.scheme, parsed.netloc,
                              '/live/' + '/'.join(parts), parsed.query, parsed.fragment)))
    elif (len(parts) == 4 and parts[0].lower() == 'live'
          and re.fullmatch(r'[0-9]+\.m3u8', parts[3], re.I)
          and all(parts[1:3])):
        out.append(urlunsplit((parsed.scheme, parsed.netloc,
                              '/' + '/'.join(parts[1:]), parsed.query, parsed.fragment)))
    return out


def _probe(url, timeout=3.0, opener=None):
    # HEAD não é confiável em vários provedores Xtream; GET de amostra curta.
    try:
        req = Request(url, headers=IBO_HEADERS, method='GET')
        response = (opener.open(req, timeout=timeout) if opener is not None
                    else urlopen(req, timeout=timeout))
        try:
            code = int(getattr(response, 'status', response.getcode()) or 0)
            data = response.read(2048)
            mime = str(response.headers.get('Content-Type', '')).lower()
        finally:
            response.close()
        if code not in (200, 206):
            return False, 'http_%d' % code
        if data.lstrip(b'\xef\xbb\xbf\r\n\t ').startswith(b'#EXTM3U'):
            return True, 'hls'
        if data[:1] == b'G' and ('video/mp2t' in mime or 'octet-stream' in mime):
            return False, 'ts_direto'
        return False, 'corpo_nao_hls'
    except HTTPError as exc:
        return False, 'http_%d' % int(exc.code)
    except (URLError, socket.timeout, TimeoutError, OSError) as exc:
        return False, 'rede_%s' % exc.__class__.__name__
    except Exception as exc:
        return False, 'erro_%s' % exc.__class__.__name__


def resolve_live_hls(raw, source='', timeout=3.0, opener=None):
    """Somente Lista 05; retorna URL final e diagnóstico sem segredos.

    Na ausência de manifesto comprovado, mantém a URL da lista para não
    introduzir downgrade silencioso ou ignorar uma falha de autenticação.
    """
    try:
        if not urlsplit(str(source or '')).path.lower().endswith('/lista05.txt'):
            return raw, 'outra_lista', False
        candidates = _candidate_urls(str(raw or ''))
        if not candidates or len(candidates) == 1:
            return raw, 'nao_xtream', False
        events = []
        for i, candidate in enumerate(candidates):
            ok, result = _probe(candidate, timeout=timeout, opener=opener)
            events.append(('original' if i == 0 else 'alternativo') + ':' + result)
            if ok:
                return candidate, '|'.join(events), True
        return candidates[0], '|'.join(events), False
    except Exception as exc:
        return raw, 'erro_%s' % exc.__class__.__name__, False
