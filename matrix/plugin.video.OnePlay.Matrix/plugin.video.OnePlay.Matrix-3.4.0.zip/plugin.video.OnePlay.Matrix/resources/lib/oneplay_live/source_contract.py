# -*- coding: utf-8 -*-
"""Contrato HTTP da infraestrutura EmbedTV atual.

Regra 0.0.19:
- catálogo: https://embedtv.lat/api/channels
- playback primário: campo ``url`` retornado pela API para o canal
- fallback de startup: https://w7.embedtv.lat/<id>
- mídia resolvida/segmentos: Referer https://w7.embedtv.lat/

Não existem neste módulo URLs de reprodução das versões homologadas antigas.
"""
from urllib.parse import quote, urlparse

BROWSER_UA = (
    'Mozilla/5.0 (Linux; Android 10; K) '
    'AppleWebKit/537.36 (KHTML, like Gecko) '
    'Chrome/152.0.0.0 Mobile Safari/537.36'
)

COMMON_HEADERS = {
    'Accept': '*/*',
    'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7,it;q=0.6',
    'Priority': 'u=1, i',
    'Sec-CH-UA': '"Chromium";v="152", "Not?A_Brand";v="24", "Google Chrome";v="152"',
    'Sec-CH-UA-Mobile': '?1',
    'Sec-CH-UA-Platform': '"Android"',
    'Sec-Fetch-Dest': 'empty',
    'Sec-Fetch-Mode': 'cors',
    'Sec-Fetch-Site': 'cross-site',
    'User-Agent': BROWSER_UA,
}

API_REFERER = 'https://embedtv.lat/'
W7_REFERER = 'https://w7.embedtv.lat/'
W7_BASE = 'https://w7.embedtv.lat/{id}'


def _merge(base, extra=None):
    out = dict(base)
    if isinstance(extra, dict):
        for key, value in extra.items():
            if key and value is not None:
                out[str(key)] = str(value)
    return out


def api_headers(extra=None):
    h = _merge(COMMON_HEADERS, extra)
    h['Referer'] = API_REFERER
    h['Sec-Fetch-Site'] = 'same-site'
    return h


def media_headers(extra=None):
    # Contrato comprovado nos fetches fornecidos: file.txt e segmentos
    # camuflados trafegam no contexto de https://w7.embedtv.lat/.
    h = _merge(COMMON_HEADERS, extra)
    h['Referer'] = W7_REFERER
    h['Sec-Fetch-Site'] = 'cross-site'
    return h


def api_source(channel_url, extra_headers=None):
    url = str(channel_url or '').strip()
    if not url.startswith(('http://', 'https://')):
        return None
    host = (urlparse(url).hostname or '').lower()
    if host != 'embedtv.lat' and not host.endswith('.embedtv.lat'):
        return None
    h = media_headers(extra_headers)
    return {
        'name': 'embedtv-api-url',
        'url': url,
        'playlist_headers': dict(h),
        'resource_headers': dict(h),
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'source_kind': 'api-url',
    }


def w7_source(channel_id, extra_headers=None):
    cid = quote(str(channel_id or '').strip(), safe='_-.')
    if not cid:
        return None
    h = media_headers(extra_headers)
    return {
        'name': 'embedtv-w7',
        'url': W7_BASE.format(id=cid),
        'playlist_headers': dict(h),
        'resource_headers': dict(h),
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'source_kind': 'w7',
    }


def is_trusted_embed_page(url):
    try:
        host = (urlparse(str(url or '')).hostname or '').lower()
    except Exception:
        return False
    return host == 'embedtv.lat' or host.endswith('.embedtv.lat')
