# -*- coding: utf-8 -*-

import socket
import threading
import struct
import random
import time
import os
import re
from urllib.parse import urlparse, unquote, urljoin, quote, parse_qs
from urllib.request import Request, urlopen
from urllib.error import HTTPError
import ssl
from collections import deque
import gzip
import zlib
import socketserver
import http.client
from urllib.parse import urlsplit

try:
    import xbmcvfs
except Exception:
    xbmcvfs = None

PROXY_PORT_POOL = [57845, 57846, 57847, 57848, 57849, 57850]
PROXY_PORT = PROXY_PORT_POOL[0]
port_state_lock = threading.Lock()

def get_active_port():
    with port_state_lock:
        return PROXY_PORT

def set_active_port(port):
    global PROXY_PORT
    with port_state_lock:
        PROXY_PORT = port
    persist_port(port)

def port_state_path():
    try:
        if xbmcvfs is not None:
            base = xbmcvfs.translatePath(
                'special://profile/addon_data/plugin.video.kingiptv/'
            )
        else:
            base = os.path.join(os.path.expanduser("~"), ".kingiptv_proxy")
        if base and not os.path.isdir(base):
            os.makedirs(base, exist_ok=True)
        return os.path.join(base, "active_proxy_port.txt")
    except Exception:
        return None

def persist_port(port):
    path = port_state_path()
    if not path:
        return
    try:
        with open(path, "w") as f:
            f.write(str(port))
    except Exception:
        pass

def read_persisted_port():
    path = port_state_path()
    if not path:
        return None
    try:
        with open(path, "r") as f:
            value = f.read().strip()
        return int(value) if value else None
    except Exception:
        return None

def get_preferred_port():
    return read_persisted_port()

def is_port_free(port, host="127.0.0.1"):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.3)
    try:
        return s.connect_ex((host, port)) != 0
    except Exception:
        return True
    finally:
        try:
            s.close()
        except Exception:
            pass

CACHE_DURATION_SECONDS = 5
CACHE_MAX_CHUNKS = 250
MAX_RETRIES = 3
MAX_RECONNECT_RETRIES = 2
RETRY_DELAY = 0.3
BUFFER_SIZE = 32768
MAX_EOF_RECONNECTS = 3
MAX_TOTAL_RECONNECTS = 5
MAX_STALL_SECONDS = 10
CLIENT_ALIVE_CHECK_EVERY = 1.0
MAX_ACTIVE_CHANNEL_STREAMS = 12
CACHE_ENTRY_TTL = 300
CACHE_CLEANUP_INTERVAL = 60
PREFETCH_SEGMENT_COUNT = 1
SEGMENT_CACHE_TTL = 300
SEGMENT_CACHE_MAX = 20
SOCKET_IDLE_TIMEOUT = 10
SOCKET_STREAM_TIMEOUT = 10
PREFETCH_TIMEOUT = 8
PREFETCH_MAX_RETRIES = 2
MAX_PREFETCH_THREADS = 2
MAX_CONCURRENT_HANDLERS = 40
CHANNEL_IDLE_ABORT_SECONDS = 10
PLAYLIST_REFRESH_INTERVAL = 600

EXTINF_RE = re.compile(r'#EXTINF:\s*([\d.]+)')
TARGETDURATION_RE = re.compile(r'#EXT-X-TARGETDURATION:\s*(\d+(?:\.\d+)?)')
MEDIA_SEQUENCE_RE = re.compile(r'#EXT-X-MEDIA-SEQUENCE:\s*(\d+)')
MIN_PLAYLIST_INTERVAL_FLOOR = 2.0

PLAYLIST_REFRESH_BY_TARGET = {
    15: 10.0,
    20: 13.3,
    25: 16.7,
    30: 20.0,
    35: 23.3,
    40: 26.7,
    45: 30.0,
    50: 33.3,
    55: 36.7,
    60: 40.0,
}
PLAYLIST_REFRESH_TOLERANCE = 1.0
PLAYLIST_REFRESH_RATIO_DEFAULT = 2.0 / 3.0

AUTH_ERROR_CODES = {401, 403, 404, 410, 451}

CHROME_UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/150.0.7871.114 Safari/537.36"
)

UA_POOL = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.114 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.7827.200 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.7692.100 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/145.0.7549.90 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.7391.85 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.114 Safari/537.36",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.7827.200 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:150.0) Gecko/20100101 Firefox/150.0",
    "Mozilla/5.0 (X11; Linux x86_64; rv:152.0) Gecko/20100101 Firefox/152.0",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.114 Safari/537.36 Edg/150.0.3593.56",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7759.62 Safari/537.36 Edg/148.0.3479.40",
    "Mozilla/5.0 (Linux; Android 15; Pixel 9) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/150.0.7871.114 Mobile Safari/537.36",
    "Mozilla/5.0 (Linux; Android 14; SM-S928B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.7759.62 Mobile Safari/537.36",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (iPhone; CPU iPhone OS 18_3 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.3 Mobile/15E148 Safari/604.1",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Safari/605.1.15",
]

def get_origin(url):
    try:
        parsed = urlparse(url)
        if parsed.scheme and parsed.netloc:
            return "{}://{}".format(parsed.scheme, parsed.netloc)
    except Exception:
        pass
    return ''

class SimpleDNS:
    def __init__(self):
        self.cache = {}
        self.cache_lock = threading.Lock()
        self.dns_servers = [
            ("1.1.1.1", 53),
            ("8.8.8.8", 53),
            ("208.67.222.222", 53),
            ("9.9.9.9", 53),
        ]
        self.original_getaddrinfo = socket.getaddrinfo
        socket.getaddrinfo = self.resolver
        self.timeout = 5.0
        self.max_retries = 2

    def build_query(self, domain, qtype=1):
        transaction_id = random.randint(0, 65535)
        header = struct.pack(">HHHHHH", transaction_id, 0x0100, 1, 0, 0, 0)
        qname = b"".join(
            bytes([len(part)]) + part.encode() for part in domain.split(".")
        ) + b"\x00"
        return header + qname + struct.pack(">HH", qtype, 1)

    def parse_response(self, data):
        try:
            flags = struct.unpack(">H", data[2:4])[0]
            if (flags & 0x000F) != 0:
                return None, None
            answer_count = struct.unpack(">H", data[6:8])[0]
            if answer_count == 0:
                return None, None
            offset = 12
            while data[offset] != 0:
                offset += 1
            offset += 5
            ips = []
            ttl = 3600
            for _ in range(answer_count):
                if data[offset] & 0xC0:
                    offset += 2
                else:
                    while data[offset] != 0:
                        offset += 1
                    offset += 1
                rtype, rclass, ttl, rdlength = struct.unpack(">HHIH", data[offset:offset+10])
                offset += 10
                if rtype == 1 and rdlength == 4:
                    ip = struct.unpack(">BBBB", data[offset:offset+4])
                    ips.append(".".join(map(str, ip)))
                elif rtype == 28 and rdlength == 16:
                    ip = struct.unpack(">16B", data[offset:offset+16])
                    ips.append(":".join("{:02x}{:02x}".format(ip[i], ip[i+1]) for i in range(0, 16, 2)))
                offset += rdlength
            if ips:
                return ips, ttl
        except Exception:
            pass
        return None, None

    def resolve_udp(self, domain):
        for server, port in self.dns_servers:
            for attempt in range(self.max_retries):
                try:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.settimeout(self.timeout)
                    query = self.build_query(domain)
                    sock.sendto(query, (server, port))
                    data, _ = sock.recvfrom(2048)
                    sock.close()
                    ips, ttl = self.parse_response(data)
                    if ips:
                        return ips, ttl
                except Exception:
                    continue
        return None, None

    def resolve_tcp(self, domain):
        for server, port in self.dns_servers:
            try:
                sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
                sock.settimeout(self.timeout + 1)
                sock.connect((server, port))
                query = self.build_query(domain)
                sock.send(struct.pack(">H", len(query)) + query)
                resp_len_data = sock.recv(2)
                if len(resp_len_data) != 2:
                    sock.close()
                    continue
                resp_len = struct.unpack(">H", resp_len_data)[0]
                data = b""
                while len(data) < resp_len:
                    chunk = sock.recv(min(4096, resp_len - len(data)))
                    if not chunk:
                        break
                    data += chunk
                sock.close()
                if len(data) == resp_len:
                    ips, ttl = self.parse_response(data)
                    if ips:
                        return ips, ttl
            except Exception:
                continue
        return None, None

    def resolve(self, domain):
        if not domain or domain == '':
            return None
        with self.cache_lock:
            if domain in self.cache:
                entry = self.cache[domain]
                if entry["expires"] > time.time():
                    return entry["ips"]
                else:
                    del self.cache[domain]

        ips, ttl = self.resolve_udp(domain)
        if not ips:
            ips, ttl = self.resolve_tcp(domain)

        if ips:
            with self.cache_lock:
                self.cache[domain] = {
                    "ips": ips,
                    "expires": time.time() + (ttl if ttl else 3600)
                }
            return ips
        return None

    def resolver(self, host, port, *args, **kwargs):
        try:
            socket.inet_aton(host)
            return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (host, port))]
        except Exception:
            ips = self.resolve(host)
            if ips:
                results = []
                for ip in ips:
                    try:
                        socket.inet_aton(ip)
                        results.append((socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port)))
                    except Exception:
                        try:
                            socket.inet_pton(socket.AF_INET6, ip)
                            results.append((socket.AF_INET6, socket.SOCK_STREAM, 6, "", (ip, port)))
                        except Exception:
                            continue
                if results:
                    return results
        return self.original_getaddrinfo(host, port, *args, **kwargs)

dns = SimpleDNS()

class CircularBuffer:
    def __init__(self, max_seconds=5, max_chunks=250):
        self.buffer = deque(maxlen=max_chunks)
        self.timestamps = deque(maxlen=max_chunks)
        self.max_seconds = max_seconds
        self.total_bytes = 0
        self.lock = threading.Lock()
        self.last_update = 0
        self.stream_started = False

    def add_chunk(self, chunk):
        with self.lock:
            self.buffer.append(chunk)
            self.timestamps.append(time.time())
            self.total_bytes += len(chunk)
            self.last_update = time.time()
            cutoff = time.time() - self.max_seconds
            while self.timestamps and self.timestamps[0] < cutoff:
                removed = self.buffer.popleft()
                self.timestamps.popleft()
                self.total_bytes -= len(removed)

    def get_recovery_chunks(self, duration=3):
        with self.lock:
            if not self.buffer:
                return []
            cutoff = time.time() - duration
            recovery = []
            for i, ts in enumerate(self.timestamps):
                if ts >= cutoff:
                    recovery.append(self.buffer[i])
            if not recovery and self.buffer:
                recovery = list(self.buffer)[-20:]
            return recovery

    def get_continuous_chunks(self, count=30):
        with self.lock:
            if not self.buffer:
                return []
            return list(self.buffer)[-count:]

    def clear(self):
        with self.lock:
            self.buffer.clear()
            self.timestamps.clear()
            self.total_bytes = 0
            self.stream_started = False

class UnifiedProxy:
    def __init__(self):
        self.channel_caches = {}
        self.ssl_context = ssl.create_default_context()
        self.ssl_context.check_hostname = False
        self.ssl_context.verify_mode = ssl.CERT_NONE
        self.stream_lock = threading.Lock()
        self.cache_lock = threading.Lock()
        self.segment_cache = {}
        self.segment_cache_lock = threading.Lock()
        self.prefetching = set()
        self.prefetching_lock = threading.Lock()
        self.active_streams = 0
        self.active_streams_lock = threading.Lock()
        self.channel_cache_last_used = {}
        self.maintenance_started = False
        self.maintenance_lock = threading.Lock()
        self.channel_warmed_up = set()
        self.warmup_lock = threading.Lock()
        self.prefetch_threads_active = 0
        self.prefetch_threads_lock = threading.Lock()
        self.active_handlers = 0
        self.active_handlers_lock = threading.Lock()
        self.channel_ua_cache = {}
        self.channel_ua_lock = threading.Lock()
        self.original_playlist_urls = {}
        self.playlist_lock = threading.Lock()
        self.playlist_state = {}

    def get_user_agent_for_channel(self, channel_url):
        key = self.channel_key(channel_url)
        with self.channel_ua_lock:
            if key not in self.channel_ua_cache:
                self.channel_ua_cache[key] = random.choice(UA_POOL)
            return self.channel_ua_cache[key]

    def start_maintenance(self):
        with self.maintenance_lock:
            if self.maintenance_started:
                return
            self.maintenance_started = True
        t = threading.Thread(target=self.cleanup_loop, daemon=True)
        t.start()

    def cleanup_loop(self):
        while True:
            time.sleep(CACHE_CLEANUP_INTERVAL)
            now = time.time()
            try:
                with self.stream_lock:
                    stale = [k for k, ts in self.channel_cache_last_used.items()
                             if now - ts > CACHE_ENTRY_TTL]
                    for k in stale:
                        self.channel_caches.pop(k, None)
                        self.channel_cache_last_used.pop(k, None)
                with self.warmup_lock:
                    for k in stale:
                        self.channel_warmed_up.discard(k)
            except Exception:
                pass

    def acquire_handler_slot(self):
        with self.active_handlers_lock:
            self.active_handlers += 1
            over_limit = self.active_handlers > MAX_CONCURRENT_HANDLERS
        return not over_limit

    def release_handler_slot(self):
        with self.active_handlers_lock:
            if self.active_handlers > 0:
                self.active_handlers -= 1

    def acquire_stream_slot(self):
        with self.active_streams_lock:
            if self.active_streams >= MAX_ACTIVE_CHANNEL_STREAMS:
                return False
            self.active_streams += 1
            return True

    def release_stream_slot(self):
        with self.active_streams_lock:
            if self.active_streams > 0:
                self.active_streams -= 1

    def get_random_user_agent(self):
        return random.choice(UA_POOL)

    def get_local_ip(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        except Exception:
            ip = "127.0.0.1"
        finally:
            s.close()
        return ip

    def extract_url_from_path(self, path):
        result = {'url': None, 'playlist_url': None}
        if '/?url=' in path:
            query_part = path.split('/?', 1)[1]
            params = parse_qs(query_part)
            url_list = params.get('url', [])
            if url_list:
                result['url'] = unquote(url_list[0])
            playlist_list = params.get('playlist_url', [])
            if playlist_list:
                result['playlist_url'] = unquote(playlist_list[0])
            return result
        if '/tsdownloader' in path and '?url=' in path:
            params = path.split('?', 1)[1]
            for param in params.split('&'):
                if param.startswith('url='):
                    result['url'] = unquote(param[4:])
                elif param.startswith('playlist_url='):
                    result['playlist_url'] = unquote(param[13:])
            return result
        if path.startswith('/http://') or path.startswith('/https://'):
            result['url'] = unquote(path[1:])
            return result
        if path.startswith('http://') or path.startswith('https://'):
            result['url'] = unquote(path)
            return result
        return result

    def channel_key(self, url):
        return re.sub(r'(_=\d+|timestamp=\d+|t=\d+|seq=\d+)', '', url)

    def get_channel_cache(self, url):
        clean_url = self.channel_key(url)
        with self.stream_lock:
            if clean_url not in self.channel_caches:
                self.channel_caches[clean_url] = CircularBuffer(CACHE_DURATION_SECONDS, CACHE_MAX_CHUNKS)
            self.channel_cache_last_used[clean_url] = time.time()
            return self.channel_caches[clean_url]

    def fetch_channel_with_fallback(self, url, headers=None, range_header=None, cache=None,
                                     is_alive=None, max_retries=None, timeout=15):
        if headers is None:
            headers = {}
        retries = max_retries if max_retries is not None else MAX_RETRIES
        fixed_ua = self.get_user_agent_for_channel(url)
        for attempt in range(retries):
            if is_alive is not None and not is_alive():
                return None, 0, None
            user_agent = fixed_ua if attempt == 0 else self.get_random_user_agent()
            origin = get_origin(url)
            req_headers = {
                'User-Agent': user_agent,
                'Accept': '*/*',
                'Accept-Language': 'pt-BR,pt;q=0.9',
                'Connection': 'keep-alive'
            }
            if origin:
                req_headers['Origin'] = origin
                req_headers['Referer'] = origin + '/'
            for key, value in headers.items():
                if key.lower() not in ['host', 'connection', 'content-length', 'range', 'user-agent', 'accept-encoding']:
                    req_headers[key] = value
            if range_header:
                req_headers['Range'] = range_header
            try:
                req = Request(url, headers=req_headers)
                if url.startswith('https'):
                    response = urlopen(req, timeout=timeout, context=self.ssl_context)
                else:
                    response = urlopen(req, timeout=timeout)
                status_code = response.getcode()
                content_encoding = response.headers.get('content-encoding', '').lower()
                if status_code not in [200, 206]:
                    return None, status_code, None
                try:
                    if hasattr(response.fp, '_sock') and response.fp._sock:
                        response.fp._sock.settimeout(10)
                except Exception:
                    pass
                return response, status_code, content_encoding
            except HTTPError as e:
                if e.code in AUTH_ERROR_CODES:
                    return None, e.code, None
                if attempt < retries - 1:
                    if is_alive is not None and not is_alive():
                        return None, 0, None
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, e.code, None
            except Exception:
                if attempt < retries - 1:
                    if is_alive is not None and not is_alive():
                        return None, 0, None
                    time.sleep(RETRY_DELAY * (attempt + 1))
                    continue
                return None, 0, None
        return None, 0, None

    def reconnect_stream(self, url, headers, cache, is_alive, channel_key, refresh_url, playlist_headers):
        if refresh_url:
            seg = self.refresh_and_locate_segment(url, refresh_url, playlist_headers, channel_key)
            if seg != url:
                response, status, _ = self.fetch_channel_with_fallback(
                    seg, headers, None, cache, is_alive=is_alive, max_retries=MAX_RECONNECT_RETRIES
                )
                if response and status in (200, 206):
                    return response, status, seg
        response, status, _ = self.fetch_channel_with_fallback(
            url, headers, None, cache, is_alive=is_alive, max_retries=MAX_RECONNECT_RETRIES
        )
        if response and status in (200, 206):
            return response, status, url
        return None, 0, url

    def segment_key(self, url):
        try:
            parts = urlsplit(url)
            return "{}://{}{}?{}".format(parts.scheme, parts.netloc, parts.path, parts.query)
        except Exception:
            return url

    def get_cached_segment(self, url):
        key = self.segment_key(url)
        with self.segment_cache_lock:
            entry = self.segment_cache.get(key)
            if not entry:
                return None
            data, ts = entry
            if time.time() - ts > SEGMENT_CACHE_TTL:
                del self.segment_cache[key]
                return None
            if len(data) >= 188 and data[0] == 0x47:
                return data
            del self.segment_cache[key]
            return None

    def store_segment(self, url, data):
        if not data or len(data) < 188 or data[0] != 0x47:
            return
        key = self.segment_key(url)
        with self.segment_cache_lock:
            self.segment_cache[key] = (data, time.time())
            if len(self.segment_cache) > SEGMENT_CACHE_MAX:
                oldest_key = min(self.segment_cache, key=lambda k: self.segment_cache[k][1])
                if oldest_key != key:
                    del self.segment_cache[oldest_key]

    def _fetch_segment_bytes(self, url, headers, timeout, max_retries):
        response = None
        try:
            response, status, content_encoding = self.fetch_channel_with_fallback(
                url, headers, max_retries=max_retries, timeout=timeout
            )
            if not response or status not in (200, 206):
                return None, status
            content_length = response.headers.get('content-length')
            try:
                expected_size = int(content_length) if content_length else None
            except Exception:
                expected_size = None
            data = b""
            deadline = time.time() + timeout
            while True:
                if time.time() > deadline:
                    return None, status
                chunk = response.read(BUFFER_SIZE)
                if not chunk:
                    break
                data += chunk
                if expected_size and len(data) >= expected_size:
                    break
            if expected_size is not None and len(data) != expected_size:
                return None, status
            if content_encoding == 'gzip':
                data = gzip.decompress(data)
            elif content_encoding == 'deflate':
                data = zlib.decompress(data)
            if len(data) < 188 or data[0] != 0x47:
                return None, status
            return data, status
        except Exception:
            return None, 0
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass

    def download_complete_segment(self, url, headers, timeout=20):
        data, _ = self._fetch_segment_bytes(url, headers, timeout=timeout, max_retries=MAX_RETRIES)
        return data

    def download_segment_to_cache(self, url, headers):
        try:
            data, _ = self._fetch_segment_bytes(
                url, headers, timeout=PREFETCH_TIMEOUT, max_retries=PREFETCH_MAX_RETRIES
            )
            if data:
                self.store_segment(url, data)
        finally:
            with self.prefetching_lock:
                self.prefetching.discard(self.segment_key(url))
            with self.prefetch_threads_lock:
                if self.prefetch_threads_active > 0:
                    self.prefetch_threads_active -= 1

    def prefetch_segments(self, urls, headers, channel_key=None):
        to_fetch = []
        for seg_url in urls[:PREFETCH_SEGMENT_COUNT]:
            key = self.segment_key(seg_url)
            with self.prefetching_lock:
                if self.get_cached_segment(seg_url):
                    continue
                if key in self.prefetching:
                    continue
                self.prefetching.add(key)
            to_fetch.append(seg_url)
        if not to_fetch:
            return []
        with self.prefetch_threads_lock:
            if self.prefetch_threads_active >= MAX_PREFETCH_THREADS:
                with self.prefetching_lock:
                    for seg_url in to_fetch:
                        self.prefetching.discard(self.segment_key(seg_url))
                return []
            self.prefetch_threads_active += 1
        t = threading.Thread(target=self.download_segments_sequentially, args=(to_fetch, headers, channel_key))
        t.daemon = True
        t.start()
        return [t]

    def download_segments_sequentially(self, urls, headers, channel_key=None):
        for seg_url in urls:
            if channel_key is not None:
                last_used = self.channel_cache_last_used.get(channel_key)
                if last_used is not None and (time.time() - last_used) > CHANNEL_IDLE_ABORT_SECONDS:
                    with self.prefetching_lock:
                        self.prefetching.discard(self.segment_key(seg_url))
                    continue
            self.download_segment_to_cache(seg_url, headers)

    def _segment_filename(self, url):
        return url.split('/')[-1].split('?')[0]

    def find_segment_by_filename(self, channel_key, filename):
        with self.playlist_lock:
            state = self.playlist_state.get(channel_key)
        if not state:
            return None
        for seg_url, _dur in state['segments']:
            if self._segment_filename(seg_url) == filename:
                return seg_url
        return None

    def refresh_and_locate_segment(self, old_url, refresh_url, playlist_headers, channel_key):
        self.get_playlist_state(channel_key, refresh_url, playlist_headers,
                                 fallback_url=self.original_playlist_urls.get(channel_key),
                                 force=True)
        found = self.find_segment_by_filename(channel_key, self._segment_filename(old_url))
        return found or old_url

    def prefetch_next_segments(self, served_url, headers, channel_key):
        with self.playlist_lock:
            state = self.playlist_state.get(channel_key)
        if not state or not state['segments']:
            return
        segments = [s[0] for s in state['segments']]
        served_name = self._segment_filename(served_url)
        for i, seg in enumerate(segments):
            if self._segment_filename(seg) == served_name:
                next_segments = segments[i + 1:i + 1 + PREFETCH_SEGMENT_COUNT]
                if next_segments:
                    self.prefetch_segments(next_segments, headers, channel_key=channel_key)
                return

    def fetch_playlist_raw(self, url, headers, fallback_url=None):
        candidates = [url]
        if fallback_url and fallback_url != url:
            candidates.append(fallback_url)
        for candidate in candidates:
            try:
                response, status, content_encoding = self.fetch_channel_with_fallback(
                    candidate, headers, max_retries=2, timeout=10
                )
                if response and status in (200, 206):
                    raw = response.read()
                    final_url = response.geturl() or candidate
                    response.close()
                    try:
                        if content_encoding == 'gzip':
                            raw = gzip.decompress(raw)
                        elif content_encoding == 'deflate':
                            raw = zlib.decompress(raw)
                    except Exception:
                        pass
                    return raw, final_url
            except Exception:
                continue
        return None, None

    def _parse_playlist_segments(self, playlist_text, base_url):
        segments = []
        target_duration = None
        media_sequence = None
        pending_duration = None
        for raw_line in playlist_text.split('\n'):
            line = raw_line.strip()
            if not line:
                continue
            if line.startswith('#EXT-X-TARGETDURATION'):
                m = TARGETDURATION_RE.search(line)
                if m:
                    try:
                        target_duration = float(m.group(1))
                    except Exception:
                        pass
                continue
            if line.startswith('#EXT-X-MEDIA-SEQUENCE'):
                m = MEDIA_SEQUENCE_RE.search(line)
                if m:
                    try:
                        media_sequence = int(m.group(1))
                    except Exception:
                        pass
                continue
            if line.startswith('#EXTINF'):
                m = EXTINF_RE.search(line)
                if m:
                    try:
                        pending_duration = float(m.group(1))
                    except Exception:
                        pending_duration = None
                continue
            if line.startswith('#'):
                continue
            absolute = urljoin(base_url + '/', line)
            if absolute.startswith(('http://', 'https://')):
                segments.append((absolute, pending_duration))
            pending_duration = None
        return segments, target_duration, media_sequence

    def _compute_min_interval(self, total_duration):
        if total_duration and total_duration > 0:
            for tier, refresh in PLAYLIST_REFRESH_BY_TARGET.items():
                if abs(total_duration - tier) <= PLAYLIST_REFRESH_TOLERANCE:
                    return max(refresh, MIN_PLAYLIST_INTERVAL_FLOOR)
            interval = total_duration * PLAYLIST_REFRESH_RATIO_DEFAULT
        else:
            interval = 6.0 * PLAYLIST_REFRESH_RATIO_DEFAULT
        return max(interval, MIN_PLAYLIST_INTERVAL_FLOOR)

    def _ingest_playlist_text(self, channel_key, playlist_text, base_url, fetched_from_origin=True):
        segments, target_duration, media_sequence = self._parse_playlist_segments(playlist_text, base_url)
        with self.playlist_lock:
            prev = self.playlist_state.get(channel_key)
        req_count = prev['request_count'] if prev else 0
        if fetched_from_origin:
            req_count += 1
        total_duration = sum(d for _, d in segments if d is not None)
        min_interval = self._compute_min_interval(total_duration)
        state = {
            'content': playlist_text,
            'base': base_url,
            'segments': segments,
            'target_duration': target_duration,
            'total_duration': total_duration,
            'media_sequence': media_sequence,
            'last_fetch_ts': time.time(),
            'request_count': req_count,
            'min_interval': min_interval,
        }
        with self.playlist_lock:
            self.playlist_state[channel_key] = state
        return state

    def get_playlist_state(self, channel_key, playlist_url, headers, fallback_url=None, force=False):
        now = time.time()
        with self.playlist_lock:
            state = self.playlist_state.get(channel_key)
        if state and not force:
            elapsed = now - state['last_fetch_ts']
            if elapsed < state.get('min_interval', MIN_PLAYLIST_INTERVAL_FLOOR):
                return state, False
        raw, final_url = self.fetch_playlist_raw(playlist_url, headers, fallback_url)
        if raw is None:
            return state, False
        try:
            playlist_text = raw.decode('utf-8', errors='ignore')
        except Exception:
            playlist_text = raw.decode('latin-1', errors='ignore')
        base_url = (final_url or playlist_url).rsplit('/', 1)[0]
        new_state = self._ingest_playlist_text(channel_key, playlist_text, base_url, fetched_from_origin=True)
        return new_state, True

    def rewrite_m3u8_urls(self, playlist_content, base_url, proxy_host, headers=None, prefetch=True, channel_key=None, playlist_original_url=None):
        segment_urls = []
        playlist_original_url_encoded = quote(playlist_original_url, safe='') if playlist_original_url else ''
        def to_proxy_url(raw_url):
            raw_url = raw_url.strip()
            if not raw_url:
                return raw_url
            try:
                absolute = urljoin(base_url + '/', raw_url)
                if absolute.startswith('http://127.0.0.1') or absolute.startswith('http://localhost'):
                    return absolute
                if absolute.startswith(('http://', 'https://')):
                    full_proxy_url = "http://{}/?url={}".format(proxy_host, quote(absolute, safe=''))
                    if playlist_original_url_encoded:
                        full_proxy_url += "&playlist_url={}".format(playlist_original_url_encoded)
                    return absolute, full_proxy_url
            except Exception:
                pass
            return None
        def proxify_line(raw_url):
            result = to_proxy_url(raw_url)
            if not result:
                return raw_url
            absolute, proxied = result
            segment_urls.append(absolute)
            return proxied
        def proxify_attr(match):
            raw_url = match.group(1)
            result = to_proxy_url(raw_url)
            if not result:
                return match.group(0)
            _, proxied = result
            return 'URI="{}"'.format(proxied)
        uri_attr_re = re.compile(r'URI="([^"]+)"')
        lines = []
        for line in playlist_content.split('\n'):
            line = line.rstrip()
            if not line:
                lines.append(line)
                continue
            if line.startswith('#'):
                if 'URI="' in line:
                    line = uri_attr_re.sub(proxify_attr, line)
            else:
                line = proxify_line(line)
            lines.append(line)
        if prefetch and segment_urls:
            self.prefetch_segments(segment_urls, headers, channel_key=channel_key)
        return '\n'.join(lines)

    def _send_error(self, wfile, code, message=""):
        try:
            body = f"{code} {message}".encode()
            wfile.write(f"HTTP/1.1 {code} {message}\r\n".encode())
            wfile.write(b"Content-Type: text/plain\r\n")
            wfile.write(f"Content-Length: {len(body)}\r\n".encode())
            wfile.write(b"Connection: close\r\n\r\n")
            wfile.write(body)
        except Exception:
            pass

    def _send_segment(self, wfile, data, keep_alive=False):
        try:
            wfile.write(b"HTTP/1.1 200 OK\r\n")
            wfile.write(b"Content-Type: video/mp2t\r\n")
            wfile.write(b"Access-Control-Allow-Origin: *\r\n")
            wfile.write(b"Cache-Control: no-cache\r\n")
            if keep_alive:
                wfile.write(b"Connection: keep-alive\r\n")
            wfile.write(f"Content-Length: {len(data)}\r\n".encode())
            wfile.write(b"\r\n")
            wfile.write(data)
        except Exception:
            pass

    def _write_m3u8_response(self, write_fn, state, channel_key, playlist_original_url, headers):
        proxy_host = "127.0.0.1:{}".format(get_active_port())
        rewritten = self.rewrite_m3u8_urls(
            state['content'], state['base'], proxy_host, headers,
            channel_key=channel_key, playlist_original_url=playlist_original_url
        )
        body = rewritten.encode('utf-8')
        write_fn(
            b"HTTP/1.1 200 OK\r\n"
            b"Content-Type: application/vnd.apple.mpegurl\r\n" +
            "Content-Length: {}\r\n".format(len(body)).encode() +
            b"Access-Control-Allow-Origin: *\r\n"
            b"Cache-Control: no-cache\r\n\r\n" +
            body
        )

    def handle_channel_stream(self, url, headers, wfile, client_sock=None, method='GET', playlist_original_url=None):
        if method in ('HEAD', 'OPTIONS'):
            content_type = 'application/vnd.apple.mpegurl' if '.m3u8' in url.lower() else 'video/mp2t'
            try:
                wfile.write("HTTP/1.1 200 OK\r\n".encode())
                wfile.write("Content-Type: {}\r\n".format(content_type).encode())
                wfile.write(b"Access-Control-Allow-Origin: *\r\n")
                wfile.write(b"Cache-Control: no-cache\r\n")
                wfile.write(b"Content-Length: 0\r\n")
                wfile.write(b"\r\n")
            except Exception:
                pass
            return

        playlist_url = playlist_original_url if playlist_original_url else url
        playlist_headers = headers
        channel_key = self.channel_key(playlist_url)

        if not url.lower().endswith('.ts') and not playlist_original_url:
            self.original_playlist_urls[channel_key] = url

        refresh_url = self.original_playlist_urls.get(channel_key, playlist_url)

        is_ts_segment = '.ts' in url.lower() or '/segment/' in url.lower()
        if is_ts_segment:
            cached = self.get_cached_segment(url)
            if cached:
                self._send_segment(wfile, cached)
                self.prefetch_next_segments(url, headers, channel_key)
                return

            segment_data = self.download_complete_segment(url, headers)
            if segment_data is None:
                refreshed_url = self.refresh_and_locate_segment(url, refresh_url, playlist_headers, channel_key)
                if refreshed_url != url:
                    url = refreshed_url
                    segment_data = self.download_complete_segment(url, headers)

            if segment_data is None:
                self._send_error(wfile, 503, "Segmento indisponivel")
                return

            self.store_segment(url, segment_data)
            self._send_segment(wfile, segment_data)
            self.prefetch_next_segments(url, headers, channel_key)
            return

        cache = self.get_channel_cache(url)

        if not url.lower().endswith('.m3u8'):
            cached_segment = self.get_cached_segment(url)
            if cached_segment:
                self._send_segment(wfile, cached_segment, keep_alive=True)
                cache.add_chunk(cached_segment)
                return

        client_gone = [False]

        def safe_write(data):
            if client_gone[0]:
                return False
            try:
                wfile.write(data)
                return True
            except (BrokenPipeError, socket.error, ConnectionResetError, ConnectionAbortedError):
                client_gone[0] = True
                return False
            except Exception:
                client_gone[0] = True
                return False

        last_alive_check = [0.0]
        def is_client_alive():
            if client_gone[0]:
                return False
            if client_sock is None:
                return True
            now = time.time()
            if now - last_alive_check[0] < 0.25:
                return True
            last_alive_check[0] = now
            try:
                client_sock.settimeout(0)
                peek = client_sock.recv(1, socket.MSG_PEEK)
                if peek == b'':
                    client_gone[0] = True
                    return False
                return True
            except BlockingIOError:
                return True
            except (ConnectionResetError, ConnectionAbortedError, OSError):
                client_gone[0] = True
                return False
            except Exception:
                return True
            finally:
                try:
                    client_sock.settimeout(SOCKET_STREAM_TIMEOUT)
                except Exception:
                    pass

        if url.lower().endswith('.m3u8'):
            state, _fetched = self.get_playlist_state(
                channel_key, url, headers,
                fallback_url=self.original_playlist_urls.get(channel_key)
            )
            if not state:
                self._send_error(wfile, 503, "Playlist indisponivel")
                return
            self._write_m3u8_response(safe_write, state, channel_key, url, headers)
            return

        response = None
        stream_slot_acquired = self.acquire_stream_slot()
        if not stream_slot_acquired:
            return
        try:
            response, status_code, content_encoding = self.fetch_channel_with_fallback(
                url, headers, None, cache, is_alive=is_client_alive
            )
            if response is None:
                self._send_error(wfile, 503, "Origem indisponivel")
                return
            if response and status_code in [200, 206]:
                content_type = response.headers.get('content-type', '').lower()
                content_url = response.geturl()
                if 'mpegurl' in content_type or '.m3u8' in content_url.lower():
                    raw_content = response.read()
                    try:
                        if content_encoding == 'gzip':
                            content = gzip.decompress(raw_content)
                        elif content_encoding == 'deflate':
                            content = zlib.decompress(raw_content)
                        else:
                            content = raw_content
                    except Exception:
                        content = raw_content
                    try:
                        playlist_text = content.decode('utf-8', errors='ignore')
                        base_url = content_url.rsplit('/', 1)[0]
                        state = self._ingest_playlist_text(channel_key, playlist_text, base_url,
                                                             fetched_from_origin=True)
                        response.close()
                        self._write_m3u8_response(safe_write, state, channel_key, content_url, headers)
                        return
                    except Exception:
                        return
                content_length_header = response.headers.get('content-length')
                try:
                    expected_length = int(content_length_header) if content_length_header else None
                except (TypeError, ValueError):
                    expected_length = None

                bytes_received = 0
                header_bytes = ("HTTP/1.1 {} OK\r\n".format(206 if status_code == 206 else 200) +
                                "Content-Type: video/mp2t\r\n"
                                "Access-Control-Allow-Origin: *\r\n"
                                "Cache-Control: no-cache\r\n"
                                "Connection: keep-alive\r\n")
                if content_length_header:
                    header_bytes += "Content-Length: {}\r\n".format(content_length_header)
                header_bytes += "\r\n"
                if not safe_write(header_bytes.encode()):
                    return
                cache.stream_started = True

                consecutive_errors = 0
                eof_reconnects = 0
                total_reconnects = 0
                last_progress = time.time()
                while not client_gone[0]:
                    if not is_client_alive():
                        break
                    if time.time() - last_progress > MAX_STALL_SECONDS:
                        break
                    if total_reconnects > MAX_TOTAL_RECONNECTS:
                        break
                    try:
                        if response:
                            chunk = response.read(BUFFER_SIZE)
                            if chunk:
                                cache.add_chunk(chunk)
                                if not safe_write(chunk):
                                    break
                                bytes_received += len(chunk)
                                consecutive_errors = 0
                                eof_reconnects = 0
                                last_progress = time.time()
                            else:
                                try:
                                    response.close()
                                except Exception:
                                    pass
                                response = None
                                if expected_length is not None and bytes_received >= expected_length:
                                    break
                                eof_reconnects += 1
                                if eof_reconnects > MAX_EOF_RECONNECTS:
                                    break
                        else:
                            total_reconnects += 1
                            if not is_client_alive():
                                break
                            new_response, new_status, new_url = self.reconnect_stream(
                                url, headers, cache, is_client_alive, channel_key, refresh_url, playlist_headers
                            )
                            if new_response:
                                url = new_url
                                response = new_response
                                expected_length = None
                                bytes_received = 0
                                consecutive_errors = 0
                                eof_reconnects = 0
                                last_progress = time.time()
                                continue
                            if not is_client_alive():
                                break
                            time.sleep(1)
                    except (BrokenPipeError, socket.error, ConnectionResetError, ConnectionAbortedError):
                        client_gone[0] = True
                        break
                    except Exception:
                        consecutive_errors += 1
                        if consecutive_errors >= 3:
                            total_reconnects += 1
                            if not is_client_alive():
                                break
                            if response:
                                try:
                                    response.close()
                                except Exception:
                                    pass
                                response = None
                            new_response, new_status, new_url = self.reconnect_stream(
                                url, headers, cache, is_client_alive, channel_key, refresh_url, playlist_headers
                            )
                            if new_response:
                                url = new_url
                                response = new_response
                                expected_length = None
                                bytes_received = 0
                                consecutive_errors = 0
                                last_progress = time.time()
                                continue
                        time.sleep(0.5)
        except Exception:
            pass
        finally:
            if response:
                try:
                    response.close()
                except Exception:
                    pass
            if stream_slot_acquired:
                self.release_stream_slot()

class ProxyHandler(socketserver.StreamRequestHandler):
    proxy = UnifiedProxy()

    def send_response(self, code, message=None):
        if message is None:
            message = http.client.responses.get(code, "OK")
        self.resp_statusline = f"HTTP/1.1 {code} {message}\r\n"
        self.resp_headers = []

    def send_header(self, key, value):
        self.resp_headers.append((key, value))

    def end_headers(self):
        try:
            has_conn = any(k.lower() == "connection" for k, _ in self.resp_headers)
            if not has_conn:
                self.resp_headers.append(("Connection", "close"))
            data = self.resp_statusline
            for k, v in self.resp_headers:
                data += f"{k}: {v}\r\n"
            data += "\r\n"
            self.wfile.write(data.encode("utf-8", "replace"))
        except Exception:
            pass

    def send_error(self, code, message=""):
        body = (f"{code} {message}").encode("utf-8", "replace")
        self.send_response(code)
        self.send_header("Content-Type", "text/plain; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        try:
            self.wfile.write(body)
        except Exception:
            pass

    def handle(self):
        try:
            self.connection.settimeout(SOCKET_IDLE_TIMEOUT)
        except Exception:
            pass
        slot_ok = True
        try:
            slot_ok = self.proxy.acquire_handler_slot()
        except Exception:
            slot_ok = True
        try:
            if not slot_ok:
                try:
                    self.send_error(503, "Too Many Connections")
                except Exception:
                    pass
                return
            raw = self.rfile.readline(65537)
            if not raw:
                return
            if raw.startswith(b"\x16\x03") or raw.startswith(b"PRI * HTTP/2.0"):
                self.send_error(400, "Bad Request")
                return
            line = raw.decode("iso-8859-1", "replace").rstrip("\r\n")
            parts = line.split(" ")
            if len(parts) < 2:
                self.send_error(400, "Bad Request")
                return
            self.command = parts[0].upper()
            if len(parts) >= 3 and parts[-1].startswith("HTTP/"):
                self.request_version = parts[-1]
                target = " ".join(parts[1:-1])
            else:
                self.request_version = "HTTP/1.1"
                target = " ".join(parts[1:])
            if target.startswith("http://") or target.startswith("https://"):
                try:
                    u = urlsplit(target)
                    target = (u.path or "/") + (("?" + u.query) if u.query else "")
                except Exception:
                    pass
            self.path = target
            headers = {}
            while True:
                h = self.rfile.readline(65537)
                if not h or h in (b"\r\n", b"\n"):
                    break
                hs = h.decode("iso-8859-1", "replace")
                if ":" in hs:
                    k, v = hs.split(":", 1)
                    headers[k.strip().lower()] = v.strip()
            self.headers = headers
            if self.command == "OPTIONS":
                self.do_OPTIONS()
            elif self.command == "HEAD":
                self.do_HEAD()
            else:
                self.do_GET()
        except Exception:
            try:
                self.send_error(500, "Internal Server Error")
            except Exception:
                pass
        finally:
            try:
                self.proxy.release_handler_slot()
            except Exception:
                pass

    def do_GET(self):
        self.process_request()

    def do_HEAD(self):
        self.process_request()

    def do_OPTIONS(self):
        self.send_response(200)
        self.send_header('Access-Control-Allow-Origin', '*')
        self.send_header('Access-Control-Allow-Methods', 'GET, HEAD, OPTIONS')
        self.send_header('Access-Control-Allow-Headers', 'Range, Origin, Content-Type, Accept')
        self.send_header('Content-Length', '0')
        self.end_headers()

    def process_request(self):
        try:
            parsed = self.proxy.extract_url_from_path(self.path)
            url = parsed.get('url')
            playlist_original_url = parsed.get('playlist_url')
            if not url:
                html = """<html><body>
<h2>XC Pro Proxy Active</h2>
<p>Proxy funcionando na porta {}</p>
</body></html>""".format(get_active_port()).encode("utf-8")
                self.send_response(200)
                self.send_header('Content-Type', 'text/html; charset=utf-8')
                self.send_header('Content-Length', str(len(html)))
                self.end_headers()
                self.wfile.write(html)
                return
            headers = {}
            for key, value in self.headers.items():
                headers[key.lower()] = value
            self.proxy.handle_channel_stream(url, headers, self.wfile, getattr(self, 'connection', None), method=self.command, playlist_original_url=playlist_original_url)
        except Exception:
            try:
                self.send_error(500, "Internal Server Error")
            except Exception:
                pass

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

def make_redirect_handler(target_port):
    class RedirectHandler(socketserver.StreamRequestHandler):
        def handle(self):
            try:
                raw = self.rfile.readline(65537)
                if not raw:
                    return
                line = raw.decode("iso-8859-1", "replace").rstrip("\r\n")
                parts = line.split(" ")
                target = parts[1] if len(parts) >= 2 else "/"
                if target.startswith("http://") or target.startswith("https://"):
                    try:
                        u = urlsplit(target)
                        target = (u.path or "/") + (("?" + u.query) if u.query else "")
                    except Exception:
                        pass
                while True:
                    h = self.rfile.readline(65537)
                    if not h or h in (b"\r\n", b"\n"):
                        break
                location = "http://127.0.0.1:{}{}".format(target_port, target)
                resp = (
                    "HTTP/1.1 302 Found\r\n"
                    "Location: {}\r\n"
                    "Content-Length: 0\r\n"
                    "Connection: close\r\n\r\n"
                ).format(location).encode("utf-8")
                self.wfile.write(resp)
            except Exception:
                pass
    return RedirectHandler

class RedirectTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

class NoPortAvailableError(Exception):
    pass

class UnifiedServer:
    def __init__(self, ports=None):
        self.ports = list(ports) if ports else list(PROXY_PORT_POOL)
        self.port = None
        self.server = None
        self.running = False
        self.monitor = None
        self.redirect_servers = []

    def bind_with_rotation(self):
        remaining = list(self.ports)
        preferred = read_persisted_port()
        ordered = []
        if preferred in remaining:
            ordered.append(preferred)
            remaining.remove(preferred)
        random.shuffle(remaining)
        ordered.extend(remaining)
        last_err = None
        for p in ordered:
            try:
                server = ThreadedTCPServer(("127.0.0.1", p), ProxyHandler)
                return server, p
            except OSError as e:
                last_err = e
                continue
        raise NoPortAvailableError(
            "Nenhuma porta livre no pool de rotacao: {}".format(ordered)
        ) from last_err

    def start_backup_redirects(self):
        handler_cls = make_redirect_handler(self.port)
        for p in self.ports:
            if p == self.port:
                continue
            try:
                srv = RedirectTCPServer(("127.0.0.1", p), handler_cls)
                srv.timeout = 1
            except OSError:
                continue
            th = threading.Thread(target=self.serve_redirects, args=(srv,), daemon=True)
            th.start()
            self.redirect_servers.append((srv, th))

    def serve_redirects(self, srv):
        while self.running:
            try:
                srv.handle_request()
            except Exception:
                break

    def stop_backup_redirects(self):
        for srv, _th in self.redirect_servers:
            try:
                srv.server_close()
            except Exception:
                pass
        self.redirect_servers = []

    def start(self, monitor=None):
        self.monitor = monitor
        self.running = True
        try:
            self.server, self.port = self.bind_with_rotation()
            set_active_port(self.port)
            self.server.timeout = 1
            self.start_backup_redirects()
            ProxyHandler.proxy.start_maintenance()
            while self.running:
                if self.monitor and self.monitor.abortRequested():
                    break
                try:
                    self.server.handle_request()
                except OSError:
                    pass
                except Exception:
                    pass
        except NoPortAvailableError:
            pass
        except Exception:
            pass
        finally:
            self.stop()

    def stop(self):
        self.running = False
        self.stop_backup_redirects()
        try:
            if self.server:
                try:
                    self.server.server_close()
                except Exception:
                    pass
                self.server = None
        except Exception:
            pass

    def is_running(self):
        return self.running and self.server is not None
