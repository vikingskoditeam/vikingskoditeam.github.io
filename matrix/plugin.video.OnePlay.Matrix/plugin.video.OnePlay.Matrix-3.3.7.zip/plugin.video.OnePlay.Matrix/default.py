# -*- coding: utf-8 -*-
from __future__ import unicode_literals

# Inicialização local e rápida da Home do OnePlay Matrix.
# A Home não consulta catálogo, M3U, EPG, proxy, DNS nem player.

import os
import sys
from urllib.parse import parse_qsl, urlencode

try:
    from kodi_six import xbmc, xbmcplugin, xbmcgui, xbmcaddon, xbmcvfs
except ImportError:
    import xbmc
    import xbmcplugin
    import xbmcgui
    import xbmcaddon
    import xbmcvfs

ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON = xbmcaddon.Addon()
TRANSLATE = xbmcvfs.translatePath
HOME_DIR = TRANSLATE(ADDON.getAddonInfo('path'))
ADDON_ICON = os.path.join(HOME_DIR, 'icon.png')
ADDON_FANART = os.path.join(HOME_DIR, 'fanart.jpg')

WELCOME_LABEL = '[COLOR aquamarine]:::[/COLOR]BEM-VINDOS AO ONEPLAY[COLOR aquamarine]:::[/COLOR]'
ONEPLAY_DESC = '''
Para trabalhar em equipe precisamos ter empatia, transparência, solidariedade e muita lealdade, esses ingredientes são necessários para o sucesso em grupo.

[B][COLOR aquamarine]Repositório Oficial ONEPLAY[/COLOR][/B]
[COLOR blue]https://oneplayhd.github.io[/COLOR]

[B][COLOR aquamarine]Grupo Oficial FACEBOOK[/COLOR][/B]
[COLOR blue]https://tinyurl.com/oneplay2019[/COLOR]

[B][COLOR aquamarine]Grupo Oficial TELEGRAM[/COLOR][/B]
[COLOR blue]http://t.me/oneplay2019[/COLOR]
    '''


def _setting_text(key, default=''):
    try:
        value = ADDON.getSetting(key)
        return value if value not in (None, '') else default
    except Exception:
        return default


def _setting_bool(key, default=False):
    try:
        return str(_setting_text(key, 'true' if default else 'false')).lower() == 'true'
    except Exception:
        return default


def _build_url(query):
    return '{}?{}'.format(BASE_URL, urlencode(query or {}))


def _set_video_info(item, title='', plot=''):
    # API atual, com fallback seguro para builds Kodi mais antigas.
    try:
        tag = item.getVideoInfoTag()
    except Exception:
        tag = None
    if tag is not None:
        try:
            if title and hasattr(tag, 'setTitle'):
                tag.setTitle(str(title))
            if plot and hasattr(tag, 'setPlot'):
                tag.setPlot(str(plot))
        except Exception:
            pass
    else:
        try:
            item.setInfo('video', {'title': title, 'plot': plot, 'mediatype': 'video'})
        except Exception:
            pass
    try:
        item.setProperty('mediatype', 'video')
    except Exception:
        pass


def _skin_signature():
    skin_id = ''
    skin_theme = ''
    try:
        skin_id = xbmc.getSkinDir() or ''
    except Exception:
        pass
    try:
        skin_theme = xbmc.getInfoLabel('Skin.CurrentTheme') or ''
    except Exception:
        pass
    return '{}|{}'.format(skin_id, skin_theme).strip('|') or 'default'


def _apply_default_list_view(flag_key):
    """Aplica a lista padrão uma vez por skin durante a sessão atual.

    A marcação fica em uma propriedade global do Kodi, não no settings.xml do
    addon. Assim, abrir Filmes/Séries pela primeira vez não dispara
    onSettingsChanged() no service.py nem acorda a sincronização de DNS/EPG.
    O cache de diretório continua sob responsabilidade do Kodi via
    endOfDirectory(..., cacheToDisc=True).
    """
    signature = _skin_signature()
    property_name = 'OnePlayMatrix.ViewState.{}'.format(flag_key)
    window = None
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(property_name) == signature:
            return
    except Exception:
        window = None

    try:
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        return

    # Mantido apenas na primeira entrada de cada área/skin da sessão. Nas
    # voltas pelo histórico, o Kodi usa a lista cacheada sem nova espera.
    try:
        xbmc.sleep(40)
        xbmc.executebuiltin('Container.SetViewMode(50)')
    except Exception:
        pass

    if window is not None:
        try:
            window.setProperty(property_name, signature)
        except Exception:
            pass


def _end_local_directory(content, view_flag):
    """Fecha diretórios inteiramente locais com cache de navegação do Kodi."""
    try:
        xbmcplugin.setContent(ADDON_HANDLE, content)
    except Exception:
        pass
    try:
        # Filmes/Séries e Home não dependem de resposta remota. Persistir
        # a lista permite ao Kodi reutilizar o histórico sem revalidar nada.
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True, updateListing=False, cacheToDisc=True)
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=True)
        except Exception:
            pass
    except Exception:
        pass
    _apply_default_list_view(view_flag)


def _vip_description():
    return '''[B][COLOR aquamarine]OFICIAL[/COLOR] [COLOR white]Kodi e Android[/COLOR][/B]

Ao entrar no [COLOR aquamarine]VIP[/COLOR], será exibido um [COLOR aquamarine]QR Code[/COLOR] com o WhatsApp de atendimento e os valores dos planos.
Escolha o plano desejado e entre em contato para realizar a contratação.

Depois, confirme em [COLOR aquamarine]OK[/COLOR] e selecione o [COLOR aquamarine]Servidor[/COLOR] informado.
Digite seu [COLOR aquamarine]usuário[/COLOR] e confirme.
Em seguida, digite sua [COLOR aquamarine]senha[/COLOR] e confirme novamente.

Após a validação, os conteúdos VIP serão liberados.

Conexão recomendada: [COLOR gold]30 MB[/COLOR]'''


def home():
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    items = [
        ('Pesquisar', 'Buscar filmes e séries pelo nome do conteúdo.', TRANSLATE(os.path.join(image_dir, 'pesquisar.png')), {'action': 'search'}),
        ('TV ao vivo', 'Entrar nas listas e categorias de canais ao vivo.', TRANSLATE(os.path.join(image_dir, 'tv.png')), {'action': 'tv'}),
        ('Filmes', 'Explorar filmes em alta, top avaliados e lançamentos.', TRANSLATE(os.path.join(image_dir, 'filmes.png')), {'action': 'menu_movies'}),
        ('Séries', 'Explorar séries em alta, top avaliadas e lançamentos.', TRANSLATE(os.path.join(image_dir, 'series.png')), {'action': 'menu_series'}),
        ('Configurações', 'Abrir as configurações do addon OnePlay.', TRANSLATE(os.path.join(image_dir, 'configuracoes.png')), {'action': 'open_settings'}),
    ]

    if _setting_bool('mostrarboasvindas', True):
        items.insert(0, (WELCOME_LABEL, ONEPLAY_DESC, ADDON_ICON, {'action': 'donate'}))
    if _setting_bool('exibirvip', True):
        items.insert(1, ('VIP', _vip_description(), TRANSLATE(os.path.join(image_dir, 'vip.png')), {'action': ''}))

    for label, description, icon, query in items:
        url = 'plugin://plugin.video.oneplayvip/?origin=oneplay_matrix' if label == 'VIP' else _build_url(query)
        list_item = xbmcgui.ListItem(label)
        try:
            list_item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        except Exception:
            pass
        _set_video_info(list_item, title=label, plot=description)
        is_folder = label not in ('Configurações', WELCOME_LABEL)
        if not is_folder:
            try:
                list_item.setProperty('IsPlayable', 'false')
            except Exception:
                pass
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)

    _end_local_directory('movies', 'default_view_home_list_applied')


def _add_local_folder(label, description, icon_name, query):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, icon_name))
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
    except Exception:
        pass
    _set_video_info(item, title=label, plot=description)
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url(query),
        listitem=item,
        isFolder=True
    )


def _add_local_settings_item(plot):
    image_dir = os.path.join(HOME_DIR, 'resources', 'images')
    icon = TRANSLATE(os.path.join(image_dir, 'configuracoes.png'))
    label = 'Configurações'
    item = xbmcgui.ListItem(label)
    try:
        item.setArt({'icon': icon, 'thumb': icon, 'poster': icon, 'fanart': ADDON_FANART})
        item.setProperty('IsPlayable', 'false')
    except Exception:
        pass
    _set_video_info(item, title=label, plot=plot)
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=_build_url({'action': 'open_settings'}),
        listitem=item,
        isFolder=False
    )


def menu_movies_fast():
    """Menu local de Filmes; não importa routes.py, DNS ou catálogo."""
    items = (
        ('Filmes - Em Alta', 'Ver os filmes em tendência na semana.', {'action': 'list', 'type': 'movie', 'category': 'trending'}),
        ('Filmes - Top Avaliados', 'Ver os filmes mais bem avaliados.', {'action': 'list', 'type': 'movie', 'category': 'top'}),
        ('Filmes - Em Cartaz', 'Ver os filmes atualmente em cartaz conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'now_playing'}),
        ('Filmes - Próximos Lançamentos', 'Ver os próximos lançamentos de filmes conforme a região configurada.', {'action': 'list', 'type': 'movie', 'category': 'upcoming'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'filmes.png', query)
    if _setting_bool('pluto_exibir_filmes', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Filmes - Pluto TV',
            'Abrir os filmes sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_movies'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de filmes.')
    _end_local_directory('movies', 'default_view_movies_list_applied')


def menu_series_fast():
    """Menu local de Séries; não importa routes.py, DNS ou catálogo."""
    items = (
        ('Séries - Em Alta', 'Ver as séries em tendência na semana.', {'action': 'list', 'type': 'series', 'category': 'trending'}),
        ('Séries - Top Avaliadas', 'Ver as séries mais bem avaliadas.', {'action': 'list', 'type': 'series', 'category': 'top'}),
        ('Séries - No Ar', 'Ver séries com episódios em exibição nos próximos dias.', {'action': 'list', 'type': 'series', 'category': 'on_the_air'}),
        ('Séries - Estreias Recentes', 'Ver séries com estreia inicial recente.', {'action': 'list', 'type': 'series', 'category': 'recent_premieres'}),
    )
    for label, description, query in items:
        _add_local_folder(label, description, 'series.png', query)
    if _setting_bool('pluto_exibir_series', True):
        # A sessão Pluto é criada somente quando o usuário realmente abre Pluto.
        _add_local_folder(
            'Séries - Pluto TV',
            'Abrir as séries sob demanda do Pluto TV respeitando o país configurado em Pluto TV.',
            'pluto.png',
            {'action': 'pluto_series'}
        )
    _add_local_settings_item('Abrir as configurações do addon OnePlay a partir da área de séries.')
    _end_local_directory('tvshows', 'default_view_series_list_applied')


def _dispatch_to_routes(paramstring):
    # Importação tardia: apenas ações fora da Home precisam da implementação
    # completa (M3U, EPG, TMDB, Pluto, proxy, DNS e HTTP).
    from resources.lib import routes
    routes.router(paramstring)


def main():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith('?') else (sys.argv[2] if len(sys.argv) > 2 else '')
    params = dict(parse_qsl(paramstring, keep_blank_values=True))
    action = params.get('action')

    # Home, Filmes e Séries são diretórios puramente locais. Eles não devem
    # carregar o roteador, DNS, proxy, TMDB, Pluto ou requests.
    if action == 'menu_movies':
        menu_movies_fast()
        return
    if action == 'menu_series':
        menu_series_fast()
        return

    if action is None:
        start_page = _setting_text('paginainicial', '0')
        if start_page == '0':
            home()
            return
        if start_page == '2':
            menu_movies_fast()
            return
        if start_page == '3':
            menu_series_fast()
            return

    _dispatch_to_routes(paramstring)


if __name__ == '__main__':
    main()
