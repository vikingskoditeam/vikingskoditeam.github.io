# -*- coding: utf-8 -*-
"""XC Pro - rotas principais do addon Kodi.

Fluxo mantido conservador:
- Xtream Codes via player_api.php
- QR Code de pareamento usando skin XML
- Menus de canais, filmes, séries, busca, conta e troca de conta
- Playback resolvido por rota interna e proxy local persistente mantido pelo service.py
"""

import base64
import datetime
import json
import os
import re
import sys
import threading
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo('path'))


MENU_ICON_PATH = os.path.join(ADDON_PATH, 'resources', 'media', 'menu')


def menu_icon(filename):
    return os.path.join(MENU_ICON_PATH, filename)


def set_art_with_fallback(list_item, primary_icon=None, fallback_icon=None):
    icon = primary_icon or fallback_icon
    if not icon:
        return
    try:
        list_item.setArt({'icon': icon, 'thumb': icon})
    except Exception:
        pass


def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log('[XC Pro] {}'.format(msg), level)
    except Exception:
        pass


def get_int_setting(setting_id, default_value):
    try:
        value = ADDON.getSetting(setting_id)
        value = int(value) if value else int(default_value)
        if 1 <= value <= 65535:
            return value
    except Exception:
        pass
    return int(default_value)


PROXY_PORT = get_int_setting('proxy_port', 9097)
WEBSERVER_PORT = get_int_setting('webserver_port', 9099)


def get_profile_path():
    profile = ADDON.getAddonInfo('profile')
    try:
        profile = xbmcvfs.translatePath(profile)
    except Exception:
        pass
    try:
        if not xbmcvfs.exists(profile):
            xbmcvfs.mkdirs(profile)
    except Exception:
        try:
            if not os.path.exists(profile):
                os.makedirs(profile)
        except Exception:
            pass
    return profile


EPG_CACHE_FILE = os.path.join(get_profile_path(), 'epg_cache.json')
EPG_CACHE_DURATION = 86400
EPG_XML_FILE = os.path.join(get_profile_path(), 'epg_xmltv.xml')
EPG_XML_INDEX_FILE = os.path.join(get_profile_path(), 'epg_xmltv_index.json')
EPG_XML_META_FILE = os.path.join(get_profile_path(), 'epg_xmltv_meta.json')
EPG_XML_TTL = 86400
EPG_XML_INDEX_VERSION = 'xcpro_epg_xmltv_login_v4'
XC_EPG_COLOR = 'FF2C7AA9'
EPG_HEADER_COLOR = 'gold'


def normalize_host(host):
    host = (host or '').strip()
    if not host:
        return ''
    if not host.startswith(('http://', 'https://')):
        host = 'http://' + host
    try:
        parsed = urllib.parse.urlparse(host)
        if parsed.scheme and parsed.netloc:
            return '{}://{}'.format(parsed.scheme, parsed.netloc).rstrip('/')
    except Exception:
        pass
    return host.rstrip('/')


def get_credentials():
    host = normalize_host(ADDON.getSetting('host'))
    username = (ADDON.getSetting('username') or '').strip()
    password = (ADDON.getSetting('password') or '').strip()
    return host, username, password


def has_credentials():
    host, user, password = get_credentials()
    return bool(host and user and password)


def quote_path(value):
    return urllib.parse.quote(str(value or ''), safe='')


def clean_extension(ext, default='mp4'):
    ext = str(ext or default).strip().strip('.')
    if not ext:
        ext = default
    # Evita extensão com query acidental ou caracteres indevidos.
    ext = ext.split('?', 1)[0].split('&', 1)[0].strip()
    if not ext:
        ext = default
    return ext


def build_stream_url(kind, stream_id, ext=None):
    host, user, password = get_credentials()
    if not host or not user or not password or not stream_id:
        return ''

    user_q = quote_path(user)
    pass_q = quote_path(password)
    stream_q = quote_path(stream_id)

    if kind == 'live':
        return '{}/live/{}/{}/{}.m3u8'.format(host, user_q, pass_q, stream_q)
    if kind == 'movie':
        return '{}/movie/{}/{}/{}.{}'.format(host, user_q, pass_q, stream_q, clean_extension(ext))
    if kind == 'series':
        return '{}/series/{}/{}/{}.{}'.format(host, user_q, pass_q, stream_q, clean_extension(ext))
    return ''


def build_proxy_url(native_url):
    if not native_url:
        return ''
    return 'http://127.0.0.1:{}/?url={}'.format(PROXY_PORT, urllib.parse.quote(native_url, safe=''))


def build_play_url(kind, stream_id, ext=None):
    return build_proxy_url(build_stream_url(kind, stream_id, ext))


def build_play_route(kind, stream_id, ext=None):
    if kind == 'live':
        return build_url({'mode': 'play_live', 'stream_id': stream_id})
    if kind == 'movie':
        return build_url({'mode': 'play_movie', 'stream_id': stream_id, 'ext': clean_extension(ext)})
    if kind == 'series':
        return build_url({'mode': 'play_series', 'stream_id': stream_id, 'ext': clean_extension(ext)})
    return ''


def resolve_playback(kind, stream_id, ext=None):
    url = build_play_url(kind, stream_id, ext)
    li = xbmcgui.ListItem(path=url)
    li.setProperty('IsPlayable', 'true')
    try:
        if kind == 'live':
            li.setMimeType('application/vnd.apple.mpegurl')
            li.setContentLookup(False)
            try:
                programs = get_epg_fast_for_stream({'stream_id': stream_id}, limit=4, xml_index=load_epg_xml_index(build_if_missing=False), allow_remote_fallback=True)
                current, nextp = epg_lookup_current_next(programs)
                plot = build_live_epg_plot(
                    current=current,
                    nextp=nextp,
                    include_desc=True,
                    show_now_next=True,
                    now_next_color=XC_EPG_COLOR,
                )
                if plot:
                    li.setInfo('video', {'plot': plot})
            except Exception as exc:
                log('Erro ao aplicar EPG no player live {}: {}'.format(stream_id, exc), xbmc.LOGWARNING)
        else:
            li.setContentLookup(True)
    except Exception:
        pass
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, bool(url), li)


def safe_float(value):
    try:
        if value in (None, ''):
            return None
        return float(value)
    except Exception:
        return None


def safe_int(value):
    try:
        if value in (None, ''):
            return None
        return int(value)
    except Exception:
        return None


def decode_base64(text):
    if not text:
        return ''
    try:
        # Alguns Xtreams entregam title/desc base64, outros já entregam texto comum.
        decoded = base64.b64decode(str(text)).decode('utf-8')
        return decoded or str(text)
    except Exception:
        return str(text)


def color(text, color_name):
    if text is None:
        text = ''
    color_name = color_name or XC_EPG_COLOR
    return '[COLOR {0}]{1}[/COLOR]'.format(color_name, text)


def clean_text_value(value):
    if value in (None, ''):
        return ''
    try:
        if isinstance(value, (list, tuple)):
            value = ', '.join([str(v).strip() for v in value if str(v).strip()])
        elif isinstance(value, dict):
            value = value.get('name') or value.get('title') or ''
        value = decode_base64(value).strip()
        if value.lower() in ('none', 'null', 'n/a', 'na', 'sem informação', 'sem informacao'):
            return ''
        return value
    except Exception:
        return ''


def first_text(data, *keys):
    if not isinstance(data, dict):
        return ''
    for key in keys:
        value = clean_text_value(data.get(key))
        if value:
            return value
    return ''


def extract_year_from_text(value):
    value = clean_text_value(value)
    if not value:
        return None
    try:
        match = re.search(r'(19|20)\d{2}', value)
        if match:
            return int(match.group(0))
    except Exception:
        pass
    return None


def build_vod_video_info(item, media_type='movie'):
    info = {}
    if not isinstance(item, dict):
        return info

    title = first_text(item, 'name', 'title')
    if title:
        info['title'] = title

    plot = first_text(item, 'plot', 'description', 'desc', 'overview', 'short_description', 'storyline')
    if plot:
        info['plot'] = plot

    genre = first_text(item, 'genre', 'genres', 'category_name')
    if genre:
        info['genre'] = genre

    director = first_text(item, 'director')
    if director:
        info['director'] = director

    # Campos como cast/duration variam muito entre servidores Xtream e podem quebrar
    # xbmcgui.ListItem.setInfo em algumas versões/skins quando chegam como string.
    # Para produção conservadora, mantemos a sinopse e metadados estáveis.
    duration = safe_int(item.get('duration_secs') or item.get('duration_seconds'))
    if duration is not None:
        info['duration'] = duration

    rating = safe_float(item.get('rating') or item.get('rating_5based') or item.get('vote_average'))
    if rating is not None:
        info['rating'] = rating

    released = first_text(item, 'releaseDate', 'releasedate', 'release_date', 'premiered', 'aired')
    if released:
        info['premiered'] = released
        info['aired'] = released

    year = safe_int(item.get('year')) or extract_year_from_text(released)
    if year is not None:
        info['year'] = year

    if media_type:
        info['mediatype'] = media_type

    return info


def sanitize_video_info(info):
    if not isinstance(info, dict):
        return {}
    clean = {}
    text_keys = ('title', 'plot', 'genre', 'director', 'premiered', 'aired', 'mediatype')
    for key in text_keys:
        value = info.get(key)
        if value not in (None, ''):
            clean[key] = str(value)
    if info.get('rating') is not None:
        rating = safe_float(info.get('rating'))
        if rating is not None:
            clean['rating'] = rating
    if info.get('year') is not None:
        year = safe_int(info.get('year'))
        if year is not None:
            clean['year'] = year
    if info.get('duration') is not None:
        duration = safe_int(info.get('duration'))
        if duration is not None:
            clean['duration'] = duration
    return clean


def safe_set_video_info(list_item, info):
    info = sanitize_video_info(info)
    if not info:
        return
    try:
        list_item.setInfo('video', info)
    except Exception as exc:
        log('Falha ao aplicar metadados de vídeo: {}'.format(exc), xbmc.LOGWARNING)
        # Fallback mínimo: sinopse/título são os campos que interessam para VOD/Séries.
        fallback = {}
        if info.get('title'):
            fallback['title'] = info.get('title')
        if info.get('plot'):
            fallback['plot'] = info.get('plot')
        if fallback:
            try:
                list_item.setInfo('video', fallback)
            except Exception:
                pass


def enrich_vod_art(list_item, item, fallback_icon):
    if not isinstance(item, dict):
        set_art_with_fallback(list_item, fallback_icon=fallback_icon)
        return
    icon = (
        item.get('stream_icon') or item.get('cover') or item.get('cover_big') or
        item.get('movie_image') or item.get('poster') or item.get('image')
    )
    set_art_with_fallback(list_item, icon, fallback_icon)
    try:
        fanart = item.get('fanart') or item.get('backdrop') or item.get('backdrop_path')
        if isinstance(fanart, (list, tuple)):
            fanart = fanart[0] if fanart else ''
        if fanart:
            list_item.setArt({'fanart': str(fanart)})
    except Exception:
        pass


def build_url(query):
    return BASE_URL + '?' + urllib.parse.urlencode(query)


def end_directory(succeeded=True):
    try:
        xbmcplugin.endOfDirectory(ADDON_HANDLE, succeeded=succeeded)
    except TypeError:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
    except Exception:
        pass


def notify(title, message, level=xbmcgui.NOTIFICATION_INFO, duration=3000):
    try:
        xbmcgui.Dialog().notification(title, message, level, duration)
    except Exception:
        pass


def get_browser_headers(host=None):
    """Cabeçalhos conservadores para evitar bloqueio 403 em servidores/WAF sensíveis."""
    origin = ''
    try:
        parsed = urllib.parse.urlparse(host or '')
        if parsed.scheme and parsed.netloc:
            origin = '{}://{}'.format(parsed.scheme, parsed.netloc)
    except Exception:
        origin = ''

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
        'Accept': 'application/json,text/plain,*/*',
        'Accept-Language': 'pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7',
        'Connection': 'close',
    }
    if origin:
        headers['Origin'] = origin
        headers['Referer'] = origin + '/'
    return headers


# -----------------------------------------------------------------------------
# API Xtream Codes
# -----------------------------------------------------------------------------


def fetch_api(action=None, extra_params=None, timeout=10):
    host, user, password = get_credentials()
    if not host or not user or not password:
        return None

    params = {
        'username': user,
        'password': password,
    }
    if action:
        params['action'] = action
    if extra_params:
        params.update(extra_params)

    url = '{}/player_api.php?{}'.format(host, urllib.parse.urlencode(params))

    try:
        response = requests.get(url, timeout=timeout, headers=get_browser_headers(host), allow_redirects=True)
        if response.status_code != 200:
            log('Resposta API HTTP {} em {}'.format(response.status_code, action or 'account'), xbmc.LOGWARNING)
            return None
        return response.json()
    except Exception as exc:
        log('Erro de requisição na API ({}): {}'.format(action or 'account', exc), xbmc.LOGERROR)
        return None


# -----------------------------------------------------------------------------
# EPG XMLTV diário / cache local
# -----------------------------------------------------------------------------


_EPG_XML_INDEX_MEMORY = None
_EPG_XML_INDEX_MEMORY_TS = 0


def safe_read_json(path, default=None):
    try:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as file_obj:
                data = json.load(file_obj)
                return data
    except Exception as exc:
        log('Falha ao ler JSON {}: {}'.format(path, exc), xbmc.LOGWARNING)
    return {} if default is None else default


def safe_write_json(path, data):
    try:
        with open(path, 'w', encoding='utf-8') as file_obj:
            json.dump(data or {}, file_obj, ensure_ascii=False)
        return True
    except Exception as exc:
        log('Falha ao salvar JSON {}: {}'.format(path, exc), xbmc.LOGWARNING)
    return False


def normalize_epg_channel_id(value):
    value = str(value or '').strip()
    if not value:
        return ''
    # Normalização conservadora: minúsculas e sem espaços nas pontas.
    return value.lower()


def extract_xml_text(element, child_name):
    if element is None:
        return ''
    try:
        child = element.find(child_name)
        if child is not None and child.text:
            return child.text.strip()
    except Exception:
        pass
    # fallback para XML com namespace
    try:
        for child in list(element):
            tag = str(child.tag or '').split('}', 1)[-1]
            if tag == child_name and child.text:
                return child.text.strip()
    except Exception:
        pass
    return ''


def parse_xmltv_time(value):
    value = str(value or '').strip()
    if not value:
        return 0
    # Exemplos XMLTV:
    # 20260607190000 -0300
    # 20260607190000 +0000
    # 2026-06-07T19:00:00Z
    try:
        main = value.split(' ', 1)[0].strip()
        tz = value.split(' ', 1)[1].strip() if ' ' in value else ''
        if len(main) >= 14 and main[:14].isdigit():
            dt = datetime.datetime.strptime(main[:14], '%Y%m%d%H%M%S')
            if tz and len(tz) >= 5 and (tz[0] in '+-') and tz[1:5].isdigit():
                sign = 1 if tz[0] == '+' else -1
                offset = sign * (int(tz[1:3]) * 3600 + int(tz[3:5]) * 60)
                return int(dt.replace(tzinfo=datetime.timezone(datetime.timedelta(seconds=offset))).timestamp())
            return int(time.mktime(dt.timetuple()))
        if 'T' in value:
            return int(datetime.datetime.fromisoformat(value.replace('Z', '+00:00')).timestamp())
    except Exception:
        return 0
    return 0


def build_epg_xml_urls():
    host, user, password = get_credentials()
    if not host or not user or not password:
        return []
    params = urllib.parse.urlencode({'username': user, 'password': password})
    return [
        ('xmltv.php', '{}/xmltv.php?{}'.format(host, params)),
        ('epg.php', '{}/epg.php?{}'.format(host, params)),
    ]


def build_epg_xml_url():
    urls = build_epg_xml_urls()
    return urls[0][1] if urls else ''


def epg_meta_fingerprint():
    host, user, password = get_credentials()
    return '{}|{}|{}'.format(host, user, password)


def clear_epg_runtime_memory():
    global _EPG_XML_INDEX_MEMORY, _EPG_XML_INDEX_MEMORY_TS
    _EPG_XML_INDEX_MEMORY = None
    _EPG_XML_INDEX_MEMORY_TS = 0


def clear_epg_xml_cache(reason=''):
    clear_epg_runtime_memory()
    for path in (EPG_XML_FILE, EPG_XML_INDEX_FILE, EPG_XML_META_FILE, EPG_CACHE_FILE):
        try:
            if path and os.path.exists(path):
                os.remove(path)
        except Exception as exc:
            log('Falha ao limpar cache EPG {}: {}'.format(path, exc), xbmc.LOGWARNING)
    if reason:
        log('Cache EPG limpo: {}'.format(reason), xbmc.LOGINFO)


def epg_cache_belongs_to_current_login():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    return bool(meta.get('fingerprint') == epg_meta_fingerprint())


def ensure_epg_cache_login_scope():
    if not has_credentials():
        return False
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta and meta.get('fingerprint') != epg_meta_fingerprint():
        clear_epg_xml_cache('login/servidor alterado')
        return False
    return True


def epg_xml_file_is_fresh():
    meta = safe_read_json(EPG_XML_META_FILE, {})
    if meta.get('fingerprint') != epg_meta_fingerprint():
        return False
    fetched_at = int(meta.get('fetched_at') or 0)
    if not fetched_at or (time.time() - fetched_at) >= EPG_XML_TTL:
        return False
    try:
        return os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128
    except Exception:
        return False


def download_epg_xml_if_needed(force=False):
    # Se trocou login/servidor, nunca reaproveita XML antigo.
    ensure_epg_cache_login_scope()

    if not force and epg_xml_file_is_fresh():
        return True

    urls = build_epg_xml_urls()
    if not urls:
        return False

    current_fp = epg_meta_fingerprint()
    had_current_xml = epg_cache_belongs_to_current_login() and os.path.exists(EPG_XML_FILE)
    last_error = ''

    for label, url in urls:
        try:
            response = requests.get(url, timeout=45, headers=get_browser_headers(get_credentials()[0]), allow_redirects=True)
            if response.status_code != 200 or not response.content:
                last_error = 'HTTP {} em {}'.format(response.status_code, label)
                log('EPG XML não baixado: {}'.format(last_error), xbmc.LOGWARNING)
                continue

            content = response.content
            sample = content[:512].lower()
            if b'<tv' not in sample and b'<xmltv' not in sample and b'<epg' not in sample:
                last_error = '{} não parece XMLTV'.format(label)
                log('EPG XML rejeitado: {}'.format(last_error), xbmc.LOGWARNING)
                continue

            tmp_path = EPG_XML_FILE + '.tmp'
            with open(tmp_path, 'wb') as file_obj:
                file_obj.write(content)
            try:
                if os.path.exists(EPG_XML_FILE):
                    os.remove(EPG_XML_FILE)
            except Exception:
                pass
            os.rename(tmp_path, EPG_XML_FILE)

            safe_write_json(EPG_XML_META_FILE, {
                'fingerprint': current_fp,
                'fetched_at': int(time.time()),
                'size': len(content),
                'source': label,
            })

            try:
                if os.path.exists(EPG_XML_INDEX_FILE):
                    os.remove(EPG_XML_INDEX_FILE)
            except Exception:
                pass
            clear_epg_runtime_memory()
            log('EPG XMLTV salvo para o login atual via {}: {} bytes'.format(label, len(content)))
            return True
        except Exception as exc:
            last_error = '{}: {}'.format(label, exc)
            log('Falha ao baixar EPG XML em {}: {}'.format(label, exc), xbmc.LOGWARNING)

    if last_error:
        log('Falha geral ao baixar XMLTV: {}'.format(last_error), xbmc.LOGWARNING)
    return bool(had_current_xml and os.path.exists(EPG_XML_FILE) and os.path.getsize(EPG_XML_FILE) > 128)


def epg_index_is_fresh(index):
    if not isinstance(index, dict):
        return False
    if index.get('version') != EPG_XML_INDEX_VERSION:
        return False
    if index.get('fingerprint') != epg_meta_fingerprint():
        return False
    generated_at = int(index.get('generated_at') or 0)
    if not generated_at or (time.time() - generated_at) >= EPG_XML_TTL:
        return False

    channels = index.get('channels')
    if not isinstance(channels, dict) or not channels:
        return False

    now_ts = int(time.time())
    window_start = int(index.get('window_start') or 0)
    window_end = int(index.get('window_end') or 0)
    if window_start and now_ts < window_start:
        return False
    if window_end and now_ts > window_end:
        return False

    return True


def build_epg_xml_index():
    if not download_epg_xml_if_needed(False):
        return {}

    if not os.path.exists(EPG_XML_FILE):
        return {}

    now_ts = int(time.time())
    # janela de hoje + uma margem curta para madrugada/próximo dia
    start_day = datetime.datetime.fromtimestamp(now_ts).replace(hour=0, minute=0, second=0, microsecond=0)
    window_start = int(start_day.timestamp()) - 3600
    window_end = int((start_day + datetime.timedelta(days=2)).timestamp()) + 3600

    channels = {}
    count = 0
    try:
        for event, elem in ET.iterparse(EPG_XML_FILE, events=('end',)):
            tag = str(elem.tag or '').split('}', 1)[-1]
            if tag != 'programme':
                # evita crescimento de memória em XML grande sem apagar filhos antes do programme fechar
                if tag not in ('title', 'desc'):
                    try:
                        elem.clear()
                    except Exception:
                        pass
                continue

            cid = normalize_epg_channel_id(elem.get('channel'))
            start = parse_xmltv_time(elem.get('start'))
            end = parse_xmltv_time(elem.get('stop') or elem.get('end'))
            if start <= 0:
                try:
                    elem.clear()
                except Exception:
                    pass
                continue
            if end <= start:
                end = start + 3600

            # guarda somente janela útil para as telas do Kodi
            if end < window_start or start > window_end:
                try:
                    elem.clear()
                except Exception:
                    pass
                continue

            title = extract_xml_text(elem, 'title')
            desc = extract_xml_text(elem, 'desc')
            if cid and title:
                channels.setdefault(cid, []).append({
                    'start': start,
                    'end': end,
                    'title': title,
                    'desc': desc,
                })
                count += 1

            try:
                elem.clear()
            except Exception:
                pass

        for cid in list(channels.keys()):
            channels[cid].sort(key=lambda item: item.get('start') or 0)

        index = {
            'version': EPG_XML_INDEX_VERSION,
            'fingerprint': epg_meta_fingerprint(),
            'generated_at': int(time.time()),
            'window_start': window_start,
            'window_end': window_end,
            'channels': channels,
        }
        safe_write_json(EPG_XML_INDEX_FILE, index)
        log('Índice EPG XML criado: canais={}, programas={}'.format(len(channels), count))
        return index
    except Exception as exc:
        log('Falha ao criar índice EPG XML: {}'.format(exc), xbmc.LOGWARNING)
        return {}


def load_epg_xml_index(build_if_missing=False):
    global _EPG_XML_INDEX_MEMORY, _EPG_XML_INDEX_MEMORY_TS

    ensure_epg_cache_login_scope()

    now = time.time()
    if epg_index_is_fresh(_EPG_XML_INDEX_MEMORY) and (now - _EPG_XML_INDEX_MEMORY_TS) < 300:
        return _EPG_XML_INDEX_MEMORY

    index = safe_read_json(EPG_XML_INDEX_FILE, {})
    if not epg_index_is_fresh(index) and build_if_missing:
        index = build_epg_xml_index()

    if epg_index_is_fresh(index):
        _EPG_XML_INDEX_MEMORY = index
        _EPG_XML_INDEX_MEMORY_TS = now
        return index

    return {}


def epg_programs_from_xml_index(index, epg_channel_id, limit=12):
    cid = normalize_epg_channel_id(epg_channel_id)
    if not cid or not isinstance(index, dict):
        return []
    channels = index.get('channels') if isinstance(index.get('channels'), dict) else {}
    programs = channels.get(cid) or []
    if not programs:
        # fallback leve: alguns provedores alteram caixa ou prefixos
        for key, value in channels.items():
            if key == cid or key.endswith(cid) or cid.endswith(key):
                programs = value or []
                break

    now_ts = int(time.time())
    out = []
    for program in programs:
        try:
            end = int(program.get('end') or 0)
            start = int(program.get('start') or 0)
        except Exception:
            continue
        if end and end < now_ts - 300:
            continue
        out.append(program)
        if len(out) >= int(limit or 12):
            break
    return out


def get_epg_fast_for_stream(item, limit=12, xml_index=None, allow_remote_fallback=True):
    """EPG rápido: tenta XMLTV local diário; fallback remoto só quando necessário."""
    if not isinstance(item, dict):
        return []
    epg_channel_id = item.get('epg_channel_id') or item.get('epg_id') or item.get('channel_id')
    if epg_channel_id:
        programs = epg_programs_from_xml_index(xml_index or load_epg_xml_index(), epg_channel_id, limit=limit)
        if programs:
            return programs

    if not allow_remote_fallback:
        return []

    stream_id = item.get('stream_id')
    if stream_id is None:
        return []
    return normalize_epg_programs(get_epg(stream_id, limit=limit))


# -----------------------------------------------------------------------------
# QR Code / pareamento
# -----------------------------------------------------------------------------


def get_local_ip():
    import socket
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(('8.8.8.8', 80))
        return sock.getsockname()[0]
    except Exception:
        return '127.0.0.1'
    finally:
        try:
            sock.close()
        except Exception:
            pass


def build_pairing_qr_url(pairing_url, size=500):
    return 'https://api.qrserver.com/v1/create-qr-code/?size={0}x{0}&margin=20&data={1}'.format(
        int(size), urllib.parse.quote(pairing_url, safe='')
    )


def download_pairing_qr(pairing_url):
    qr_url = build_pairing_qr_url(pairing_url)
    qr_path = os.path.join(get_profile_path(), 'xcpro_pairing_qr.png')
    try:
        response = requests.get(qr_url, timeout=10)
        if response.status_code == 200 and response.content:
            with open(qr_path, 'wb') as file_obj:
                file_obj.write(response.content)
            return qr_path
        log('Falha ao baixar QR Code: HTTP {}'.format(response.status_code), xbmc.LOGWARNING)
    except Exception as exc:
        log('Erro ao baixar QR Code de pareamento: {}'.format(exc), xbmc.LOGWARNING)
    return None


class QRCodeDialog(xbmcgui.WindowXMLDialog):
    """Janela XML do QR Code usando resources/skins/Default/1080i/QRCodeDialog.xml."""

    qr_path = ''
    _watching = False

    def onInit(self):
        try:
            xbmcgui.Window(10000).clearProperty('xcpro_pairing_saved')
            if self.qr_path:
                self.getControl(1001).setImage(self.qr_path)
            self.setFocusId(1002)
            self._watching = True
            watcher = threading.Thread(target=self._watch_pairing_saved)
            watcher.daemon = True
            watcher.start()
        except Exception as exc:
            log('Erro ao preparar janela XML do QR Code: {}'.format(exc), xbmc.LOGWARNING)

    def _watch_pairing_saved(self):
        """Fecha a janela automaticamente quando o celular salva as credenciais."""
        try:
            while self._watching and not xbmc.Monitor().abortRequested():
                if xbmcgui.Window(10000).getProperty('xcpro_pairing_saved') == '1':
                    try:
                        xbmc.executebuiltin('Dialog.Close(all,true)')
                    except Exception:
                        pass
                    try:
                        self.close()
                    except Exception:
                        pass
                    break
                xbmc.sleep(500)
        except Exception:
            pass

    def close(self):
        self._watching = False
        try:
            xbmcgui.WindowXMLDialog.close(self)
        except Exception:
            pass

    def onClick(self, control_id):
        if control_id == 1002:
            self.close()

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            action_id = 0
        if action_id in (9, 10, 92):
            self.close()


def show_qr_skin_dialog(qr_path):
    if not qr_path:
        return False
    try:
        dialog = QRCodeDialog('QRCodeDialog.xml', ADDON_PATH, 'Default', '1080i')
        dialog.qr_path = qr_path
        dialog.doModal()
        del dialog
        return True
    except Exception as exc:
        log('Erro ao abrir janela XML do QR Code: {}'.format(exc), xbmc.LOGWARNING)
        return False


def show_pairing_instruction():
    pairing_url = 'http://{}:{}'.format(get_local_ip(), WEBSERVER_PORT)
    qr_url = build_pairing_qr_url(pairing_url)

    li_pair = xbmcgui.ListItem(label='[COLOR yellow]Configurar pelo celular (QR Code)[/COLOR]')
    # Ícone local/padrão no menu. O QR real só aparece dentro da janela de pareamento.
    li_pair.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=build_url({'mode': 'show_qr_dialog', 'pairing_url': pairing_url}),
        listitem=li_pair,
        isFolder=False,
    )

    li_manual = xbmcgui.ListItem(label='Configurar manualmente pelo Kodi')
    li_manual.setArt({'icon': menu_icon('settings.png'), 'thumb': menu_icon('settings.png')})
    xbmcplugin.addDirectoryItem(
        handle=ADDON_HANDLE,
        url=build_url({'mode': 'open_settings'}),
        listitem=li_manual,
        isFolder=False,
    )

    end_directory()


def show_qr_dialog(pairing_url=None, qr_url=None):
    pairing_url = pairing_url or 'http://{}:{}'.format(get_local_ip(), WEBSERVER_PORT)

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        qr_path = download_pairing_qr(pairing_url)
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if qr_path and show_qr_skin_dialog(qr_path):
        return

    xbmcgui.Dialog().ok(
        'Pareamento de Login - XC Pro',
        'Não foi possível abrir o QR Code agora.\n\n'
        'Acesse pelo navegador do celular:\n'
        '[B]{}[/B]'.format(pairing_url),
    )


# -----------------------------------------------------------------------------
# Menus
# -----------------------------------------------------------------------------


def show_main_menu():
    if not has_credentials():
        show_pairing_instruction()
        return

    items = [
        ('Canais Ao Vivo', 'live_categories', menu_icon('live.png'), True),
        ('Filmes (VOD)', 'movie_categories', menu_icon('movies.png'), True),
        ('Séries', 'series_categories', menu_icon('series.png'), True),
        ('Busca Global', 'search', menu_icon('search.png'), True),
        ('Minha Conta / Status', 'account_status', menu_icon('account.png'), False),
        ('Trocar Conta / Parear QR', 're_pair', menu_icon('settings.png'), False),
    ]

    for title, mode, icon, is_folder in items:
        li = xbmcgui.ListItem(label=title)
        set_art_with_fallback(li, fallback_icon=icon)
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': mode}),
            listitem=li,
            isFolder=is_folder,
        )

    end_directory()


def add_category_items(categories, mode, icon):
    count = 0
    for cat in categories or []:
        category_id = cat.get('category_id')
        category_name = cat.get('category_name') or 'Sem Nome'
        if category_id is None:
            continue
        li = xbmcgui.ListItem(label=category_name)
        set_art_with_fallback(li, fallback_icon=icon)
        xbmcplugin.addDirectoryItem(
            handle=ADDON_HANDLE,
            url=build_url({'mode': mode, 'category_id': category_id}),
            listitem=li,
            isFolder=True,
        )
        count += 1
    return count


def show_live_categories():
    categories = fetch_api('get_live_categories')
    if not add_category_items(categories, 'live_streams', menu_icon('live.png')):
        notify('Aviso', 'Nenhuma categoria de canais encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_movie_categories():
    categories = fetch_api('get_vod_categories')
    if not add_category_items(categories, 'movie_streams', menu_icon('movies.png')):
        notify('Aviso', 'Nenhuma categoria de filmes encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_categories():
    categories = fetch_api('get_series_categories')
    if not add_category_items(categories, 'series_list', menu_icon('series.png')):
        notify('Aviso', 'Nenhuma categoria de séries encontrada.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_live_streams(category_id):
    streams = fetch_api('get_live_streams', {'category_id': category_id})
    count = 0
    for item in streams or []:
        stream_id = item.get('stream_id')
        if stream_id is None:
            continue
        label = item.get('name') or 'Sem Nome'
        epg_title = item.get('epg_title') or ''
        if epg_title:
            label = '{} [COLOR gray]({})[/COLOR]'.format(label, decode_base64(epg_title))

        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, item.get('stream_icon'), menu_icon('live.png'))
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_play_route('live', stream_id), li, isFolder=False)
        count += 1

    if not count:
        notify('Aviso', 'Nenhum canal encontrado nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_movie_streams(category_id):
    streams = fetch_api('get_vod_streams', {'category_id': category_id})
    count = 0
    for item in streams or []:
        stream_id = item.get('stream_id')
        if stream_id is None:
            continue

        li = xbmcgui.ListItem(label=item.get('name') or 'Sem Nome')
        enrich_vod_art(li, item, menu_icon('movies.png'))

        info = build_vod_video_info(item, 'movie')
        if info:
            safe_set_video_info(li, info)

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_play_route('movie', stream_id, item.get('container_extension') or 'mp4'),
            li,
            isFolder=False,
        )
        count += 1

    if not count:
        notify('Aviso', 'Nenhum filme encontrado nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_list(category_id):
    series = fetch_api('get_series', {'category_id': category_id})
    count = 0
    for item in series or []:
        series_id = item.get('series_id')
        if series_id is None:
            continue

        li = xbmcgui.ListItem(label=item.get('name') or 'Sem Nome')
        enrich_vod_art(li, item, menu_icon('series.png'))

        info = build_vod_video_info(item, 'tvshow')
        if info:
            safe_set_video_info(li, info)

        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'series_info', 'series_id': series_id}),
            li,
            isFolder=True,
        )
        count += 1

    if not count:
        notify('Aviso', 'Nenhuma série encontrada nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_info(series_id):
    data = fetch_api('get_series_info', {'series_id': series_id})
    episodes = data.get('episodes') if isinstance(data, dict) else None
    if not episodes:
        notify('Aviso', 'Sem episódios disponíveis.', xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    def sort_key(value):
        try:
            return int(value)
        except Exception:
            return 0

    series_info = data.get('info') if isinstance(data.get('info'), dict) else {}
    series_plot = first_text(series_info, 'plot', 'description', 'desc', 'overview')

    count = 0
    for season_num in sorted(episodes.keys(), key=sort_key):
        label = 'Temporada {}'.format(season_num)
        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, series_info.get('cover') or series_info.get('cover_big'), menu_icon('series.png'))
        season_info = build_vod_video_info(series_info, 'season')
        if series_plot and 'plot' not in season_info:
            season_info['plot'] = series_plot
        if season_info:
            li.setInfo('video', season_info)
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'series_episodes', 'series_id': series_id, 'season_num': season_num}),
            li,
            isFolder=True,
        )
        count += 1

    if not count:
        notify('Aviso', 'Sem temporadas disponíveis.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def show_series_episodes(series_id, season_num):
    data = fetch_api('get_series_info', {'series_id': series_id})
    episodes = data.get('episodes') if isinstance(data, dict) else None
    eps = []
    if isinstance(episodes, dict):
        eps = episodes.get(str(season_num), []) or []

    count = 0
    for ep in eps:
        stream_id = ep.get('id')
        if stream_id is None:
            continue

        title = 'Episódio {} - {}'.format(ep.get('episode_num', 'X'), ep.get('title') or 'Sem Título')
        li = xbmcgui.ListItem(label=title)
        info = ep.get('info') if isinstance(ep.get('info'), dict) else {}
        thumb = info.get('movie_image') or info.get('cover_big') or info.get('cover')
        set_art_with_fallback(li, thumb, menu_icon('series.png'))
        if info:
            video_info = {}
            ep_plot = first_text(info, 'plot', 'description', 'desc', 'overview')
            if ep_plot:
                video_info['plot'] = ep_plot
            if info.get('rating'):
                rating = safe_float(info.get('rating'))
                if rating is not None:
                    video_info['rating'] = rating
            if video_info:
                safe_set_video_info(li, video_info)

        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_play_route('series', stream_id, ep.get('container_extension') or 'mp4'),
            li,
            isFolder=False,
        )
        count += 1

    if not count:
        notify('Aviso', 'Nenhum episódio encontrado.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


# -----------------------------------------------------------------------------
# Conta/configurações
# -----------------------------------------------------------------------------


def show_account_status():
    host, user, _ = get_credentials()
    data = fetch_api(None)
    dialog = xbmcgui.Dialog()

    if isinstance(data, dict):
        user_info = data.get('user_info') if isinstance(data.get('user_info'), dict) else {}
        status = user_info.get('status') or 'ONLINE'
        exp_date = user_info.get('exp_date')
        exp_label = ''
        if exp_date:
            try:
                exp_label = time.strftime('%d/%m/%Y %H:%M', time.localtime(int(exp_date)))
            except Exception:
                exp_label = str(exp_date)

        extra = ''
        if exp_label:
            extra += '\nVencimento: [B]{}[/B]'.format(exp_label)
        if user_info.get('active_cons') is not None and user_info.get('max_connections') is not None:
            extra += '\nConexões: [B]{}/{}[/B]'.format(user_info.get('active_cons'), user_info.get('max_connections'))

        dialog.ok(
            'XC Pro Status',
            'Conexão ativa e autenticada!\n\n'
            'Servidor: [B]{}[/B]\n'
            'Usuário: [B]{}[/B]\n'
            'Status: [COLOR green]{}[/COLOR]{}'.format(host, user, status, extra),
        )
    else:
        dialog.ok(
            'XC Pro Status',
            'Módulo offline ou credenciais incorretas.\n\n'
            'Servidor: {}\n'
            'Usuário: {}\n'
            'Status: [COLOR red]ERRO DE CONEXÃO[/COLOR]'.format(host, user),
        )


def open_settings():
    old_fingerprint = epg_meta_fingerprint()
    ADDON.openSettings()
    host, user, password = get_credentials()
    if host and ADDON.getSetting('host') != host:
        ADDON.setSetting('host', host)

    if old_fingerprint != epg_meta_fingerprint():
        clear_epg_xml_cache('configuração manual alterada')

    if host and user and password:
        account = fetch_api(timeout=8)
        if isinstance(account, dict) and account.get('user_info'):
            notify('XC Pro', 'Configuração manual validada.', xbmcgui.NOTIFICATION_INFO)
        else:
            notify('XC Pro', 'Dados salvos, mas o servidor não validou a conexão.', xbmcgui.NOTIFICATION_WARNING, 5000)
    xbmc.executebuiltin('Container.Refresh')


def clear_account_and_pair():
    if not xbmcgui.Dialog().yesno('XC Pro', 'Deseja limpar a conta atual e configurar novamente?'):
        return
    ADDON.setSetting('host', '')
    ADDON.setSetting('username', '')
    ADDON.setSetting('password', '')
    clear_epg_xml_cache('conta removida')
    notify('XC Pro', 'Conta removida. Abra o QR Code para parear novamente.', xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


# -----------------------------------------------------------------------------
# Busca global
# -----------------------------------------------------------------------------


def search_global():
    keyboard = xbmc.Keyboard('', 'Digite o termo para buscar')
    keyboard.doModal()

    if not keyboard.isConfirmed():
        end_directory()
        return

    search_term = keyboard.getText().lower().strip()
    if not search_term:
        end_directory()
        return

    results = []
    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        live_streams = fetch_api('get_live_streams')
        for stream in live_streams or []:
            name = stream.get('name') or ''
            if search_term in name.lower() and stream.get('stream_id') is not None:
                results.append({
                    'type': 'live',
                    'title': name,
                    'stream_id': stream.get('stream_id'),
                    'icon': stream.get('stream_icon', ''),
                })

        movies = fetch_api('get_vod_streams')
        for movie in movies or []:
            name = movie.get('name') or ''
            if search_term in name.lower() and movie.get('stream_id') is not None:
                results.append({
                    'type': 'movie',
                    'title': name,
                    'stream_id': movie.get('stream_id'),
                    'icon': movie.get('stream_icon', ''),
                    'ext': movie.get('container_extension') or 'mp4',
                    'info': build_vod_video_info(movie, 'movie'),
                })

        series_list = fetch_api('get_series')
        for serie in series_list or []:
            name = serie.get('name') or ''
            if search_term in name.lower() and serie.get('series_id') is not None:
                results.append({
                    'type': 'series',
                    'title': name,
                    'series_id': serie.get('series_id'),
                    'icon': serie.get('cover', ''),
                    'info': build_vod_video_info(serie, 'tvshow'),
                })
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not results:
        notify('Busca', "Nenhum resultado para '{}'".format(search_term), xbmcgui.NOTIFICATION_INFO)
        end_directory()
        return

    for result in results:
        result_type = result['type']
        if result_type == 'live':
            url = build_url({'mode': 'play_live', 'stream_id': result['stream_id']})
            li = xbmcgui.ListItem(label='[COLOR red]CANAL:[/COLOR] {}'.format(result['title']))
            is_folder = False
        elif result_type == 'movie':
            url = build_url({'mode': 'play_movie', 'stream_id': result['stream_id'], 'ext': result.get('ext') or 'mp4'})
            li = xbmcgui.ListItem(label='[COLOR blue]FILME:[/COLOR] {}'.format(result['title']))
            is_folder = False
        else:
            url = build_url({'mode': 'series_info', 'series_id': result['series_id']})
            li = xbmcgui.ListItem(label='[COLOR green]SÉRIE:[/COLOR] {}'.format(result['title']))
            is_folder = True

        fallback = menu_icon('live.png') if result_type == 'live' else (menu_icon('movies.png') if result_type == 'movie' else menu_icon('series.png'))
        set_art_with_fallback(li, result.get('icon'), fallback)
        if result.get('info'):
            try:
                safe_set_video_info(li, result.get('info'))
            except Exception:
                pass
        if not is_folder:
            li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(ADDON_HANDLE, url, li, isFolder=is_folder)

    end_directory()


# -----------------------------------------------------------------------------
# EPG
# -----------------------------------------------------------------------------


def get_epg(stream_id, limit=5):
    epg_cache = {}
    if os.path.exists(EPG_CACHE_FILE):
        try:
            with open(EPG_CACHE_FILE, 'r', encoding='utf-8') as file_obj:
                epg_cache = json.load(file_obj)
        except Exception:
            epg_cache = {}

    cache_key = 'epg_{}_{}'.format(stream_id, limit)
    current_time = time.time()

    cached = epg_cache.get(cache_key)
    if isinstance(cached, dict) and (current_time - cached.get('timestamp', 0)) < EPG_CACHE_DURATION:
        return cached.get('data') or []

    epg_data = None
    attempts = [
        ('get_short_epg', {'stream_id': stream_id, 'limit': limit}),
        ('get_simple_data_table', {'stream_id': stream_id}),
        ('get_epg_for_stream', {'stream_id': stream_id}),
    ]

    for action, params in attempts:
        epg_data = fetch_api(action, params)
        if epg_data:
            break

    processed_data = []
    if isinstance(epg_data, list):
        processed_data = epg_data
    elif isinstance(epg_data, dict):
        if isinstance(epg_data.get('epg_listings'), list):
            processed_data = epg_data.get('epg_listings')
        elif isinstance(epg_data.get('data'), list):
            processed_data = epg_data.get('data')
        else:
            for value in epg_data.values():
                if isinstance(value, list):
                    processed_data = value
                    break
            if not processed_data and epg_data:
                processed_data = [epg_data]

    if processed_data:
        epg_cache[cache_key] = {'timestamp': current_time, 'data': processed_data}
        if len(epg_cache) > 100:
            for old_key in sorted(epg_cache, key=lambda key: epg_cache[key].get('timestamp', 0))[:-100]:
                epg_cache.pop(old_key, None)
        try:
            with open(EPG_CACHE_FILE, 'w', encoding='utf-8') as file_obj:
                json.dump(epg_cache, file_obj)
        except Exception as exc:
            log('Erro ao salvar cache EPG: {}'.format(exc), xbmc.LOGWARNING)

    return processed_data


def extract_program_title(program):
    if not isinstance(program, dict):
        return ''
    title = program.get('title') or program.get('name') or program.get('event') or program.get('event_name') or ''
    return decode_base64(title).strip()


def extract_program_desc(program):
    if not isinstance(program, dict):
        return ''
    desc = program.get('description') or program.get('desc') or program.get('plot') or ''
    return decode_base64(desc).strip()


def normalize_epoch_seconds(value):
    if value in (None, ''):
        return 0
    try:
        if isinstance(value, (int, float)):
            return int(value)
        raw = str(value).strip()
        if not raw:
            return 0
        if raw.isdigit():
            return int(raw)

        # Formatos comuns: ISO, Xtream e XMLTV básico.
        cleaned = raw.replace('Z', '+00:00')
        try:
            return int(datetime.datetime.fromisoformat(cleaned).timestamp())
        except Exception:
            pass

        for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%Y%m%d%H%M%S'):
            try:
                return int(datetime.datetime.strptime(raw[:len(datetime.datetime.now().strftime(fmt))], fmt).timestamp())
            except Exception:
                continue

        # XMLTV às vezes vem como 20260607190000 +0000.
        compact = raw.split()[0]
        if compact.isdigit() and len(compact) >= 14:
            return int(datetime.datetime.strptime(compact[:14], '%Y%m%d%H%M%S').timestamp())
    except Exception:
        return 0
    return 0


def normalize_epg_program(program):
    if not isinstance(program, dict):
        return None
    title = extract_program_title(program)
    desc = extract_program_desc(program)
    start = normalize_epoch_seconds(
        program.get('start_timestamp') or program.get('start') or program.get('start_time') or program.get('start_date')
    )
    end = normalize_epoch_seconds(
        program.get('end_timestamp') or program.get('stop_timestamp') or program.get('end') or program.get('stop') or program.get('end_time')
    )
    if end <= start and start > 0:
        end = start + 3600
    return {
        'title': title,
        'desc': desc,
        'start': start,
        'end': end,
        'raw': program,
    }


def normalize_epg_programs(epg_data):
    programs = []
    for program in epg_data or []:
        normalized = normalize_epg_program(program)
        if normalized and (normalized.get('title') or normalized.get('desc') or normalized.get('start')):
            programs.append(normalized)
    programs.sort(key=lambda item: item.get('start') or 0)
    return programs


def epg_format_range(program):
    if not program:
        return ''
    start = int(program.get('start') or 0)
    end = int(program.get('end') or 0)
    if start <= 0:
        return ''
    if end <= start:
        end = start + 3600
    return '{} - {}'.format(
        datetime.datetime.fromtimestamp(start).strftime('%H:%M'),
        datetime.datetime.fromtimestamp(end).strftime('%H:%M'),
    )


def epg_lookup_current_next(programs):
    now = int(time.time())
    current = None
    nextp = None

    for index, program in enumerate(programs or []):
        start = int(program.get('start') or 0)
        end = int(program.get('end') or 0)
        if start and end and start <= now < end:
            current = program
            if index + 1 < len(programs):
                nextp = programs[index + 1]
            break
        if start and start > now:
            nextp = program
            if index - 1 >= 0:
                prev = programs[index - 1]
                prev_end = int(prev.get('end') or 0)
                if prev_end >= now:
                    current = prev
            break

    if not current and programs:
        # Alguns servidores entregam get_short_epg começando no programa atual sem timestamp útil.
        first = programs[0]
        if not first.get('start') or first.get('start') <= now:
            current = first
            if len(programs) > 1:
                nextp = programs[1]

    return current, nextp


def build_live_epg_plot(current=None, nextp=None, include_desc=True, day_schedule=None, compact=False, show_now_next=True, now_next_color=None, current_color=None, next_color=None, schedule_color=None, schedule_header_color=None, schedule_current_color=None):
    """Formato inspirado no OnePlayVIP, adaptado ao XC Pro sem transplantar o runtime pesado do EPG."""
    parts = []

    if current_color is None:
        current_color = now_next_color
    if next_color is None:
        next_color = now_next_color

    if show_now_next and current:
        current_title = str(current.get('title') or '').strip()
        current_desc = str(current.get('desc') or '').strip()
        current_range = epg_format_range(current)
        if current_range and current_title:
            current_line = 'Agora: {} | {}'.format(current_range, current_title)
        elif current_title:
            current_line = 'Agora: {}'.format(current_title)
        else:
            current_line = ''
        if current_line:
            parts.append(color(current_line, current_color or XC_EPG_COLOR))
        if include_desc and current_desc:
            parts.append(current_desc)

    if show_now_next and nextp:
        next_title = str(nextp.get('title') or '').strip()
        next_desc = str(nextp.get('desc') or '').strip()
        next_range = epg_format_range(nextp)
        if current and (next_title or (include_desc and next_desc)) and not compact:
            parts.append('')
        if next_range and next_title:
            next_line = 'Próximo: {} | {}'.format(next_range, next_title)
        elif next_title:
            next_line = 'Próximo: {}'.format(next_title)
        else:
            next_line = ''
        if next_line:
            parts.append(color(next_line, next_color or XC_EPG_COLOR))
        if include_desc and next_desc:
            parts.append(next_desc)

    schedule_lines = []
    now_ts = int(time.time())
    for program in day_schedule or []:
        title = str(program.get('title') or '').strip()
        when = epg_format_range(program)
        if when and title:
            line = '{} | {}'.format(when, title)
        elif title:
            line = title
        else:
            line = ''
        if not line:
            continue

        start = int(program.get('start') or 0)
        end = int(program.get('end') or 0)
        is_current = bool(start and (start <= now_ts < (end if end > start else start + 3600)))

        if is_current and schedule_current_color:
            schedule_lines.append(color(line, schedule_current_color))
        elif schedule_color:
            schedule_lines.append(color(line, schedule_color))
        else:
            schedule_lines.append(line)

    if schedule_lines:
        if parts and not compact:
            parts.append('')
        header = 'Grade do dia'
        if schedule_header_color:
            header = color(header, schedule_header_color)
        elif compact:
            header = color(header, EPG_HEADER_COLOR)
        parts.append(header)
        parts.extend(schedule_lines)

    return '\n'.join(parts).strip()


def show_live_streams_with_epg(category_id):
    streams = fetch_api('get_live_streams', {'category_id': category_id})
    if not streams:
        notify('Aviso', 'Nenhum canal encontrado.', xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    count = 0
    try:
        # Navegação rápida: categoria só lê o índice pronto.
        # O download/parse do XMLTV inteiro fica no service.py em background.
        xml_index = load_epg_xml_index(build_if_missing=False)
        allow_remote_fallback = False

        for item in streams:
            stream_id = item.get('stream_id')
            if stream_id is None:
                continue

            name = item.get('name') or 'Sem Nome'
            label = name
            programs = []
            current = None
            nextp = None
            try:
                programs = get_epg_fast_for_stream(
                    item,
                    limit=12,
                    xml_index=xml_index,
                    allow_remote_fallback=allow_remote_fallback,
                )
                current, nextp = epg_lookup_current_next(programs)
                current_title = str((current or {}).get('title') or '').strip()
                if current_title:
                    label = '{} - {}'.format(name, color(current_title, XC_EPG_COLOR))
            except Exception as exc:
                log('Erro ao aplicar EPG rápido no canal {}: {}'.format(item.get('name'), exc), xbmc.LOGWARNING)

            li = xbmcgui.ListItem(label=label)
            set_art_with_fallback(li, item.get('stream_icon'), menu_icon('live.png'))

            info_labels = {'title': name}
            plot = build_live_epg_plot(
                current=current,
                nextp=nextp,
                include_desc=False,
                day_schedule=programs,
                compact=True,
                show_now_next=False,
                schedule_current_color=XC_EPG_COLOR,
                schedule_header_color=EPG_HEADER_COLOR,
            )
            if plot:
                info_labels['plot'] = plot
            elif current:
                desc = current.get('desc') or ''
                if desc:
                    info_labels['plot'] = desc
            if current and current.get('title'):
                info_labels['tvshowtitle'] = current.get('title')
            if info_labels:
                li.setInfo('video', info_labels)

            li.setProperty('IsPlayable', 'true')
            full_epg_url = build_url({
                'mode': 'show_full_epg',
                'stream_id': stream_id,
                'stream_name': item.get('name') or 'Canal',
                'epg_channel_id': item.get('epg_channel_id') or '',
            })
            li.addContextMenuItems([
                ('Ver Programação Completa', 'Container.Update({})'.format(full_epg_url))
            ])
            xbmcplugin.addDirectoryItem(ADDON_HANDLE, build_play_route('live', stream_id), li, isFolder=False)
            count += 1
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not count:
        notify('Aviso', 'Nenhum canal disponível nesta categoria.', xbmcgui.NOTIFICATION_WARNING)
    end_directory()


def format_epg_time(start_time):
    ts = normalize_epoch_seconds(start_time)
    if ts:
        return datetime.datetime.fromtimestamp(ts).strftime('%H:%M')
    if not start_time:
        return ''
    try:
        value = str(start_time)
        if len(value) >= 5:
            return value[:5]
    except Exception:
        return ''
    return ''


def show_full_epg(stream_id, stream_name, epg_channel_id=None):
    """Lista a programação completa como uma pasta real do Kodi.

    Ajuste conservador:
    - usa o índice XMLTV salvo quando existir;
    - se o índice ainda não existir, tenta construir uma vez apenas nesta tela;
    - mantém fallback antigo por stream_id;
    - não usa RunPlugin, porque esta função monta diretório/listagem.
    """
    stream_name = stream_name or 'Canal'
    programs = []

    xbmc.executebuiltin('ActivateWindow(busydialognocancel)')
    try:
        if epg_channel_id:
            # Primeiro caminho: índice já pronto em background.
            index = load_epg_xml_index(build_if_missing=False)
            programs = epg_programs_from_xml_index(index, epg_channel_id, limit=48)

            # Se o usuário pediu programação completa e o índice ainda não existe,
            # tenta construir usando XMLTV local/atual. Isso não afeta abertura das categorias.
            if not programs:
                index = load_epg_xml_index(build_if_missing=True)
                programs = epg_programs_from_xml_index(index, epg_channel_id, limit=48)

        if not programs and stream_id:
            epg_data = get_epg(stream_id, limit=48)
            programs = normalize_epg_programs(epg_data)
    except Exception as exc:
        log('Erro ao carregar Programação Completa de {}: {}'.format(stream_name, exc), xbmc.LOGWARNING)
        programs = []
    finally:
        xbmc.executebuiltin('Dialog.Close(busydialognocancel)')

    if not programs:
        notify('EPG', 'Sem informação de programação para {}'.format(stream_name or 'este canal'), xbmcgui.NOTIFICATION_WARNING)
        end_directory()
        return

    try:
        xbmcplugin.setContent(ADDON_HANDLE, 'videos')
    except Exception:
        pass

    count = 0
    now_ts = int(time.time())
    for program in programs:
        if not isinstance(program, dict):
            continue

        title = str(program.get('title') or 'Sem título').strip() or 'Sem título'
        description = str(program.get('desc') or '').strip()
        formatted_time = epg_format_range(program) or format_epg_time(program.get('start'))
        label = '{} | {}'.format(formatted_time, title) if formatted_time else title

        try:
            start_int = int(program.get('start') or 0)
            end_int = int(program.get('end') or 0)
        except Exception:
            start_int, end_int = 0, 0

        is_current = bool(start_int and start_int <= now_ts < (end_int if end_int > start_int else start_int + 3600))
        if is_current:
            label = color(label, XC_EPG_COLOR)

        li = xbmcgui.ListItem(label=label)
        set_art_with_fallback(li, fallback_icon=menu_icon('live.png'))

        info = {
            'title': title,
            'tvshowtitle': stream_name,
        }
        if description:
            info['plot'] = description
        if start_int:
            info['aired'] = time.strftime('%Y-%m-%d', time.localtime(start_int))
        safe_set_video_info(li, info)

        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            ADDON_HANDLE,
            build_url({'mode': 'noop'}),
            li,
            isFolder=False
        )
        count += 1

    if not count:
        notify('EPG', 'Nenhum programa encontrado para {}'.format(stream_name or 'este canal'), xbmcgui.NOTIFICATION_WARNING)
    end_directory()


# -----------------------------------------------------------------------------
# Playback por rota da busca
# -----------------------------------------------------------------------------


def play_live_stream(stream_id):
    resolve_playback('live', stream_id)


def play_movie_stream(stream_id, ext='mp4'):
    resolve_playback('movie', stream_id, ext)


def play_series_stream(stream_id, ext='mp4'):
    resolve_playback('series', stream_id, ext)


# -----------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------


def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get('mode')

    if not mode:
        show_main_menu()
    elif mode == 'live_categories':
        show_live_categories()
    elif mode == 'live_streams':
        show_live_streams_with_epg(params.get('category_id'))
    elif mode == 'movie_categories':
        show_movie_categories()
    elif mode == 'movie_streams':
        show_movie_streams(params.get('category_id'))
    elif mode == 'series_categories':
        show_series_categories()
    elif mode == 'series_list':
        show_series_list(params.get('category_id'))
    elif mode == 'series_info':
        show_series_info(params.get('series_id'))
    elif mode == 'series_episodes':
        show_series_episodes(params.get('series_id'), params.get('season_num'))
    elif mode == 'account_status':
        show_account_status()
    elif mode == 'show_qr_dialog':
        show_qr_dialog(params.get('pairing_url'), params.get('qr_url'))
    elif mode == 'open_settings':
        open_settings()
    elif mode == 're_pair':
        clear_account_and_pair()
    elif mode == 'search':
        search_global()
    elif mode == 'show_full_epg':
        show_full_epg(params.get('stream_id'), params.get('stream_name'), params.get('epg_channel_id'))
    elif mode == 'noop':
        end_directory()
    elif mode == 'play_live':
        play_live_stream(params.get('stream_id'))
    elif mode == 'play_movie':
        play_movie_stream(params.get('stream_id'), params.get('ext') or 'mp4')
    elif mode == 'play_series':
        play_series_stream(params.get('stream_id'), params.get('ext') or 'mp4')
    else:
        log('Modo desconhecido: {}'.format(mode), xbmc.LOGWARNING)
        show_main_menu()


if __name__ == '__main__':
    main()
