# -*- coding: utf-8 -*-
"""Catálogo/resolvedor isolado da Opção 1 do OnePlay Live.

O único ponto fixo desta integração é a página pública de catálogo. Os canais
são descobertos estruturalmente nos dados serializados que o site publicar e
cada reprodução parte do ``href`` atual desse catálogo. Redirects, página de
player, slug, lista de CDN e manifesto HLS continuam dinâmicos e são validados
pelo motor homologado.

O player público atual declara ``CHANNEL_SLUG``, ``CDN_HOSTS`` e ``RAW_SRC`` no
próprio HTML. O resolvedor lê apenas esse subconjunto declarativo: não executa
JavaScript e nunca usa o CDN capturado em HAR como URL fixa.
"""
import ast
import json
import os
import re
import time
from html import unescape as html_unescape
from urllib.parse import urljoin
from urllib.request import Request

import xbmc
import xbmcaddon
import xbmcvfs

from .proxy import cloudflare_urlopen
from .source_contract import (
    is_safe_public_url, media_headers, page_headers,
)
from .storage import write_json_atomic

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
CATALOG_URL = 'https://embedcanais.online/'
MAX_HTML_BYTES = 768 * 1024
MAX_CACHE_BYTES = 512 * 1024
CACHE_TTL = 5 * 60
_CACHE_FILE = os.path.join(PROFILE, 'oneplay_live_option1_catalog.json')
_MEMO = None
_MEMO_DEADLINE = 0.0

# Equivalencias editoriais comprovadas entre os IDs publicados pela Opção 1
# e os IDs usados pelo EPG homologado da Opção 2. IDs iguais não precisam
# aparecer aqui: são consultados diretamente. Não há casamento fuzzy; canais
# sem correspondência real permanecem sem EPG.
_EPG_ID_ALIASES = {
    'aee': 'ae',
    'amazonprimevideo': 'primevideo',
    'amazonprimevideo02': 'primevideo2',
    'amazonprimevideo03': 'primevideo3',
    'amazonprimevideo04': 'primevideo4',
    'canaloff': 'off',
    'cazetv': 'caze1',
    'cazetv2': 'caze2',
    'cazetv3': 'caze3',
    'discoverytheater': 'discoverytheather',
    'disneyplus': 'disneyplus1',
    'disneyplus02': 'disneyplus2',
    'disneyplus03': 'disneyplus3',
    'globoplaynovelas': 'globonovelas',
    'max': 'max1',
    'max02': 'max2',
    'max03': 'max3',
    'paieterno': 'tvpaieterno',
    'paramountplus02': 'paramountplus2',
    'premiereclubes': 'premiere',
    'sportynet1': 'sportynetplus1',
    'sportynet2': 'sportynetplus2',
    'sportynet3': 'sportynetplus3',
    'tcaction': 'telecineaction',
    'tccult': 'telecinecult',
    'tcfun': 'telecinefun',
    'tcpipoca': 'telecinepipoca',
    'tcpremium': 'telecinepremium',
    'tctouch': 'telecinetouch',
    'tnt1': 'tnt',
    'tvaparecida': 'aparecida',
    'tvcultura': 'cultura',
    'warner': 'warnerchannel',
}


def epg_id_for(channel_id):
    """Retorna somente ID exato ou alias auditado; nunca usa fuzzy."""
    cid = str(channel_id or '').strip().lower()
    return _EPG_ID_ALIASES.get(cid, cid)


def _log(message, warning=False):
    xbmc.log('[ONEPLAY LIVE] OPCAO1 %s' % message,
             xbmc.LOGWARNING if warning else xbmc.LOGINFO)


def _balanced_fragment(text, start, opener='[', closer=']'):
    """Retorna um literal balanceado sem executar JavaScript."""
    if not isinstance(text, str) or start < 0 or start >= len(text) or text[start] != opener:
        return ''
    depth = 0
    quote = ''
    escaped = False
    limit = min(len(text), start + MAX_HTML_BYTES)
    for pos in range(start, limit):
        char = text[pos]
        if quote:
            if escaped:
                escaped = False
            elif char == '\\':
                escaped = True
            elif char == quote:
                quote = ''
            continue
        if char in ('"', "'"):
            quote = char
        elif char == opener:
            depth += 1
        elif char == closer:
            depth -= 1
            if depth == 0:
                return text[start:pos + 1]
    return ''


def _safe_literal(raw):
    """Aceita somente literais list/dict; nunca avalia chamadas/código."""
    raw = str(raw or '').strip()
    if not raw or len(raw) > MAX_HTML_BYTES:
        return None
    try:
        value = json.loads(raw)
    except Exception:
        try:
            value = ast.literal_eval(raw)
        except Exception:
            return None
    return value if isinstance(value, (list, dict)) else None


def _iframe_src(value, base_url):
    text = html_unescape(str(value or ''))
    match = re.search(r'<iframe\b[^>]*\bsrc\s*=\s*(["\'])(.*?)\1', text, re.I | re.S)
    if not match:
        return ''
    return urljoin(base_url, html_unescape(match.group(2).strip()))


def _row_public_url(raw, base_url):
    if not isinstance(raw, dict):
        return ''
    for key in ('href', 'url', 'api_url', 'source_page', 'player_url', 'embed_url'):
        value = str(raw.get(key) or '').strip()
        if value:
            value = urljoin(base_url, html_unescape(value))
            if is_safe_public_url(value):
                return value
    value = _iframe_src(raw.get('iframe') or raw.get('embed') or '', base_url)
    return value if is_safe_public_url(value) else ''


def _channel_row_score(rows, base_url):
    if not isinstance(rows, list) or not rows:
        return 0
    score = 0
    for raw in rows[:2000]:
        if not isinstance(raw, dict):
            continue
        slug = str(raw.get('slug') or raw.get('id') or '').strip().lower()
        name = str(raw.get('name') or raw.get('title') or raw.get('label') or '').strip()
        if slug and name and _row_public_url(raw, base_url):
            score += 1
    return score


def _walk_arrays(value):
    if isinstance(value, list):
        yield value
        for item in value:
            for child in _walk_arrays(item):
                yield child
    elif isinstance(value, dict):
        for item in value.values():
            for child in _walk_arrays(item):
                yield child


def _extract_channel_rows(text, base_url):
    """Descobre o maior catálogo público serializado na página.

    Não depende do nome ``CHANNELS``. Procura arrays literais publicados em
    scripts JS e blocos ``application/json`` e seleciona estruturalmente o
    conjunto que realmente contém canais com nome + id/slug + URL pública.
    """
    if not isinstance(text, str) or not text:
        raise ValueError('HTML vazio')

    candidates = []
    seen = set()

    # JSON explícito publicado no documento.
    for match in re.finditer(
            r'<script\b[^>]*\btype\s*=\s*(["\'])application/(?:ld\+)?json\1[^>]*>(.*?)</script>',
            text, re.I | re.S):
        value = _safe_literal(html_unescape(match.group(2)))
        if value is None:
            continue
        for rows in _walk_arrays(value):
            key = id(rows)
            if key not in seen:
                seen.add(key)
                candidates.append(rows)

    # Arrays literais atribuídos em JavaScript. O nome da variável é ignorado.
    assign_re = re.compile(
        r'(?:(?:const|let|var)\s+[A-Za-z_$][\w$]*|(?:window|self)\.[A-Za-z_$][\w$]*)\s*=\s*\[',
        re.I)
    for match in assign_re.finditer(text):
        start = text.find('[', match.start(), match.end() + 1)
        raw = _balanced_fragment(text, start, '[', ']')
        if not raw:
            continue
        rows = _safe_literal(raw)
        if isinstance(rows, list):
            candidates.append(rows)

    best = None
    best_score = 0
    for rows in candidates:
        score = _channel_row_score(rows, base_url)
        if score > best_score:
            best = rows
            best_score = score

    # Falha fechada: evita interpretar arrays auxiliares pequenos como catálogo.
    if best is None or best_score < 3:
        raise ValueError('catálogo público serializado não encontrado')
    return best


def _normalize(rows, base_url):
    out = []
    by_slug = {}
    category_order = []
    for raw in rows if isinstance(rows, list) else []:
        if not isinstance(raw, dict):
            continue
        slug = str(raw.get('slug') or raw.get('id') or '').strip().lower()
        name = str(raw.get('name') or raw.get('title') or raw.get('label') or '').strip()
        category = str(raw.get('category') or raw.get('group') or raw.get('genre') or 'Outros').strip() or 'Outros'
        raw_categories = raw.get('categories') if isinstance(raw.get('categories'), list) else [category]
        categories = []
        for value in raw_categories:
            value = str(value or '').strip()[:80]
            if value and value not in categories:
                categories.append(value)
                if value not in category_order:
                    category_order.append(value)
        if not categories:
            categories = [category[:80]]
            if categories[0] not in category_order:
                category_order.append(categories[0])
        category = categories[0]
        href = _row_public_url(raw, base_url)
        image = str(raw.get('image') or raw.get('logo') or raw.get('poster') or '').strip()
        image = urljoin(base_url, html_unescape(image)) if image else ''
        if not slug or not re.fullmatch(r'[a-z0-9_-]{1,96}', slug):
            continue
        if not name or not is_safe_public_url(href):
            continue
        if image and not is_safe_public_url(image):
            image = ''
        existing = by_slug.get(slug)
        if existing is not None:
            for value in categories:
                if value not in existing['categories']:
                    existing['categories'].append(value)
            continue
        item = {
            'id': slug,
            'epg_id': epg_id_for(slug),
            'name': name[:160],
            'categories': list(categories),
            'category': category,
            'description': str(raw.get('description') or '').strip()[:500],
            'image': image,
            'preview': '',
            'api_url': href,
            'source_page': href,
            'stream_url': '',
            'headers': {},
            '_catalog_url': base_url,
            '_contract_signature': href,
            '_oneplay_source': 'option1',
        }
        by_slug[slug] = item
        out.append(item)
    if len(out) < 3 or len(out) > 2000:
        raise ValueError('quantidade de canais fora do esperado: %d' % len(out))
    return out, category_order


def _fetch_live():
    # Ponto fixo único: página pública oficial. Todo o restante nasce do HTML
    # recebido naquele instante, inclusive eventual redirecionamento canônico.
    headers = page_headers(page_url=CATALOG_URL, parent_url=CATALOG_URL)
    headers['Sec-Fetch-Dest'] = 'document'
    headers['Sec-Fetch-Site'] = 'none'
    headers.pop('Referer', None)
    headers.pop('Origin', None)
    request = Request(CATALOG_URL, headers=headers, method='GET')
    with cloudflare_urlopen(request, timeout=10, allow_native_fallback=True) as response:
        data = response.read(MAX_HTML_BYTES + 1)
        if len(data) > MAX_HTML_BYTES:
            raise ValueError('HTML excedeu limite')
        text = data.decode('utf-8', 'ignore')
        final_catalog_url = str(getattr(response, 'url', CATALOG_URL) or CATALOG_URL)
    if not is_safe_public_url(final_catalog_url):
        final_catalog_url = CATALOG_URL
    rows = _extract_channel_rows(text, final_catalog_url)
    channels, category_order = _normalize(rows, final_catalog_url)
    return {
        'channels': channels,
        'category_order': category_order,
        'catalog_url': final_catalog_url,
        'fetched_at': int(time.time()),
    }


def _read_cache(fresh_only=False):
    try:
        if fresh_only and time.time() - os.path.getmtime(_CACHE_FILE) > CACHE_TTL:
            return None
        with open(_CACHE_FILE, 'rb') as fh:
            raw = fh.read(MAX_CACHE_BYTES + 1)
        if len(raw) > MAX_CACHE_BYTES:
            return None
        obj = json.loads(raw.decode('utf-8'))
        channels = obj.get('channels') if isinstance(obj, dict) else None
        if not isinstance(channels, list):
            return None
        # Revalida o cache com o mesmo contrato de segurança.
        normalized, category_order = _normalize(channels, str(obj.get('catalog_url') or CATALOG_URL))
        return {
            'channels': normalized,
            'category_order': list(obj.get('category_order') or category_order),
            'catalog_url': str(obj.get('catalog_url') or CATALOG_URL),
            'fetched_at': int(obj.get('fetched_at') or 0),
        }
    except Exception:
        return None


def _write_cache(payload):
    try:
        xbmcvfs.mkdirs(PROFILE)
        write_json_atomic(_CACHE_FILE, payload, MAX_CACHE_BYTES)
    except Exception as exc:
        _log('cache não pôde ser atualizado: %s' % exc, True)


def _payload(force=False):
    global _MEMO, _MEMO_DEADLINE
    now = time.monotonic()
    if not force and _MEMO is not None and now < _MEMO_DEADLINE:
        return _MEMO
    if not force:
        fresh = _read_cache(True)
        if fresh is not None:
            _MEMO = fresh
            _MEMO_DEADLINE = now + CACHE_TTL
            return fresh
    try:
        live = _fetch_live()
        _write_cache(live)
        _MEMO = live
        _MEMO_DEADLINE = now + CACHE_TTL
        _log('catálogo atualizado canais=%d' % len(live.get('channels') or []))
        return live
    except Exception as exc:
        _log('catálogo online indisponível: %s' % exc, True)
    stale = _read_cache(False)
    if stale is not None:
        _MEMO = stale
        _MEMO_DEADLINE = now + min(CACHE_TTL, 60)
        _log('usando cache anterior canais=%d' % len(stale.get('channels') or []), True)
        return stale
    _MEMO = {'channels': []}
    _MEMO_DEADLINE = now + 20
    return _MEMO


def source_for(channel):
    """Usa somente a URL que o site oficial publicou para o canal atual."""
    if not isinstance(channel, dict):
        return None
    url = str(channel.get('api_url') or channel.get('source_page') or '').strip()
    catalog_url = str(channel.get('_catalog_url') or CATALOG_URL).strip()
    if not is_safe_public_url(url):
        return None
    if not is_safe_public_url(catalog_url):
        catalog_url = CATALOG_URL

    page_h = page_headers(page_url=url, parent_url=catalog_url)
    # O próprio site abre o href dentro de um iframe; o Referer é derivado da
    # página pública atual, não de domínio/player codificado no addon.
    page_h['Referer'] = catalog_url
    resource_h = media_headers(page_url=url)
    return {
        'name': 'opcao1-public-site',
        'url': url,
        'playlist_headers': page_h,
        'resource_headers': resource_h,
        'allow_html_resolve': True,
        'allow_native_dns_fallback': True,
        'progressive_html_read': True,
        'preserve_navigation_referer': True,
        'public_site_only': True,
        'public_player_contract': True,
        'source_kind': 'public-site-page',
        # Segue no máximo dois documentos/iframes explicitamente publicados.
        # Não há host, CDN, slug ou endpoint de mídia codificado.
        'max_html_depth': 2,
    }


class Catalog:
    def __init__(self):
        payload = _payload(False) or {}
        self._channels = list(payload.get('channels') or [])
        self._category_order = list(payload.get('category_order') or [])
        self._catalog_url = str(payload.get('catalog_url') or CATALOG_URL)
        self._last_refresh_status = 'idle'

    def channels(self):
        return list(self._channels)

    def categories(self):
        present = []
        for channel in self._channels:
            for name in channel.get('categories') or [channel.get('category') or 'Outros']:
                name = str(name or '').strip()
                if name and name not in present:
                    present.append(name)
        ordered = [name for name in self._category_order if name in present]
        ordered.extend(name for name in present if name not in ordered)
        return ordered

    def category_description(self, category):
        category = str(category or '').strip()
        return 'Canais publicados atualmente pelo site na categoria %s.' % category if category else 'Canais publicados atualmente pelo site.'

    def by_category(self, category):
        return [c for c in self._channels if category in (c.get('categories') or [c.get('category')])]

    def get(self, channel_id):
        wanted = str(channel_id or '').strip().lower()
        for channel in self._channels:
            if str(channel.get('id') or '').strip().lower() == wanted:
                return channel
        return None

    def last_refresh_status(self):
        return self._last_refresh_status

    def refresh_get(self, channel_id):
        global _MEMO, _MEMO_DEADLINE
        try:
            live = _fetch_live()
            _write_cache(live)
            _MEMO = live
            _MEMO_DEADLINE = time.monotonic() + CACHE_TTL
            self._channels = list(live.get('channels') or [])
            self._category_order = list(live.get('category_order') or [])
            self._catalog_url = str(live.get('catalog_url') or CATALOG_URL)
            _log('catálogo forçado atualizado canais=%d' % len(self._channels))
            wanted = str(channel_id or '').strip().lower()
            for channel in self._channels:
                if str(channel.get('id') or '').strip().lower() == wanted:
                    self._last_refresh_status = 'ok'
                    return channel
            self._last_refresh_status = 'channel_removed'
            _log('canal não está mais no catálogo público id=%s' % channel_id, True)
            return None
        except Exception as exc:
            self._last_refresh_status = 'catalog_unavailable'
            _log('refresh live falhou id=%s: %s' % (channel_id, exc), True)
        return None

